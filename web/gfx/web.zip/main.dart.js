(function(){var supportsDirectProtoAccess=function(){var z=function(){}
z.prototype={p:{}}
var y=new z()
if(!(y.__proto__&&y.__proto__.p===z.prototype.p))return false
try{if(typeof navigator!="undefined"&&typeof navigator.userAgent=="string"&&navigator.userAgent.indexOf("Chrome/")>=0)return true
if(typeof version=="function"&&version.length==0){var x=version()
if(/^\d+\.\d+\.\d+\.\d+$/.test(x))return true}}catch(w){}return false}()
function map(a){a=Object.create(null)
a.x=0
delete a.x
return a}var A=map()
var B=map()
var C=map()
var D=map()
var E=map()
var F=map()
var G=map()
var H=map()
var J=map()
var K=map()
var L=map()
var M=map()
var N=map()
var O=map()
var P=map()
var Q=map()
var R=map()
var S=map()
var T=map()
var U=map()
var V=map()
var W=map()
var X=map()
var Y=map()
var Z=map()
function I(){}init()
function setupProgram(a,b){"use strict"
function generateAccessor(a9,b0,b1){var g=a9.split("-")
var f=g[0]
var e=f.length
var d=f.charCodeAt(e-1)
var c
if(g.length>1)c=true
else c=false
d=d>=60&&d<=64?d-59:d>=123&&d<=126?d-117:d>=37&&d<=43?d-27:0
if(d){var a0=d&3
var a1=d>>2
var a2=f=f.substring(0,e-1)
var a3=f.indexOf(":")
if(a3>0){a2=f.substring(0,a3)
f=f.substring(a3+1)}if(a0){var a4=a0&2?"r":""
var a5=a0&1?"this":"r"
var a6="return "+a5+"."+f
var a7=b1+".prototype.g"+a2+"="
var a8="function("+a4+"){"+a6+"}"
if(c)b0.push(a7+"$reflectable("+a8+");\n")
else b0.push(a7+a8+";\n")}if(a1){var a4=a1&2?"r,v":"v"
var a5=a1&1?"this":"r"
var a6=a5+"."+f+"=v"
var a7=b1+".prototype.s"+a2+"="
var a8="function("+a4+"){"+a6+"}"
if(c)b0.push(a7+"$reflectable("+a8+");\n")
else b0.push(a7+a8+";\n")}}return f}function defineClass(a2,a3){var g=[]
var f="function "+a2+"("
var e=""
var d=""
for(var c=0;c<a3.length;c++){if(c!=0)f+=", "
var a0=generateAccessor(a3[c],g,a2)
d+="'"+a0+"',"
var a1="p_"+a0
f+=a1
e+="this."+a0+" = "+a1+";\n"}if(supportsDirectProtoAccess)e+="this."+"$deferredAction"+"();"
f+=") {\n"+e+"}\n"
f+=a2+".builtin$cls=\""+a2+"\";\n"
f+="$desc=$collectedClasses."+a2+"[1];\n"
f+=a2+".prototype = $desc;\n"
if(typeof defineClass.name!="string")f+=a2+".name=\""+a2+"\";\n"
f+=a2+"."+"$__fields__"+"=["+d+"];\n"
f+=g.join("")
return f}init.createNewIsolate=function(){return new I()}
init.classIdExtractor=function(c){return c.constructor.name}
init.classFieldsExtractor=function(c){var g=c.constructor.$__fields__
if(!g)return[]
var f=[]
f.length=g.length
for(var e=0;e<g.length;e++)f[e]=c[g[e]]
return f}
init.instanceFromClassId=function(c){return new init.allClasses[c]()}
init.initializeEmptyInstance=function(c,d,e){init.allClasses[c].apply(d,e)
return d}
var z=supportsDirectProtoAccess?function(c,d){var g=c.prototype
g.__proto__=d.prototype
g.constructor=c
g["$is"+c.name]=c
return convertToFastObject(g)}:function(){function tmp(){}return function(a0,a1){tmp.prototype=a1.prototype
var g=new tmp()
convertToSlowObject(g)
var f=a0.prototype
var e=Object.keys(f)
for(var d=0;d<e.length;d++){var c=e[d]
g[c]=f[c]}g["$is"+a0.name]=a0
g.constructor=a0
a0.prototype=g
return g}}()
function finishClasses(a4){var g=init.allClasses
a4.combinedConstructorFunction+="return [\n"+a4.constructorsList.join(",\n  ")+"\n]"
var f=new Function("$collectedClasses",a4.combinedConstructorFunction)(a4.collected)
a4.combinedConstructorFunction=null
for(var e=0;e<f.length;e++){var d=f[e]
var c=d.name
var a0=a4.collected[c]
var a1=a0[0]
a0=a0[1]
g[c]=d
a1[c]=d}f=null
var a2=init.finishedClasses
function finishClass(c1){if(a2[c1])return
a2[c1]=true
var a5=a4.pending[c1]
if(a5&&a5.indexOf("+")>0){var a6=a5.split("+")
a5=a6[0]
var a7=a6[1]
finishClass(a7)
var a8=g[a7]
var a9=a8.prototype
var b0=g[c1].prototype
var b1=Object.keys(a9)
for(var b2=0;b2<b1.length;b2++){var b3=b1[b2]
if(!u.call(b0,b3))b0[b3]=a9[b3]}}if(!a5||typeof a5!="string"){var b4=g[c1]
var b5=b4.prototype
b5.constructor=b4
b5.$isb=b4
b5.$deferredAction=function(){}
return}finishClass(a5)
var b6=g[a5]
if(!b6)b6=existingIsolateProperties[a5]
var b4=g[c1]
var b5=z(b4,b6)
if(a9)b5.$deferredAction=mixinDeferredActionHelper(a9,b5)
if(Object.prototype.hasOwnProperty.call(b5,"%")){var b7=b5["%"].split(";")
if(b7[0]){var b8=b7[0].split("|")
for(var b2=0;b2<b8.length;b2++){init.interceptorsByTag[b8[b2]]=b4
init.leafTags[b8[b2]]=true}}if(b7[1]){b8=b7[1].split("|")
if(b7[2]){var b9=b7[2].split("|")
for(var b2=0;b2<b9.length;b2++){var c0=g[b9[b2]]
c0.$nativeSuperclassTag=b8[0]}}for(b2=0;b2<b8.length;b2++){init.interceptorsByTag[b8[b2]]=b4
init.leafTags[b8[b2]]=false}}b5.$deferredAction()}if(b5.$isi)b5.$deferredAction()}var a3=Object.keys(a4.pending)
for(var e=0;e<a3.length;e++)finishClass(a3[e])}function finishAddStubsHelper(){var g=this
while(!g.hasOwnProperty("$deferredAction"))g=g.__proto__
delete g.$deferredAction
var f=Object.keys(g)
for(var e=0;e<f.length;e++){var d=f[e]
var c=d.charCodeAt(0)
var a0
if(d!=="^"&&d!=="$reflectable"&&c!==43&&c!==42&&(a0=g[d])!=null&&a0.constructor===Array&&d!=="<>")addStubs(g,a0,d,false,[])}convertToFastObject(g)
g=g.__proto__
g.$deferredAction()}function mixinDeferredActionHelper(c,d){var g
if(d.hasOwnProperty("$deferredAction"))g=d.$deferredAction
return function foo(){if(!supportsDirectProtoAccess)return
var f=this
while(!f.hasOwnProperty("$deferredAction"))f=f.__proto__
if(g)f.$deferredAction=g
else{delete f.$deferredAction
convertToFastObject(f)}c.$deferredAction()
f.$deferredAction()}}function processClassData(b1,b2,b3){b2=convertToSlowObject(b2)
var g
var f=Object.keys(b2)
var e=false
var d=supportsDirectProtoAccess&&b1!="b"
for(var c=0;c<f.length;c++){var a0=f[c]
var a1=a0.charCodeAt(0)
if(a0==="m"){processStatics(init.statics[b1]=b2.m,b3)
delete b2.m}else if(a1===43){w[g]=a0.substring(1)
var a2=b2[a0]
if(a2>0)b2[g].$reflectable=a2}else if(a1===42){b2[g].$D=b2[a0]
var a3=b2.$methodsWithOptionalArguments
if(!a3)b2.$methodsWithOptionalArguments=a3={}
a3[a0]=g}else{var a4=b2[a0]
if(a0!=="^"&&a4!=null&&a4.constructor===Array&&a0!=="<>")if(d)e=true
else addStubs(b2,a4,a0,false,[])
else g=a0}}if(e)b2.$deferredAction=finishAddStubsHelper
var a5=b2["^"],a6,a7,a8=a5
var a9=a8.split(";")
a8=a9[1]?a9[1].split(","):[]
a7=a9[0]
a6=a7.split(":")
if(a6.length==2){a7=a6[0]
var b0=a6[1]
if(b0)b2.$S=function(b4){return function(){return init.types[b4]}}(b0)}if(a7)b3.pending[b1]=a7
b3.combinedConstructorFunction+=defineClass(b1,a8)
b3.constructorsList.push(b1)
b3.collected[b1]=[m,b2]
i.push(b1)}function processStatics(a3,a4){var g=Object.keys(a3)
for(var f=0;f<g.length;f++){var e=g[f]
if(e==="^")continue
var d=a3[e]
var c=e.charCodeAt(0)
var a0
if(c===43){v[a0]=e.substring(1)
var a1=a3[e]
if(a1>0)a3[a0].$reflectable=a1
if(d&&d.length)init.typeInformation[a0]=d}else if(c===42){m[a0].$D=d
var a2=a3.$methodsWithOptionalArguments
if(!a2)a3.$methodsWithOptionalArguments=a2={}
a2[e]=a0}else if(typeof d==="function"){m[a0=e]=d
h.push(e)
init.globalFunctions[e]=d}else if(d.constructor===Array)addStubs(m,d,e,true,h)
else{a0=e
processClassData(e,d,a4)}}}function addStubs(b2,b3,b4,b5,b6){var g=0,f=b3[g],e
if(typeof f=="string")e=b3[++g]
else{e=f
f=b4}var d=[b2[b4]=b2[f]=e]
e.$stubName=b4
b6.push(b4)
for(g++;g<b3.length;g++){e=b3[g]
if(typeof e!="function")break
if(!b5)e.$stubName=b3[++g]
d.push(e)
if(e.$stubName){b2[e.$stubName]=e
b6.push(e.$stubName)}}for(var c=0;c<d.length;g++,c++)d[c].$callName=b3[g]
var a0=b3[g]
b3=b3.slice(++g)
var a1=b3[0]
var a2=a1>>1
var a3=(a1&1)===1
var a4=a1===3
var a5=a1===1
var a6=b3[1]
var a7=a6>>1
var a8=(a6&1)===1
var a9=a2+a7!=d[0].length
var b0=b3[2]
if(typeof b0=="number")b3[2]=b0+b
var b1=2*a7+a2+3
if(a0){e=tearOff(d,b3,b5,b4,a9)
b2[b4].$getter=e
e.$getterStub=true
if(b5){init.globalFunctions[b4]=e
b6.push(a0)}b2[a0]=e
d.push(e)
e.$stubName=a0
e.$callName=null}}function tearOffGetter(c,d,e,f){return f?new Function("funcs","reflectionInfo","name","H","c","return function tearOff_"+e+y+++"(x) {"+"if (c === null) c = "+"H.cy"+"("+"this, funcs, reflectionInfo, false, [x], name);"+"return new c(this, funcs[0], x, name);"+"}")(c,d,e,H,null):new Function("funcs","reflectionInfo","name","H","c","return function tearOff_"+e+y+++"() {"+"if (c === null) c = "+"H.cy"+"("+"this, funcs, reflectionInfo, false, [], name);"+"return new c(this, funcs[0], null, name);"+"}")(c,d,e,H,null)}function tearOff(c,d,e,f,a0){var g
return e?function(){if(g===void 0)g=H.cy(this,c,d,true,[],f).prototype
return g}:tearOffGetter(c,d,f,a0)}var y=0
if(!init.libraries)init.libraries=[]
if(!init.mangledNames)init.mangledNames=map()
if(!init.mangledGlobalNames)init.mangledGlobalNames=map()
if(!init.statics)init.statics=map()
if(!init.typeInformation)init.typeInformation=map()
if(!init.globalFunctions)init.globalFunctions=map()
var x=init.libraries
var w=init.mangledNames
var v=init.mangledGlobalNames
var u=Object.prototype.hasOwnProperty
var t=a.length
var s=map()
s.collected=map()
s.pending=map()
s.constructorsList=[]
s.combinedConstructorFunction="function $reflectable(fn){fn.$reflectable=1;return fn};\n"+"var $desc;\n"
for(var r=0;r<t;r++){var q=a[r]
var p=q[0]
var o=q[1]
var n=q[2]
var m=q[3]
var l=q[4]
var k=!!q[5]
var j=l&&l["^"]
if(j instanceof Array)j=j[0]
var i=[]
var h=[]
processStatics(l,s)
x.push([p,o,i,h,n,j,k,m])}finishClasses(s)}I.L=function(){}
var dart=[["","",,H,{"^":"",lE:{"^":"b;a"}}],["","",,J,{"^":"",
m:function(a){return void 0},
bJ:function(a,b,c,d){return{i:a,p:b,e:c,x:d}},
bE:function(a){var z,y,x,w,v
z=a[init.dispatchPropertyName]
if(z==null)if($.cB==null){H.kG()
z=a[init.dispatchPropertyName]}if(z!=null){y=z.p
if(!1===y)return z.i
if(!0===y)return a
x=Object.getPrototypeOf(a)
if(y===x)return z.i
if(z.e===x)throw H.a(new P.b8("Return interceptor for "+H.d(y(a,z))))}w=a.constructor
v=w==null?null:w[$.$get$c_()]
if(v!=null)return v
v=H.kP(a)
if(v!=null)return v
if(typeof a=="function")return C.P
y=Object.getPrototypeOf(a)
if(y==null)return C.y
if(y===Object.prototype)return C.y
if(typeof w=="function"){Object.defineProperty(w,$.$get$c_(),{value:C.q,enumerable:false,writable:true,configurable:true})
return C.q}return C.q},
i:{"^":"b;",
w:function(a,b){return a===b},
gC:function(a){return H.aa(a)},
j:["d8",function(a){return H.bs(a)}],
"%":"Blob|Client|DOMError|DOMImplementation|File|FileError|MediaError|NavigatorUserMediaError|PositionError|PushMessageData|Range|SQLError|SVGAnimatedLength|SVGAnimatedLengthList|SVGAnimatedNumber|SVGAnimatedNumberList|SVGAnimatedString|WindowClient"},
h2:{"^":"i;",
j:function(a){return String(a)},
gC:function(a){return a?519018:218159},
$isaS:1},
h4:{"^":"i;",
w:function(a,b){return null==b},
j:function(a){return"null"},
gC:function(a){return 0}},
c0:{"^":"i;",
gC:function(a){return 0},
j:["da",function(a){return String(a)}],
$ish5:1},
hI:{"^":"c0;"},
b9:{"^":"c0;"},
b3:{"^":"c0;",
j:function(a){var z=a[$.$get$cW()]
return z==null?this.da(a):J.V(z)},
$S:function(){return{func:1,opt:[,,,,,,,,,,,,,,,,]}}},
b0:{"^":"i;$ti",
bz:function(a,b){if(!!a.immutable$list)throw H.a(new P.l(b))},
by:function(a,b){if(!!a.fixed$length)throw H.a(new P.l(b))},
p:function(a,b){var z
this.by(a,"remove")
for(z=0;z<a.length;++z)if(J.z(a[z],b)){a.splice(z,1)
return!0}return!1},
b4:function(a,b){return new H.bw(a,b,[H.y(a,0)])},
H:function(a,b){var z,y
z=a.length
for(y=0;y<z;++y){b.$1(a[y])
if(a.length!==z)throw H.a(new P.W(a))}},
a4:function(a,b){return new H.aK(a,b,[H.y(a,0),null])},
a3:function(a,b){var z,y,x,w
z=a.length
y=new Array(z)
y.fixed$length=Array
for(x=0;x<a.length;++x){w=H.d(a[x])
if(x>=z)return H.e(y,x)
y[x]=w}return y.join(b)},
ep:function(a,b,c){var z,y,x
z=a.length
for(y=!1,x=0;x<z;++x){y=c.$2(y,a[x])
if(a.length!==z)throw H.a(new P.W(a))}return y},
G:function(a,b){if(b>>>0!==b||b>=a.length)return H.e(a,b)
return a[b]},
bZ:function(a,b,c){var z=a.length
if(b>z)throw H.a(P.D(b,0,a.length,"start",null))
if(c==null)c=a.length
else{if(typeof c!=="number"||Math.floor(c)!==c)throw H.a(H.K(c))
if(c<b||c>a.length)throw H.a(P.D(c,b,a.length,"end",null))}if(b===c)return H.u([],[H.y(a,0)])
return H.u(a.slice(b,c),[H.y(a,0)])},
gN:function(a){if(a.length>0)return a[0]
throw H.a(H.b_())},
gb1:function(a){var z=a.length
if(z>0)return a[z-1]
throw H.a(H.b_())},
A:function(a,b,c,d,e){var z,y,x
this.bz(a,"setRange")
P.a_(b,c,a.length,null,null,null)
z=c-b
if(z===0)return
if(e<0)H.v(P.D(e,0,null,"skipCount",null))
if(e+z>d.length)throw H.a(H.db())
if(e<b)for(y=z-1;y>=0;--y){x=e+y
if(x>>>0!==x||x>=d.length)return H.e(d,x)
a[b+y]=d[x]}else for(y=0;y<z;++y){x=e+y
if(x>>>0!==x||x>=d.length)return H.e(d,x)
a[b+y]=d[x]}},
R:function(a,b,c,d){return this.A(a,b,c,d,0)},
ar:function(a,b,c,d){var z
this.bz(a,"fill range")
P.a_(b,c,a.length,null,null,null)
for(z=b;z<c;++z)a[z]=d},
P:function(a,b,c,d){var z,y,x,w,v,u
this.by(a,"replaceRange")
P.a_(b,c,a.length,null,null,null)
d=C.a.a5(d)
if(typeof c!=="number")return c.aI()
z=c-b
y=d.length
x=b+y
w=a.length
if(z>=y){v=z-y
u=w-v
this.R(a,b,x,d)
if(v!==0){this.A(a,x,u,a,c)
this.sh(a,u)}}else{u=w+(y-z)
this.sh(a,u)
this.A(a,x,u,a,c)
this.R(a,b,x,d)}},
cA:function(a,b){var z,y
z=a.length
for(y=0;y<z;++y){if(b.$1(a[y])===!0)return!0
if(a.length!==z)throw H.a(new P.W(a))}return!1},
b0:function(a,b,c){var z
if(c>=a.length)return-1
if(c<0)c=0
for(z=c;z<a.length;++z)if(J.z(a[z],b))return z
return-1},
F:function(a,b){var z
for(z=0;z<a.length;++z)if(J.z(a[z],b))return!0
return!1},
gu:function(a){return a.length===0},
j:function(a){return P.bl(a,"[","]")},
gD:function(a){return new J.bU(a,a.length,0,null)},
gC:function(a){return H.aa(a)},
gh:function(a){return a.length},
sh:function(a,b){this.by(a,"set length")
if(typeof b!=="number"||Math.floor(b)!==b)throw H.a(P.aE(b,"newLength",null))
if(b<0)throw H.a(P.D(b,0,null,"newLength",null))
a.length=b},
i:function(a,b){if(typeof b!=="number"||Math.floor(b)!==b)throw H.a(H.B(a,b))
if(b>=a.length||b<0)throw H.a(H.B(a,b))
return a[b]},
q:function(a,b,c){this.bz(a,"indexed set")
if(typeof b!=="number"||Math.floor(b)!==b)throw H.a(H.B(a,b))
if(b>=a.length||b<0)throw H.a(H.B(a,b))
a[b]=c},
$isI:1,
$asI:I.L,
$ish:1,
$ash:null,
$isf:1,
$asf:null},
lD:{"^":"b0;$ti"},
bU:{"^":"b;a,b,c,d",
gt:function(){return this.d},
l:function(){var z,y,x
z=this.a
y=z.length
if(this.b!==y)throw H.a(H.a5(z))
x=this.c
if(x>=y){this.d=null
return!1}this.d=z[x]
this.c=x+1
return!0}},
b1:{"^":"i;",
bL:function(a){if(a>0){if(a!==1/0)return Math.round(a)}else if(a>-1/0)return 0-Math.round(0-a)
throw H.a(new P.l(""+a+".round()"))},
j:function(a){if(a===0&&1/a<0)return"-0.0"
else return""+a},
gC:function(a){return a&0x1FFFFFFF},
X:function(a,b){if(typeof b!=="number")throw H.a(H.K(b))
return a+b},
b6:function(a,b){var z=a%b
if(z===0)return 0
if(z>0)return z
if(b<0)return z-b
else return z+b},
K:function(a,b){return(a|0)===a?a/b|0:this.e3(a,b)},
e3:function(a,b){var z=a/b
if(z>=-2147483648&&z<=2147483647)return z|0
if(z>0){if(z!==1/0)return Math.floor(z)}else if(z>-1/0)return Math.ceil(z)
throw H.a(new P.l("Result of truncating division is "+H.d(z)+": "+H.d(a)+" ~/ "+b))},
a9:function(a,b){var z
if(a>0)z=b>31?0:a>>>b
else{z=b>31?31:b
z=a>>z>>>0}return z},
e0:function(a,b){if(b<0)throw H.a(H.K(b))
return b>31?0:a>>>b},
I:function(a,b){if(typeof b!=="number")throw H.a(H.K(b))
return a<b},
ak:function(a,b){if(typeof b!=="number")throw H.a(H.K(b))
return a>b},
$isbg:1},
dc:{"^":"b1;",$isbg:1,$isj:1},
h3:{"^":"b1;",$isbg:1},
b2:{"^":"i;",
E:function(a,b){if(typeof b!=="number"||Math.floor(b)!==b)throw H.a(H.B(a,b))
if(b<0)throw H.a(H.B(a,b))
if(b>=a.length)H.v(H.B(a,b))
return a.charCodeAt(b)},
B:function(a,b){if(b>=a.length)throw H.a(H.B(a,b))
return a.charCodeAt(b)},
X:function(a,b){if(typeof b!=="string")throw H.a(P.aE(b,null,null))
return a+b},
P:function(a,b,c,d){var z,y
H.cv(b)
c=P.a_(b,c,a.length,null,null,null)
H.cv(c)
z=a.substring(0,b)
y=a.substring(c)
return z+d+y},
V:function(a,b,c){var z
H.cv(c)
if(typeof c!=="number")return c.I()
if(c<0||c>a.length)throw H.a(P.D(c,0,a.length,null,null))
z=c+b.length
if(z>a.length)return!1
return b===a.substring(c,z)},
L:function(a,b){return this.V(a,b,0)},
k:function(a,b,c){if(typeof b!=="number"||Math.floor(b)!==b)H.v(H.K(b))
if(c==null)c=a.length
if(typeof c!=="number"||Math.floor(c)!==c)H.v(H.K(c))
if(typeof b!=="number")return b.I()
if(b<0)throw H.a(P.bt(b,null,null))
if(typeof c!=="number")return H.r(c)
if(b>c)throw H.a(P.bt(b,null,null))
if(c>a.length)throw H.a(P.bt(c,null,null))
return a.substring(b,c)},
at:function(a,b){return this.k(a,b,null)},
eU:function(a){return a.toLowerCase()},
eV:function(a){return a.toUpperCase()},
eW:function(a){var z,y,x,w,v
z=a.trim()
y=z.length
if(y===0)return z
if(this.B(z,0)===133){x=J.h6(z,1)
if(x===y)return""}else x=0
w=y-1
v=this.E(z,w)===133?J.h7(z,w):y
if(x===0&&v===y)return z
return z.substring(x,v)},
cX:function(a,b){var z,y
if(0>=b)return""
if(b===1||a.length===0)return a
if(b!==b>>>0)throw H.a(C.C)
for(z=a,y="";!0;){if((b&1)===1)y=z+y
b=b>>>1
if(b===0)break
z+=z}return y},
b0:function(a,b,c){var z
if(c<0||c>a.length)throw H.a(P.D(c,0,a.length,null,null))
z=a.indexOf(b,c)
return z},
b_:function(a,b){return this.b0(a,b,0)},
eh:function(a,b,c){if(c>a.length)throw H.a(P.D(c,0,a.length,null,null))
return H.l1(a,b,c)},
gu:function(a){return a.length===0},
j:function(a){return a},
gC:function(a){var z,y,x
for(z=a.length,y=0,x=0;x<z;++x){y=536870911&y+a.charCodeAt(x)
y=536870911&y+((524287&y)<<10)
y^=y>>6}y=536870911&y+((67108863&y)<<3)
y^=y>>11
return 536870911&y+((16383&y)<<15)},
gh:function(a){return a.length},
i:function(a,b){if(typeof b!=="number"||Math.floor(b)!==b)throw H.a(H.B(a,b))
if(b>=a.length||b<0)throw H.a(H.B(a,b))
return a[b]},
$isI:1,
$asI:I.L,
$iso:1,
m:{
dd:function(a){if(a<256)switch(a){case 9:case 10:case 11:case 12:case 13:case 32:case 133:case 160:return!0
default:return!1}switch(a){case 5760:case 8192:case 8193:case 8194:case 8195:case 8196:case 8197:case 8198:case 8199:case 8200:case 8201:case 8202:case 8232:case 8233:case 8239:case 8287:case 12288:case 65279:return!0
default:return!1}},
h6:function(a,b){var z,y
for(z=a.length;b<z;){y=C.a.B(a,b)
if(y!==32&&y!==13&&!J.dd(y))break;++b}return b},
h7:function(a,b){var z,y
for(;b>0;b=z){z=b-1
y=C.a.E(a,z)
if(y!==32&&y!==13&&!J.dd(y))break}return b}}}}],["","",,H,{"^":"",
bG:function(a){var z,y
z=a^48
if(z<=9)return z
y=a|32
if(97<=y&&y<=102)return y-87
return-1},
eg:function(a){if(typeof a!=="number"||Math.floor(a)!==a)throw H.a(P.aE(a,"count","is not an integer"))
if(a<0)H.v(P.D(a,0,null,"count",null))
return a},
b_:function(){return new P.C("No element")},
h1:function(){return new P.C("Too many elements")},
db:function(){return new P.C("Too few elements")},
f:{"^":"H;$ti",$asf:null},
aJ:{"^":"f;$ti",
gD:function(a){return new H.bn(this,this.gh(this),0,null)},
H:function(a,b){var z,y
z=this.gh(this)
for(y=0;y<z;++y){b.$1(this.G(0,y))
if(z!==this.gh(this))throw H.a(new P.W(this))}},
gu:function(a){return this.gh(this)===0},
b4:function(a,b){return this.d9(0,b)},
a4:function(a,b){return new H.aK(this,b,[H.x(this,"aJ",0),null])},
a6:function(a,b){var z,y,x
z=H.u([],[H.x(this,"aJ",0)])
C.b.sh(z,this.gh(this))
for(y=0;y<this.gh(this);++y){x=this.G(0,y)
if(y>=z.length)return H.e(z,y)
z[y]=x}return z},
a5:function(a){return this.a6(a,!0)}},
i7:{"^":"aJ;a,b,c,$ti",
gdG:function(){var z,y
z=J.U(this.a)
y=this.c
if(y==null||y>z)return z
return y},
ge1:function(){var z,y
z=J.U(this.a)
y=this.b
if(y>z)return z
return y},
gh:function(a){var z,y,x
z=J.U(this.a)
y=this.b
if(y>=z)return 0
x=this.c
if(x==null||x>=z)return z-y
if(typeof x!=="number")return x.aI()
return x-y},
G:function(a,b){var z,y
z=this.ge1()
if(typeof b!=="number")return H.r(b)
y=z+b
if(!(b<0)){z=this.gdG()
if(typeof z!=="number")return H.r(z)
z=y>=z}else z=!0
if(z)throw H.a(P.a2(b,this,"index",null,null))
return J.aV(this.a,y)},
a6:function(a,b){var z,y,x,w,v,u,t,s,r
z=this.b
y=this.a
x=J.w(y)
w=x.gh(y)
v=this.c
if(v!=null&&v<w)w=v
if(typeof w!=="number")return w.aI()
u=w-z
if(u<0)u=0
t=H.u(new Array(u),this.$ti)
for(s=0;s<u;++s){r=x.G(y,z+s)
if(s>=t.length)return H.e(t,s)
t[s]=r
if(x.gh(y)<w)throw H.a(new P.W(this))}return t}},
bn:{"^":"b;a,b,c,d",
gt:function(){return this.d},
l:function(){var z,y,x,w
z=this.a
y=J.w(z)
x=y.gh(z)
if(this.b!==x)throw H.a(new P.W(z))
w=this.c
if(w>=x){this.d=null
return!1}this.d=y.G(z,w);++this.c
return!0}},
bo:{"^":"H;a,b,$ti",
gD:function(a){return new H.hl(null,J.ad(this.a),this.b,this.$ti)},
gh:function(a){return J.U(this.a)},
gu:function(a){return J.cI(this.a)},
G:function(a,b){return this.b.$1(J.aV(this.a,b))},
$asH:function(a,b){return[b]},
m:{
bp:function(a,b,c,d){if(!!a.$isf)return new H.bY(a,b,[c,d])
return new H.bo(a,b,[c,d])}}},
bY:{"^":"bo;a,b,$ti",$isf:1,
$asf:function(a,b){return[b]}},
hl:{"^":"bm;a,b,c,$ti",
l:function(){var z=this.b
if(z.l()){this.a=this.c.$1(z.gt())
return!0}this.a=null
return!1},
gt:function(){return this.a}},
aK:{"^":"aJ;a,b,$ti",
gh:function(a){return J.U(this.a)},
G:function(a,b){return this.b.$1(J.aV(this.a,b))},
$asaJ:function(a,b){return[b]},
$asf:function(a,b){return[b]},
$asH:function(a,b){return[b]}},
bw:{"^":"H;a,b,$ti",
gD:function(a){return new H.it(J.ad(this.a),this.b,this.$ti)},
a4:function(a,b){return new H.bo(this,b,[H.y(this,0),null])}},
it:{"^":"bm;a,b,$ti",
l:function(){var z,y
for(z=this.a,y=this.b;z.l();)if(y.$1(z.gt())===!0)return!0
return!1},
gt:function(){return this.a.gt()}},
dB:{"^":"H;a,b,$ti",
gD:function(a){return new H.ia(J.ad(this.a),this.b,this.$ti)},
m:{
i9:function(a,b,c){if(typeof b!=="number"||Math.floor(b)!==b||b<0)throw H.a(P.aD(b))
if(!!J.m(a).$isf)return new H.fr(a,b,[c])
return new H.dB(a,b,[c])}}},
fr:{"^":"dB;a,b,$ti",
gh:function(a){var z,y
z=J.U(this.a)
y=this.b
if(z>y)return y
return z},
$isf:1,
$asf:null},
ia:{"^":"bm;a,b,$ti",
l:function(){if(--this.b>=0)return this.a.l()
this.b=-1
return!1},
gt:function(){if(this.b<0)return
return this.a.gt()}},
dx:{"^":"H;a,b,$ti",
gD:function(a){return new H.hV(J.ad(this.a),this.b,this.$ti)},
m:{
hU:function(a,b,c){if(!!J.m(a).$isf)return new H.fq(a,H.eg(b),[c])
return new H.dx(a,H.eg(b),[c])}}},
fq:{"^":"dx;a,b,$ti",
gh:function(a){var z=J.U(this.a)-this.b
if(z>=0)return z
return 0},
$isf:1,
$asf:null},
hV:{"^":"bm;a,b,$ti",
l:function(){var z,y
for(z=this.a,y=0;y<this.b;++y)z.l()
this.b=0
return z.l()},
gt:function(){return this.a.gt()}},
d6:{"^":"b;$ti",
sh:function(a,b){throw H.a(new P.l("Cannot change the length of a fixed-length list"))},
p:function(a,b){throw H.a(new P.l("Cannot remove from a fixed-length list"))},
P:function(a,b,c,d){throw H.a(new P.l("Cannot remove from a fixed-length list"))}}}],["","",,H,{"^":"",
bd:function(a,b){var z=a.az(b)
if(!init.globalState.d.cy)init.globalState.f.aE()
return z},
eH:function(a,b){var z,y,x,w,v,u
z={}
z.a=b
if(b==null){b=[]
z.a=b
y=b}else y=b
if(!J.m(y).$ish)throw H.a(P.aD("Arguments to main must be a List: "+H.d(y)))
init.globalState=new H.jl(0,0,1,null,null,null,null,null,null,null,null,null,a)
y=init.globalState
x=self.window==null
w=self.Worker
v=x&&!!self.postMessage
y.x=v
v=!v
if(v)w=w!=null&&$.$get$d9()!=null
else w=!0
y.y=w
y.r=x&&v
y.f=new H.iX(P.c3(null,H.bb),0)
x=P.j
y.z=new H.af(0,null,null,null,null,null,0,[x,H.co])
y.ch=new H.af(0,null,null,null,null,null,0,[x,null])
if(y.x===!0){w=new H.jk()
y.Q=w
self.onmessage=function(c,d){return function(e){c(d,e)}}(H.fV,w)
self.dartPrint=self.dartPrint||function(c){return function(d){if(self.console&&self.console.log)self.console.log(d)
else self.postMessage(c(d))}}(H.jm)}if(init.globalState.x===!0)return
y=init.globalState.a++
w=P.J(null,null,null,x)
v=new H.bu(0,null,!1)
u=new H.co(y,new H.af(0,null,null,null,null,null,0,[x,H.bu]),w,init.createNewIsolate(),v,new H.am(H.bM()),new H.am(H.bM()),!1,!1,[],P.J(null,null,null,null),null,null,!1,!0,P.J(null,null,null,null))
w.v(0,0)
u.c3(0,v)
init.globalState.e=u
init.globalState.d=u
if(H.aA(a,{func:1,args:[,]}))u.az(new H.l_(z,a))
else if(H.aA(a,{func:1,args:[,,]}))u.az(new H.l0(z,a))
else u.az(a)
init.globalState.f.aE()},
fZ:function(){var z=init.currentScript
if(z!=null)return String(z.src)
if(init.globalState.x===!0)return H.h_()
return},
h_:function(){var z,y
z=new Error().stack
if(z==null){z=function(){try{throw new Error()}catch(x){return x.stack}}()
if(z==null)throw H.a(new P.l("No stack trace"))}y=z.match(new RegExp("^ *at [^(]*\\((.*):[0-9]*:[0-9]*\\)$","m"))
if(y!=null)return y[1]
y=z.match(new RegExp("^[^@]*@(.*):[0-9]*$","m"))
if(y!=null)return y[1]
throw H.a(new P.l('Cannot extract URI from "'+z+'"'))},
fV:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n
z=new H.bx(!0,[]).ad(b.data)
y=J.w(z)
switch(y.i(z,"command")){case"start":init.globalState.b=y.i(z,"id")
x=y.i(z,"functionName")
w=x==null?init.globalState.cx:init.globalFunctions[x]()
v=y.i(z,"args")
u=new H.bx(!0,[]).ad(y.i(z,"msg"))
t=y.i(z,"isSpawnUri")
s=y.i(z,"startPaused")
r=new H.bx(!0,[]).ad(y.i(z,"replyTo"))
y=init.globalState.a++
q=P.j
p=P.J(null,null,null,q)
o=new H.bu(0,null,!1)
n=new H.co(y,new H.af(0,null,null,null,null,null,0,[q,H.bu]),p,init.createNewIsolate(),o,new H.am(H.bM()),new H.am(H.bM()),!1,!1,[],P.J(null,null,null,null),null,null,!1,!0,P.J(null,null,null,null))
p.v(0,0)
n.c3(0,o)
init.globalState.f.a.a_(new H.bb(n,new H.fW(w,v,u,t,s,r),"worker-start"))
init.globalState.d=n
init.globalState.f.aE()
break
case"spawn-worker":break
case"message":if(y.i(z,"port")!=null)J.aC(y.i(z,"port"),y.i(z,"msg"))
init.globalState.f.aE()
break
case"close":init.globalState.ch.p(0,$.$get$da().i(0,a))
a.terminate()
init.globalState.f.aE()
break
case"log":H.fU(y.i(z,"msg"))
break
case"print":if(init.globalState.x===!0){y=init.globalState.Q
q=P.P(["command","print","msg",z])
q=new H.au(!0,P.aN(null,P.j)).U(q)
y.toString
self.postMessage(q)}else P.bL(y.i(z,"msg"))
break
case"error":throw H.a(y.i(z,"msg"))}},
fU:function(a){var z,y,x,w
if(init.globalState.x===!0){y=init.globalState.Q
x=P.P(["command","log","msg",a])
x=new H.au(!0,P.aN(null,P.j)).U(x)
y.toString
self.postMessage(x)}else try{self.console.log(a)}catch(w){H.E(w)
z=H.S(w)
y=P.bk(z)
throw H.a(y)}},
fX:function(a,b,c,d,e,f){var z,y,x,w
z=init.globalState.d
y=z.a
$.dr=$.dr+("_"+y)
$.ds=$.ds+("_"+y)
y=z.e
x=init.globalState.d.a
w=z.f
J.aC(f,["spawned",new H.bC(y,x),w,z.r])
x=new H.fY(a,b,c,d,z)
if(e===!0){z.cz(w,w)
init.globalState.f.a.a_(new H.bb(z,x,"start isolate"))}else x.$0()},
k6:function(a){return new H.bx(!0,[]).ad(new H.au(!1,P.aN(null,P.j)).U(a))},
l_:{"^":"c:1;a,b",
$0:function(){this.b.$1(this.a.a)}},
l0:{"^":"c:1;a,b",
$0:function(){this.b.$2(this.a.a,null)}},
jl:{"^":"b;a,b,c,d,e,f,r,x,y,z,Q,ch,cx",m:{
jm:function(a){var z=P.P(["command","print","msg",a])
return new H.au(!0,P.aN(null,P.j)).U(z)}}},
co:{"^":"b;a,b,c,eB:d<,ei:e<,f,r,x,y,z,Q,ch,cx,cy,db,dx",
cz:function(a,b){if(!this.f.w(0,a))return
if(this.Q.v(0,b)&&!this.y)this.y=!0
this.bv()},
eN:function(a){var z,y,x,w,v,u
if(!this.y)return
z=this.Q
z.p(0,a)
if(z.a===0){for(z=this.z;y=z.length,y!==0;){if(0>=y)return H.e(z,-1)
x=z.pop()
y=init.globalState.f.a
w=y.b
v=y.a
u=v.length
w=(w-1&u-1)>>>0
y.b=w
if(w<0||w>=u)return H.e(v,w)
v[w]=x
if(w===y.c)y.ce();++y.d}this.y=!1}this.bv()},
e8:function(a,b){var z,y,x
if(this.ch==null)this.ch=[]
for(z=J.m(a),y=0;x=this.ch,y<x.length;y+=2)if(z.w(a,x[y])){z=this.ch
x=y+1
if(x>=z.length)return H.e(z,x)
z[x]=b
return}x.push(a)
this.ch.push(b)},
eM:function(a){var z,y,x
if(this.ch==null)return
for(z=J.m(a),y=0;x=this.ch,y<x.length;y+=2)if(z.w(a,x[y])){z=this.ch
x=y+2
z.toString
if(typeof z!=="object"||z===null||!!z.fixed$length)H.v(new P.l("removeRange"))
P.a_(y,x,z.length,null,null,null)
z.splice(y,x-y)
return}},
d5:function(a,b){if(!this.r.w(0,a))return
this.db=b},
es:function(a,b,c){var z=J.m(b)
if(!z.w(b,0))z=z.w(b,1)&&!this.cy
else z=!0
if(z){J.aC(a,c)
return}z=this.cx
if(z==null){z=P.c3(null,null)
this.cx=z}z.a_(new H.jf(a,c))},
er:function(a,b){var z
if(!this.r.w(0,a))return
z=J.m(b)
if(!z.w(b,0))z=z.w(b,1)&&!this.cy
else z=!0
if(z){this.bC()
return}z=this.cx
if(z==null){z=P.c3(null,null)
this.cx=z}z.a_(this.geC())},
eu:function(a,b){var z,y,x
z=this.dx
if(z.a===0){if(this.db===!0&&this===init.globalState.e)return
if(self.console&&self.console.error)self.console.error(a,b)
else{P.bL(a)
if(b!=null)P.bL(b)}return}y=new Array(2)
y.fixed$length=Array
y[0]=J.V(a)
y[1]=b==null?null:J.V(b)
for(x=new P.bc(z,z.r,null,null),x.c=z.e;x.l();)J.aC(x.d,y)},
az:function(a){var z,y,x,w,v,u,t
z=init.globalState.d
init.globalState.d=this
$=this.d
y=null
x=this.cy
this.cy=!0
try{y=a.$0()}catch(u){w=H.E(u)
v=H.S(u)
this.eu(w,v)
if(this.db===!0){this.bC()
if(this===init.globalState.e)throw u}}finally{this.cy=x
init.globalState.d=z
if(z!=null)$=z.geB()
if(this.cx!=null)for(;t=this.cx,!t.gu(t);)this.cx.cO().$0()}return y},
bE:function(a){return this.b.i(0,a)},
c3:function(a,b){var z=this.b
if(z.aX(a))throw H.a(P.bk("Registry: ports must be registered only once."))
z.q(0,a,b)},
bv:function(){var z=this.b
if(z.gh(z)-this.c.a>0||this.y||!this.x)init.globalState.z.q(0,this.a,this)
else this.bC()},
bC:[function(){var z,y,x,w,v
z=this.cx
if(z!=null)z.ac(0)
for(z=this.b,y=z.gbR(z),y=y.gD(y);y.l();)y.gt().dC()
z.ac(0)
this.c.ac(0)
init.globalState.z.p(0,this.a)
this.dx.ac(0)
if(this.ch!=null){for(x=0;z=this.ch,y=z.length,x<y;x+=2){w=z[x]
v=x+1
if(v>=y)return H.e(z,v)
J.aC(w,z[v])}this.ch=null}},"$0","geC",0,0,2]},
jf:{"^":"c:2;a,b",
$0:function(){J.aC(this.a,this.b)}},
iX:{"^":"b;a,b",
ek:function(){var z=this.a
if(z.b===z.c)return
return z.cO()},
cQ:function(){var z,y,x
z=this.ek()
if(z==null){if(init.globalState.e!=null)if(init.globalState.z.aX(init.globalState.e.a))if(init.globalState.r===!0){y=init.globalState.e.b
y=y.gu(y)}else y=!1
else y=!1
else y=!1
if(y)H.v(P.bk("Program exited with open ReceivePorts."))
y=init.globalState
if(y.x===!0){x=y.z
x=x.gu(x)&&y.f.b===0}else x=!1
if(x){y=y.Q
x=P.P(["command","close"])
x=new H.au(!0,new P.e5(0,null,null,null,null,null,0,[null,P.j])).U(x)
y.toString
self.postMessage(x)}return!1}z.eK()
return!0},
cp:function(){if(self.window!=null)new H.iY(this).$0()
else for(;this.cQ(););},
aE:function(){var z,y,x,w,v
if(init.globalState.x!==!0)this.cp()
else try{this.cp()}catch(x){z=H.E(x)
y=H.S(x)
w=init.globalState.Q
v=P.P(["command","error","msg",H.d(z)+"\n"+H.d(y)])
v=new H.au(!0,P.aN(null,P.j)).U(v)
w.toString
self.postMessage(v)}}},
iY:{"^":"c:2;a",
$0:function(){if(!this.a.cQ())return
P.cd(C.r,this)}},
bb:{"^":"b;a,b,c",
eK:function(){var z=this.a
if(z.y){z.z.push(this)
return}z.az(this.b)}},
jk:{"^":"b;"},
fW:{"^":"c:1;a,b,c,d,e,f",
$0:function(){H.fX(this.a,this.b,this.c,this.d,this.e,this.f)}},
fY:{"^":"c:2;a,b,c,d,e",
$0:function(){var z,y
z=this.e
z.x=!0
if(this.d!==!0)this.a.$1(this.c)
else{y=this.a
if(H.aA(y,{func:1,args:[,,]}))y.$2(this.b,this.c)
else if(H.aA(y,{func:1,args:[,]}))y.$1(this.b)
else y.$0()}z.bv()}},
dY:{"^":"b;"},
bC:{"^":"dY;b,a",
aG:function(a,b){var z,y,x
z=init.globalState.z.i(0,this.a)
if(z==null)return
y=this.b
if(y.gcj())return
x=H.k6(b)
if(z.gei()===y){y=J.w(x)
switch(y.i(x,0)){case"pause":z.cz(y.i(x,1),y.i(x,2))
break
case"resume":z.eN(y.i(x,1))
break
case"add-ondone":z.e8(y.i(x,1),y.i(x,2))
break
case"remove-ondone":z.eM(y.i(x,1))
break
case"set-errors-fatal":z.d5(y.i(x,1),y.i(x,2))
break
case"ping":z.es(y.i(x,1),y.i(x,2),y.i(x,3))
break
case"kill":z.er(y.i(x,1),y.i(x,2))
break
case"getErrors":y=y.i(x,1)
z.dx.v(0,y)
break
case"stopErrors":y=y.i(x,1)
z.dx.p(0,y)
break}return}init.globalState.f.a.a_(new H.bb(z,new H.js(this,x),"receive"))},
w:function(a,b){if(b==null)return!1
return b instanceof H.bC&&J.z(this.b,b.b)},
gC:function(a){return this.b.gbn()}},
js:{"^":"c:1;a,b",
$0:function(){var z=this.a.b
if(!z.gcj())z.du(this.b)}},
cr:{"^":"dY;b,c,a",
aG:function(a,b){var z,y,x
z=P.P(["command","message","port",this,"msg",b])
y=new H.au(!0,P.aN(null,P.j)).U(z)
if(init.globalState.x===!0){init.globalState.Q.toString
self.postMessage(y)}else{x=init.globalState.ch.i(0,this.b)
if(x!=null)x.postMessage(y)}},
w:function(a,b){if(b==null)return!1
return b instanceof H.cr&&J.z(this.b,b.b)&&J.z(this.a,b.a)&&J.z(this.c,b.c)},
gC:function(a){var z,y,x
z=this.b
if(typeof z!=="number")return z.b9()
y=this.a
if(typeof y!=="number")return y.b9()
x=this.c
if(typeof x!=="number")return H.r(x)
return(z<<16^y<<8^x)>>>0}},
bu:{"^":"b;bn:a<,b,cj:c<",
dC:function(){this.c=!0
this.b=null},
du:function(a){if(this.c)return
this.b.$1(a)},
$ishN:1},
dF:{"^":"b;a,b,c",
ab:function(){if(self.setTimeout!=null){if(this.b)throw H.a(new P.l("Timer in event loop cannot be canceled."))
var z=this.c
if(z==null)return;--init.globalState.f.b
if(this.a)self.clearTimeout(z)
else self.clearInterval(z)
this.c=null}else throw H.a(new P.l("Canceling a timer."))},
dl:function(a,b){if(self.setTimeout!=null){++init.globalState.f.b
this.c=self.setInterval(H.az(new H.ie(this,b),0),a)}else throw H.a(new P.l("Periodic timer."))},
dk:function(a,b){var z,y
if(a===0)z=self.setTimeout==null||init.globalState.x===!0
else z=!1
if(z){this.c=1
z=init.globalState.f
y=init.globalState.d
z.a.a_(new H.bb(y,new H.ig(this,b),"timer"))
this.b=!0}else if(self.setTimeout!=null){++init.globalState.f.b
this.c=self.setTimeout(H.az(new H.ih(this,b),0),a)}else throw H.a(new P.l("Timer greater than 0."))},
m:{
ic:function(a,b){var z=new H.dF(!0,!1,null)
z.dk(a,b)
return z},
id:function(a,b){var z=new H.dF(!1,!1,null)
z.dl(a,b)
return z}}},
ig:{"^":"c:2;a,b",
$0:function(){this.a.c=null
this.b.$0()}},
ih:{"^":"c:2;a,b",
$0:function(){this.a.c=null;--init.globalState.f.b
this.b.$0()}},
ie:{"^":"c:1;a,b",
$0:function(){this.b.$1(this.a)}},
am:{"^":"b;bn:a<",
gC:function(a){var z=this.a
if(typeof z!=="number")return z.d6()
z=C.e.a9(z,0)^C.e.K(z,4294967296)
z=(~z>>>0)+(z<<15>>>0)&4294967295
z=((z^z>>>12)>>>0)*5&4294967295
z=((z^z>>>4)>>>0)*2057&4294967295
return(z^z>>>16)>>>0},
w:function(a,b){var z,y
if(b==null)return!1
if(b===this)return!0
if(b instanceof H.am){z=this.a
y=b.a
return z==null?y==null:z===y}return!1}},
au:{"^":"b;a,b",
U:[function(a){var z,y,x,w,v
if(a==null||typeof a==="string"||typeof a==="number"||typeof a==="boolean")return a
z=this.b
y=z.i(0,a)
if(y!=null)return["ref",y]
z.q(0,a,z.gh(z))
z=J.m(a)
if(!!z.$isdg)return["buffer",a]
if(!!z.$isc5)return["typed",a]
if(!!z.$isI)return this.d1(a)
if(!!z.$isfT){x=this.gcZ()
w=a.gT()
w=H.bp(w,x,H.x(w,"H",0),null)
w=P.aq(w,!0,H.x(w,"H",0))
z=z.gbR(a)
z=H.bp(z,x,H.x(z,"H",0),null)
return["map",w,P.aq(z,!0,H.x(z,"H",0))]}if(!!z.$ish5)return this.d2(a)
if(!!z.$isi)this.cS(a)
if(!!z.$ishN)this.aF(a,"RawReceivePorts can't be transmitted:")
if(!!z.$isbC)return this.d3(a)
if(!!z.$iscr)return this.d4(a)
if(!!z.$isc){v=a.$static_name
if(v==null)this.aF(a,"Closures can't be transmitted:")
return["function",v]}if(!!z.$isam)return["capability",a.a]
if(!(a instanceof P.b))this.cS(a)
return["dart",init.classIdExtractor(a),this.d0(init.classFieldsExtractor(a))]},"$1","gcZ",2,0,0],
aF:function(a,b){throw H.a(new P.l((b==null?"Can't transmit:":b)+" "+H.d(a)))},
cS:function(a){return this.aF(a,null)},
d1:function(a){var z=this.d_(a)
if(!!a.fixed$length)return["fixed",z]
if(!a.fixed$length)return["extendable",z]
if(!a.immutable$list)return["mutable",z]
if(a.constructor===Array)return["const",z]
this.aF(a,"Can't serialize indexable: ")},
d_:function(a){var z,y,x
z=[]
C.b.sh(z,a.length)
for(y=0;y<a.length;++y){x=this.U(a[y])
if(y>=z.length)return H.e(z,y)
z[y]=x}return z},
d0:function(a){var z
for(z=0;z<a.length;++z)C.b.q(a,z,this.U(a[z]))
return a},
d2:function(a){var z,y,x,w
if(!!a.constructor&&a.constructor!==Object)this.aF(a,"Only plain JS Objects are supported:")
z=Object.keys(a)
y=[]
C.b.sh(y,z.length)
for(x=0;x<z.length;++x){w=this.U(a[z[x]])
if(x>=y.length)return H.e(y,x)
y[x]=w}return["js-object",z,y]},
d4:function(a){if(this.a)return["sendport",a.b,a.a,a.c]
return["raw sendport",a]},
d3:function(a){if(this.a)return["sendport",init.globalState.b,a.a,a.b.gbn()]
return["raw sendport",a]}},
bx:{"^":"b;a,b",
ad:[function(a){var z,y,x,w,v,u
if(a==null||typeof a==="string"||typeof a==="number"||typeof a==="boolean")return a
if(typeof a!=="object"||a===null||a.constructor!==Array)throw H.a(P.aD("Bad serialized message: "+H.d(a)))
switch(C.b.gN(a)){case"ref":if(1>=a.length)return H.e(a,1)
z=a[1]
y=this.b
if(z>>>0!==z||z>=y.length)return H.e(y,z)
return y[z]
case"buffer":if(1>=a.length)return H.e(a,1)
x=a[1]
this.b.push(x)
return x
case"typed":if(1>=a.length)return H.e(a,1)
x=a[1]
this.b.push(x)
return x
case"fixed":if(1>=a.length)return H.e(a,1)
x=a[1]
this.b.push(x)
y=H.u(this.ay(x),[null])
y.fixed$length=Array
return y
case"extendable":if(1>=a.length)return H.e(a,1)
x=a[1]
this.b.push(x)
return H.u(this.ay(x),[null])
case"mutable":if(1>=a.length)return H.e(a,1)
x=a[1]
this.b.push(x)
return this.ay(x)
case"const":if(1>=a.length)return H.e(a,1)
x=a[1]
this.b.push(x)
y=H.u(this.ay(x),[null])
y.fixed$length=Array
return y
case"map":return this.en(a)
case"sendport":return this.eo(a)
case"raw sendport":if(1>=a.length)return H.e(a,1)
x=a[1]
this.b.push(x)
return x
case"js-object":return this.em(a)
case"function":if(1>=a.length)return H.e(a,1)
x=init.globalFunctions[a[1]]()
this.b.push(x)
return x
case"capability":if(1>=a.length)return H.e(a,1)
return new H.am(a[1])
case"dart":y=a.length
if(1>=y)return H.e(a,1)
w=a[1]
if(2>=y)return H.e(a,2)
v=a[2]
u=init.instanceFromClassId(w)
this.b.push(u)
this.ay(v)
return init.initializeEmptyInstance(w,u,v)
default:throw H.a("couldn't deserialize: "+H.d(a))}},"$1","gel",2,0,0],
ay:function(a){var z,y,x
z=J.w(a)
y=0
while(!0){x=z.gh(a)
if(typeof x!=="number")return H.r(x)
if(!(y<x))break
z.q(a,y,this.ad(z.i(a,y)));++y}return a},
en:function(a){var z,y,x,w,v,u
z=a.length
if(1>=z)return H.e(a,1)
y=a[1]
if(2>=z)return H.e(a,2)
x=a[2]
w=P.de()
this.b.push(w)
y=J.eV(y,this.gel()).a5(0)
for(z=J.w(y),v=J.w(x),u=0;u<z.gh(y);++u){if(u>=y.length)return H.e(y,u)
w.q(0,y[u],this.ad(v.i(x,u)))}return w},
eo:function(a){var z,y,x,w,v,u,t
z=a.length
if(1>=z)return H.e(a,1)
y=a[1]
if(2>=z)return H.e(a,2)
x=a[2]
if(3>=z)return H.e(a,3)
w=a[3]
if(J.z(y,init.globalState.b)){v=init.globalState.z.i(0,x)
if(v==null)return
u=v.bE(w)
if(u==null)return
t=new H.bC(u,x)}else t=new H.cr(y,w,x)
this.b.push(t)
return t},
em:function(a){var z,y,x,w,v,u,t
z=a.length
if(1>=z)return H.e(a,1)
y=a[1]
if(2>=z)return H.e(a,2)
x=a[2]
w={}
this.b.push(w)
z=J.w(y)
v=J.w(x)
u=0
while(!0){t=z.gh(y)
if(typeof t!=="number")return H.r(t)
if(!(u<t))break
w[z.i(y,u)]=this.ad(v.i(x,u));++u}return w}}}],["","",,H,{"^":"",
kz:function(a){return init.types[a]},
kO:function(a,b){var z
if(b!=null){z=b.x
if(z!=null)return z}return!!J.m(a).$isO},
d:function(a){var z
if(typeof a==="string")return a
if(typeof a==="number"){if(a!==0)return""+a}else if(!0===a)return"true"
else if(!1===a)return"false"
else if(a==null)return"null"
z=J.V(a)
if(typeof z!=="string")throw H.a(H.K(a))
return z},
aa:function(a){var z=a.$identityHash
if(z==null){z=Math.random()*0x3fffffff|0
a.$identityHash=z}return z},
ca:function(a,b){if(b==null)throw H.a(new P.N(a,null,null))
return b.$1(a)},
ar:function(a,b,c){var z,y,x,w,v,u
z=/^\s*[+-]?((0x[a-f0-9]+)|(\d+)|([a-z0-9]+))\s*$/i.exec(a)
if(z==null)return H.ca(a,c)
if(3>=z.length)return H.e(z,3)
y=z[3]
if(b==null){if(y!=null)return parseInt(a,10)
if(z[2]!=null)return parseInt(a,16)
return H.ca(a,c)}if(b<2||b>36)throw H.a(P.D(b,2,36,"radix",null))
if(b===10&&y!=null)return parseInt(a,10)
if(b<10||y==null){x=b<=10?47+b:86+b
w=z[1]
for(v=w.length,u=0;u<v;++u)if((C.a.B(w,u)|32)>x)return H.ca(a,c)}return parseInt(a,b)},
cc:function(a){var z,y,x,w,v,u,t,s
z=J.m(a)
y=z.constructor
if(typeof y=="function"){x=y.name
w=typeof x==="string"?x:null}else w=null
if(w==null||z===C.I||!!J.m(a).$isb9){v=C.u(a)
if(v==="Object"){u=a.constructor
if(typeof u=="function"){t=String(u).match(/^\s*function\s*([\w$]*)\s*\(/)
s=t==null?null:t[1]
if(typeof s==="string"&&/^\w+$/.test(s))w=s}if(w==null)w=v}else w=v}w=w
if(w.length>1&&C.a.B(w,0)===36)w=C.a.at(w,1)
return function(b,c){return b.replace(/[^<,> ]+/g,function(d){return c[d]||d})}(w+H.eB(H.bF(a),0,null),init.mangledGlobalNames)},
bs:function(a){return"Instance of '"+H.cc(a)+"'"},
hJ:function(){if(!!self.location)return self.location.href
return},
dq:function(a){var z,y,x,w,v
z=a.length
if(z<=500)return String.fromCharCode.apply(null,a)
for(y="",x=0;x<z;x=w){w=x+500
v=w<z?w:z
y+=String.fromCharCode.apply(null,a.slice(x,v))}return y},
hK:function(a){var z,y,x,w
z=H.u([],[P.j])
for(y=a.length,x=0;x<a.length;a.length===y||(0,H.a5)(a),++x){w=a[x]
if(typeof w!=="number"||Math.floor(w)!==w)throw H.a(H.K(w))
if(w<=65535)z.push(w)
else if(w<=1114111){z.push(55296+(C.c.a9(w-65536,10)&1023))
z.push(56320+(w&1023))}else throw H.a(H.K(w))}return H.dq(z)},
dv:function(a){var z,y,x,w
for(z=a.length,y=0;x=a.length,y<x;x===z||(0,H.a5)(a),++y){w=a[y]
if(typeof w!=="number"||Math.floor(w)!==w)throw H.a(H.K(w))
if(w<0)throw H.a(H.K(w))
if(w>65535)return H.hK(a)}return H.dq(a)},
hL:function(a,b,c){var z,y,x,w
if(typeof c!=="number")return c.eY()
if(c<=500&&b===0&&c===a.length)return String.fromCharCode.apply(null,a)
for(z=b,y="";z<c;z=x){x=z+500
if(x<c)w=x
else w=c
y+=String.fromCharCode.apply(null,a.subarray(z,w))}return y},
du:function(a){var z
if(0<=a){if(a<=65535)return String.fromCharCode(a)
if(a<=1114111){z=a-65536
return String.fromCharCode((55296|C.c.a9(z,10))>>>0,56320|z&1023)}}throw H.a(P.D(a,0,1114111,null,null))},
cb:function(a,b){if(a==null||typeof a==="boolean"||typeof a==="number"||typeof a==="string")throw H.a(H.K(a))
return a[b]},
dt:function(a,b,c){if(a==null||typeof a==="boolean"||typeof a==="number"||typeof a==="string")throw H.a(H.K(a))
a[b]=c},
r:function(a){throw H.a(H.K(a))},
e:function(a,b){if(a==null)J.U(a)
throw H.a(H.B(a,b))},
B:function(a,b){var z,y
if(typeof b!=="number"||Math.floor(b)!==b)return new P.Z(!0,b,"index",null)
z=J.U(a)
if(!(b<0)){if(typeof z!=="number")return H.r(z)
y=b>=z}else y=!0
if(y)return P.a2(b,a,"index",null,z)
return P.bt(b,"index",null)},
ku:function(a,b,c){if(a>c)return new P.b4(0,c,!0,a,"start","Invalid value")
if(b!=null){if(typeof b!=="number"||Math.floor(b)!==b)return new P.Z(!0,b,"end",null)
if(b<a||b>c)return new P.b4(a,c,!0,b,"end","Invalid value")}return new P.Z(!0,b,"end",null)},
K:function(a){return new P.Z(!0,a,null,null)},
cv:function(a){if(typeof a!=="number"||Math.floor(a)!==a)throw H.a(H.K(a))
return a},
a:function(a){var z
if(a==null)a=new P.c8()
z=new Error()
z.dartException=a
if("defineProperty" in Object){Object.defineProperty(z,"message",{get:H.eI})
z.name=""}else z.toString=H.eI
return z},
eI:function(){return J.V(this.dartException)},
v:function(a){throw H.a(a)},
a5:function(a){throw H.a(new P.W(a))},
E:function(a){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l
z=new H.l3(a)
if(a==null)return
if(typeof a!=="object")return a
if("dartException" in a)return z.$1(a.dartException)
else if(!("message" in a))return a
y=a.message
if("number" in a&&typeof a.number=="number"){x=a.number
w=x&65535
if((C.c.a9(x,16)&8191)===10)switch(w){case 438:return z.$1(H.c1(H.d(y)+" (Error "+w+")",null))
case 445:case 5007:v=H.d(y)+" (Error "+w+")"
return z.$1(new H.dm(v,null))}}if(a instanceof TypeError){u=$.$get$dI()
t=$.$get$dJ()
s=$.$get$dK()
r=$.$get$dL()
q=$.$get$dP()
p=$.$get$dQ()
o=$.$get$dN()
$.$get$dM()
n=$.$get$dS()
m=$.$get$dR()
l=u.W(y)
if(l!=null)return z.$1(H.c1(y,l))
else{l=t.W(y)
if(l!=null){l.method="call"
return z.$1(H.c1(y,l))}else{l=s.W(y)
if(l==null){l=r.W(y)
if(l==null){l=q.W(y)
if(l==null){l=p.W(y)
if(l==null){l=o.W(y)
if(l==null){l=r.W(y)
if(l==null){l=n.W(y)
if(l==null){l=m.W(y)
v=l!=null}else v=!0}else v=!0}else v=!0}else v=!0}else v=!0}else v=!0}else v=!0
if(v)return z.$1(new H.dm(y,l==null?null:l.method))}}return z.$1(new H.il(typeof y==="string"?y:""))}if(a instanceof RangeError){if(typeof y==="string"&&y.indexOf("call stack")!==-1)return new P.dy()
y=function(b){try{return String(b)}catch(k){}return null}(a)
return z.$1(new P.Z(!1,null,null,typeof y==="string"?y.replace(/^RangeError:\s*/,""):y))}if(typeof InternalError=="function"&&a instanceof InternalError)if(typeof y==="string"&&y==="too much recursion")return new P.dy()
return a},
S:function(a){var z
if(a==null)return new H.e7(a,null)
z=a.$cachedTrace
if(z!=null)return z
return a.$cachedTrace=new H.e7(a,null)},
kT:function(a){if(a==null||typeof a!='object')return J.ac(a)
else return H.aa(a)},
kx:function(a,b){var z,y,x,w
z=a.length
for(y=0;y<z;y=w){x=y+1
w=x+1
b.q(0,a[y],a[x])}return b},
kI:function(a,b,c,d,e,f,g){switch(c){case 0:return H.bd(b,new H.kJ(a))
case 1:return H.bd(b,new H.kK(a,d))
case 2:return H.bd(b,new H.kL(a,d,e))
case 3:return H.bd(b,new H.kM(a,d,e,f))
case 4:return H.bd(b,new H.kN(a,d,e,f,g))}throw H.a(P.bk("Unsupported number of arguments for wrapped closure"))},
az:function(a,b){var z
if(a==null)return
z=a.$identity
if(!!z)return z
z=function(c,d,e,f){return function(g,h,i,j){return f(c,e,d,g,h,i,j)}}(a,b,init.globalState.d,H.kI)
a.$identity=z
return z},
ff:function(a,b,c,d,e,f){var z,y,x,w,v,u,t,s,r,q,p,o,n,m
z=b[0]
y=z.$callName
if(!!J.m(c).$ish){z.$reflectionInfo=c
x=H.hP(z).r}else x=c
w=d?Object.create(new H.hZ().constructor.prototype):Object.create(new H.bW(null,null,null,null).constructor.prototype)
w.$initialize=w.constructor
if(d)v=function(){this.$initialize()}
else{u=$.a0
$.a0=J.al(u,1)
v=new Function("a,b,c,d"+u,"this.$initialize(a,b,c,d"+u+")")}w.constructor=v
v.prototype=w
if(!d){t=e.length==1&&!0
s=H.cS(a,z,t)
s.$reflectionInfo=c}else{w.$static_name=f
s=z
t=!1}if(typeof x=="number")r=function(g,h){return function(){return g(h)}}(H.kz,x)
else if(typeof x=="function")if(d)r=x
else{q=t?H.cR:H.bX
r=function(g,h){return function(){return g.apply({$receiver:h(this)},arguments)}}(x,q)}else throw H.a("Error in reflectionInfo.")
w.$S=r
w[y]=s
for(u=b.length,p=1;p<u;++p){o=b[p]
n=o.$callName
if(n!=null){m=d?o:H.cS(a,o,t)
w[n]=m}}w["call*"]=s
w.$R=z.$R
w.$D=z.$D
return v},
fc:function(a,b,c,d){var z=H.bX
switch(b?-1:a){case 0:return function(e,f){return function(){return f(this)[e]()}}(c,z)
case 1:return function(e,f){return function(g){return f(this)[e](g)}}(c,z)
case 2:return function(e,f){return function(g,h){return f(this)[e](g,h)}}(c,z)
case 3:return function(e,f){return function(g,h,i){return f(this)[e](g,h,i)}}(c,z)
case 4:return function(e,f){return function(g,h,i,j){return f(this)[e](g,h,i,j)}}(c,z)
case 5:return function(e,f){return function(g,h,i,j,k){return f(this)[e](g,h,i,j,k)}}(c,z)
default:return function(e,f){return function(){return e.apply(f(this),arguments)}}(d,z)}},
cS:function(a,b,c){var z,y,x,w,v,u,t
if(c)return H.fe(a,b)
z=b.$stubName
y=b.length
x=a[z]
w=b==null?x==null:b===x
v=!w||y>=27
if(v)return H.fc(y,!w,z,b)
if(y===0){w=$.a0
$.a0=J.al(w,1)
u="self"+H.d(w)
w="return function(){var "+u+" = this."
v=$.aF
if(v==null){v=H.bj("self")
$.aF=v}return new Function(w+H.d(v)+";return "+u+"."+H.d(z)+"();}")()}t="abcdefghijklmnopqrstuvwxyz".split("").splice(0,y).join(",")
w=$.a0
$.a0=J.al(w,1)
t+=H.d(w)
w="return function("+t+"){return this."
v=$.aF
if(v==null){v=H.bj("self")
$.aF=v}return new Function(w+H.d(v)+"."+H.d(z)+"("+t+");}")()},
fd:function(a,b,c,d){var z,y
z=H.bX
y=H.cR
switch(b?-1:a){case 0:throw H.a(new H.hR("Intercepted function with no arguments."))
case 1:return function(e,f,g){return function(){return f(this)[e](g(this))}}(c,z,y)
case 2:return function(e,f,g){return function(h){return f(this)[e](g(this),h)}}(c,z,y)
case 3:return function(e,f,g){return function(h,i){return f(this)[e](g(this),h,i)}}(c,z,y)
case 4:return function(e,f,g){return function(h,i,j){return f(this)[e](g(this),h,i,j)}}(c,z,y)
case 5:return function(e,f,g){return function(h,i,j,k){return f(this)[e](g(this),h,i,j,k)}}(c,z,y)
case 6:return function(e,f,g){return function(h,i,j,k,l){return f(this)[e](g(this),h,i,j,k,l)}}(c,z,y)
default:return function(e,f,g,h){return function(){h=[g(this)]
Array.prototype.push.apply(h,arguments)
return e.apply(f(this),h)}}(d,z,y)}},
fe:function(a,b){var z,y,x,w,v,u,t,s
z=H.f8()
y=$.cQ
if(y==null){y=H.bj("receiver")
$.cQ=y}x=b.$stubName
w=b.length
v=a[x]
u=b==null?v==null:b===v
t=!u||w>=28
if(t)return H.fd(w,!u,x,b)
if(w===1){y="return function(){return this."+H.d(z)+"."+H.d(x)+"(this."+H.d(y)+");"
u=$.a0
$.a0=J.al(u,1)
return new Function(y+H.d(u)+"}")()}s="abcdefghijklmnopqrstuvwxyz".split("").splice(0,w-1).join(",")
y="return function("+s+"){return this."+H.d(z)+"."+H.d(x)+"(this."+H.d(y)+", "+s+");"
u=$.a0
$.a0=J.al(u,1)
return new Function(y+H.d(u)+"}")()},
cy:function(a,b,c,d,e,f){var z
b.fixed$length=Array
if(!!J.m(c).$ish){c.fixed$length=Array
z=c}else z=c
return H.ff(a,b,z,!!d,e,f)},
kZ:function(a,b){var z=J.w(b)
throw H.a(H.fa(H.cc(a),z.k(b,3,z.gh(b))))},
bH:function(a,b){var z
if(a!=null)z=(typeof a==="object"||typeof a==="function")&&J.m(a)[b]
else z=!0
if(z)return a
H.kZ(a,b)},
kv:function(a){var z=J.m(a)
return"$S" in z?z.$S():null},
aA:function(a,b){var z
if(a==null)return!1
z=H.kv(a)
return z==null?!1:H.eA(z,b)},
l2:function(a){throw H.a(new P.fl(a))},
bM:function(){return(Math.random()*0x100000000>>>0)+(Math.random()*0x100000000>>>0)*4294967296},
ey:function(a){return init.getIsolateTag(a)},
u:function(a,b){a.$ti=b
return a},
bF:function(a){if(a==null)return
return a.$ti},
ez:function(a,b){return H.cD(a["$as"+H.d(b)],H.bF(a))},
x:function(a,b,c){var z=H.ez(a,b)
return z==null?null:z[c]},
y:function(a,b){var z=H.bF(a)
return z==null?null:z[b]},
aB:function(a,b){var z
if(a==null)return"dynamic"
if(typeof a==="object"&&a!==null&&a.constructor===Array)return a[0].builtin$cls+H.eB(a,1,b)
if(typeof a=="function")return a.builtin$cls
if(typeof a==="number"&&Math.floor(a)===a)return H.d(a)
if(typeof a.func!="undefined"){z=a.typedef
if(z!=null)return H.aB(z,b)
return H.ke(a,b)}return"unknown-reified-type"},
ke:function(a,b){var z,y,x,w,v,u,t,s,r,q,p
z=!!a.v?"void":H.aB(a.ret,b)
if("args" in a){y=a.args
for(x=y.length,w="",v="",u=0;u<x;++u,v=", "){t=y[u]
w=w+v+H.aB(t,b)}}else{w=""
v=""}if("opt" in a){s=a.opt
w+=v+"["
for(x=s.length,v="",u=0;u<x;++u,v=", "){t=s[u]
w=w+v+H.aB(t,b)}w+="]"}if("named" in a){r=a.named
w+=v+"{"
for(x=H.kw(r),q=x.length,v="",u=0;u<q;++u,v=", "){p=x[u]
w=w+v+H.aB(r[p],b)+(" "+H.d(p))}w+="}"}return"("+w+") => "+z},
eB:function(a,b,c){var z,y,x,w,v,u
if(a==null)return""
z=new P.ag("")
for(y=b,x=!0,w=!0,v="";y<a.length;++y){if(x)x=!1
else z.n=v+", "
u=a[y]
if(u!=null)w=!1
v=z.n+=H.aB(u,c)}return w?"":"<"+z.j(0)+">"},
cD:function(a,b){if(a==null)return b
a=a.apply(null,b)
if(a==null)return
if(typeof a==="object"&&a!==null&&a.constructor===Array)return a
if(typeof a=="function")return a.apply(null,b)
return b},
be:function(a,b,c,d){var z,y
if(a==null)return!1
z=H.bF(a)
y=J.m(a)
if(y[b]==null)return!1
return H.es(H.cD(y[d],z),c)},
es:function(a,b){var z,y
if(a==null||b==null)return!0
z=a.length
for(y=0;y<z;++y)if(!H.T(a[y],b[y]))return!1
return!0},
bf:function(a,b,c){return a.apply(b,H.ez(b,c))},
T:function(a,b){var z,y,x,w,v,u
if(a===b)return!0
if(a==null||b==null)return!0
if(a.builtin$cls==="br")return!0
if('func' in b)return H.eA(a,b)
if('func' in a)return b.builtin$cls==="ly"||b.builtin$cls==="b"
z=typeof a==="object"&&a!==null&&a.constructor===Array
y=z?a[0]:a
x=typeof b==="object"&&b!==null&&b.constructor===Array
w=x?b[0]:b
if(w!==y){v=H.aB(w,null)
if(!('$is'+v in y.prototype))return!1
u=y.prototype["$as"+v]}else u=null
if(!z&&u==null||!x)return!0
z=z?a.slice(1):null
x=b.slice(1)
return H.es(H.cD(u,z),x)},
er:function(a,b,c){var z,y,x,w,v
z=b==null
if(z&&a==null)return!0
if(z)return c
if(a==null)return!1
y=a.length
x=b.length
if(c){if(y<x)return!1}else if(y!==x)return!1
for(w=0;w<x;++w){z=a[w]
v=b[w]
if(!(H.T(z,v)||H.T(v,z)))return!1}return!0},
kl:function(a,b){var z,y,x,w,v,u
if(b==null)return!0
if(a==null)return!1
z=Object.getOwnPropertyNames(b)
z.fixed$length=Array
y=z
for(z=y.length,x=0;x<z;++x){w=y[x]
if(!Object.hasOwnProperty.call(a,w))return!1
v=b[w]
u=a[w]
if(!(H.T(v,u)||H.T(u,v)))return!1}return!0},
eA:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l
if(!('func' in a))return!1
if("v" in a){if(!("v" in b)&&"ret" in b)return!1}else if(!("v" in b)){z=a.ret
y=b.ret
if(!(H.T(z,y)||H.T(y,z)))return!1}x=a.args
w=b.args
v=a.opt
u=b.opt
t=x!=null?x.length:0
s=w!=null?w.length:0
r=v!=null?v.length:0
q=u!=null?u.length:0
if(t>s)return!1
if(t+r<s+q)return!1
if(t===s){if(!H.er(x,w,!1))return!1
if(!H.er(v,u,!0))return!1}else{for(p=0;p<t;++p){o=x[p]
n=w[p]
if(!(H.T(o,n)||H.T(n,o)))return!1}for(m=p,l=0;m<s;++l,++m){o=v[l]
n=w[m]
if(!(H.T(o,n)||H.T(n,o)))return!1}for(m=0;m<q;++l,++m){o=v[l]
n=u[m]
if(!(H.T(o,n)||H.T(n,o)))return!1}}return H.kl(a.named,b.named)},
mD:function(a){var z=$.cA
return"Instance of "+(z==null?"<Unknown>":z.$1(a))},
mA:function(a){return H.aa(a)},
mz:function(a,b,c){Object.defineProperty(a,b,{value:c,enumerable:false,writable:true,configurable:true})},
kP:function(a){var z,y,x,w,v,u
z=$.cA.$1(a)
y=$.bD[z]
if(y!=null){Object.defineProperty(a,init.dispatchPropertyName,{value:y,enumerable:false,writable:true,configurable:true})
return y.i}x=$.bI[z]
if(x!=null)return x
w=init.interceptorsByTag[z]
if(w==null){z=$.eq.$2(a,z)
if(z!=null){y=$.bD[z]
if(y!=null){Object.defineProperty(a,init.dispatchPropertyName,{value:y,enumerable:false,writable:true,configurable:true})
return y.i}x=$.bI[z]
if(x!=null)return x
w=init.interceptorsByTag[z]}}if(w==null)return
x=w.prototype
v=z[0]
if(v==="!"){y=H.cC(x)
$.bD[z]=y
Object.defineProperty(a,init.dispatchPropertyName,{value:y,enumerable:false,writable:true,configurable:true})
return y.i}if(v==="~"){$.bI[z]=x
return x}if(v==="-"){u=H.cC(x)
Object.defineProperty(Object.getPrototypeOf(a),init.dispatchPropertyName,{value:u,enumerable:false,writable:true,configurable:true})
return u.i}if(v==="+")return H.eE(a,x)
if(v==="*")throw H.a(new P.b8(z))
if(init.leafTags[z]===true){u=H.cC(x)
Object.defineProperty(Object.getPrototypeOf(a),init.dispatchPropertyName,{value:u,enumerable:false,writable:true,configurable:true})
return u.i}else return H.eE(a,x)},
eE:function(a,b){var z=Object.getPrototypeOf(a)
Object.defineProperty(z,init.dispatchPropertyName,{value:J.bJ(b,z,null,null),enumerable:false,writable:true,configurable:true})
return b},
cC:function(a){return J.bJ(a,!1,null,!!a.$isO)},
kS:function(a,b,c){var z=b.prototype
if(init.leafTags[a]===true)return J.bJ(z,!1,null,!!z.$isO)
else return J.bJ(z,c,null,null)},
kG:function(){if(!0===$.cB)return
$.cB=!0
H.kH()},
kH:function(){var z,y,x,w,v,u,t,s
$.bD=Object.create(null)
$.bI=Object.create(null)
H.kC()
z=init.interceptorsByTag
y=Object.getOwnPropertyNames(z)
if(typeof window!="undefined"){window
x=function(){}
for(w=0;w<y.length;++w){v=y[w]
u=$.eF.$1(v)
if(u!=null){t=H.kS(v,z[v],u)
if(t!=null){Object.defineProperty(u,init.dispatchPropertyName,{value:t,enumerable:false,writable:true,configurable:true})
x.prototype=u}}}}for(w=0;w<y.length;++w){v=y[w]
if(/^[A-Za-z_]/.test(v)){s=z[v]
z["!"+v]=s
z["~"+v]=s
z["-"+v]=s
z["+"+v]=s
z["*"+v]=s}}},
kC:function(){var z,y,x,w,v,u,t
z=C.J()
z=H.ay(C.K,H.ay(C.L,H.ay(C.t,H.ay(C.t,H.ay(C.N,H.ay(C.M,H.ay(C.O(C.u),z)))))))
if(typeof dartNativeDispatchHooksTransformer!="undefined"){y=dartNativeDispatchHooksTransformer
if(typeof y=="function")y=[y]
if(y.constructor==Array)for(x=0;x<y.length;++x){w=y[x]
if(typeof w=="function")z=w(z)||z}}v=z.getTag
u=z.getUnknownTag
t=z.prototypeForTag
$.cA=new H.kD(v)
$.eq=new H.kE(u)
$.eF=new H.kF(t)},
ay:function(a,b){return a(b)||b},
l1:function(a,b,c){var z=a.indexOf(b,c)
return z>=0},
hO:{"^":"b;a,b,c,d,e,f,r,x",m:{
hP:function(a){var z,y,x
z=a.$reflectionInfo
if(z==null)return
z.fixed$length=Array
z=z
y=z[0]
x=z[1]
return new H.hO(a,z,(y&1)===1,y>>1,x>>1,(x&1)===1,z[2],null)}}},
ij:{"^":"b;a,b,c,d,e,f",
W:function(a){var z,y,x
z=new RegExp(this.a).exec(a)
if(z==null)return
y=Object.create(null)
x=this.b
if(x!==-1)y.arguments=z[x+1]
x=this.c
if(x!==-1)y.argumentsExpr=z[x+1]
x=this.d
if(x!==-1)y.expr=z[x+1]
x=this.e
if(x!==-1)y.method=z[x+1]
x=this.f
if(x!==-1)y.receiver=z[x+1]
return y},
m:{
a4:function(a){var z,y,x,w,v,u
a=a.replace(String({}),'$receiver$').replace(/[[\]{}()*+?.\\^$|]/g,"\\$&")
z=a.match(/\\\$[a-zA-Z]+\\\$/g)
if(z==null)z=[]
y=z.indexOf("\\$arguments\\$")
x=z.indexOf("\\$argumentsExpr\\$")
w=z.indexOf("\\$expr\\$")
v=z.indexOf("\\$method\\$")
u=z.indexOf("\\$receiver\\$")
return new H.ij(a.replace(new RegExp('\\\\\\$arguments\\\\\\$','g'),'((?:x|[^x])*)').replace(new RegExp('\\\\\\$argumentsExpr\\\\\\$','g'),'((?:x|[^x])*)').replace(new RegExp('\\\\\\$expr\\\\\\$','g'),'((?:x|[^x])*)').replace(new RegExp('\\\\\\$method\\\\\\$','g'),'((?:x|[^x])*)').replace(new RegExp('\\\\\\$receiver\\\\\\$','g'),'((?:x|[^x])*)'),y,x,w,v,u)},
bv:function(a){return function($expr$){var $argumentsExpr$='$arguments$'
try{$expr$.$method$($argumentsExpr$)}catch(z){return z.message}}(a)},
dO:function(a){return function($expr$){try{$expr$.$method$}catch(z){return z.message}}(a)}}},
dm:{"^":"G;a,b",
j:function(a){var z=this.b
if(z==null)return"NullError: "+H.d(this.a)
return"NullError: method not found: '"+H.d(z)+"' on null"}},
hb:{"^":"G;a,b,c",
j:function(a){var z,y
z=this.b
if(z==null)return"NoSuchMethodError: "+H.d(this.a)
y=this.c
if(y==null)return"NoSuchMethodError: method not found: '"+z+"' ("+H.d(this.a)+")"
return"NoSuchMethodError: method not found: '"+z+"' on '"+y+"' ("+H.d(this.a)+")"},
m:{
c1:function(a,b){var z,y
z=b==null
y=z?null:b.method
return new H.hb(a,y,z?null:b.receiver)}}},
il:{"^":"G;a",
j:function(a){var z=this.a
return z.length===0?"Error":"Error: "+z}},
l3:{"^":"c:0;a",
$1:function(a){if(!!J.m(a).$isG)if(a.$thrownJsError==null)a.$thrownJsError=this.a
return a}},
e7:{"^":"b;a,b",
j:function(a){var z,y
z=this.b
if(z!=null)return z
z=this.a
y=z!==null&&typeof z==="object"?z.stack:null
z=y==null?"":y
this.b=z
return z}},
kJ:{"^":"c:1;a",
$0:function(){return this.a.$0()}},
kK:{"^":"c:1;a,b",
$0:function(){return this.a.$1(this.b)}},
kL:{"^":"c:1;a,b,c",
$0:function(){return this.a.$2(this.b,this.c)}},
kM:{"^":"c:1;a,b,c,d",
$0:function(){return this.a.$3(this.b,this.c,this.d)}},
kN:{"^":"c:1;a,b,c,d,e",
$0:function(){return this.a.$4(this.b,this.c,this.d,this.e)}},
c:{"^":"b;",
j:function(a){return"Closure '"+H.cc(this).trim()+"'"},
gcW:function(){return this},
gcW:function(){return this}},
dC:{"^":"c;"},
hZ:{"^":"dC;",
j:function(a){var z=this.$static_name
if(z==null)return"Closure of unknown static method"
return"Closure '"+z+"'"}},
bW:{"^":"dC;a,b,c,d",
w:function(a,b){if(b==null)return!1
if(this===b)return!0
if(!(b instanceof H.bW))return!1
return this.a===b.a&&this.b===b.b&&this.c===b.c},
gC:function(a){var z,y
z=this.c
if(z==null)y=H.aa(this.a)
else y=typeof z!=="object"?J.ac(z):H.aa(z)
z=H.aa(this.b)
if(typeof y!=="number")return y.f0()
return(y^z)>>>0},
j:function(a){var z=this.c
if(z==null)z=this.a
return"Closure '"+H.d(this.d)+"' of "+H.bs(z)},
m:{
bX:function(a){return a.a},
cR:function(a){return a.c},
f8:function(){var z=$.aF
if(z==null){z=H.bj("self")
$.aF=z}return z},
bj:function(a){var z,y,x,w,v
z=new H.bW("self","target","receiver","name")
y=Object.getOwnPropertyNames(z)
y.fixed$length=Array
x=y
for(y=x.length,w=0;w<y;++w){v=x[w]
if(z[v]===a)return v}}}},
f9:{"^":"G;a",
j:function(a){return this.a},
m:{
fa:function(a,b){return new H.f9("CastError: Casting value of type '"+a+"' to incompatible type '"+b+"'")}}},
hR:{"^":"G;a",
j:function(a){return"RuntimeError: "+H.d(this.a)}},
af:{"^":"b;a,b,c,d,e,f,r,$ti",
gh:function(a){return this.a},
gu:function(a){return this.a===0},
gT:function(){return new H.hh(this,[H.y(this,0)])},
gbR:function(a){return H.bp(this.gT(),new H.ha(this),H.y(this,0),H.y(this,1))},
aX:function(a){var z,y
if(typeof a==="string"){z=this.b
if(z==null)return!1
return this.c9(z,a)}else if(typeof a==="number"&&(a&0x3ffffff)===a){y=this.c
if(y==null)return!1
return this.c9(y,a)}else return this.ey(a)},
ey:function(a){var z=this.d
if(z==null)return!1
return this.aB(this.aN(z,this.aA(a)),a)>=0},
i:function(a,b){var z,y,x
if(typeof b==="string"){z=this.b
if(z==null)return
y=this.av(z,b)
return y==null?null:y.gaf()}else if(typeof b==="number"&&(b&0x3ffffff)===b){x=this.c
if(x==null)return
y=this.av(x,b)
return y==null?null:y.gaf()}else return this.ez(b)},
ez:function(a){var z,y,x
z=this.d
if(z==null)return
y=this.aN(z,this.aA(a))
x=this.aB(y,a)
if(x<0)return
return y[x].gaf()},
q:function(a,b,c){var z,y,x,w,v,u
if(typeof b==="string"){z=this.b
if(z==null){z=this.bp()
this.b=z}this.c2(z,b,c)}else if(typeof b==="number"&&(b&0x3ffffff)===b){y=this.c
if(y==null){y=this.bp()
this.c=y}this.c2(y,b,c)}else{x=this.d
if(x==null){x=this.bp()
this.d=x}w=this.aA(b)
v=this.aN(x,w)
if(v==null)this.bu(x,w,[this.bq(b,c)])
else{u=this.aB(v,b)
if(u>=0)v[u].saf(c)
else v.push(this.bq(b,c))}}},
p:function(a,b){if(typeof b==="string")return this.cn(this.b,b)
else if(typeof b==="number"&&(b&0x3ffffff)===b)return this.cn(this.c,b)
else return this.eA(b)},
eA:function(a){var z,y,x,w
z=this.d
if(z==null)return
y=this.aN(z,this.aA(a))
x=this.aB(y,a)
if(x<0)return
w=y.splice(x,1)[0]
this.cu(w)
return w.gaf()},
ac:function(a){if(this.a>0){this.f=null
this.e=null
this.d=null
this.c=null
this.b=null
this.a=0
this.r=this.r+1&67108863}},
H:function(a,b){var z,y
z=this.e
y=this.r
for(;z!=null;){b.$2(z.a,z.b)
if(y!==this.r)throw H.a(new P.W(this))
z=z.c}},
c2:function(a,b,c){var z=this.av(a,b)
if(z==null)this.bu(a,b,this.bq(b,c))
else z.saf(c)},
cn:function(a,b){var z
if(a==null)return
z=this.av(a,b)
if(z==null)return
this.cu(z)
this.ca(a,b)
return z.gaf()},
bq:function(a,b){var z,y
z=new H.hg(a,b,null,null)
if(this.e==null){this.f=z
this.e=z}else{y=this.f
z.d=y
y.c=z
this.f=z}++this.a
this.r=this.r+1&67108863
return z},
cu:function(a){var z,y
z=a.gdQ()
y=a.c
if(z==null)this.e=y
else z.c=y
if(y==null)this.f=z
else y.d=z;--this.a
this.r=this.r+1&67108863},
aA:function(a){return J.ac(a)&0x3ffffff},
aB:function(a,b){var z,y
if(a==null)return-1
z=a.length
for(y=0;y<z;++y)if(J.z(a[y].gcK(),b))return y
return-1},
j:function(a){return P.hm(this)},
av:function(a,b){return a[b]},
aN:function(a,b){return a[b]},
bu:function(a,b,c){a[b]=c},
ca:function(a,b){delete a[b]},
c9:function(a,b){return this.av(a,b)!=null},
bp:function(){var z=Object.create(null)
this.bu(z,"<non-identifier-key>",z)
this.ca(z,"<non-identifier-key>")
return z},
$isfT:1},
ha:{"^":"c:0;a",
$1:function(a){return this.a.i(0,a)}},
hg:{"^":"b;cK:a<,af:b@,c,dQ:d<"},
hh:{"^":"f;a,$ti",
gh:function(a){return this.a.a},
gu:function(a){return this.a.a===0},
gD:function(a){var z,y
z=this.a
y=new H.hi(z,z.r,null,null)
y.c=z.e
return y}},
hi:{"^":"b;a,b,c,d",
gt:function(){return this.d},
l:function(){var z=this.a
if(this.b!==z.r)throw H.a(new P.W(z))
else{z=this.c
if(z==null){this.d=null
return!1}else{this.d=z.a
this.c=z.c
return!0}}}},
kD:{"^":"c:0;a",
$1:function(a){return this.a(a)}},
kE:{"^":"c:12;a",
$2:function(a,b){return this.a(a,b)}},
kF:{"^":"c:7;a",
$1:function(a){return this.a(a)}},
h8:{"^":"b;a,b,c,d",
j:function(a){return"RegExp/"+this.a+"/"},
m:{
h9:function(a,b,c,d){var z,y,x,w
z=b?"m":""
y=c?"":"i"
x=d?"g":""
w=function(e,f){try{return new RegExp(e,f)}catch(v){return v}}(a,z+y+x)
if(w instanceof RegExp)return w
throw H.a(new P.N("Illegal RegExp pattern ("+String(w)+")",a,null))}}}}],["","",,H,{"^":"",
kw:function(a){var z=H.u(a?Object.keys(a):[],[null])
z.fixed$length=Array
return z}}],["","",,H,{"^":"",
kY:function(a){if(typeof dartPrint=="function"){dartPrint(a)
return}if(typeof console=="object"&&typeof console.log!="undefined"){console.log(a)
return}if(typeof window=="object")return
if(typeof print=="function"){print(a)
return}throw"Unable to print message: "+String(a)}}],["","",,H,{"^":"",
eh:function(a){return a},
kd:function(a){return a},
hp:function(a){return new Int8Array(H.kd(a))},
k5:function(a,b,c){var z
if(!(a>>>0!==a))if(b==null)z=a>c
else if(!(b>>>0!==b)){if(typeof b!=="number")return H.r(b)
z=a>b||b>c}else z=!0
else z=!0
if(z)throw H.a(H.ku(a,b,c))
if(b==null)return c
return b},
dg:{"^":"i;",$isdg:1,"%":"ArrayBuffer"},
c5:{"^":"i;",
dM:function(a,b,c,d){if(typeof b!=="number"||Math.floor(b)!==b)throw H.a(P.aE(b,d,"Invalid list position"))
else throw H.a(P.D(b,0,c,d,null))},
c5:function(a,b,c,d){if(b>>>0!==b||b>c)this.dM(a,b,c,d)},
$isc5:1,
"%":"DataView;ArrayBufferView;c4|dh|dj|bq|di|dk|a9"},
c4:{"^":"c5;",
gh:function(a){return a.length},
cs:function(a,b,c,d,e){var z,y,x
z=a.length
this.c5(a,b,z,"start")
this.c5(a,c,z,"end")
if(b>c)throw H.a(P.D(b,0,c,null,null))
y=c-b
if(e<0)throw H.a(P.aD(e))
x=d.length
if(x-e<y)throw H.a(new P.C("Not enough elements"))
if(e!==0||x!==y)d=d.subarray(e,e+y)
a.set(d,b)},
$isO:1,
$asO:I.L,
$isI:1,
$asI:I.L},
bq:{"^":"dj;",
i:function(a,b){if(b>>>0!==b||b>=a.length)H.v(H.B(a,b))
return a[b]},
q:function(a,b,c){if(b>>>0!==b||b>=a.length)H.v(H.B(a,b))
a[b]=c},
A:function(a,b,c,d,e){if(!!J.m(d).$isbq){this.cs(a,b,c,d,e)
return}this.c_(a,b,c,d,e)},
R:function(a,b,c,d){return this.A(a,b,c,d,0)}},
dh:{"^":"c4+Q;",$asO:I.L,$asI:I.L,
$ash:function(){return[P.ak]},
$asf:function(){return[P.ak]},
$ish:1,
$isf:1},
dj:{"^":"dh+d6;",$asO:I.L,$asI:I.L,
$ash:function(){return[P.ak]},
$asf:function(){return[P.ak]}},
a9:{"^":"dk;",
q:function(a,b,c){if(b>>>0!==b||b>=a.length)H.v(H.B(a,b))
a[b]=c},
A:function(a,b,c,d,e){if(!!J.m(d).$isa9){this.cs(a,b,c,d,e)
return}this.c_(a,b,c,d,e)},
R:function(a,b,c,d){return this.A(a,b,c,d,0)},
$ish:1,
$ash:function(){return[P.j]},
$isf:1,
$asf:function(){return[P.j]}},
di:{"^":"c4+Q;",$asO:I.L,$asI:I.L,
$ash:function(){return[P.j]},
$asf:function(){return[P.j]},
$ish:1,
$isf:1},
dk:{"^":"di+d6;",$asO:I.L,$asI:I.L,
$ash:function(){return[P.j]},
$asf:function(){return[P.j]}},
lP:{"^":"bq;",$ish:1,
$ash:function(){return[P.ak]},
$isf:1,
$asf:function(){return[P.ak]},
"%":"Float32Array"},
lQ:{"^":"bq;",$ish:1,
$ash:function(){return[P.ak]},
$isf:1,
$asf:function(){return[P.ak]},
"%":"Float64Array"},
lR:{"^":"a9;",
i:function(a,b){if(b>>>0!==b||b>=a.length)H.v(H.B(a,b))
return a[b]},
$ish:1,
$ash:function(){return[P.j]},
$isf:1,
$asf:function(){return[P.j]},
"%":"Int16Array"},
lS:{"^":"a9;",
i:function(a,b){if(b>>>0!==b||b>=a.length)H.v(H.B(a,b))
return a[b]},
$ish:1,
$ash:function(){return[P.j]},
$isf:1,
$asf:function(){return[P.j]},
"%":"Int32Array"},
lT:{"^":"a9;",
i:function(a,b){if(b>>>0!==b||b>=a.length)H.v(H.B(a,b))
return a[b]},
$ish:1,
$ash:function(){return[P.j]},
$isf:1,
$asf:function(){return[P.j]},
"%":"Int8Array"},
lU:{"^":"a9;",
i:function(a,b){if(b>>>0!==b||b>=a.length)H.v(H.B(a,b))
return a[b]},
$ish:1,
$ash:function(){return[P.j]},
$isf:1,
$asf:function(){return[P.j]},
"%":"Uint16Array"},
lV:{"^":"a9;",
i:function(a,b){if(b>>>0!==b||b>=a.length)H.v(H.B(a,b))
return a[b]},
$ish:1,
$ash:function(){return[P.j]},
$isf:1,
$asf:function(){return[P.j]},
"%":"Uint32Array"},
lW:{"^":"a9;",
gh:function(a){return a.length},
i:function(a,b){if(b>>>0!==b||b>=a.length)H.v(H.B(a,b))
return a[b]},
$ish:1,
$ash:function(){return[P.j]},
$isf:1,
$asf:function(){return[P.j]},
"%":"CanvasPixelArray|Uint8ClampedArray"},
dl:{"^":"a9;",
gh:function(a){return a.length},
i:function(a,b){if(b>>>0!==b||b>=a.length)H.v(H.B(a,b))
return a[b]},
bZ:function(a,b,c){return new Uint8Array(a.subarray(b,H.k5(b,c,a.length)))},
$isdl:1,
$ish:1,
$ash:function(){return[P.j]},
$isf:1,
$asf:function(){return[P.j]},
"%":";Uint8Array"}}],["","",,P,{"^":"",
ix:function(){var z,y,x
z={}
if(self.scheduleImmediate!=null)return P.km()
if(self.MutationObserver!=null&&self.document!=null){y=self.document.createElement("div")
x=self.document.createElement("span")
z.a=null
new self.MutationObserver(H.az(new P.iz(z),1)).observe(y,{childList:true})
return new P.iy(z,y,x)}else if(self.setImmediate!=null)return P.kn()
return P.ko()},
mg:[function(a){++init.globalState.f.b
self.scheduleImmediate(H.az(new P.iA(a),0))},"$1","km",2,0,5],
mh:[function(a){++init.globalState.f.b
self.setImmediate(H.az(new P.iB(a),0))},"$1","kn",2,0,5],
mi:[function(a){P.ce(C.r,a)},"$1","ko",2,0,5],
cu:function(a,b){if(H.aA(a,{func:1,args:[P.br,P.br]})){b.toString
return a}else{b.toString
return a}},
kg:function(){var z,y
for(;z=$.aw,z!=null;){$.aQ=null
y=z.b
$.aw=y
if(y==null)$.aP=null
z.a.$0()}},
my:[function(){$.cs=!0
try{P.kg()}finally{$.aQ=null
$.cs=!1
if($.aw!=null)$.$get$cg().$1(P.eu())}},"$0","eu",0,0,2],
eo:function(a){var z=new P.dW(a,null)
if($.aw==null){$.aP=z
$.aw=z
if(!$.cs)$.$get$cg().$1(P.eu())}else{$.aP.b=z
$.aP=z}},
kj:function(a){var z,y,x
z=$.aw
if(z==null){P.eo(a)
$.aQ=$.aP
return}y=new P.dW(a,null)
x=$.aQ
if(x==null){y.b=z
$.aQ=y
$.aw=y}else{y.b=x.b
x.b=y
$.aQ=y
if(y.b==null)$.aP=y}},
eG:function(a){var z=$.n
if(C.d===z){P.aj(null,null,C.d,a)
return}z.toString
P.aj(null,null,z,z.bx(a,!0))},
el:function(a){var z,y,x,w
if(a==null)return
try{a.$0()}catch(x){z=H.E(x)
y=H.S(x)
w=$.n
w.toString
P.ax(null,null,w,z,y)}},
mw:[function(a){},"$1","kp",2,0,29],
kh:[function(a,b){var z=$.n
z.toString
P.ax(null,null,z,a,b)},function(a){return P.kh(a,null)},"$2","$1","kq",2,2,3,0],
mx:[function(){},"$0","et",0,0,2],
k3:function(a,b,c){var z=a.ab()
if(!!J.m(z).$isa8&&z!==$.$get$aH())z.bS(new P.k4(b,c))
else b.ao(c)},
k2:function(a,b,c){$.n.toString
a.bb(b,c)},
cd:function(a,b){var z=$.n
if(z===C.d){z.toString
return P.ce(a,b)}return P.ce(a,z.bx(b,!0))},
ii:function(a,b){var z,y
z=$.n
if(z===C.d){z.toString
return P.dG(a,b)}y=z.cB(b,!0)
$.n.toString
return P.dG(a,y)},
ce:function(a,b){var z=C.c.K(a.a,1000)
return H.ic(z<0?0:z,b)},
dG:function(a,b){var z=C.c.K(a.a,1000)
return H.id(z<0?0:z,b)},
iv:function(){return $.n},
ax:function(a,b,c,d,e){var z={}
z.a=d
P.kj(new P.ki(z,e))},
ei:function(a,b,c,d){var z,y
y=$.n
if(y===c)return d.$0()
$.n=c
z=y
try{y=d.$0()
return y}finally{$.n=z}},
ek:function(a,b,c,d,e){var z,y
y=$.n
if(y===c)return d.$1(e)
$.n=c
z=y
try{y=d.$1(e)
return y}finally{$.n=z}},
ej:function(a,b,c,d,e,f){var z,y
y=$.n
if(y===c)return d.$2(e,f)
$.n=c
z=y
try{y=d.$2(e,f)
return y}finally{$.n=z}},
aj:function(a,b,c,d){var z=C.d!==c
if(z)d=c.bx(d,!(!z||!1))
P.eo(d)},
iz:{"^":"c:0;a",
$1:function(a){var z,y;--init.globalState.f.b
z=this.a
y=z.a
z.a=null
y.$0()}},
iy:{"^":"c:13;a,b,c",
$1:function(a){var z,y;++init.globalState.f.b
this.a.a=a
z=this.b
y=this.c
z.firstChild?z.removeChild(y):z.appendChild(y)}},
iA:{"^":"c:1;a",
$0:function(){--init.globalState.f.b
this.a.$0()}},
iB:{"^":"c:1;a",
$0:function(){--init.globalState.f.b
this.a.$0()}},
iD:{"^":"dZ;a,$ti"},
iE:{"^":"iJ;y,dP:z<,Q,x,a,b,c,d,e,f,r,$ti",
aQ:[function(){},"$0","gaP",0,0,2],
aS:[function(){},"$0","gaR",0,0,2]},
ch:{"^":"b;aq:c<,$ti",
gaO:function(){return this.c<4},
dH:function(){var z=this.r
if(z!=null)return z
z=new P.X(0,$.n,null,[null])
this.r=z
return z},
co:function(a){var z,y
z=a.Q
y=a.z
if(z==null)this.d=y
else z.z=y
if(y==null)this.e=z
else y.Q=z
a.Q=a
a.z=a},
e2:function(a,b,c,d){var z,y,x,w
if((this.c&4)!==0){if(c==null)c=P.et()
z=new P.iV($.n,0,c,this.$ti)
z.cq()
return z}z=$.n
y=d?1:0
x=new P.iE(0,null,null,this,null,null,null,z,y,null,null,this.$ti)
x.c0(a,b,c,d,H.y(this,0))
x.Q=x
x.z=x
x.y=this.c&1
w=this.e
this.e=x
x.z=null
x.Q=w
if(w==null)this.d=x
else w.z=x
if(this.d===x)P.el(this.a)
return x},
dR:function(a){var z
if(a.gdP()===a)return
z=a.y
if((z&2)!==0)a.y=z|4
else{this.co(a)
if((this.c&2)===0&&this.d==null)this.bf()}return},
dS:function(a){},
dT:function(a){},
bc:["dc",function(){if((this.c&4)!==0)return new P.C("Cannot add new events after calling close")
return new P.C("Cannot add new events while doing an addStream")}],
v:[function(a,b){if(!this.gaO())throw H.a(this.bc())
this.aV(b)},"$1","ge7",2,0,function(){return H.bf(function(a){return{func:1,v:true,args:[a]}},this.$receiver,"ch")}],
cD:function(a){var z
if((this.c&4)!==0)return this.r
if(!this.gaO())throw H.a(this.bc())
this.c|=4
z=this.dH()
this.ax()
return z},
cd:function(a){var z,y,x,w
z=this.c
if((z&2)!==0)throw H.a(new P.C("Cannot fire new event. Controller is already firing an event"))
y=this.d
if(y==null)return
x=z&1
this.c=z^3
for(;y!=null;){z=y.y
if((z&1)===x){y.y=z|2
a.$1(y)
z=y.y^=1
w=y.z
if((z&4)!==0)this.co(y)
y.y&=4294967293
y=w}else y=y.z}this.c&=4294967293
if(this.d==null)this.bf()},
bf:function(){if((this.c&4)!==0&&this.r.a===0)this.r.be(null)
P.el(this.b)}},
cp:{"^":"ch;a,b,c,d,e,f,r,$ti",
gaO:function(){return P.ch.prototype.gaO.call(this)===!0&&(this.c&2)===0},
bc:function(){if((this.c&2)!==0)return new P.C("Cannot fire new event. Controller is already firing an event")
return this.dc()},
aV:function(a){var z=this.d
if(z==null)return
if(z===this.e){this.c|=2
z.au(a)
this.c&=4294967293
if(this.d==null)this.bf()
return}this.cd(new P.jK(this,a))},
ax:function(){if(this.d!=null)this.cd(new P.jL(this))
else this.r.be(null)}},
jK:{"^":"c;a,b",
$1:function(a){a.au(this.b)},
$S:function(){return H.bf(function(a){return{func:1,args:[[P.as,a]]}},this.a,"cp")}},
jL:{"^":"c;a",
$1:function(a){a.c4()},
$S:function(){return H.bf(function(a){return{func:1,args:[[P.as,a]]}},this.a,"cp")}},
iI:{"^":"b;$ti",
eg:[function(a,b){var z
if(a==null)a=new P.c8()
z=this.a
if(z.a!==0)throw H.a(new P.C("Future already completed"))
$.n.toString
z.dw(a,b)},function(a){return this.eg(a,null)},"ef","$2","$1","gee",2,2,3,0]},
iw:{"^":"iI;a,$ti",
ed:function(a,b){var z=this.a
if(z.a!==0)throw H.a(new P.C("Future already completed"))
z.be(b)}},
ck:{"^":"b;br:a<,b,c,d,e",
ge6:function(){return this.b.b},
gcG:function(){return(this.c&1)!==0},
gex:function(){return(this.c&2)!==0},
gcF:function(){return this.c===8},
ev:function(a){return this.b.b.bN(this.d,a)},
eD:function(a){if(this.c!==6)return!0
return this.b.b.bN(this.d,J.aW(a))},
eq:function(a){var z,y,x
z=this.e
y=J.q(a)
x=this.b.b
if(H.aA(z,{func:1,args:[,,]}))return x.eR(z,y.gae(a),a.ga7())
else return x.bN(z,y.gae(a))},
ew:function(){return this.b.b.cP(this.d)}},
X:{"^":"b;aq:a<,b,dW:c<,$ti",
gdN:function(){return this.a===2},
gbo:function(){return this.a>=4},
cR:function(a,b){var z,y
z=$.n
if(z!==C.d){z.toString
if(b!=null)b=P.cu(b,z)}y=new P.X(0,z,null,[null])
this.aJ(new P.ck(null,y,b==null?1:3,a,b))
return y},
bP:function(a){return this.cR(a,null)},
bS:function(a){var z,y
z=$.n
y=new P.X(0,z,null,this.$ti)
if(z!==C.d)z.toString
this.aJ(new P.ck(null,y,8,a,null))
return y},
aJ:function(a){var z,y
z=this.a
if(z<=1){a.a=this.c
this.c=a}else{if(z===2){y=this.c
if(!y.gbo()){y.aJ(a)
return}this.a=y.a
this.c=y.c}z=this.b
z.toString
P.aj(null,null,z,new P.j2(this,a))}},
cm:function(a){var z,y,x,w,v
z={}
z.a=a
if(a==null)return
y=this.a
if(y<=1){x=this.c
this.c=a
if(x!=null){for(w=a;w.gbr()!=null;)w=w.a
w.a=x}}else{if(y===2){v=this.c
if(!v.gbo()){v.cm(a)
return}this.a=v.a
this.c=v.c}z.a=this.aU(a)
y=this.b
y.toString
P.aj(null,null,y,new P.j9(z,this))}},
aT:function(){var z=this.c
this.c=null
return this.aU(z)},
aU:function(a){var z,y,x
for(z=a,y=null;z!=null;y=z,z=x){x=z.gbr()
z.a=y}return y},
ao:function(a){var z,y
z=this.$ti
if(H.be(a,"$isa8",z,"$asa8"))if(H.be(a,"$isX",z,null))P.bA(a,this)
else P.e2(a,this)
else{y=this.aT()
this.a=4
this.c=a
P.at(this,y)}},
aK:[function(a,b){var z=this.aT()
this.a=8
this.c=new P.bi(a,b)
P.at(this,z)},function(a){return this.aK(a,null)},"f1","$2","$1","gbj",2,2,3,0],
be:function(a){var z
if(H.be(a,"$isa8",this.$ti,"$asa8")){this.dA(a)
return}this.a=1
z=this.b
z.toString
P.aj(null,null,z,new P.j4(this,a))},
dA:function(a){var z
if(H.be(a,"$isX",this.$ti,null)){if(a.a===8){this.a=1
z=this.b
z.toString
P.aj(null,null,z,new P.j8(this,a))}else P.bA(a,this)
return}P.e2(a,this)},
dw:function(a,b){var z
this.a=1
z=this.b
z.toString
P.aj(null,null,z,new P.j3(this,a,b))},
dr:function(a,b){this.a=4
this.c=a},
$isa8:1,
m:{
e2:function(a,b){var z,y,x
b.a=1
try{a.cR(new P.j5(b),new P.j6(b))}catch(x){z=H.E(x)
y=H.S(x)
P.eG(new P.j7(b,z,y))}},
bA:function(a,b){var z,y,x
for(;a.gdN();)a=a.c
z=a.gbo()
y=b.c
if(z){b.c=null
x=b.aU(y)
b.a=a.a
b.c=a.c
P.at(b,x)}else{b.a=2
b.c=a
a.cm(y)}},
at:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n
z={}
z.a=a
for(y=a;!0;){x={}
w=y.a===8
if(b==null){if(w){v=y.c
y=y.b
u=J.aW(v)
t=v.ga7()
y.toString
P.ax(null,null,y,u,t)}return}for(;b.gbr()!=null;b=s){s=b.a
b.a=null
P.at(z.a,b)}r=z.a.c
x.a=w
x.b=r
y=!w
if(!y||b.gcG()||b.gcF()){q=b.ge6()
if(w){u=z.a.b
u.toString
u=u==null?q==null:u===q
if(!u)q.toString
else u=!0
u=!u}else u=!1
if(u){y=z.a
v=y.c
y=y.b
u=J.aW(v)
t=v.ga7()
y.toString
P.ax(null,null,y,u,t)
return}p=$.n
if(p==null?q!=null:p!==q)$.n=q
else p=null
if(b.gcF())new P.jc(z,x,w,b).$0()
else if(y){if(b.gcG())new P.jb(x,b,r).$0()}else if(b.gex())new P.ja(z,x,b).$0()
if(p!=null)$.n=p
y=x.b
if(!!J.m(y).$isa8){o=b.b
if(y.a>=4){n=o.c
o.c=null
b=o.aU(n)
o.a=y.a
o.c=y.c
z.a=y
continue}else P.bA(y,o)
return}}o=b.b
b=o.aT()
y=x.a
u=x.b
if(!y){o.a=4
o.c=u}else{o.a=8
o.c=u}z.a=o
y=o}}}},
j2:{"^":"c:1;a,b",
$0:function(){P.at(this.a,this.b)}},
j9:{"^":"c:1;a,b",
$0:function(){P.at(this.b,this.a.a)}},
j5:{"^":"c:0;a",
$1:function(a){var z=this.a
z.a=0
z.ao(a)}},
j6:{"^":"c:14;a",
$2:function(a,b){this.a.aK(a,b)},
$1:function(a){return this.$2(a,null)}},
j7:{"^":"c:1;a,b,c",
$0:function(){this.a.aK(this.b,this.c)}},
j4:{"^":"c:1;a,b",
$0:function(){var z,y
z=this.a
y=z.aT()
z.a=4
z.c=this.b
P.at(z,y)}},
j8:{"^":"c:1;a,b",
$0:function(){P.bA(this.b,this.a)}},
j3:{"^":"c:1;a,b,c",
$0:function(){this.a.aK(this.b,this.c)}},
jc:{"^":"c:2;a,b,c,d",
$0:function(){var z,y,x,w,v,u,t
z=null
try{z=this.d.ew()}catch(w){y=H.E(w)
x=H.S(w)
if(this.c){v=J.aW(this.a.a.c)
u=y
u=v==null?u==null:v===u
v=u}else v=!1
u=this.b
if(v)u.b=this.a.a.c
else u.b=new P.bi(y,x)
u.a=!0
return}if(!!J.m(z).$isa8){if(z instanceof P.X&&z.gaq()>=4){if(z.gaq()===8){v=this.b
v.b=z.gdW()
v.a=!0}return}t=this.a.a
v=this.b
v.b=z.bP(new P.jd(t))
v.a=!1}}},
jd:{"^":"c:0;a",
$1:function(a){return this.a}},
jb:{"^":"c:2;a,b,c",
$0:function(){var z,y,x,w
try{this.a.b=this.b.ev(this.c)}catch(x){z=H.E(x)
y=H.S(x)
w=this.a
w.b=new P.bi(z,y)
w.a=!0}}},
ja:{"^":"c:2;a,b,c",
$0:function(){var z,y,x,w,v,u,t,s
try{z=this.a.a.c
w=this.c
if(w.eD(z)===!0&&w.e!=null){v=this.b
v.b=w.eq(z)
v.a=!1}}catch(u){y=H.E(u)
x=H.S(u)
w=this.a
v=J.aW(w.a.c)
t=y
s=this.b
if(v==null?t==null:v===t)s.b=w.a.c
else s.b=new P.bi(y,x)
s.a=!0}}},
dW:{"^":"b;a,b"},
ab:{"^":"b;$ti",
a4:function(a,b){return new P.jn(b,this,[H.x(this,"ab",0),null])},
gh:function(a){var z,y
z={}
y=new P.X(0,$.n,null,[P.j])
z.a=0
this.M(new P.i1(z),!0,new P.i2(z,y),y.gbj())
return y},
gu:function(a){var z,y
z={}
y=new P.X(0,$.n,null,[P.aS])
z.a=null
z.a=this.M(new P.i_(z,y),!0,new P.i0(y),y.gbj())
return y},
a5:function(a){var z,y,x
z=H.x(this,"ab",0)
y=H.u([],[z])
x=new P.X(0,$.n,null,[[P.h,z]])
this.M(new P.i3(this,y),!0,new P.i4(y,x),x.gbj())
return x}},
i1:{"^":"c:0;a",
$1:function(a){++this.a.a}},
i2:{"^":"c:1;a,b",
$0:function(){this.b.ao(this.a.a)}},
i_:{"^":"c:0;a,b",
$1:function(a){P.k3(this.a.a,this.b,!1)}},
i0:{"^":"c:1;a",
$0:function(){this.a.ao(!0)}},
i3:{"^":"c;a,b",
$1:function(a){this.b.push(a)},
$S:function(){return H.bf(function(a){return{func:1,args:[a]}},this.a,"ab")}},
i4:{"^":"c:1;a,b",
$0:function(){this.b.ao(this.a)}},
dz:{"^":"b;$ti"},
dZ:{"^":"jG;a,$ti",
gC:function(a){return(H.aa(this.a)^892482866)>>>0},
w:function(a,b){if(b==null)return!1
if(this===b)return!0
if(!(b instanceof P.dZ))return!1
return b.a===this.a}},
iJ:{"^":"as;$ti",
bs:function(){return this.x.dR(this)},
aQ:[function(){this.x.dS(this)},"$0","gaP",0,0,2],
aS:[function(){this.x.dT(this)},"$0","gaR",0,0,2]},
as:{"^":"b;aq:e<,$ti",
aD:function(a,b){var z=this.e
if((z&8)!==0)return
this.e=(z+128|4)>>>0
if(z<128&&this.r!=null)this.r.cC()
if((z&4)===0&&(this.e&32)===0)this.cf(this.gaP())},
bH:function(a){return this.aD(a,null)},
bK:function(){var z=this.e
if((z&8)!==0)return
if(z>=128){z-=128
this.e=z
if(z<128){if((z&64)!==0){z=this.r
z=!z.gu(z)}else z=!1
if(z)this.r.b7(this)
else{z=(this.e&4294967291)>>>0
this.e=z
if((z&32)===0)this.cf(this.gaR())}}}},
ab:function(){var z=(this.e&4294967279)>>>0
this.e=z
if((z&8)===0)this.bg()
z=this.f
return z==null?$.$get$aH():z},
bg:function(){var z=(this.e|8)>>>0
this.e=z
if((z&64)!==0)this.r.cC()
if((this.e&32)===0)this.r=null
this.f=this.bs()},
au:["dd",function(a){var z=this.e
if((z&8)!==0)return
if(z<32)this.aV(a)
else this.bd(new P.iS(a,null,[H.x(this,"as",0)]))}],
bb:["de",function(a,b){var z=this.e
if((z&8)!==0)return
if(z<32)this.cr(a,b)
else this.bd(new P.iU(a,b,null))}],
c4:function(){var z=this.e
if((z&8)!==0)return
z=(z|2)>>>0
this.e=z
if(z<32)this.ax()
else this.bd(C.D)},
aQ:[function(){},"$0","gaP",0,0,2],
aS:[function(){},"$0","gaR",0,0,2],
bs:function(){return},
bd:function(a){var z,y
z=this.r
if(z==null){z=new P.jH(null,null,0,[H.x(this,"as",0)])
this.r=z}z.v(0,a)
y=this.e
if((y&64)===0){y=(y|64)>>>0
this.e=y
if(y<128)this.r.b7(this)}},
aV:function(a){var z=this.e
this.e=(z|32)>>>0
this.d.bO(this.a,a)
this.e=(this.e&4294967263)>>>0
this.bh((z&4)!==0)},
cr:function(a,b){var z,y
z=this.e
y=new P.iG(this,a,b)
if((z&1)!==0){this.e=(z|16)>>>0
this.bg()
z=this.f
if(!!J.m(z).$isa8&&z!==$.$get$aH())z.bS(y)
else y.$0()}else{y.$0()
this.bh((z&4)!==0)}},
ax:function(){var z,y
z=new P.iF(this)
this.bg()
this.e=(this.e|16)>>>0
y=this.f
if(!!J.m(y).$isa8&&y!==$.$get$aH())y.bS(z)
else z.$0()},
cf:function(a){var z=this.e
this.e=(z|32)>>>0
a.$0()
this.e=(this.e&4294967263)>>>0
this.bh((z&4)!==0)},
bh:function(a){var z,y
if((this.e&64)!==0){z=this.r
z=z.gu(z)}else z=!1
if(z){z=(this.e&4294967231)>>>0
this.e=z
if((z&4)!==0)if(z<128){z=this.r
z=z==null||z.gu(z)}else z=!1
else z=!1
if(z)this.e=(this.e&4294967291)>>>0}for(;!0;a=y){z=this.e
if((z&8)!==0){this.r=null
return}y=(z&4)!==0
if(a===y)break
this.e=(z^32)>>>0
if(y)this.aQ()
else this.aS()
this.e=(this.e&4294967263)>>>0}z=this.e
if((z&64)!==0&&z<128)this.r.b7(this)},
c0:function(a,b,c,d,e){var z,y
z=a==null?P.kp():a
y=this.d
y.toString
this.a=z
this.b=P.cu(b==null?P.kq():b,y)
this.c=c==null?P.et():c}},
iG:{"^":"c:2;a,b,c",
$0:function(){var z,y,x,w,v,u
z=this.a
y=z.e
if((y&8)!==0&&(y&16)===0)return
z.e=(y|32)>>>0
y=z.b
x=H.aA(y,{func:1,args:[P.b,P.b6]})
w=z.d
v=this.b
u=z.b
if(x)w.eS(u,v,this.c)
else w.bO(u,v)
z.e=(z.e&4294967263)>>>0}},
iF:{"^":"c:2;a",
$0:function(){var z,y
z=this.a
y=z.e
if((y&16)===0)return
z.e=(y|42)>>>0
z.d.bM(z.c)
z.e=(z.e&4294967263)>>>0}},
jG:{"^":"ab;$ti",
M:function(a,b,c,d){return this.a.e2(a,d,c,!0===b)},
b2:function(a,b,c){return this.M(a,null,b,c)}},
e_:{"^":"b;b3:a@"},
iS:{"^":"e_;b,a,$ti",
bI:function(a){a.aV(this.b)}},
iU:{"^":"e_;ae:b>,a7:c<,a",
bI:function(a){a.cr(this.b,this.c)}},
iT:{"^":"b;",
bI:function(a){a.ax()},
gb3:function(){return},
sb3:function(a){throw H.a(new P.C("No events after a done."))}},
jt:{"^":"b;aq:a<",
b7:function(a){var z=this.a
if(z===1)return
if(z>=1){this.a=1
return}P.eG(new P.ju(this,a))
this.a=1},
cC:function(){if(this.a===1)this.a=3}},
ju:{"^":"c:1;a,b",
$0:function(){var z,y,x,w
z=this.a
y=z.a
z.a=0
if(y===3)return
x=z.b
w=x.gb3()
z.b=w
if(w==null)z.c=null
x.bI(this.b)}},
jH:{"^":"jt;b,c,a,$ti",
gu:function(a){return this.c==null},
v:function(a,b){var z=this.c
if(z==null){this.c=b
this.b=b}else{z.sb3(b)
this.c=b}}},
iV:{"^":"b;a,aq:b<,c,$ti",
cq:function(){if((this.b&2)!==0)return
var z=this.a
z.toString
P.aj(null,null,z,this.gdZ())
this.b=(this.b|2)>>>0},
aD:function(a,b){this.b+=4},
bH:function(a){return this.aD(a,null)},
bK:function(){var z=this.b
if(z>=4){z-=4
this.b=z
if(z<4&&(z&1)===0)this.cq()}},
ab:function(){return $.$get$aH()},
ax:[function(){var z=(this.b&4294967293)>>>0
this.b=z
if(z>=4)return
this.b=(z|1)>>>0
z=this.c
if(z!=null)this.a.bM(z)},"$0","gdZ",0,0,2]},
k4:{"^":"c:1;a,b",
$0:function(){return this.a.ao(this.b)}},
cj:{"^":"ab;$ti",
M:function(a,b,c,d){return this.dF(a,d,c,!0===b)},
b2:function(a,b,c){return this.M(a,null,b,c)},
dF:function(a,b,c,d){return P.j1(this,a,b,c,d,H.x(this,"cj",0),H.x(this,"cj",1))},
cg:function(a,b){b.au(a)},
dL:function(a,b,c){c.bb(a,b)},
$asab:function(a,b){return[b]}},
e1:{"^":"as;x,y,a,b,c,d,e,f,r,$ti",
au:function(a){if((this.e&2)!==0)return
this.dd(a)},
bb:function(a,b){if((this.e&2)!==0)return
this.de(a,b)},
aQ:[function(){var z=this.y
if(z==null)return
z.bH(0)},"$0","gaP",0,0,2],
aS:[function(){var z=this.y
if(z==null)return
z.bK()},"$0","gaR",0,0,2],
bs:function(){var z=this.y
if(z!=null){this.y=null
return z.ab()}return},
f2:[function(a){this.x.cg(a,this)},"$1","gdI",2,0,function(){return H.bf(function(a,b){return{func:1,v:true,args:[a]}},this.$receiver,"e1")}],
f4:[function(a,b){this.x.dL(a,b,this)},"$2","gdK",4,0,15],
f3:[function(){this.c4()},"$0","gdJ",0,0,2],
dq:function(a,b,c,d,e,f,g){this.y=this.x.a.b2(this.gdI(),this.gdJ(),this.gdK())},
$asas:function(a,b){return[b]},
m:{
j1:function(a,b,c,d,e,f,g){var z,y
z=$.n
y=e?1:0
y=new P.e1(a,null,null,null,null,z,y,null,null,[f,g])
y.c0(b,c,d,e,g)
y.dq(a,b,c,d,e,f,g)
return y}}},
jn:{"^":"cj;b,a,$ti",
cg:function(a,b){var z,y,x,w
z=null
try{z=this.b.$1(a)}catch(w){y=H.E(w)
x=H.S(w)
P.k2(b,y,x)
return}b.au(z)}},
dE:{"^":"b;"},
bi:{"^":"b;ae:a>,a7:b<",
j:function(a){return H.d(this.a)},
$isG:1},
k1:{"^":"b;"},
ki:{"^":"c:1;a,b",
$0:function(){var z,y,x
z=this.a
y=z.a
if(y==null){x=new P.c8()
z.a=x
z=x}else z=y
y=this.b
if(y==null)throw H.a(z)
x=H.a(z)
x.stack=J.V(y)
throw x}},
jx:{"^":"k1;",
bM:function(a){var z,y,x,w
try{if(C.d===$.n){x=a.$0()
return x}x=P.ei(null,null,this,a)
return x}catch(w){z=H.E(w)
y=H.S(w)
x=P.ax(null,null,this,z,y)
return x}},
bO:function(a,b){var z,y,x,w
try{if(C.d===$.n){x=a.$1(b)
return x}x=P.ek(null,null,this,a,b)
return x}catch(w){z=H.E(w)
y=H.S(w)
x=P.ax(null,null,this,z,y)
return x}},
eS:function(a,b,c){var z,y,x,w
try{if(C.d===$.n){x=a.$2(b,c)
return x}x=P.ej(null,null,this,a,b,c)
return x}catch(w){z=H.E(w)
y=H.S(w)
x=P.ax(null,null,this,z,y)
return x}},
bx:function(a,b){if(b)return new P.jy(this,a)
else return new P.jz(this,a)},
cB:function(a,b){return new P.jA(this,a)},
i:function(a,b){return},
cP:function(a){if($.n===C.d)return a.$0()
return P.ei(null,null,this,a)},
bN:function(a,b){if($.n===C.d)return a.$1(b)
return P.ek(null,null,this,a,b)},
eR:function(a,b,c){if($.n===C.d)return a.$2(b,c)
return P.ej(null,null,this,a,b,c)}},
jy:{"^":"c:1;a,b",
$0:function(){return this.a.bM(this.b)}},
jz:{"^":"c:1;a,b",
$0:function(){return this.a.cP(this.b)}},
jA:{"^":"c:0;a,b",
$1:function(a){return this.a.bO(this.b,a)}}}],["","",,P,{"^":"",
de:function(){return new H.af(0,null,null,null,null,null,0,[null,null])},
P:function(a){return H.kx(a,new H.af(0,null,null,null,null,null,0,[null,null]))},
h0:function(a,b,c){var z,y
if(P.ct(a)){if(b==="("&&c===")")return"(...)"
return b+"..."+c}z=[]
y=$.$get$aR()
y.push(a)
try{P.kf(a,z)}finally{if(0>=y.length)return H.e(y,-1)
y.pop()}y=P.dA(b,z,", ")+c
return y.charCodeAt(0)==0?y:y},
bl:function(a,b,c){var z,y,x
if(P.ct(a))return b+"..."+c
z=new P.ag(b)
y=$.$get$aR()
y.push(a)
try{x=z
x.n=P.dA(x.gn(),a,", ")}finally{if(0>=y.length)return H.e(y,-1)
y.pop()}y=z
y.n=y.gn()+c
y=z.gn()
return y.charCodeAt(0)==0?y:y},
ct:function(a){var z,y
for(z=0;y=$.$get$aR(),z<y.length;++z)if(a===y[z])return!0
return!1},
kf:function(a,b){var z,y,x,w,v,u,t,s,r,q
z=a.gD(a)
y=0
x=0
while(!0){if(!(y<80||x<3))break
if(!z.l())return
w=H.d(z.gt())
b.push(w)
y+=w.length+2;++x}if(!z.l()){if(x<=5)return
if(0>=b.length)return H.e(b,-1)
v=b.pop()
if(0>=b.length)return H.e(b,-1)
u=b.pop()}else{t=z.gt();++x
if(!z.l()){if(x<=4){b.push(H.d(t))
return}v=H.d(t)
if(0>=b.length)return H.e(b,-1)
u=b.pop()
y+=v.length+2}else{s=z.gt();++x
for(;z.l();t=s,s=r){r=z.gt();++x
if(x>100){while(!0){if(!(y>75&&x>3))break
if(0>=b.length)return H.e(b,-1)
y-=b.pop().length+2;--x}b.push("...")
return}}u=H.d(t)
v=H.d(s)
y+=v.length+u.length+4}}if(x>b.length+2){y+=5
q="..."}else q=null
while(!0){if(!(y>80&&b.length>3))break
if(0>=b.length)return H.e(b,-1)
y-=b.pop().length+2
if(q==null){y+=5
q="..."}}if(q!=null)b.push(q)
b.push(u)
b.push(v)},
J:function(a,b,c,d){return new P.jg(0,null,null,null,null,null,0,[d])},
df:function(a,b){var z,y,x
z=P.J(null,null,null,b)
for(y=a.length,x=0;x<a.length;a.length===y||(0,H.a5)(a),++x)z.v(0,a[x])
return z},
hm:function(a){var z,y,x
z={}
if(P.ct(a))return"{...}"
y=new P.ag("")
try{$.$get$aR().push(a)
x=y
x.n=x.gn()+"{"
z.a=!0
a.H(0,new P.hn(z,y))
z=y
z.n=z.gn()+"}"}finally{z=$.$get$aR()
if(0>=z.length)return H.e(z,-1)
z.pop()}z=y.gn()
return z.charCodeAt(0)==0?z:z},
e5:{"^":"af;a,b,c,d,e,f,r,$ti",
aA:function(a){return H.kT(a)&0x3ffffff},
aB:function(a,b){var z,y,x
if(a==null)return-1
z=a.length
for(y=0;y<z;++y){x=a[y].gcK()
if(x==null?b==null:x===b)return y}return-1},
m:{
aN:function(a,b){return new P.e5(0,null,null,null,null,null,0,[a,b])}}},
jg:{"^":"je;a,b,c,d,e,f,r,$ti",
gD:function(a){var z=new P.bc(this,this.r,null,null)
z.c=this.e
return z},
gh:function(a){return this.a},
gu:function(a){return this.a===0},
F:function(a,b){var z,y
if(typeof b==="string"&&b!=="__proto__"){z=this.b
if(z==null)return!1
return z[b]!=null}else if(typeof b==="number"&&(b&0x3ffffff)===b){y=this.c
if(y==null)return!1
return y[b]!=null}else return this.dE(b)},
dE:function(a){var z=this.d
if(z==null)return!1
return this.aM(z[this.aL(a)],a)>=0},
bE:function(a){var z
if(!(typeof a==="string"&&a!=="__proto__"))z=typeof a==="number"&&(a&0x3ffffff)===a
else z=!0
if(z)return this.F(0,a)?a:null
else return this.dO(a)},
dO:function(a){var z,y,x
z=this.d
if(z==null)return
y=z[this.aL(a)]
x=this.aM(y,a)
if(x<0)return
return J.bO(y,x).gcc()},
v:function(a,b){var z,y,x
if(typeof b==="string"&&b!=="__proto__"){z=this.b
if(z==null){y=Object.create(null)
y["<non-identifier-key>"]=y
delete y["<non-identifier-key>"]
this.b=y
z=y}return this.c6(z,b)}else if(typeof b==="number"&&(b&0x3ffffff)===b){x=this.c
if(x==null){y=Object.create(null)
y["<non-identifier-key>"]=y
delete y["<non-identifier-key>"]
this.c=y
x=y}return this.c6(x,b)}else return this.a_(b)},
a_:function(a){var z,y,x
z=this.d
if(z==null){z=P.ji()
this.d=z}y=this.aL(a)
x=z[y]
if(x==null)z[y]=[this.bi(a)]
else{if(this.aM(x,a)>=0)return!1
x.push(this.bi(a))}return!0},
p:function(a,b){if(typeof b==="string"&&b!=="__proto__")return this.c7(this.b,b)
else if(typeof b==="number"&&(b&0x3ffffff)===b)return this.c7(this.c,b)
else return this.bt(b)},
bt:function(a){var z,y,x
z=this.d
if(z==null)return!1
y=z[this.aL(a)]
x=this.aM(y,a)
if(x<0)return!1
this.c8(y.splice(x,1)[0])
return!0},
ac:function(a){if(this.a>0){this.f=null
this.e=null
this.d=null
this.c=null
this.b=null
this.a=0
this.r=this.r+1&67108863}},
c6:function(a,b){if(a[b]!=null)return!1
a[b]=this.bi(b)
return!0},
c7:function(a,b){var z
if(a==null)return!1
z=a[b]
if(z==null)return!1
this.c8(z)
delete a[b]
return!0},
bi:function(a){var z,y
z=new P.jh(a,null,null)
if(this.e==null){this.f=z
this.e=z}else{y=this.f
z.c=y
y.b=z
this.f=z}++this.a
this.r=this.r+1&67108863
return z},
c8:function(a){var z,y
z=a.gdD()
y=a.b
if(z==null)this.e=y
else z.b=y
if(y==null)this.f=z
else y.c=z;--this.a
this.r=this.r+1&67108863},
aL:function(a){return J.ac(a)&0x3ffffff},
aM:function(a,b){var z,y
if(a==null)return-1
z=a.length
for(y=0;y<z;++y)if(J.z(a[y].gcc(),b))return y
return-1},
$isf:1,
$asf:null,
m:{
ji:function(){var z=Object.create(null)
z["<non-identifier-key>"]=z
delete z["<non-identifier-key>"]
return z}}},
jh:{"^":"b;cc:a<,b,dD:c<"},
bc:{"^":"b;a,b,c,d",
gt:function(){return this.d},
l:function(){var z=this.a
if(this.b!==z.r)throw H.a(new P.W(z))
else{z=this.c
if(z==null){this.d=null
return!1}else{this.d=z.a
this.c=z.b
return!0}}}},
je:{"^":"hS;$ti"},
ap:{"^":"hv;$ti"},
hv:{"^":"b+Q;",$ash:null,$asf:null,$ish:1,$isf:1},
Q:{"^":"b;$ti",
gD:function(a){return new H.bn(a,this.gh(a),0,null)},
G:function(a,b){return this.i(a,b)},
H:function(a,b){var z,y
z=this.gh(a)
for(y=0;y<z;++y){b.$1(this.i(a,y))
if(z!==this.gh(a))throw H.a(new P.W(a))}},
gu:function(a){return this.gh(a)===0},
gN:function(a){if(this.gh(a)===0)throw H.a(H.b_())
return this.i(a,0)},
a4:function(a,b){return new H.aK(a,b,[H.x(a,"Q",0),null])},
a6:function(a,b){var z,y,x
z=[H.x(a,"Q",0)]
if(b){y=H.u([],z)
C.b.sh(y,this.gh(a))}else y=H.u(new Array(this.gh(a)),z)
for(x=0;x<this.gh(a);++x){z=this.i(a,x)
if(x>=y.length)return H.e(y,x)
y[x]=z}return y},
a5:function(a){return this.a6(a,!0)},
p:function(a,b){var z
for(z=0;z<this.gh(a);++z)if(J.z(this.i(a,z),b)){this.A(a,z,this.gh(a)-1,a,z+1)
this.sh(a,this.gh(a)-1)
return!0}return!1},
ar:function(a,b,c,d){var z
P.a_(b,c,this.gh(a),null,null,null)
for(z=b;z<c;++z)this.q(a,z,d)},
A:["c_",function(a,b,c,d,e){var z,y,x,w,v
P.a_(b,c,this.gh(a),null,null,null)
z=c-b
if(z===0)return
y=e<0
if(y)H.v(P.D(e,0,null,"skipCount",null))
if(H.be(d,"$ish",[H.x(a,"Q",0)],"$ash")){x=e
w=d}else{if(y)H.v(P.D(e,0,null,"start",null))
w=new H.i7(d,e,null,[H.x(d,"Q",0)]).a6(0,!1)
x=0}y=J.w(w)
if(x+z>y.gh(w))throw H.a(H.db())
if(x<b)for(v=z-1;v>=0;--v)this.q(a,b+v,y.i(w,x+v))
else for(v=0;v<z;++v)this.q(a,b+v,y.i(w,x+v))},function(a,b,c,d){return this.A(a,b,c,d,0)},"R",null,null,"gf_",6,2,null,1],
P:function(a,b,c,d){var z,y,x,w,v
P.a_(b,c,this.gh(a),null,null,null)
d=C.a.a5(d)
if(typeof c!=="number")return c.aI()
z=c-b
y=d.length
x=b+y
if(z>=y){w=z-y
v=this.gh(a)-w
this.R(a,b,x,d)
if(w!==0){this.A(a,x,v,a,c)
this.sh(a,v)}}else{v=this.gh(a)+(y-z)
this.sh(a,v)
this.A(a,x,v,a,c)
this.R(a,b,x,d)}},
b0:function(a,b,c){var z
if(c>=this.gh(a))return-1
if(c<0)c=0
for(z=c;z<this.gh(a);++z)if(J.z(this.i(a,z),b))return z
return-1},
j:function(a){return P.bl(a,"[","]")},
$ish:1,
$ash:null,
$isf:1,
$asf:null},
hn:{"^":"c:16;a,b",
$2:function(a,b){var z,y
z=this.a
if(!z.a)this.b.n+=", "
z.a=!1
z=this.b
y=z.n+=H.d(a)
z.n=y+": "
z.n+=H.d(b)}},
hj:{"^":"aJ;a,b,c,d,$ti",
gD:function(a){return new P.jj(this,this.c,this.d,this.b,null)},
gu:function(a){return this.b===this.c},
gh:function(a){return(this.c-this.b&this.a.length-1)>>>0},
G:function(a,b){var z,y,x,w
z=(this.c-this.b&this.a.length-1)>>>0
if(typeof b!=="number")return H.r(b)
if(0>b||b>=z)H.v(P.a2(b,this,"index",null,z))
y=this.a
x=y.length
w=(this.b+b&x-1)>>>0
if(w<0||w>=x)return H.e(y,w)
return y[w]},
p:function(a,b){var z,y
for(z=this.b;z!==this.c;z=(z+1&this.a.length-1)>>>0){y=this.a
if(z<0||z>=y.length)return H.e(y,z)
if(J.z(y[z],b)){this.bt(z);++this.d
return!0}}return!1},
ac:function(a){var z,y,x,w,v
z=this.b
y=this.c
if(z!==y){for(x=this.a,w=x.length,v=w-1;z!==y;z=(z+1&v)>>>0){if(z<0||z>=w)return H.e(x,z)
x[z]=null}this.c=0
this.b=0;++this.d}},
j:function(a){return P.bl(this,"{","}")},
cO:function(){var z,y,x,w
z=this.b
if(z===this.c)throw H.a(H.b_());++this.d
y=this.a
x=y.length
if(z>=x)return H.e(y,z)
w=y[z]
y[z]=null
this.b=(z+1&x-1)>>>0
return w},
a_:function(a){var z,y,x
z=this.a
y=this.c
x=z.length
if(y<0||y>=x)return H.e(z,y)
z[y]=a
x=(y+1&x-1)>>>0
this.c=x
if(this.b===x)this.ce();++this.d},
bt:function(a){var z,y,x,w,v,u,t,s
z=this.a
y=z.length
x=y-1
w=this.b
v=this.c
if((a-w&x)>>>0<(v-a&x)>>>0){for(u=a;u!==w;u=t){t=(u-1&x)>>>0
if(t<0||t>=y)return H.e(z,t)
v=z[t]
if(u<0||u>=y)return H.e(z,u)
z[u]=v}if(w>=y)return H.e(z,w)
z[w]=null
this.b=(w+1&x)>>>0
return(a+1&x)>>>0}else{w=(v-1&x)>>>0
this.c=w
for(u=a;u!==w;u=s){s=(u+1&x)>>>0
if(s<0||s>=y)return H.e(z,s)
v=z[s]
if(u<0||u>=y)return H.e(z,u)
z[u]=v}if(w<0||w>=y)return H.e(z,w)
z[w]=null
return a}},
ce:function(){var z,y,x,w
z=new Array(this.a.length*2)
z.fixed$length=Array
y=H.u(z,this.$ti)
z=this.a
x=this.b
w=z.length-x
C.b.A(y,0,w,z,x)
C.b.A(y,w,w+this.b,this.a,0)
this.b=0
this.c=this.a.length
this.a=y},
di:function(a,b){var z=new Array(8)
z.fixed$length=Array
this.a=H.u(z,[b])},
$asf:null,
m:{
c3:function(a,b){var z=new P.hj(null,0,0,0,[b])
z.di(a,b)
return z}}},
jj:{"^":"b;a,b,c,d,e",
gt:function(){return this.e},
l:function(){var z,y,x
z=this.a
if(this.c!==z.d)H.v(new P.W(z))
y=this.d
if(y===this.b){this.e=null
return!1}z=z.a
x=z.length
if(y>=x)return H.e(z,y)
this.e=z[y]
this.d=(y+1&x-1)>>>0
return!0}},
hT:{"^":"b;$ti",
gu:function(a){return this.a===0},
Y:function(a,b){var z
for(z=J.ad(b);z.l();)this.v(0,z.gt())},
a4:function(a,b){return new H.bY(this,b,[H.y(this,0),null])},
j:function(a){return P.bl(this,"{","}")},
a3:function(a,b){var z,y
z=new P.bc(this,this.r,null,null)
z.c=this.e
if(!z.l())return""
if(b===""){y=""
do y+=H.d(z.d)
while(z.l())}else{y=H.d(z.d)
for(;z.l();)y=y+b+H.d(z.d)}return y.charCodeAt(0)==0?y:y},
G:function(a,b){var z,y,x
if(typeof b!=="number"||Math.floor(b)!==b)throw H.a(P.bT("index"))
if(b<0)H.v(P.D(b,0,null,"index",null))
for(z=new P.bc(this,this.r,null,null),z.c=this.e,y=0;z.l();){x=z.d
if(b===y)return x;++y}throw H.a(P.a2(b,this,"index",null,y))},
$isf:1,
$asf:null},
hS:{"^":"hT;$ti"}}],["","",,P,{"^":"",f6:{"^":"fg;a",
eG:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i
z=J.w(a)
c=P.a_(b,c,z.gh(a),null,null,null)
y=$.$get$dX()
if(typeof c!=="number")return H.r(c)
x=b
w=x
v=null
u=-1
t=-1
s=0
for(;x<c;x=r){r=x+1
q=z.E(a,x)
if(q===37){p=r+2
if(p<=c){o=H.bG(C.a.B(a,r))
n=H.bG(C.a.B(a,r+1))
m=o*16+n-(n&256)
if(m===37)m=-1
r=p}else m=-1}else m=q
if(0<=m&&m<=127){if(m<0||m>=y.length)return H.e(y,m)
l=y[m]
if(l>=0){m=C.a.E("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",l)
if(m===q)continue
q=m}else{if(l===-1){if(u<0){k=v==null?v:v.n.length
if(k==null)k=0
if(typeof k!=="number")return k.X()
u=k+(x-w)
t=x}++s
if(q===61)continue}q=m}if(l!==-2){if(v==null)v=new P.ag("")
v.n+=C.a.k(a,w,x)
v.n+=H.du(q)
w=r
continue}}throw H.a(new P.N("Invalid base64 data",a,x))}if(v!=null){z=v.n+=z.k(a,w,c)
k=z.length
if(u>=0)P.cP(a,t,c,u,s,k)
else{j=C.c.b6(k-1,4)+1
if(j===1)throw H.a(new P.N("Invalid base64 encoding length ",a,c))
for(;j<4;){z+="="
v.n=z;++j}}z=v.n
return C.a.P(a,b,c,z.charCodeAt(0)==0?z:z)}i=c-b
if(u>=0)P.cP(a,t,c,u,s,i)
else{j=C.e.b6(i,4)
if(j===1)throw H.a(new P.N("Invalid base64 encoding length ",a,c))
if(j>1)a=z.P(a,c,c,j===2?"==":"=")}return a},
m:{
cP:function(a,b,c,d,e,f){if(C.e.b6(f,4)!==0)throw H.a(new P.N("Invalid base64 padding, padded length must be multiple of four, is "+H.d(f),a,c))
if(d+e!==f)throw H.a(new P.N("Invalid base64 padding, '=' not at the end",a,b))
if(e>2)throw H.a(new P.N("Invalid base64 padding, more than two '=' characters",a,b))}}},f7:{"^":"fh;a"},fg:{"^":"b;"},fh:{"^":"b;"}}],["","",,P,{"^":"",
i6:function(a,b,c){var z,y,x
z=J.ad(a)
for(y=0;y<b;++y)if(!z.l())throw H.a(P.D(b,0,y,null,null))
x=[]
for(;z.l();)x.push(z.gt())
return H.dv(x)},
d3:function(a){if(typeof a==="number"||typeof a==="boolean"||null==a)return J.V(a)
if(typeof a==="string")return JSON.stringify(a)
return P.fu(a)},
fu:function(a){var z=J.m(a)
if(!!z.$isc)return z.j(a)
return H.bs(a)},
bk:function(a){return new P.j0(a)},
aq:function(a,b,c){var z,y
z=H.u([],[c])
for(y=J.ad(a);y.l();)z.push(y.gt())
if(b)return z
z.fixed$length=Array
return z},
hk:function(a,b,c,d){var z,y,x
z=H.u([],[d])
C.b.sh(z,a)
for(y=0;y<a;++y){x=b.$1(y)
if(y>=z.length)return H.e(z,y)
z[y]=x}return z},
bL:function(a){H.kY(H.d(a))},
hQ:function(a,b,c){return new H.h8(a,H.h9(a,!1,!0,!1),null,null)},
i5:function(a,b,c){var z,y
if(typeof a==="object"&&a!==null&&a.constructor===Array){z=a.length
c=P.a_(b,c,z,null,null,null)
if(b<=0){if(typeof c!=="number")return c.I()
y=c<z}else y=!0
return H.dv(y?J.f2(a,b,c):a)}if(!!J.m(a).$isdl)return H.hL(a,b,P.a_(b,c,a.length,null,null,null))
return P.i6(a,b,c)},
dU:function(){var z=H.hJ()
if(z!=null)return P.iq(z,0,null)
throw H.a(new P.l("'Uri.base' is not supported"))},
iq:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n,m
c=a.length
z=b+5
if(c>=z){y=((C.a.B(a,b+4)^58)*3|C.a.B(a,b)^100|C.a.B(a,b+1)^97|C.a.B(a,b+2)^116|C.a.B(a,b+3)^97)>>>0
if(y===0)return P.dT(b>0||c<c?C.a.k(a,b,c):a,5,null).gcT()
else if(y===32)return P.dT(C.a.k(a,z,c),0,null).gcT()}x=H.u(new Array(8),[P.j])
x[0]=0
w=b-1
x[1]=w
x[2]=w
x[7]=w
x[3]=b
x[4]=b
x[5]=c
x[6]=c
if(P.em(a,b,c,0,x)>=14)x[7]=c
v=x[1]
if(typeof v!=="number")return v.bT()
if(v>=b)if(P.em(a,b,v,20,x)===20)x[7]=v
w=x[2]
if(typeof w!=="number")return w.X()
u=w+1
t=x[3]
s=x[4]
r=x[5]
q=x[6]
if(typeof q!=="number")return q.I()
if(typeof r!=="number")return H.r(r)
if(q<r)r=q
if(typeof s!=="number")return s.I()
if(s<u||s<=v)s=r
if(typeof t!=="number")return t.I()
if(t<u)t=s
w=x[7]
if(typeof w!=="number")return w.I()
p=w<b
if(p)if(u>v+3){o=null
p=!1}else{w=t>b
if(w&&t+1===s){o=null
p=!1}else{if(!(r<c&&r===s+2&&C.a.V(a,"..",s)))n=r>s+2&&C.a.V(a,"/..",r-3)
else n=!0
if(n){o=null
p=!1}else{if(v===b+4)if(C.a.V(a,"file",b)){if(u<=b){if(!C.a.V(a,"/",s)){m="file:///"
y=3}else{m="file://"
y=2}a=m+C.a.k(a,s,c)
v-=b
z=y-b
r+=z
q+=z
c=a.length
b=0
u=7
t=7
s=7}else if(s===r)if(b===0&&!0){a=C.a.P(a,s,r,"/");++r;++q;++c}else{a=C.a.k(a,b,s)+"/"+C.a.k(a,r,c)
v-=b
u-=b
t-=b
s-=b
z=1-b
r+=z
q+=z
c=a.length
b=0}o="file"}else if(C.a.V(a,"http",b)){if(w&&t+3===s&&C.a.V(a,"80",t+1))if(b===0&&!0){a=C.a.P(a,t,s,"")
s-=3
r-=3
q-=3
c-=3}else{a=C.a.k(a,b,t)+C.a.k(a,s,c)
v-=b
u-=b
t-=b
z=3+b
s-=z
r-=z
q-=z
c=a.length
b=0}o="http"}else o=null
else if(v===z&&C.a.V(a,"https",b)){if(w&&t+4===s&&C.a.V(a,"443",t+1))if(b===0&&!0){a=C.a.P(a,t,s,"")
s-=4
r-=4
q-=4
c-=3}else{a=C.a.k(a,b,t)+C.a.k(a,s,c)
v-=b
u-=b
t-=b
z=4+b
s-=z
r-=z
q-=z
c=a.length
b=0}o="https"}else o=null
p=!0}}}else o=null
if(p){if(b>0||c<a.length){a=C.a.k(a,b,c)
v-=b
u-=b
t-=b
s-=b
r-=b
q-=b}return new P.jF(a,v,u,t,s,r,q,o,null)}return P.jO(a,b,c,v,u,t,s,r,q,o)},
io:function(a,b,c){var z,y,x,w,v,u,t,s,r
z=new P.ip(a)
y=H.eh(4)
x=new Uint8Array(y)
for(w=b,v=w,u=0;w<c;++w){t=C.a.E(a,w)
if(t!==46){if((t^48)>9)z.$2("invalid character",w)}else{if(u===3)z.$2("IPv4 address should contain exactly 4 parts",w)
s=H.ar(C.a.k(a,v,w),null,null)
if(J.bN(s,255))z.$2("each part must be in the range 0..255",v)
r=u+1
if(u>=y)return H.e(x,u)
x[u]=s
v=w+1
u=r}}if(u!==3)z.$2("IPv4 address should contain exactly 4 parts",c)
s=H.ar(C.a.k(a,v,c),null,null)
if(J.bN(s,255))z.$2("each part must be in the range 0..255",v)
if(u>=y)return H.e(x,u)
x[u]=s
return x},
dV:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i
if(c==null)c=a.length
z=new P.ir(a)
y=new P.is(a,z)
if(a.length<2)z.$1("address is too short")
x=[]
for(w=b,v=w,u=!1,t=!1;w<c;++w){s=C.a.E(a,w)
if(s===58){if(w===b){++w
if(C.a.E(a,w)!==58)z.$2("invalid start colon.",w)
v=w}if(w===v){if(u)z.$2("only one wildcard `::` is allowed",w)
x.push(-1)
u=!0}else x.push(y.$2(v,w))
v=w+1}else if(s===46)t=!0}if(x.length===0)z.$1("too few parts")
r=v===c
q=J.z(C.b.gb1(x),-1)
if(r&&!q)z.$2("expected a part after last `:`",c)
if(!r)if(!t)x.push(y.$2(v,c))
else{p=P.io(a,v,c)
o=p[0]
if(typeof o!=="number")return o.b9()
n=p[1]
if(typeof n!=="number")return H.r(n)
x.push((o<<8|n)>>>0)
n=p[2]
if(typeof n!=="number")return n.b9()
o=p[3]
if(typeof o!=="number")return H.r(o)
x.push((n<<8|o)>>>0)}if(u){if(x.length>7)z.$1("an address with a wildcard must have less than 7 parts")}else if(x.length!==8)z.$1("an address without a wildcard must contain exactly 8 parts")
m=new Uint8Array(16)
for(w=0,l=0;w<x.length;++w){k=x[w]
if(J.m(k).w(k,-1)){j=9-x.length
for(i=0;i<j;++i){if(l<0||l>=16)return H.e(m,l)
m[l]=0
o=l+1
if(o>=16)return H.e(m,o)
m[o]=0
l+=2}}else{if(typeof k!=="number")return k.d6()
o=C.e.a9(k,8)
if(l<0||l>=16)return H.e(m,l)
m[l]=o
o=l+1
if(o>=16)return H.e(m,o)
m[o]=k&255
l+=2}}return m},
k8:function(){var z,y,x,w,v
z=P.hk(22,new P.ka(),!0,P.b7)
y=new P.k9(z)
x=new P.kb()
w=new P.kc()
v=y.$2(0,225)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",1)
x.$3(v,".",14)
x.$3(v,":",34)
x.$3(v,"/",3)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(14,225)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",1)
x.$3(v,".",15)
x.$3(v,":",34)
x.$3(v,"/",234)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(15,225)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",1)
x.$3(v,"%",225)
x.$3(v,":",34)
x.$3(v,"/",9)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(1,225)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",1)
x.$3(v,":",34)
x.$3(v,"/",10)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(2,235)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",139)
x.$3(v,"/",131)
x.$3(v,".",146)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(3,235)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",11)
x.$3(v,"/",68)
x.$3(v,".",18)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(4,229)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",5)
w.$3(v,"AZ",229)
x.$3(v,":",102)
x.$3(v,"@",68)
x.$3(v,"[",232)
x.$3(v,"/",138)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(5,229)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",5)
w.$3(v,"AZ",229)
x.$3(v,":",102)
x.$3(v,"@",68)
x.$3(v,"/",138)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(6,231)
w.$3(v,"19",7)
x.$3(v,"@",68)
x.$3(v,"/",138)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(7,231)
w.$3(v,"09",7)
x.$3(v,"@",68)
x.$3(v,"/",138)
x.$3(v,"?",172)
x.$3(v,"#",205)
x.$3(y.$2(8,8),"]",5)
v=y.$2(9,235)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",11)
x.$3(v,".",16)
x.$3(v,"/",234)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(16,235)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",11)
x.$3(v,".",17)
x.$3(v,"/",234)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(17,235)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",11)
x.$3(v,"/",9)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(10,235)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",11)
x.$3(v,".",18)
x.$3(v,"/",234)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(18,235)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",11)
x.$3(v,".",19)
x.$3(v,"/",234)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(19,235)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",11)
x.$3(v,"/",234)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(11,235)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",11)
x.$3(v,"/",10)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(12,236)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",12)
x.$3(v,"?",12)
x.$3(v,"#",205)
v=y.$2(13,237)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",13)
x.$3(v,"?",13)
w.$3(y.$2(20,245),"az",21)
v=y.$2(21,245)
w.$3(v,"az",21)
w.$3(v,"09",21)
x.$3(v,"+-.",21)
return z},
em:function(a,b,c,d,e){var z,y,x,w,v,u
z=$.$get$en()
for(y=b;y<c;++y){if(d<0||d>=z.length)return H.e(z,d)
x=z[d]
w=C.a.B(a,y)^96
v=J.bO(x,w>95?31:w)
if(typeof v!=="number")return v.eX()
d=v&31
u=C.e.a9(v,5)
if(u>=8)return H.e(e,u)
e[u]=y}return d},
aS:{"^":"b;"},
"+bool":0,
ak:{"^":"bg;"},
"+double":0,
ao:{"^":"b;a",
X:function(a,b){return new P.ao(C.c.X(this.a,b.gcb()))},
I:function(a,b){return C.c.I(this.a,b.gcb())},
ak:function(a,b){return C.c.ak(this.a,b.gcb())},
w:function(a,b){if(b==null)return!1
if(!(b instanceof P.ao))return!1
return this.a===b.a},
gC:function(a){return this.a&0x1FFFFFFF},
j:function(a){var z,y,x,w,v
z=new P.fp()
y=this.a
if(y<0)return"-"+new P.ao(0-y).j(0)
x=z.$1(C.c.K(y,6e7)%60)
w=z.$1(C.c.K(y,1e6)%60)
v=new P.fo().$1(y%1e6)
return""+C.c.K(y,36e8)+":"+H.d(x)+":"+H.d(w)+"."+H.d(v)}},
fo:{"^":"c:8;",
$1:function(a){if(a>=1e5)return""+a
if(a>=1e4)return"0"+a
if(a>=1000)return"00"+a
if(a>=100)return"000"+a
if(a>=10)return"0000"+a
return"00000"+a}},
fp:{"^":"c:8;",
$1:function(a){if(a>=10)return""+a
return"0"+a}},
G:{"^":"b;",
ga7:function(){return H.S(this.$thrownJsError)}},
c8:{"^":"G;",
j:function(a){return"Throw of null."}},
Z:{"^":"G;a,b,c,d",
gbl:function(){return"Invalid argument"+(!this.a?"(s)":"")},
gbk:function(){return""},
j:function(a){var z,y,x,w,v,u
z=this.c
y=z!=null?" ("+z+")":""
z=this.d
x=z==null?"":": "+H.d(z)
w=this.gbl()+y+x
if(!this.a)return w
v=this.gbk()
u=P.d3(this.b)
return w+v+": "+H.d(u)},
m:{
aD:function(a){return new P.Z(!1,null,null,a)},
aE:function(a,b,c){return new P.Z(!0,a,b,c)},
bT:function(a){return new P.Z(!1,null,a,"Must not be null")}}},
b4:{"^":"Z;e,f,a,b,c,d",
gbl:function(){return"RangeError"},
gbk:function(){var z,y,x
z=this.e
if(z==null){z=this.f
y=z!=null?": Not less than or equal to "+H.d(z):""}else{x=this.f
if(x==null)y=": Not greater than or equal to "+H.d(z)
else{if(typeof x!=="number")return x.ak()
if(x>z)y=": Not in range "+H.d(z)+".."+H.d(x)+", inclusive"
else y=x<z?": Valid value range is empty":": Only valid value is "+H.d(z)}}return y},
m:{
hM:function(a){return new P.b4(null,null,!1,null,null,a)},
bt:function(a,b,c){return new P.b4(null,null,!0,a,b,"Value not in range")},
D:function(a,b,c,d,e){return new P.b4(b,c,!0,a,d,"Invalid value")},
a_:function(a,b,c,d,e,f){var z
if(typeof a!=="number")return H.r(a)
if(!(0>a)){if(typeof c!=="number")return H.r(c)
z=a>c}else z=!0
if(z)throw H.a(P.D(a,0,c,"start",f))
if(b!=null){if(typeof b!=="number")return H.r(b)
if(!(a>b)){if(typeof c!=="number")return H.r(c)
z=b>c}else z=!0
if(z)throw H.a(P.D(b,a,c,"end",f))
return b}return c}}},
fH:{"^":"Z;e,h:f>,a,b,c,d",
gbl:function(){return"RangeError"},
gbk:function(){if(J.cE(this.b,0))return": index must not be negative"
var z=this.f
if(z===0)return": no indices are valid"
return": index should be less than "+H.d(z)},
m:{
a2:function(a,b,c,d,e){var z=e!=null?e:J.U(b)
return new P.fH(b,z,!0,a,c,"Index out of range")}}},
l:{"^":"G;a",
j:function(a){return"Unsupported operation: "+this.a}},
b8:{"^":"G;a",
j:function(a){var z=this.a
return z!=null?"UnimplementedError: "+H.d(z):"UnimplementedError"}},
C:{"^":"G;a",
j:function(a){return"Bad state: "+this.a}},
W:{"^":"G;a",
j:function(a){var z=this.a
if(z==null)return"Concurrent modification during iteration."
return"Concurrent modification during iteration: "+H.d(P.d3(z))+"."}},
hw:{"^":"b;",
j:function(a){return"Out of Memory"},
ga7:function(){return},
$isG:1},
dy:{"^":"b;",
j:function(a){return"Stack Overflow"},
ga7:function(){return},
$isG:1},
fl:{"^":"G;a",
j:function(a){var z=this.a
return z==null?"Reading static variable during its initialization":"Reading static variable '"+H.d(z)+"' during its initialization"}},
j0:{"^":"b;a",
j:function(a){var z=this.a
if(z==null)return"Exception"
return"Exception: "+H.d(z)}},
N:{"^":"b;a,b,c",
j:function(a){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l
z=this.a
y=""!==z?"FormatException: "+z:"FormatException"
x=this.c
w=this.b
if(typeof w!=="string")return x!=null?y+(" (at offset "+H.d(x)+")"):y
if(x!=null){if(typeof x!=="number")return x.I()
z=x<0||x>w.length}else z=!1
if(z)x=null
if(x==null){if(w.length>78)w=C.a.k(w,0,75)+"..."
return y+"\n"+w}if(typeof x!=="number")return H.r(x)
v=1
u=0
t=!1
s=0
for(;s<x;++s){r=C.a.B(w,s)
if(r===10){if(u!==s||!t)++v
u=s+1
t=!1}else if(r===13){++v
u=s+1
t=!0}}y=v>1?y+(" (at line "+v+", character "+H.d(x-u+1)+")\n"):y+(" (at character "+H.d(x+1)+")\n")
q=w.length
for(s=x;s<w.length;++s){r=C.a.E(w,s)
if(r===10||r===13){q=s
break}}if(q-u>78)if(x-u<75){p=u+75
o=u
n=""
m="..."}else{if(q-x<75){o=q-75
p=q
m=""}else{o=x-36
p=x+36
m="..."}n="..."}else{p=q
o=u
n=""
m=""}l=C.a.k(w,o,p)
return y+n+l+m+"\n"+C.a.cX(" ",x-o+n.length)+"^\n"}},
fv:{"^":"b;a,ck",
j:function(a){return"Expando:"+H.d(this.a)},
i:function(a,b){var z,y
z=this.ck
if(typeof z!=="string"){if(b==null||typeof b==="boolean"||typeof b==="number"||typeof b==="string")H.v(P.aE(b,"Expandos are not allowed on strings, numbers, booleans or null",null))
return z.get(b)}y=H.cb(b,"expando$values")
return y==null?null:H.cb(y,z)},
q:function(a,b,c){var z,y
z=this.ck
if(typeof z!=="string")z.set(b,c)
else{y=H.cb(b,"expando$values")
if(y==null){y=new P.b()
H.dt(b,"expando$values",y)}H.dt(y,z,c)}}},
j:{"^":"bg;"},
"+int":0,
H:{"^":"b;$ti",
a4:function(a,b){return H.bp(this,b,H.x(this,"H",0),null)},
b4:["d9",function(a,b){return new H.bw(this,b,[H.x(this,"H",0)])}],
a6:function(a,b){return P.aq(this,!0,H.x(this,"H",0))},
a5:function(a){return this.a6(a,!0)},
gh:function(a){var z,y
z=this.gD(this)
for(y=0;z.l();)++y
return y},
gu:function(a){return!this.gD(this).l()},
gan:function(a){var z,y
z=this.gD(this)
if(!z.l())throw H.a(H.b_())
y=z.gt()
if(z.l())throw H.a(H.h1())
return y},
G:function(a,b){var z,y,x
if(typeof b!=="number"||Math.floor(b)!==b)throw H.a(P.bT("index"))
if(b<0)H.v(P.D(b,0,null,"index",null))
for(z=this.gD(this),y=0;z.l();){x=z.gt()
if(b===y)return x;++y}throw H.a(P.a2(b,this,"index",null,y))},
j:function(a){return P.h0(this,"(",")")}},
bm:{"^":"b;"},
h:{"^":"b;$ti",$ash:null,$isf:1,$asf:null},
"+List":0,
br:{"^":"b;",
gC:function(a){return P.b.prototype.gC.call(this,this)},
j:function(a){return"null"}},
"+Null":0,
bg:{"^":"b;"},
"+num":0,
b:{"^":";",
w:function(a,b){return this===b},
gC:function(a){return H.aa(this)},
j:function(a){return H.bs(this)},
toString:function(){return this.j(this)}},
b6:{"^":"b;"},
o:{"^":"b;"},
"+String":0,
ag:{"^":"b;n<",
gh:function(a){return this.n.length},
gu:function(a){return this.n.length===0},
j:function(a){var z=this.n
return z.charCodeAt(0)==0?z:z},
m:{
dA:function(a,b,c){var z=J.ad(b)
if(!z.l())return a
if(c.length===0){do a+=H.d(z.gt())
while(z.l())}else{a+=H.d(z.gt())
for(;z.l();)a=a+c+H.d(z.gt())}return a}}},
ip:{"^":"c:17;a",
$2:function(a,b){throw H.a(new P.N("Illegal IPv4 address, "+a,this.a,b))}},
ir:{"^":"c:18;a",
$2:function(a,b){throw H.a(new P.N("Illegal IPv6 address, "+a,this.a,b))},
$1:function(a){return this.$2(a,null)}},
is:{"^":"c:19;a,b",
$2:function(a,b){var z,y
if(b-a>4)this.b.$2("an IPv6 part can only contain a maximum of 4 hex digits",a)
z=H.ar(C.a.k(this.a,a,b),16,null)
y=J.cz(z)
if(y.I(z,0)||y.ak(z,65535))this.b.$2("each part must be in the range of `0x0..0xFFFF`",a)
return z}},
e8:{"^":"b;bW:a<,b,c,d,bG:e>,f,r,x,y,z,Q,ch",
gcV:function(){return this.b},
gaY:function(a){var z=this.c
if(z==null)return""
if(C.a.L(z,"["))return C.a.k(z,1,z.length-1)
return z},
gbJ:function(a){var z=this.d
if(z==null)return P.e9(this.a)
return z},
gcM:function(a){var z=this.f
return z==null?"":z},
gcE:function(){var z=this.r
return z==null?"":z},
gcH:function(){return this.c!=null},
gcJ:function(){return this.f!=null},
gcI:function(){return this.r!=null},
j:function(a){var z=this.y
if(z==null){z=this.ci()
this.y=z}return z},
ci:function(){var z,y,x,w
z=this.a
y=z.length!==0?z+":":""
x=this.c
w=x==null
if(!w||z==="file"){z=y+"//"
y=this.b
if(y.length!==0)z=z+H.d(y)+"@"
if(!w)z+=x
y=this.d
if(y!=null)z=z+":"+H.d(y)}else z=y
z+=H.d(this.e)
y=this.f
if(y!=null)z=z+"?"+y
y=this.r
if(y!=null)z=z+"#"+y
return z.charCodeAt(0)==0?z:z},
w:function(a,b){var z,y,x
if(b==null)return!1
if(this===b)return!0
z=J.m(b)
if(!!z.$iscf){if(this.a===b.gbW())if(this.c!=null===b.gcH()){y=this.b
x=b.gcV()
if(y==null?x==null:y===x){y=this.gaY(this)
x=z.gaY(b)
if(y==null?x==null:y===x)if(J.z(this.gbJ(this),z.gbJ(b)))if(J.z(this.e,z.gbG(b))){y=this.f
x=y==null
if(!x===b.gcJ()){if(x)y=""
if(y===z.gcM(b)){z=this.r
y=z==null
if(!y===b.gcI()){if(y)z=""
z=z===b.gcE()}else z=!1}else z=!1}else z=!1}else z=!1
else z=!1
else z=!1}else z=!1}else z=!1
else z=!1
return z}return!1},
gC:function(a){var z=this.z
if(z==null){z=this.y
if(z==null){z=this.ci()
this.y=z}z=C.a.gC(z)
this.z=z}return z},
$iscf:1,
m:{
jO:function(a,b,c,d,e,f,g,h,i,j){var z,y,x,w,v,u,t
if(j==null)if(d>b)j=P.jV(a,b,d)
else{if(d===b)P.aO(a,b,"Invalid empty scheme")
j=""}if(e>b){z=d+3
y=z<e?P.jW(a,z,e-1):""
x=P.jR(a,e,f,!1)
if(typeof f!=="number")return f.X()
w=f+1
if(typeof g!=="number")return H.r(g)
v=w<g?P.jT(H.ar(C.a.k(a,w,g),null,new P.ks(a,f)),j):null}else{y=""
x=null
v=null}u=P.jS(a,g,h,null,j,x!=null)
if(typeof h!=="number")return h.I()
t=h<i?P.jU(a,h+1,i,null):null
return new P.e8(j,y,x,v,u,t,i<c?P.jQ(a,i+1,c):null,null,null,null,null,null)},
e9:function(a){if(a==="http")return 80
if(a==="https")return 443
return 0},
aO:function(a,b,c){throw H.a(new P.N(c,a,b))},
jT:function(a,b){if(a!=null&&J.z(a,P.e9(b)))return
return a},
jR:function(a,b,c,d){var z,y
if(b===c)return""
if(C.a.E(a,b)===91){if(typeof c!=="number")return c.aI()
z=c-1
if(C.a.E(a,z)!==93)P.aO(a,b,"Missing end `]` to match `[` in host")
P.dV(a,b+1,z)
return C.a.k(a,b,c).toLowerCase()}if(typeof c!=="number")return H.r(c)
y=b
for(;y<c;++y)if(C.a.E(a,y)===58){P.dV(a,b,c)
return"["+a+"]"}return P.jY(a,b,c)},
jY:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p
if(typeof c!=="number")return H.r(c)
z=b
y=z
x=null
w=!0
for(;z<c;){v=C.a.E(a,z)
if(v===37){u=P.ee(a,z,!0)
t=u==null
if(t&&w){z+=3
continue}if(x==null)x=new P.ag("")
s=C.a.k(a,y,z)
r=x.n+=!w?s.toLowerCase():s
if(t){u=C.a.k(a,z,z+3)
q=3}else if(u==="%"){u="%25"
q=1}else q=3
x.n=r+u
z+=q
y=z
w=!0}else{if(v<127){t=v>>>4
if(t>=8)return H.e(C.w,t)
t=(C.w[t]&1<<(v&15))!==0}else t=!1
if(t){if(w&&65<=v&&90>=v){if(x==null)x=new P.ag("")
if(y<z){x.n+=C.a.k(a,y,z)
y=z}w=!1}++z}else{if(v<=93){t=v>>>4
if(t>=8)return H.e(C.j,t)
t=(C.j[t]&1<<(v&15))!==0}else t=!1
if(t)P.aO(a,z,"Invalid character")
else{if((v&64512)===55296&&z+1<c){p=C.a.E(a,z+1)
if((p&64512)===56320){v=65536|(v&1023)<<10|p&1023
q=2}else q=1}else q=1
if(x==null)x=new P.ag("")
s=C.a.k(a,y,z)
x.n+=!w?s.toLowerCase():s
x.n+=P.ea(v)
z+=q
y=z}}}}if(x==null)return C.a.k(a,b,c)
if(y<c){s=C.a.k(a,y,c)
x.n+=!w?s.toLowerCase():s}t=x.n
return t.charCodeAt(0)==0?t:t},
jV:function(a,b,c){var z,y,x,w
if(b===c)return""
if(!P.ec(C.a.B(a,b)))P.aO(a,b,"Scheme not starting with alphabetic character")
for(z=b,y=!1;z<c;++z){x=C.a.B(a,z)
if(x<128){w=x>>>4
if(w>=8)return H.e(C.l,w)
w=(C.l[w]&1<<(x&15))!==0}else w=!1
if(!w)P.aO(a,z,"Illegal scheme character")
if(65<=x&&x<=90)y=!0}a=C.a.k(a,b,c)
return P.jP(y?a.toLowerCase():a)},
jP:function(a){if(a==="http")return"http"
if(a==="file")return"file"
if(a==="https")return"https"
if(a==="package")return"package"
return a},
jW:function(a,b,c){var z=P.av(a,b,c,C.V,!1)
return z==null?C.a.k(a,b,c):z},
jS:function(a,b,c,d,e,f){var z,y,x
z=e==="file"
y=z||f
x=P.av(a,b,c,C.x,!1)
if(x==null)x=C.a.k(a,b,c)
if(x.length===0){if(z)return"/"}else if(y&&!C.a.L(x,"/"))x="/"+x
return P.jX(x,e,f)},
jX:function(a,b,c){var z=b.length===0
if(z&&!c&&!C.a.L(a,"/"))return P.jZ(a,!z||c)
return P.k_(a)},
jU:function(a,b,c,d){var z=P.av(a,b,c,C.k,!1)
return z==null?C.a.k(a,b,c):z},
jQ:function(a,b,c){var z=P.av(a,b,c,C.k,!1)
return z==null?C.a.k(a,b,c):z},
ee:function(a,b,c){var z,y,x,w,v,u
z=b+2
if(z>=a.length)return"%"
y=C.a.E(a,b+1)
x=C.a.E(a,z)
w=H.bG(y)
v=H.bG(x)
if(w<0||v<0)return"%"
u=w*16+v
if(u<127){z=C.c.a9(u,4)
if(z>=8)return H.e(C.v,z)
z=(C.v[z]&1<<(u&15))!==0}else z=!1
if(z)return H.du(c&&65<=u&&90>=u?(u|32)>>>0:u)
if(y>=97||x>=97)return C.a.k(a,b,b+3).toUpperCase()
return},
ea:function(a){var z,y,x,w,v,u,t,s
if(a<128){z=new Array(3)
z.fixed$length=Array
z[0]=37
z[1]=C.a.B("0123456789ABCDEF",a>>>4)
z[2]=C.a.B("0123456789ABCDEF",a&15)}else{if(a>2047)if(a>65535){y=240
x=4}else{y=224
x=3}else{y=192
x=2}w=3*x
z=new Array(w)
z.fixed$length=Array
for(v=0;--x,x>=0;y=128){u=C.c.e0(a,6*x)&63|y
if(v>=w)return H.e(z,v)
z[v]=37
t=v+1
s=C.a.B("0123456789ABCDEF",u>>>4)
if(t>=w)return H.e(z,t)
z[t]=s
s=v+2
t=C.a.B("0123456789ABCDEF",u&15)
if(s>=w)return H.e(z,s)
z[s]=t
v+=3}}return P.i5(z,0,null)},
av:function(a,b,c,d,e){var z,y,x,w,v,u,t,s,r,q
z=!e
y=J.aT(a)
x=b
w=x
v=null
while(!0){if(typeof x!=="number")return x.I()
if(typeof c!=="number")return H.r(c)
if(!(x<c))break
c$0:{u=y.E(a,x)
if(u<127){t=u>>>4
if(t>=8)return H.e(d,t)
t=(d[t]&1<<(u&15))!==0}else t=!1
if(t)++x
else{if(u===37){s=P.ee(a,x,!1)
if(s==null){x+=3
break c$0}if("%"===s){s="%25"
r=1}else r=3}else{if(z)if(u<=93){t=u>>>4
if(t>=8)return H.e(C.j,t)
t=(C.j[t]&1<<(u&15))!==0}else t=!1
else t=!1
if(t){P.aO(a,x,"Invalid character")
s=null
r=null}else{if((u&64512)===55296){t=x+1
if(t<c){q=C.a.E(a,t)
if((q&64512)===56320){u=65536|(u&1023)<<10|q&1023
r=2}else r=1}else r=1}else r=1
s=P.ea(u)}}if(v==null)v=new P.ag("")
v.n+=C.a.k(a,w,x)
v.n+=H.d(s)
if(typeof r!=="number")return H.r(r)
x+=r
w=x}}}if(v==null)return
if(typeof w!=="number")return w.I()
if(w<c)v.n+=y.k(a,w,c)
z=v.n
return z.charCodeAt(0)==0?z:z},
ed:function(a){if(C.a.L(a,"."))return!0
return C.a.b_(a,"/.")!==-1},
k_:function(a){var z,y,x,w,v,u,t
if(!P.ed(a))return a
z=[]
for(y=a.split("/"),x=y.length,w=!1,v=0;v<y.length;y.length===x||(0,H.a5)(y),++v){u=y[v]
if(J.z(u,"..")){t=z.length
if(t!==0){if(0>=t)return H.e(z,-1)
z.pop()
if(z.length===0)z.push("")}w=!0}else if("."===u)w=!0
else{z.push(u)
w=!1}}if(w)z.push("")
return C.b.a3(z,"/")},
jZ:function(a,b){var z,y,x,w,v,u
if(!P.ed(a))return!b?P.eb(a):a
z=[]
for(y=a.split("/"),x=y.length,w=!1,v=0;v<y.length;y.length===x||(0,H.a5)(y),++v){u=y[v]
if(".."===u)if(z.length!==0&&!J.z(C.b.gb1(z),"..")){if(0>=z.length)return H.e(z,-1)
z.pop()
w=!0}else{z.push("..")
w=!1}else if("."===u)w=!0
else{z.push(u)
w=!1}}y=z.length
if(y!==0)if(y===1){if(0>=y)return H.e(z,0)
y=J.cI(z[0])===!0}else y=!1
else y=!0
if(y)return"./"
if(w||J.z(C.b.gb1(z),".."))z.push("")
if(!b){if(0>=z.length)return H.e(z,0)
y=P.eb(z[0])
if(0>=z.length)return H.e(z,0)
z[0]=y}return C.b.a3(z,"/")},
eb:function(a){var z,y,x,w
z=J.w(a)
y=z.gh(a)
if(typeof y!=="number")return y.bT()
if(y>=2&&P.ec(z.E(a,0))){x=1
while(!0){y=z.gh(a)
if(typeof y!=="number")return H.r(y)
if(!(x<y))break
w=z.E(a,x)
if(w===58)return C.a.k(a,0,x)+"%3A"+C.a.at(a,x+1)
if(w<=127){y=w>>>4
if(y>=8)return H.e(C.l,y)
y=(C.l[y]&1<<(w&15))===0}else y=!0
if(y)break;++x}}return a},
ec:function(a){var z=a|32
return 97<=z&&z<=122}}},
ks:{"^":"c:0;a,b",
$1:function(a){throw H.a(new P.N("Invalid port",this.a,this.b+1))}},
im:{"^":"b;a,b,c",
gcT:function(){var z,y,x,w,v,u,t,s
z=this.c
if(z!=null)return z
z=this.b
if(0>=z.length)return H.e(z,0)
y=this.a
z=z[0]+1
x=J.w(y)
w=x.b0(y,"?",z)
v=x.gh(y)
if(w>=0){u=w+1
t=P.av(y,u,v,C.k,!1)
if(t==null)t=x.k(y,u,v)
v=w}else t=null
s=P.av(y,z,v,C.x,!1)
z=new P.iR(this,"data",null,null,null,s==null?x.k(y,z,v):s,t,null,null,null,null,null,null)
this.c=z
return z},
j:function(a){var z,y
z=this.b
if(0>=z.length)return H.e(z,0)
y=this.a
return z[0]===-1?"data:"+H.d(y):y},
m:{
dT:function(a,b,c){var z,y,x,w,v,u,t,s,r
z=[b-1]
y=J.w(a)
x=b
w=-1
v=null
while(!0){u=y.gh(a)
if(typeof u!=="number")return H.r(u)
if(!(x<u))break
c$0:{v=y.E(a,x)
if(v===44||v===59)break
if(v===47){if(w<0){w=x
break c$0}throw H.a(new P.N("Invalid MIME type",a,x))}}++x}if(w<0&&x>b)throw H.a(new P.N("Invalid MIME type",a,x))
for(;v!==44;){z.push(x);++x
t=-1
while(!0){u=y.gh(a)
if(typeof u!=="number")return H.r(u)
if(!(x<u))break
v=y.E(a,x)
if(v===61){if(t<0)t=x}else if(v===59||v===44)break;++x}if(t>=0)z.push(t)
else{s=C.b.gb1(z)
if(v!==44||x!==s+7||!y.V(a,"base64",s+1))throw H.a(new P.N("Expecting '='",a,x))
break}}z.push(x)
u=x+1
if((z.length&1)===1)a=C.A.eG(a,u,y.gh(a))
else{r=P.av(a,u,y.gh(a),C.k,!0)
if(r!=null)a=y.P(a,u,y.gh(a),r)}return new P.im(a,z,c)}}},
ka:{"^":"c:0;",
$1:function(a){return new Uint8Array(H.eh(96))}},
k9:{"^":"c:20;a",
$2:function(a,b){var z=this.a
if(a>=z.length)return H.e(z,a)
z=z[a]
J.eM(z,0,96,b)
return z}},
kb:{"^":"c:9;",
$3:function(a,b,c){var z,y,x
for(z=b.length,y=J.Y(a),x=0;x<z;++x)y.q(a,C.a.B(b,x)^96,c)}},
kc:{"^":"c:9;",
$3:function(a,b,c){var z,y,x
for(z=C.a.B(b,0),y=C.a.B(b,1),x=J.Y(a);z<=y;++z)x.q(a,(z^96)>>>0,c)}},
jF:{"^":"b;a,b,c,d,e,f,r,x,y",
gcH:function(){return this.c>0},
gcJ:function(){var z=this.f
if(typeof z!=="number")return z.I()
return z<this.r},
gcI:function(){return this.r<this.a.length},
gbW:function(){var z,y
z=this.b
if(z<=0)return""
y=this.x
if(y!=null)return y
y=z===4
if(y&&C.a.L(this.a,"http")){this.x="http"
z="http"}else if(z===5&&C.a.L(this.a,"https")){this.x="https"
z="https"}else if(y&&C.a.L(this.a,"file")){this.x="file"
z="file"}else if(z===7&&C.a.L(this.a,"package")){this.x="package"
z="package"}else{z=C.a.k(this.a,0,z)
this.x=z}return z},
gcV:function(){var z,y
z=this.c
y=this.b+3
return z>y?C.a.k(this.a,y,z-1):""},
gaY:function(a){var z=this.c
return z>0?C.a.k(this.a,z,this.d):""},
gbJ:function(a){var z,y
if(this.c>0){z=this.d
if(typeof z!=="number")return z.X()
y=this.e
if(typeof y!=="number")return H.r(y)
y=z+1<y
z=y}else z=!1
if(z){z=this.d
if(typeof z!=="number")return z.X()
return H.ar(C.a.k(this.a,z+1,this.e),null,null)}z=this.b
if(z===4&&C.a.L(this.a,"http"))return 80
if(z===5&&C.a.L(this.a,"https"))return 443
return 0},
gbG:function(a){return C.a.k(this.a,this.e,this.f)},
gcM:function(a){var z,y
z=this.f
y=this.r
if(typeof z!=="number")return z.I()
return z<y?C.a.k(this.a,z+1,y):""},
gcE:function(){var z,y
z=this.r
y=this.a
return z<y.length?C.a.at(y,z+1):""},
gC:function(a){var z=this.y
if(z==null){z=C.a.gC(this.a)
this.y=z}return z},
w:function(a,b){var z
if(b==null)return!1
if(this===b)return!0
z=J.m(b)
if(!!z.$iscf)return this.a===z.j(b)
return!1},
j:function(a){return this.a},
$iscf:1},
iR:{"^":"e8;cx,a,b,c,d,e,f,r,x,y,z,Q,ch"}}],["","",,W,{"^":"",
f4:function(a){var z=document.createElement("a")
return z},
fk:function(a){return a.replace(/^-ms-/,"ms-").replace(/-([\da-z])/ig,function(b,c){return c.toUpperCase()})},
fs:function(a,b,c){var z,y
z=document.body
y=(z&&C.m).S(z,a,b,c)
y.toString
z=new H.bw(new W.R(y),new W.kr(),[W.k])
return z.gan(z)},
aG:function(a){var z,y,x
z="element tag unavailable"
try{y=J.eU(a)
if(typeof y==="string")z=a.tagName}catch(x){H.E(x)}return z},
fD:function(a,b,c){return W.fF(a,null,null,b,null,null,null,c).bP(new W.fE())},
fF:function(a,b,c,d,e,f,g,h){var z,y,x,w
z=W.aY
y=new P.X(0,$.n,null,[z])
x=new P.iw(y,[z])
w=new XMLHttpRequest()
C.H.eH(w,"GET",a,!0)
z=W.m4
W.ah(w,"load",new W.fG(x,w),!1,z)
W.ah(w,"error",x.gee(),!1,z)
w.send()
return y},
a1:function(a,b,c){var z=document.createElement("img")
z.src=b
return z},
ai:function(a,b){a=536870911&a+b
a=536870911&a+((524287&a)<<10)
return a^a>>>6},
e4:function(a){a=536870911&a+((67108863&a)<<3)
a^=a>>>11
return 536870911&a+((16383&a)<<15)},
k7:function(a){var z
if(a==null)return
if("postMessage" in a){z=W.iP(a)
if(!!J.m(z).$isM)return z
return}else return a},
kk:function(a){var z=$.n
if(z===C.d)return a
return z.cB(a,!0)},
aU:function(a){return new W.aM(document.querySelectorAll(a),[null])},
t:{"^":"A;","%":"HTMLBRElement|HTMLCanvasElement|HTMLContentElement|HTMLDListElement|HTMLDataListElement|HTMLDetailsElement|HTMLDialogElement|HTMLDirectoryElement|HTMLDivElement|HTMLFontElement|HTMLFrameElement|HTMLHRElement|HTMLHeadElement|HTMLHeadingElement|HTMLHtmlElement|HTMLImageElement|HTMLLabelElement|HTMLLegendElement|HTMLMarqueeElement|HTMLMenuElement|HTMLMenuItemElement|HTMLMeterElement|HTMLModElement|HTMLOListElement|HTMLOptGroupElement|HTMLOptionElement|HTMLParagraphElement|HTMLPictureElement|HTMLPreElement|HTMLProgressElement|HTMLQuoteElement|HTMLScriptElement|HTMLShadowElement|HTMLSourceElement|HTMLSpanElement|HTMLStyleElement|HTMLTableCaptionElement|HTMLTableCellElement|HTMLTableColElement|HTMLTableDataCellElement|HTMLTableHeaderCellElement|HTMLTitleElement|HTMLTrackElement|HTMLUListElement|HTMLUnknownElement;HTMLElement"},
bS:{"^":"t;ai:target=,aZ:href}",
j:function(a){return String(a)},
$isbS:1,
$isi:1,
"%":"HTMLAnchorElement"},
l6:{"^":"t;ai:target=,aZ:href}",
j:function(a){return String(a)},
$isi:1,
"%":"HTMLAreaElement"},
l7:{"^":"t;aZ:href},ai:target=","%":"HTMLBaseElement"},
bV:{"^":"t;",$isbV:1,$isM:1,$isi:1,"%":"HTMLBodyElement"},
l8:{"^":"t;J:name=","%":"HTMLButtonElement"},
fb:{"^":"k;h:length=",$isi:1,"%":"CDATASection|Comment|Text;CharacterData"},
fj:{"^":"fI;h:length=",
am:function(a,b,c,d){var z=this.dz(a,b)
a.setProperty(z,c,d)
return},
dz:function(a,b){var z,y
z=$.$get$cV()
y=z[b]
if(typeof y==="string")return y
y=W.fk(b) in a?b:P.fm()+b
z[b]=y
return y},
"%":"CSS2Properties|CSSStyleDeclaration|MSStyleCSSProperties"},
fI:{"^":"i+cU;"},
iK:{"^":"hu;a,b",
am:function(a,b,c,d){this.b.H(0,new W.iN(b,c,d))},
dm:function(a){var z=P.aq(this.a,!0,null)
this.b=new H.aK(z,new W.iM(),[H.y(z,0),null])},
m:{
iL:function(a){var z=new W.iK(a,null)
z.dm(a)
return z}}},
hu:{"^":"b+cU;"},
iM:{"^":"c:0;",
$1:function(a){return J.cJ(a)}},
iN:{"^":"c:0;a,b,c",
$1:function(a){return J.cM(a,this.a,this.b,this.c)}},
cU:{"^":"b;"},
l9:{"^":"k;",
gaC:function(a){return new W.bz(a,"click",!1,[W.a3])},
"%":"Document|HTMLDocument|XMLDocument"},
la:{"^":"k;",
gbA:function(a){if(a._docChildren==null)a._docChildren=new P.d5(a,new W.R(a))
return a._docChildren},
Z:function(a,b,c,d){var z
this.dB(a)
z=document.body
a.appendChild((z&&C.m).S(z,b,c,d))},
aH:function(a,b,c){return this.Z(a,b,null,c)},
b8:function(a,b){return this.Z(a,b,null,null)},
$isi:1,
"%":"DocumentFragment|ShadowRoot"},
lb:{"^":"i;",
j:function(a){return String(a)},
"%":"DOMException"},
fn:{"^":"i;",
j:function(a){return"Rectangle ("+H.d(a.left)+", "+H.d(a.top)+") "+H.d(this.gaj(a))+" x "+H.d(this.gag(a))},
w:function(a,b){var z
if(b==null)return!1
z=J.m(b)
if(!z.$isb5)return!1
return a.left===z.gbD(b)&&a.top===z.gbQ(b)&&this.gaj(a)===z.gaj(b)&&this.gag(a)===z.gag(b)},
gC:function(a){var z,y,x,w
z=a.left
y=a.top
x=this.gaj(a)
w=this.gag(a)
return W.e4(W.ai(W.ai(W.ai(W.ai(0,z&0x1FFFFFFF),y&0x1FFFFFFF),x&0x1FFFFFFF),w&0x1FFFFFFF))},
gag:function(a){return a.height},
gbD:function(a){return a.left},
gbQ:function(a){return a.top},
gaj:function(a){return a.width},
$isb5:1,
$asb5:I.L,
"%":";DOMRectReadOnly"},
lc:{"^":"i;h:length=",
p:function(a,b){return a.remove(b)},
"%":"DOMTokenList"},
iH:{"^":"ap;bm:a<,b",
gu:function(a){return this.a.firstElementChild==null},
gh:function(a){return this.b.length},
i:function(a,b){var z=this.b
if(b>>>0!==b||b>=z.length)return H.e(z,b)
return z[b]},
q:function(a,b,c){var z=this.b
if(b>>>0!==b||b>=z.length)return H.e(z,b)
this.a.replaceChild(c,z[b])},
sh:function(a,b){throw H.a(new P.l("Cannot resize element lists"))},
gD:function(a){var z=this.a5(this)
return new J.bU(z,z.length,0,null)},
A:function(a,b,c,d,e){throw H.a(new P.b8(null))},
R:function(a,b,c,d){return this.A(a,b,c,d,0)},
P:function(a,b,c,d){throw H.a(new P.b8(null))},
ar:function(a,b,c,d){throw H.a(new P.b8(null))},
p:function(a,b){return!1},
gN:function(a){var z=this.a.firstElementChild
if(z==null)throw H.a(new P.C("No elements"))
return z},
$asap:function(){return[W.A]},
$ash:function(){return[W.A]},
$asf:function(){return[W.A]}},
aM:{"^":"ap;a,$ti",
gh:function(a){return this.a.length},
i:function(a,b){var z=this.a
if(b>>>0!==b||b>=z.length)return H.e(z,b)
return z[b]},
q:function(a,b,c){throw H.a(new P.l("Cannot modify list"))},
sh:function(a,b){throw H.a(new P.l("Cannot modify list"))},
gN:function(a){return C.X.gN(this.a)},
ga2:function(a){return W.bB(this)},
gbY:function(a){return W.iL(this)},
gaC:function(a){return new W.ba(this,!1,"click",[W.a3])},
$ish:1,
$ash:null,
$isf:1,
$asf:null},
A:{"^":"k;bY:style=,eb:className},cl:namespaceURI=,eT:tagName=",
gea:function(a){return new W.by(a)},
gbA:function(a){return new W.iH(a,a.children)},
ga2:function(a){return new W.iW(a)},
gbB:function(a){return new W.ci(new W.by(a))},
j:function(a){return a.localName},
S:["ba",function(a,b,c,d){var z,y,x,w,v
if(c==null){if(d==null){z=$.d2
if(z==null){z=H.u([],[W.c6])
y=new W.c7(z)
z.push(W.cm(null))
z.push(W.cq())
$.d2=y
d=y}else d=z}z=$.d1
if(z==null){z=new W.ef(d)
$.d1=z
c=z}else{z.a=d
c=z}}else if(d!=null)throw H.a(P.aD("validator can only be passed if treeSanitizer is null"))
if($.a7==null){z=document
y=z.implementation.createHTMLDocument("")
$.a7=y
$.bZ=y.createRange()
y=$.a7
y.toString
x=y.createElement("base")
J.f_(x,z.baseURI)
$.a7.head.appendChild(x)}z=$.a7
if(z.body==null){z.toString
y=z.createElement("body")
z.body=y}z=$.a7
if(!!this.$isbV)w=z.body
else{y=a.tagName
z.toString
w=z.createElement(y)
$.a7.body.appendChild(w)}if("createContextualFragment" in window.Range.prototype&&!C.b.F(C.T,a.tagName)){$.bZ.selectNodeContents(w)
v=$.bZ.createContextualFragment(b)}else{w.innerHTML=b
v=$.a7.createDocumentFragment()
for(;z=w.firstChild,z!=null;)v.appendChild(z)}z=$.a7.body
if(w==null?z!=null:w!==z)J.cK(w)
c.bV(v)
document.adoptNode(v)
return v},function(a,b,c){return this.S(a,b,c,null)},"ej",null,null,"gf7",2,5,null,0,0],
Z:function(a,b,c,d){a.textContent=null
a.appendChild(this.S(a,b,c,d))},
aH:function(a,b,c){return this.Z(a,b,null,c)},
b8:function(a,b){return this.Z(a,b,null,null)},
gaC:function(a){return new W.e0(a,"click",!1,[W.a3])},
$isA:1,
$isk:1,
$isb:1,
$isi:1,
$isM:1,
"%":";Element"},
kr:{"^":"c:0;",
$1:function(a){return!!J.m(a).$isA}},
ld:{"^":"t;J:name=","%":"HTMLEmbedElement"},
le:{"^":"ae;ae:error=","%":"ErrorEvent"},
ae:{"^":"i;",
gai:function(a){return W.k7(a.target)},
d7:function(a){return a.stopPropagation()},
$isae:1,
$isb:1,
"%":"AnimationEvent|AnimationPlayerEvent|ApplicationCacheErrorEvent|AudioProcessingEvent|AutocompleteErrorEvent|BeforeInstallPromptEvent|BeforeUnloadEvent|BlobEvent|ClipboardEvent|CloseEvent|CustomEvent|DeviceLightEvent|DeviceMotionEvent|DeviceOrientationEvent|ExtendableEvent|ExtendableMessageEvent|FetchEvent|FontFaceSetLoadEvent|GamepadEvent|GeofencingEvent|HashChangeEvent|IDBVersionChangeEvent|InstallEvent|MIDIConnectionEvent|MIDIMessageEvent|MediaEncryptedEvent|MediaKeyMessageEvent|MediaQueryListEvent|MediaStreamEvent|MediaStreamTrackEvent|MessageEvent|NotificationEvent|OfflineAudioCompletionEvent|PageTransitionEvent|PopStateEvent|PresentationConnectionAvailableEvent|PresentationConnectionCloseEvent|ProgressEvent|PromiseRejectionEvent|PushEvent|RTCDTMFToneChangeEvent|RTCDataChannelEvent|RTCIceCandidateEvent|RTCPeerConnectionIceEvent|RelatedEvent|ResourceProgressEvent|SecurityPolicyViolationEvent|ServicePortConnectEvent|ServiceWorkerMessageEvent|SpeechRecognitionEvent|SpeechSynthesisEvent|StorageEvent|SyncEvent|TrackEvent|TransitionEvent|USBConnectionEvent|WebGLContextEvent|WebKitTransitionEvent;Event|InputEvent"},
M:{"^":"i;",
cw:function(a,b,c,d){if(c!=null)this.dv(a,b,c,!1)},
cN:function(a,b,c,d){if(c!=null)this.dU(a,b,c,!1)},
dv:function(a,b,c,d){return a.addEventListener(b,H.az(c,1),!1)},
dU:function(a,b,c,d){return a.removeEventListener(b,H.az(c,1),!1)},
$isM:1,
"%":"MediaStream|MessagePort;EventTarget"},
lv:{"^":"t;J:name=","%":"HTMLFieldSetElement"},
lx:{"^":"t;h:length=,J:name=,ai:target=","%":"HTMLFormElement"},
lz:{"^":"fO;",
gh:function(a){return a.length},
i:function(a,b){if(b>>>0!==b||b>=a.length)throw H.a(P.a2(b,a,null,null,null))
return a[b]},
q:function(a,b,c){throw H.a(new P.l("Cannot assign element of immutable List."))},
sh:function(a,b){throw H.a(new P.l("Cannot resize immutable List."))},
gN:function(a){if(a.length>0)return a[0]
throw H.a(new P.C("No elements"))},
G:function(a,b){if(b>>>0!==b||b>=a.length)return H.e(a,b)
return a[b]},
$ish:1,
$ash:function(){return[W.k]},
$isf:1,
$asf:function(){return[W.k]},
$isO:1,
$asO:function(){return[W.k]},
$isI:1,
$asI:function(){return[W.k]},
"%":"HTMLCollection|HTMLFormControlsCollection|HTMLOptionsCollection"},
fJ:{"^":"i+Q;",
$ash:function(){return[W.k]},
$asf:function(){return[W.k]},
$ish:1,
$isf:1},
fO:{"^":"fJ+aZ;",
$ash:function(){return[W.k]},
$asf:function(){return[W.k]},
$ish:1,
$isf:1},
aY:{"^":"fC;eQ:responseText=",
f9:function(a,b,c,d,e,f){return a.open(b,c,!0,f,e)},
eH:function(a,b,c,d){return a.open(b,c,d)},
aG:function(a,b){return a.send(b)},
$isaY:1,
$isb:1,
"%":"XMLHttpRequest"},
fE:{"^":"c:21;",
$1:function(a){return J.eT(a)}},
fG:{"^":"c:0;a,b",
$1:function(a){var z,y,x,w,v
z=this.b
y=z.status
if(typeof y!=="number")return y.bT()
x=y>=200&&y<300
w=y>307&&y<400
y=x||y===0||y===304||w
v=this.a
if(y)v.ed(0,z)
else v.ef(a)}},
fC:{"^":"M;","%":";XMLHttpRequestEventTarget"},
lA:{"^":"t;J:name=","%":"HTMLIFrameElement"},
lC:{"^":"t;J:name=",$isA:1,$isi:1,$isM:1,"%":"HTMLInputElement"},
lF:{"^":"t;J:name=","%":"HTMLKeygenElement"},
c2:{"^":"t;",$isc2:1,$isA:1,$isk:1,$isb:1,"%":"HTMLLIElement"},
lH:{"^":"t;aZ:href}","%":"HTMLLinkElement"},
lI:{"^":"i;",
j:function(a){return String(a)},
"%":"Location"},
lJ:{"^":"t;J:name=","%":"HTMLMapElement"},
lM:{"^":"t;ae:error=","%":"HTMLAudioElement|HTMLMediaElement|HTMLVideoElement"},
lN:{"^":"t;J:name=","%":"HTMLMetaElement"},
lO:{"^":"ho;",
eZ:function(a,b,c){return a.send(b,c)},
aG:function(a,b){return a.send(b)},
"%":"MIDIOutput"},
ho:{"^":"M;","%":"MIDIInput;MIDIPort"},
a3:{"^":"ik;",$isa3:1,$isae:1,$isb:1,"%":"DragEvent|MouseEvent|PointerEvent|WheelEvent"},
lX:{"^":"i;",$isi:1,"%":"Navigator"},
R:{"^":"ap;a",
gN:function(a){var z=this.a.firstChild
if(z==null)throw H.a(new P.C("No elements"))
return z},
gan:function(a){var z,y
z=this.a
y=z.childNodes.length
if(y===0)throw H.a(new P.C("No elements"))
if(y>1)throw H.a(new P.C("More than one element"))
return z.firstChild},
Y:function(a,b){var z,y,x,w
z=b.a
y=this.a
if(z!==y)for(x=z.childNodes.length,w=0;w<x;++w)y.appendChild(z.firstChild)
return},
p:function(a,b){return!1},
q:function(a,b,c){var z,y
z=this.a
y=z.childNodes
if(b>>>0!==b||b>=y.length)return H.e(y,b)
z.replaceChild(c,y[b])},
gD:function(a){var z=this.a.childNodes
return new W.d7(z,z.length,-1,null)},
A:function(a,b,c,d,e){throw H.a(new P.l("Cannot setRange on Node list"))},
R:function(a,b,c,d){return this.A(a,b,c,d,0)},
ar:function(a,b,c,d){throw H.a(new P.l("Cannot fillRange on Node list"))},
gh:function(a){return this.a.childNodes.length},
sh:function(a,b){throw H.a(new P.l("Cannot set length on immutable List."))},
i:function(a,b){var z=this.a.childNodes
if(b>>>0!==b||b>=z.length)return H.e(z,b)
return z[b]},
$asap:function(){return[W.k]},
$ash:function(){return[W.k]},
$asf:function(){return[W.k]}},
k:{"^":"M;eI:parentNode=,eJ:previousSibling=",
geF:function(a){return new W.R(a)},
eL:function(a){var z=a.parentNode
if(z!=null)z.removeChild(a)},
eP:function(a,b){var z,y
try{z=a.parentNode
J.eK(z,b,a)}catch(y){H.E(y)}return a},
dB:function(a){var z
for(;z=a.firstChild,z!=null;)a.removeChild(z)},
j:function(a){var z=a.nodeValue
return z==null?this.d8(a):z},
f6:[function(a,b){return a.appendChild(b)},"$1","ge9",2,0,22],
dV:function(a,b,c){return a.replaceChild(b,c)},
$isk:1,
$isb:1,
"%":";Node"},
hq:{"^":"fP;",
gh:function(a){return a.length},
i:function(a,b){if(b>>>0!==b||b>=a.length)throw H.a(P.a2(b,a,null,null,null))
return a[b]},
q:function(a,b,c){throw H.a(new P.l("Cannot assign element of immutable List."))},
sh:function(a,b){throw H.a(new P.l("Cannot resize immutable List."))},
gN:function(a){if(a.length>0)return a[0]
throw H.a(new P.C("No elements"))},
G:function(a,b){if(b>>>0!==b||b>=a.length)return H.e(a,b)
return a[b]},
$ish:1,
$ash:function(){return[W.k]},
$isf:1,
$asf:function(){return[W.k]},
$isO:1,
$asO:function(){return[W.k]},
$isI:1,
$asI:function(){return[W.k]},
"%":"NodeList|RadioNodeList"},
fK:{"^":"i+Q;",
$ash:function(){return[W.k]},
$asf:function(){return[W.k]},
$ish:1,
$isf:1},
fP:{"^":"fK+aZ;",
$ash:function(){return[W.k]},
$asf:function(){return[W.k]},
$ish:1,
$isf:1},
lZ:{"^":"t;J:name=","%":"HTMLObjectElement"},
m_:{"^":"t;J:name=","%":"HTMLOutputElement"},
m1:{"^":"t;J:name=","%":"HTMLParamElement"},
m3:{"^":"fb;ai:target=","%":"ProcessingInstruction"},
m5:{"^":"t;h:length=,J:name=","%":"HTMLSelectElement"},
m6:{"^":"t;J:name=","%":"HTMLSlotElement"},
m7:{"^":"ae;ae:error=","%":"SpeechRecognitionError"},
i8:{"^":"t;",
S:function(a,b,c,d){var z,y
if("createContextualFragment" in window.Range.prototype)return this.ba(a,b,c,d)
z=W.fs("<table>"+H.d(b)+"</table>",c,d)
y=document.createDocumentFragment()
y.toString
new W.R(y).Y(0,J.eQ(z))
return y},
"%":"HTMLTableElement"},
ma:{"^":"t;",
S:function(a,b,c,d){var z,y,x,w
if("createContextualFragment" in window.Range.prototype)return this.ba(a,b,c,d)
z=document
y=z.createDocumentFragment()
z=C.z.S(z.createElement("table"),b,c,d)
z.toString
z=new W.R(z)
x=z.gan(z)
x.toString
z=new W.R(x)
w=z.gan(z)
y.toString
w.toString
new W.R(y).Y(0,new W.R(w))
return y},
"%":"HTMLTableRowElement"},
mb:{"^":"t;",
S:function(a,b,c,d){var z,y,x
if("createContextualFragment" in window.Range.prototype)return this.ba(a,b,c,d)
z=document
y=z.createDocumentFragment()
z=C.z.S(z.createElement("table"),b,c,d)
z.toString
z=new W.R(z)
x=z.gan(z)
y.toString
x.toString
new W.R(y).Y(0,new W.R(x))
return y},
"%":"HTMLTableSectionElement"},
dD:{"^":"t;",
Z:function(a,b,c,d){var z
a.textContent=null
z=this.S(a,b,c,d)
a.content.appendChild(z)},
aH:function(a,b,c){return this.Z(a,b,null,c)},
b8:function(a,b){return this.Z(a,b,null,null)},
$isdD:1,
"%":"HTMLTemplateElement"},
mc:{"^":"t;J:name=","%":"HTMLTextAreaElement"},
ik:{"^":"ae;","%":"CompositionEvent|FocusEvent|KeyboardEvent|SVGZoomEvent|TextEvent|TouchEvent;UIEvent"},
iu:{"^":"M;",
cY:function(a,b,c,d){a.scrollTo(b,c)
return},
bX:function(a,b,c){return this.cY(a,b,c,null)},
gaC:function(a){return new W.bz(a,"click",!1,[W.a3])},
gal:function(a){return"scrollY" in a?C.e.bL(a.scrollY):C.e.bL(a.document.documentElement.scrollTop)},
$isi:1,
$isM:1,
"%":"DOMWindow|Window"},
mj:{"^":"k;J:name=,cl:namespaceURI=","%":"Attr"},
mk:{"^":"i;ag:height=,bD:left=,bQ:top=,aj:width=",
j:function(a){return"Rectangle ("+H.d(a.left)+", "+H.d(a.top)+") "+H.d(a.width)+" x "+H.d(a.height)},
w:function(a,b){var z,y,x
if(b==null)return!1
z=J.m(b)
if(!z.$isb5)return!1
y=a.left
x=z.gbD(b)
if(y==null?x==null:y===x){y=a.top
x=z.gbQ(b)
if(y==null?x==null:y===x){y=a.width
x=z.gaj(b)
if(y==null?x==null:y===x){y=a.height
z=z.gag(b)
z=y==null?z==null:y===z}else z=!1}else z=!1}else z=!1
return z},
gC:function(a){var z,y,x,w
z=J.ac(a.left)
y=J.ac(a.top)
x=J.ac(a.width)
w=J.ac(a.height)
return W.e4(W.ai(W.ai(W.ai(W.ai(0,z),y),x),w))},
$isb5:1,
$asb5:I.L,
"%":"ClientRect"},
ml:{"^":"k;",$isi:1,"%":"DocumentType"},
mm:{"^":"fn;",
gag:function(a){return a.height},
gaj:function(a){return a.width},
"%":"DOMRect"},
mo:{"^":"t;",$isM:1,$isi:1,"%":"HTMLFrameSetElement"},
mr:{"^":"fQ;",
gh:function(a){return a.length},
i:function(a,b){if(b>>>0!==b||b>=a.length)throw H.a(P.a2(b,a,null,null,null))
return a[b]},
q:function(a,b,c){throw H.a(new P.l("Cannot assign element of immutable List."))},
sh:function(a,b){throw H.a(new P.l("Cannot resize immutable List."))},
gN:function(a){if(a.length>0)return a[0]
throw H.a(new P.C("No elements"))},
G:function(a,b){if(b>>>0!==b||b>=a.length)return H.e(a,b)
return a[b]},
$ish:1,
$ash:function(){return[W.k]},
$isf:1,
$asf:function(){return[W.k]},
$isO:1,
$asO:function(){return[W.k]},
$isI:1,
$asI:function(){return[W.k]},
"%":"MozNamedAttrMap|NamedNodeMap"},
fL:{"^":"i+Q;",
$ash:function(){return[W.k]},
$asf:function(){return[W.k]},
$ish:1,
$isf:1},
fQ:{"^":"fL+aZ;",
$ash:function(){return[W.k]},
$asf:function(){return[W.k]},
$ish:1,
$isf:1},
mv:{"^":"M;",$isM:1,$isi:1,"%":"ServiceWorker"},
iC:{"^":"b;bm:a<",
H:function(a,b){var z,y,x,w,v
for(z=this.gT(),y=z.length,x=this.a,w=0;w<z.length;z.length===y||(0,H.a5)(z),++w){v=z[w]
b.$2(v,x.getAttribute(v))}},
gT:function(){var z,y,x,w,v,u
z=this.a.attributes
y=H.u([],[P.o])
for(x=z.length,w=0;w<x;++w){if(w>=z.length)return H.e(z,w)
v=z[w]
u=J.q(v)
if(u.gcl(v)==null)y.push(u.gJ(v))}return y},
gu:function(a){return this.gT().length===0}},
by:{"^":"iC;a",
i:function(a,b){return this.a.getAttribute(b)},
q:function(a,b,c){this.a.setAttribute(b,c)},
p:function(a,b){var z,y
z=this.a
y=z.getAttribute(b)
z.removeAttribute(b)
return y},
gh:function(a){return this.gT().length}},
ci:{"^":"b;a",
i:function(a,b){return this.a.a.getAttribute("data-"+this.a0(b))},
q:function(a,b,c){this.a.a.setAttribute("data-"+this.a0(b),c)},
p:function(a,b){var z,y,x
z="data-"+this.a0(b)
y=this.a.a
x=y.getAttribute(z)
y.removeAttribute(z)
return x},
gT:function(){var z=H.u([],[P.o])
this.a.H(0,new W.iQ(this,z))
return z},
gh:function(a){return this.gT().length},
gu:function(a){return this.gT().length===0},
e5:function(a,b){var z,y,x,w,v
z=a.split("-")
for(y=1;y<z.length;++y){x=z[y]
w=J.w(x)
v=w.gh(x)
if(typeof v!=="number")return v.ak()
if(v>0){w=J.f3(w.i(x,0))+w.at(x,1)
if(y>=z.length)return H.e(z,y)
z[y]=w}}return C.b.a3(z,"")},
e4:function(a){return this.e5(a,!1)},
a0:function(a){var z,y,x,w,v
z=J.w(a)
y=0
x=""
while(!0){w=z.gh(a)
if(typeof w!=="number")return H.r(w)
if(!(y<w))break
v=J.cN(z.i(a,y))
x=(!J.z(z.i(a,y),v)&&y>0?x+"-":x)+v;++y}return x.charCodeAt(0)==0?x:x}},
iQ:{"^":"c:23;a,b",
$2:function(a,b){if(J.aT(a).L(a,"data-"))this.b.push(this.a.e4(C.a.at(a,5)))}},
jo:{"^":"an;a,b",
O:function(){var z=P.J(null,null,null,P.o)
C.b.H(this.b,new W.jq(z))
return z},
b5:function(a){var z,y
z=a.a3(0," ")
for(y=this.a,y=new H.bn(y,y.gh(y),0,null);y.l();)J.eZ(y.d,z)},
bF:function(a){C.b.H(this.b,new W.jp(a))},
p:function(a,b){return C.b.ep(this.b,!1,new W.jr(b))},
m:{
bB:function(a){return new W.jo(a,new H.aK(a,new W.kt(),[H.y(a,0),null]).a5(0))}}},
kt:{"^":"c:4;",
$1:function(a){return J.a6(a)}},
jq:{"^":"c:10;a",
$1:function(a){return this.a.Y(0,a.O())}},
jp:{"^":"c:10;a",
$1:function(a){return a.bF(this.a)}},
jr:{"^":"c:24;a",
$2:function(a,b){return J.eW(b,this.a)===!0||a===!0}},
iW:{"^":"an;bm:a<",
O:function(){var z,y,x,w,v
z=P.J(null,null,null,P.o)
for(y=this.a.className.split(" "),x=y.length,w=0;w<y.length;y.length===x||(0,H.a5)(y),++w){v=J.cO(y[w])
if(v.length!==0)z.v(0,v)}return z},
b5:function(a){this.a.className=a.a3(0," ")},
gh:function(a){return this.a.classList.length},
gu:function(a){return this.a.classList.length===0},
F:function(a,b){return typeof b==="string"&&this.a.classList.contains(b)},
v:function(a,b){var z,y
z=this.a.classList
y=z.contains(b)
z.add(b)
return!y},
p:function(a,b){var z,y
z=this.a.classList
y=z.contains(b)
z.remove(b)
return y}},
bz:{"^":"ab;a,b,c,$ti",
M:function(a,b,c,d){return W.ah(this.a,this.b,a,!1,H.y(this,0))},
ah:function(a){return this.M(a,null,null,null)},
b2:function(a,b,c){return this.M(a,null,b,c)}},
e0:{"^":"bz;a,b,c,$ti"},
ba:{"^":"ab;a,b,c,$ti",
M:function(a,b,c,d){var z,y,x,w
z=H.y(this,0)
y=this.$ti
x=new W.jI(null,new H.af(0,null,null,null,null,null,0,[[P.ab,z],[P.dz,z]]),y)
x.a=new P.cp(null,x.gec(x),0,null,null,null,null,y)
for(z=this.a,z=new H.bn(z,z.gh(z),0,null),w=this.c;z.l();)x.v(0,new W.bz(z.d,w,!1,y))
z=x.a
z.toString
return new P.iD(z,[H.y(z,0)]).M(a,b,c,d)},
ah:function(a){return this.M(a,null,null,null)},
b2:function(a,b,c){return this.M(a,null,b,c)}},
iZ:{"^":"dz;a,b,c,d,e,$ti",
ab:function(){if(this.b==null)return
this.cv()
this.b=null
this.d=null
return},
aD:function(a,b){if(this.b==null)return;++this.a
this.cv()},
bH:function(a){return this.aD(a,null)},
bK:function(){if(this.b==null||this.a<=0)return;--this.a
this.ct()},
ct:function(){var z=this.d
if(z!=null&&this.a<=0)J.eL(this.b,this.c,z,!1)},
cv:function(){var z=this.d
if(z!=null)J.eX(this.b,this.c,z,!1)},
dn:function(a,b,c,d,e){this.ct()},
m:{
ah:function(a,b,c,d,e){var z=c==null?null:W.kk(new W.j_(c))
z=new W.iZ(0,a,b,z,!1,[e])
z.dn(a,b,c,!1,e)
return z}}},
j_:{"^":"c:0;a",
$1:function(a){return this.a.$1(a)}},
jI:{"^":"b;a,b,$ti",
v:function(a,b){var z,y
z=this.b
if(z.aX(b))return
y=this.a
z.q(0,b,W.ah(b.a,b.b,y.ge7(y),!1,H.y(b,0)))},
p:function(a,b){var z=this.b.p(0,b)
if(z!=null)z.ab()},
cD:[function(a){var z,y
for(z=this.b,y=z.gbR(z),y=y.gD(y);y.l();)y.gt().ab()
z.ac(0)
this.a.cD(0)},"$0","gec",0,0,2]},
cl:{"^":"b;cU:a<",
aa:function(a){return $.$get$e3().F(0,W.aG(a))},
a1:function(a,b,c){var z,y,x
z=W.aG(a)
y=$.$get$cn()
x=y.i(0,H.d(z)+"::"+b)
if(x==null)x=y.i(0,"*::"+b)
if(x==null)return!1
return x.$4(a,b,c,this)},
ds:function(a){var z,y
z=$.$get$cn()
if(z.gu(z)){for(y=0;y<262;++y)z.q(0,C.Q[y],W.kA())
for(y=0;y<12;++y)z.q(0,C.p[y],W.kB())}},
m:{
cm:function(a){var z,y
z=W.f4(null)
y=window.location
z=new W.cl(new W.jB(z,y))
z.ds(a)
return z},
mp:[function(a,b,c,d){return!0},"$4","kA",8,0,11],
mq:[function(a,b,c,d){return d.gcU().aW(c)},"$4","kB",8,0,11]}},
aZ:{"^":"b;$ti",
gD:function(a){return new W.d7(a,this.gh(a),-1,null)},
p:function(a,b){throw H.a(new P.l("Cannot remove from immutable List."))},
A:function(a,b,c,d,e){throw H.a(new P.l("Cannot setRange on immutable List."))},
R:function(a,b,c,d){return this.A(a,b,c,d,0)},
P:function(a,b,c,d){throw H.a(new P.l("Cannot modify an immutable List."))},
ar:function(a,b,c,d){throw H.a(new P.l("Cannot modify an immutable List."))},
$ish:1,
$ash:null,
$isf:1,
$asf:null},
c7:{"^":"b;a",
v:function(a,b){this.a.push(b)},
aa:function(a){return C.b.cA(this.a,new W.ht(a))},
a1:function(a,b,c){return C.b.cA(this.a,new W.hs(a,b,c))},
m:{
hr:function(){var z=H.u([],[W.c6])
z.push(W.cm(null))
z.push(W.cq())
return new W.c7(z)}}},
ht:{"^":"c:0;a",
$1:function(a){return a.aa(this.a)}},
hs:{"^":"c:0;a,b,c",
$1:function(a){return a.a1(this.a,this.b,this.c)}},
e6:{"^":"b;a,b,c,cU:d<",
aa:function(a){return this.a.F(0,W.aG(a))},
a1:["df",function(a,b,c){var z,y
z=W.aG(a)
y=this.c
if(y.F(0,H.d(z)+"::"+b))return this.d.aW(c)
else if(y.F(0,"*::"+b))return this.d.aW(c)
else{y=this.b
if(y.F(0,H.d(z)+"::"+b))return!0
else if(y.F(0,"*::"+b))return!0
else if(y.F(0,H.d(z)+"::*"))return!0
else if(y.F(0,"*::*"))return!0}return!1}],
c1:function(a,b,c,d){var z,y,x
this.a.Y(0,c)
if(d==null)d=C.U
z=J.Y(b)
y=z.b4(b,new W.jD())
x=z.b4(b,new W.jE())
this.b.Y(0,y)
z=this.c
z.Y(0,d)
z.Y(0,x)},
m:{
jC:function(a,b,c,d){var z=P.o
z=new W.e6(P.J(null,null,null,z),P.J(null,null,null,z),P.J(null,null,null,z),a)
z.c1(a,b,c,d)
return z}}},
jD:{"^":"c:0;",
$1:function(a){return!C.b.F(C.p,a)}},
jE:{"^":"c:0;",
$1:function(a){return C.b.F(C.p,a)}},
jM:{"^":"e6;e,a,b,c,d",
a1:function(a,b,c){if(this.df(a,b,c))return!0
if(b==="template"&&c==="")return!0
if(J.cG(a).a.getAttribute("template")==="")return this.e.F(0,b)
return!1},
m:{
cq:function(){var z=P.o
z=new W.jM(P.df(C.o,z),P.J(null,null,null,z),P.J(null,null,null,z),P.J(null,null,null,z),null)
z.c1(null,new H.aK(C.o,new W.jN(),[H.y(C.o,0),null]),["TEMPLATE"],null)
return z}}},
jN:{"^":"c:0;",
$1:function(a){return"TEMPLATE::"+H.d(a)}},
jJ:{"^":"b;",
aa:function(a){var z=J.m(a)
if(!!z.$isdw)return!1
z=!!z.$isp
if(z&&W.aG(a)==="foreignObject")return!1
if(z)return!0
return!1},
a1:function(a,b,c){if(b==="is"||C.a.L(b,"on"))return!1
return this.aa(a)}},
d7:{"^":"b;a,b,c,d",
l:function(){var z,y
z=this.c+1
y=this.b
if(z<y){this.d=J.bO(this.a,z)
this.c=z
return!0}this.d=null
this.c=y
return!1},
gt:function(){return this.d}},
iO:{"^":"b;a",
cw:function(a,b,c,d){return H.v(new P.l("You can only attach EventListeners to your own window."))},
cN:function(a,b,c,d){return H.v(new P.l("You can only attach EventListeners to your own window."))},
$isM:1,
$isi:1,
m:{
iP:function(a){if(a===window)return a
else return new W.iO(a)}}},
c6:{"^":"b;"},
jB:{"^":"b;a,b",
aW:function(a){var z,y,x,w,v
z=this.a
z.href=a
y=z.hostname
x=this.b
w=x.hostname
if(y==null?w==null:y===w){w=z.port
v=x.port
if(w==null?v==null:w===v){w=z.protocol
x=x.protocol
x=w==null?x==null:w===x}else x=!1}else x=!1
if(!x)if(y==="")if(z.port===""){z=z.protocol
z=z===":"||z===""}else z=!1
else z=!1
else z=!0
return z}},
ef:{"^":"b;a",
bV:function(a){new W.k0(this).$2(a,null)},
aw:function(a,b){var z
if(b==null){z=a.parentNode
if(z!=null)z.removeChild(a)}else b.removeChild(a)},
dY:function(a,b){var z,y,x,w,v,u,t,s
z=!0
y=null
x=null
try{y=J.cG(a)
x=y.gbm().getAttribute("is")
w=function(c){if(!(c.attributes instanceof NamedNodeMap))return true
var r=c.childNodes
if(c.lastChild&&c.lastChild!==r[r.length-1])return true
if(c.children)if(!(c.children instanceof HTMLCollection||c.children instanceof NodeList))return true
var q=0
if(c.children)q=c.children.length
for(var p=0;p<q;p++){var o=c.children[p]
if(o.id=='attributes'||o.name=='attributes'||o.id=='lastChild'||o.name=='lastChild'||o.id=='children'||o.name=='children')return true}return false}(a)
z=w===!0?!0:!(a.attributes instanceof NamedNodeMap)}catch(t){H.E(t)}v="element unprintable"
try{v=J.V(a)}catch(t){H.E(t)}try{u=W.aG(a)
this.dX(a,b,z,v,u,y,x)}catch(t){if(H.E(t) instanceof P.Z)throw t
else{this.aw(a,b)
window
s="Removing corrupted element "+H.d(v)
if(typeof console!="undefined")console.warn(s)}}},
dX:function(a,b,c,d,e,f,g){var z,y,x,w,v
if(c){this.aw(a,b)
window
z="Removing element due to corrupted attributes on <"+d+">"
if(typeof console!="undefined")console.warn(z)
return}if(!this.a.aa(a)){this.aw(a,b)
window
z="Removing disallowed element <"+H.d(e)+"> from "+J.V(b)
if(typeof console!="undefined")console.warn(z)
return}if(g!=null)if(!this.a.a1(a,"is",g)){this.aw(a,b)
window
z="Removing disallowed type extension <"+H.d(e)+' is="'+g+'">'
if(typeof console!="undefined")console.warn(z)
return}z=f.gT()
y=H.u(z.slice(0),[H.y(z,0)])
for(x=f.gT().length-1,z=f.a;x>=0;--x){if(x>=y.length)return H.e(y,x)
w=y[x]
if(!this.a.a1(a,J.cN(w),z.getAttribute(w))){window
v="Removing disallowed attribute <"+H.d(e)+" "+w+'="'+H.d(z.getAttribute(w))+'">'
if(typeof console!="undefined")console.warn(v)
z.getAttribute(w)
z.removeAttribute(w)}}if(!!J.m(a).$isdD)this.bV(a.content)}},
k0:{"^":"c:25;a",
$2:function(a,b){var z,y,x,w,v
x=this.a
switch(a.nodeType){case 1:x.dY(a,b)
break
case 8:case 11:case 3:case 4:break
default:x.aw(a,b)}z=a.lastChild
for(x=a==null;null!=z;){y=null
try{y=J.eS(z)}catch(w){H.E(w)
v=z
if(x){if(J.eR(v)!=null)v.parentNode.removeChild(v)}else a.removeChild(v)
z=null
y=a.lastChild}if(z!=null)this.$2(z,a)
z=y}}}}],["","",,P,{"^":"",
d0:function(){var z=$.d_
if(z==null){z=J.bP(window.navigator.userAgent,"Opera",0)
$.d_=z}return z},
fm:function(){var z,y
z=$.cX
if(z!=null)return z
y=$.cY
if(y==null){y=J.bP(window.navigator.userAgent,"Firefox",0)
$.cY=y}if(y)z="-moz-"
else{y=$.cZ
if(y==null){y=P.d0()!==!0&&J.bP(window.navigator.userAgent,"Trident/",0)
$.cZ=y}if(y)z="-ms-"
else z=P.d0()===!0?"-o-":"-webkit-"}$.cX=z
return z},
an:{"^":"b;",
bw:function(a){if($.$get$cT().b.test(a))return a
throw H.a(P.aE(a,"value","Not a valid class token"))},
j:function(a){return this.O().a3(0," ")},
gD:function(a){var z,y
z=this.O()
y=new P.bc(z,z.r,null,null)
y.c=z.e
return y},
a4:function(a,b){var z=this.O()
return new H.bY(z,b,[H.y(z,0),null])},
gu:function(a){return this.O().a===0},
gh:function(a){return this.O().a},
F:function(a,b){if(typeof b!=="string")return!1
this.bw(b)
return this.O().F(0,b)},
bE:function(a){return this.F(0,a)?a:null},
v:function(a,b){this.bw(b)
return this.bF(new P.fi(b))},
p:function(a,b){var z,y
this.bw(b)
z=this.O()
y=z.p(0,b)
this.b5(z)
return y},
G:function(a,b){return this.O().G(0,b)},
bF:function(a){var z,y
z=this.O()
y=a.$1(z)
this.b5(z)
return y},
$isf:1,
$asf:function(){return[P.o]}},
fi:{"^":"c:0;a",
$1:function(a){return a.v(0,this.a)}},
d5:{"^":"ap;a,b",
ga8:function(){var z,y
z=this.b
y=H.x(z,"Q",0)
return new H.bo(new H.bw(z,new P.fw(),[y]),new P.fx(),[y,null])},
H:function(a,b){C.b.H(P.aq(this.ga8(),!1,W.A),b)},
q:function(a,b,c){var z=this.ga8()
J.eY(z.b.$1(J.aV(z.a,b)),c)},
sh:function(a,b){var z=J.U(this.ga8().a)
if(b>=z)return
else if(b<0)throw H.a(P.aD("Invalid list length"))
this.eO(0,b,z)},
A:function(a,b,c,d,e){throw H.a(new P.l("Cannot setRange on filtered list"))},
R:function(a,b,c,d){return this.A(a,b,c,d,0)},
ar:function(a,b,c,d){throw H.a(new P.l("Cannot fillRange on filtered list"))},
P:function(a,b,c,d){throw H.a(new P.l("Cannot replaceRange on filtered list"))},
eO:function(a,b,c){var z=this.ga8()
z=H.hU(z,b,H.x(z,"H",0))
C.b.H(P.aq(H.i9(z,c-b,H.x(z,"H",0)),!0,null),new P.fy())},
p:function(a,b){return!1},
gh:function(a){return J.U(this.ga8().a)},
i:function(a,b){var z=this.ga8()
return z.b.$1(J.aV(z.a,b))},
gD:function(a){var z=P.aq(this.ga8(),!1,W.A)
return new J.bU(z,z.length,0,null)},
$asap:function(){return[W.A]},
$ash:function(){return[W.A]},
$asf:function(){return[W.A]}},
fw:{"^":"c:0;",
$1:function(a){return!!J.m(a).$isA}},
fx:{"^":"c:0;",
$1:function(a){return H.bH(a,"$isA")}},
fy:{"^":"c:0;",
$1:function(a){return J.cK(a)}}}],["","",,P,{"^":""}],["","",,P,{"^":"",jv:{"^":"b;a,b",
ap:function(){var z,y,x,w,v,u
z=this.a
y=4294901760*z
x=(y&4294967295)>>>0
w=55905*z
v=(w&4294967295)>>>0
u=v+x+this.b
z=(u&4294967295)>>>0
this.a=z
this.b=(C.c.K(w-v+(y-x)+(u-z),4294967296)&4294967295)>>>0},
cL:function(a){var z,y,x
if(a<=0||a>4294967296)throw H.a(P.hM("max must be in range 0 < max \u2264 2^32, was "+a))
z=a-1
if((a&z)>>>0===0){this.ap()
return(this.a&z)>>>0}do{this.ap()
y=this.a
x=y%a}while(y-x+a>=4294967296)
return x},
dt:function(a){var z,y,x,w,v,u,t,s
z=a<0?-1:0
do{y=(a&4294967295)>>>0
a=C.c.K(a-y,4294967296)
x=(a&4294967295)>>>0
a=C.c.K(a-x,4294967296)
w=((~y&4294967295)>>>0)+(y<<21>>>0)
v=(w&4294967295)>>>0
x=(~x>>>0)+((x<<21|y>>>11)>>>0)+C.c.K(w-v,4294967296)&4294967295
w=((v^(v>>>24|x<<8))>>>0)*265
y=(w&4294967295)>>>0
x=((x^x>>>24)>>>0)*265+C.c.K(w-y,4294967296)&4294967295
w=((y^(y>>>14|x<<18))>>>0)*21
y=(w&4294967295)>>>0
x=((x^x>>>14)>>>0)*21+C.c.K(w-y,4294967296)&4294967295
y=(y^(y>>>28|x<<4))>>>0
x=(x^x>>>28)>>>0
w=(y<<31>>>0)+y
v=(w&4294967295)>>>0
u=C.c.K(w-v,4294967296)
w=this.a*1037
t=(w&4294967295)>>>0
this.a=t
s=(this.b*1037+C.c.K(w-t,4294967296)&4294967295)>>>0
this.b=s
t=(t^v)>>>0
this.a=t
u=(s^x+((x<<31|y>>>1)>>>0)+u&4294967295)>>>0
this.b=u}while(a!==z)
if(u===0&&t===0)this.a=23063
this.ap()
this.ap()
this.ap()
this.ap()},
m:{
jw:function(a){var z=new P.jv(0,0)
z.dt(a)
return z}}}}],["","",,P,{"^":"",l4:{"^":"aX;ai:target=",$isi:1,"%":"SVGAElement"},l5:{"^":"p;",$isi:1,"%":"SVGAnimateElement|SVGAnimateMotionElement|SVGAnimateTransformElement|SVGAnimationElement|SVGSetElement"},lf:{"^":"p;",$isi:1,"%":"SVGFEBlendElement"},lg:{"^":"p;",$isi:1,"%":"SVGFEColorMatrixElement"},lh:{"^":"p;",$isi:1,"%":"SVGFEComponentTransferElement"},li:{"^":"p;",$isi:1,"%":"SVGFECompositeElement"},lj:{"^":"p;",$isi:1,"%":"SVGFEConvolveMatrixElement"},lk:{"^":"p;",$isi:1,"%":"SVGFEDiffuseLightingElement"},ll:{"^":"p;",$isi:1,"%":"SVGFEDisplacementMapElement"},lm:{"^":"p;",$isi:1,"%":"SVGFEFloodElement"},ln:{"^":"p;",$isi:1,"%":"SVGFEGaussianBlurElement"},lo:{"^":"p;",$isi:1,"%":"SVGFEImageElement"},lp:{"^":"p;",$isi:1,"%":"SVGFEMergeElement"},lq:{"^":"p;",$isi:1,"%":"SVGFEMorphologyElement"},lr:{"^":"p;",$isi:1,"%":"SVGFEOffsetElement"},ls:{"^":"p;",$isi:1,"%":"SVGFESpecularLightingElement"},lt:{"^":"p;",$isi:1,"%":"SVGFETileElement"},lu:{"^":"p;",$isi:1,"%":"SVGFETurbulenceElement"},lw:{"^":"p;",$isi:1,"%":"SVGFilterElement"},aX:{"^":"p;",$isi:1,"%":"SVGCircleElement|SVGClipPathElement|SVGDefsElement|SVGEllipseElement|SVGForeignObjectElement|SVGGElement|SVGGeometryElement|SVGLineElement|SVGPathElement|SVGPolygonElement|SVGPolylineElement|SVGRectElement|SVGSwitchElement;SVGGraphicsElement"},lB:{"^":"aX;",$isi:1,"%":"SVGImageElement"},aI:{"^":"i;",$isb:1,"%":"SVGLength"},lG:{"^":"fR;",
gh:function(a){return a.length},
i:function(a,b){if(b>>>0!==b||b>=a.length)throw H.a(P.a2(b,a,null,null,null))
return a.getItem(b)},
q:function(a,b,c){throw H.a(new P.l("Cannot assign element of immutable List."))},
sh:function(a,b){throw H.a(new P.l("Cannot resize immutable List."))},
gN:function(a){if(a.length>0)return a[0]
throw H.a(new P.C("No elements"))},
G:function(a,b){return this.i(a,b)},
$ish:1,
$ash:function(){return[P.aI]},
$isf:1,
$asf:function(){return[P.aI]},
"%":"SVGLengthList"},fM:{"^":"i+Q;",
$ash:function(){return[P.aI]},
$asf:function(){return[P.aI]},
$ish:1,
$isf:1},fR:{"^":"fM+aZ;",
$ash:function(){return[P.aI]},
$asf:function(){return[P.aI]},
$ish:1,
$isf:1},lK:{"^":"p;",$isi:1,"%":"SVGMarkerElement"},lL:{"^":"p;",$isi:1,"%":"SVGMaskElement"},aL:{"^":"i;",$isb:1,"%":"SVGNumber"},lY:{"^":"fS;",
gh:function(a){return a.length},
i:function(a,b){if(b>>>0!==b||b>=a.length)throw H.a(P.a2(b,a,null,null,null))
return a.getItem(b)},
q:function(a,b,c){throw H.a(new P.l("Cannot assign element of immutable List."))},
sh:function(a,b){throw H.a(new P.l("Cannot resize immutable List."))},
gN:function(a){if(a.length>0)return a[0]
throw H.a(new P.C("No elements"))},
G:function(a,b){return this.i(a,b)},
$ish:1,
$ash:function(){return[P.aL]},
$isf:1,
$asf:function(){return[P.aL]},
"%":"SVGNumberList"},fN:{"^":"i+Q;",
$ash:function(){return[P.aL]},
$asf:function(){return[P.aL]},
$ish:1,
$isf:1},fS:{"^":"fN+aZ;",
$ash:function(){return[P.aL]},
$asf:function(){return[P.aL]},
$ish:1,
$isf:1},m2:{"^":"p;",$isi:1,"%":"SVGPatternElement"},dw:{"^":"p;",$isdw:1,$isi:1,"%":"SVGScriptElement"},f5:{"^":"an;a",
O:function(){var z,y,x,w,v,u
z=this.a.getAttribute("class")
y=P.J(null,null,null,P.o)
if(z==null)return y
for(x=z.split(" "),w=x.length,v=0;v<x.length;x.length===w||(0,H.a5)(x),++v){u=J.cO(x[v])
if(u.length!==0)y.v(0,u)}return y},
b5:function(a){this.a.setAttribute("class",a.a3(0," "))}},p:{"^":"A;",
ga2:function(a){return new P.f5(a)},
gbA:function(a){return new P.d5(a,new W.R(a))},
S:function(a,b,c,d){var z,y,x,w,v,u
if(d==null){z=H.u([],[W.c6])
d=new W.c7(z)
z.push(W.cm(null))
z.push(W.cq())
z.push(new W.jJ())}c=new W.ef(d)
y='<svg version="1.1">'+H.d(b)+"</svg>"
z=document
x=z.body
w=(x&&C.m).ej(x,y,c)
v=z.createDocumentFragment()
w.toString
z=new W.R(w)
u=z.gan(z)
for(;z=u.firstChild,z!=null;)v.appendChild(z)
return v},
gaC:function(a){return new W.e0(a,"click",!1,[W.a3])},
$isp:1,
$isM:1,
$isi:1,
"%":"SVGComponentTransferFunctionElement|SVGDescElement|SVGDiscardElement|SVGFEDistantLightElement|SVGFEFuncAElement|SVGFEFuncBElement|SVGFEFuncGElement|SVGFEFuncRElement|SVGFEMergeNodeElement|SVGFEPointLightElement|SVGFESpotLightElement|SVGMetadataElement|SVGStopElement|SVGStyleElement|SVGTitleElement;SVGElement"},m8:{"^":"aX;",$isi:1,"%":"SVGSVGElement"},m9:{"^":"p;",$isi:1,"%":"SVGSymbolElement"},ib:{"^":"aX;","%":"SVGTSpanElement|SVGTextElement|SVGTextPositioningElement;SVGTextContentElement"},md:{"^":"ib;",$isi:1,"%":"SVGTextPathElement"},me:{"^":"aX;",$isi:1,"%":"SVGUseElement"},mf:{"^":"p;",$isi:1,"%":"SVGViewElement"},mn:{"^":"p;",$isi:1,"%":"SVGGradientElement|SVGLinearGradientElement|SVGRadialGradientElement"},ms:{"^":"p;",$isi:1,"%":"SVGCursorElement"},mt:{"^":"p;",$isi:1,"%":"SVGFEDropShadowElement"},mu:{"^":"p;",$isi:1,"%":"SVGMPathElement"}}],["","",,P,{"^":"",b7:{"^":"b;",$ish:1,
$ash:function(){return[P.j]},
$isf:1,
$asf:function(){return[P.j]}}}],["","",,P,{"^":""}],["","",,P,{"^":""}],["","",,P,{"^":""}],["","",,A,{"^":"",d8:{"^":"b;a,b",
j:function(a){return this.b}},fz:{"^":"b;a,b,c,d,e",
dg:function(){this.b=0
this.a=document.querySelector("#header")
this.c=C.n
W.ah(window.document,"scroll",new A.fB(this),!1,W.ae)},
m:{
fA:function(){var z=new A.fz(null,null,null,!1,0)
z.dg()
return z}}},fB:{"^":"c:0;a",
$1:function(a){var z,y,x,w,v
z=this.a
y=z.b-C.f.gal(window)
if(y<0){z.e=0
if(z.c===C.n){x=C.f.gal(window)
w=z.a.clientHeight
if(typeof w!=="number")return H.r(w)
w=x>=w
x=w}else x=!1
if(x){J.a6(z.a).v(0,"scrollfollow")
J.a6(z.a).p(0,"scrolltop")
x=z.a
w=x.style
x=x.clientHeight
if(typeof x!=="number")return x.bU()
x=C.c.j(-x)+"px"
w.top=x
z.c=C.i}else{if(z.c===C.i){x=C.f.gal(window)
w=z.a.clientHeight
if(typeof w!=="number")return H.r(w)
w=x>=w
x=w}else x=!1
if(x){x=z.a.style.top
v=J.al(H.ar(C.a.k(x,0,C.a.b_(x,"px")),null,null),y)
x=z.a.clientHeight
if(typeof x!=="number")return x.bU()
if(J.cE(v,-x)){x=z.a.clientHeight
if(typeof x!=="number")return x.bU()
v=-x}x=z.a.style
w=J.V(v)+"px"
x.top=w}}}else if(y>0&&!0){z.e=z.a.getBoundingClientRect().height
if(z.c===C.i&&C.f.gal(window)<=0){J.a6(z.a).v(0,"scrolltop")
J.a6(z.a).p(0,"scrollfollow")
x=z.a.style
x.top="0px"
z.c=C.n}else if(z.c===C.i&&C.f.gal(window)>0){x=z.a.style.top
v=J.al(H.ar(C.a.k(x,0,C.a.b_(x,"px")),null,null),y)
if(J.bN(v,0))v=0
x=z.a.style
w=J.V(v)+"px"
x.top=w}}z.b=C.f.gal(window)}}}],["","",,T,{"^":"",hc:{"^":"b;a,b,c,d",
f5:[function(a){var z,y,x,w
z=H.bH(J.bQ(a),"$isA")
z.toString
y=z.getAttribute("data-"+new W.ci(new W.by(z)).a0("value"))
z=window.location
x="https://"+H.d(y)+".hibis.com"
w=P.dU()
z.href=x+H.d(w.gbG(w))},"$1","ge_",2,0,26],
dh:function(a){var z,y,x,w
z=this.a
y=z.querySelector("#selected-language")
this.d=y
J.bR(y,a.as("lang_"+a.b))
this.b=z.querySelector("#selected-language-options")
y=document
x=new W.aM(y.querySelectorAll(".language-option"),[null])
this.c=x.a6(x,!1)
z=J.bh(z)
W.ah(z.a,z.b,new T.he(this),!1,H.y(z,0))
W.ah(y,"click",new T.hf(this),!1,W.a3)
for(z=this.c,y=z.length,x=this.ge_(),w=0;w<z.length;z.length===y||(0,H.a5)(z),++w)J.bh(z[w]).ah(x)},
m:{
hd:function(a){var z=new T.hc(document.querySelector("#language-selector"),null,null,null)
z.dh(a)
return z}}},he:{"^":"c:0;a",
$1:function(a){J.f1(a)
J.a6(this.a.b).p(0,"hide")}},hf:{"^":"c:0;a",
$1:function(a){return J.a6(this.a.b).v(0,"hide")}}}],["","",,F,{"^":"",
mB:[function(){var z,y,x
z=document
L.hX(z.querySelector(".slide-container"))
y=[null]
x=[W.a3]
new W.ba(new W.aM(z.querySelectorAll(".collapse-toggle"),y),!1,"click",x).ah(F.kQ())
new W.ba(new W.aM(z.querySelectorAll(".arrow-up-icon"),y),!1,"click",x).ah(new F.kR())
y=$.$get$cw()
y.toString
new W.ba(y,!1,"click",x).ah(F.eD())
y=$.$get$cx()
y.toString
new W.ba(y,!1,"click",x).ah(F.eD())
V.hB(null)},"$0","eC",0,0,2],
mE:[function(a){var z,y,x,w
z=J.bQ(a)
y=J.q(z)
x=y.gbB(z)
x="#"+H.d(x.a.a.getAttribute("data-"+x.a0("target")))
w=document.querySelector(x)
x=J.q(w)
if(x.ga2(w).F(0,"collapsed")){y.ga2(z).v(0,"open")
x.ga2(w).p(0,"collapsed")}else{y.ga2(z).p(0,"open")
x.ga2(w).v(0,"collapsed")}},"$1","kQ",2,0,6],
mC:[function(a){var z,y,x,w
z=J.bQ(a)
y=$.$get$cx()
y.toString
W.bB(y).p(0,"open")
y=$.$get$cw()
y.toString
W.bB(y).p(0,"open")
y=$.$get$ev()
y.toString
W.bB(y).p(0,"hide")
y=J.eO(z)
x=y.a.a.getAttribute("data-"+y.a0("target"))
y=$.$get$ew()
y.H(y,new F.kU(x))
y=$.$get$ep()
y.H(y,new F.kV(x))
y=$.$get$ex()
y.H(y,new F.kW(x))
y="#node-"+H.d(x)
w=document
y=w.querySelector(y)
y=y==null?y:J.a6(y)
if(!(y==null))J.cF(y,"open")
y=w.querySelector("#button-"+H.d(x))
y=y==null?y:J.a6(y)
if(!(y==null))J.cF(y,"open")},"$1","eD",2,0,6],
kR:{"^":"c:0;",
$1:function(a){return C.f.bX(window,0,0)}},
kU:{"^":"c:0;a",
$1:function(a){return J.bR(a,$.$get$bK().as(H.d(this.a)))}},
kV:{"^":"c:0;a",
$1:function(a){return J.bR(a,$.$get$bK().as("address_"+H.d(this.a)))}},
kW:{"^":"c:0;a",
$1:function(a){return J.cL(a,$.$get$bK().as("contact_"+H.d(this.a)),$.$get$eJ())}},
ft:{"^":"b;",
aW:function(a){return J.f0(a,"mailto:")}}},1],["","",,V,{"^":"",
hB:function(a){var z=document
V.dn(z.querySelector("#header-content"),"inc/header.html",new V.hH(a,z.querySelector("#footer")))},
dn:function(a,b,c){var z,y,x
if(a==null)throw H.a(P.bT("container"))
z=W.fD(b,null,null).bP(new V.hx(a,c))
y=new V.hy()
x=$.n
if(x!==C.d)y=P.cu(y,x)
z.aJ(new P.ck(null,new P.X(0,x,null,[H.y(z,0)]),2,null,y))},
m0:[function(a){var z,y
z=document.querySelector("#hamburger-menu").style
y=z.visibility==="visible"?"hidden":"visible"
z.visibility=y},"$1","kX",2,0,6],
hz:function(){var z,y
z=P.dU()
y=z.gaY(z)
z=$.$get$c9()
z.b=J.w(y).b_(y,".")===2?C.a.k(y,0,2):"en"
T.hd(z)
z=new W.aM(document.querySelectorAll(".lang-exp"),[null])
z.H(z,new V.hA())},
hH:{"^":"c:1;a,b",
$0:function(){var z,y
z=document
H.bH(z.querySelector("#academy"),"$isbS").href="http://fraudacademy.hibis.com"
H.bH(z.querySelector("#academy_small"),"$isbS").href="http://fraudacademy.hibis.com"
y=J.bh(z.querySelector("#hamburger"))
W.ah(y.a,y.b,V.kX(),!1,H.y(y,0))
z=J.cH(z.querySelector("#micro-nav-list"))
z.H(z,new V.hF())
A.fA()
V.dn(this.b,"inc/footer.html",new V.hG())}},
hF:{"^":"c:27;",
$1:function(a){J.bh(J.eP(J.cH(a))).ah(new V.hE())}},
hE:{"^":"c:0;",
$1:function(a){var z=document.querySelector("#hamburger-menu").style
z.visibility="hidden"
return"hidden"}},
hG:{"^":"c:1;",
$0:function(){var z,y,x
z=document
y=new W.aM(z.querySelectorAll(".unresolved"),[null])
y.H(y,new V.hC())
V.hz()
if(window.location.hash.length!==0){x=z.querySelector(window.location.hash)
if(x!=null)P.cd(C.E,new V.hD(x))}}},
hC:{"^":"c:4;",
$1:function(a){J.cM(J.cJ(a),"opacity","1","")}},
hD:{"^":"c:1;a",
$0:function(){return C.f.bX(window,0,C.e.bL(this.a.offsetTop))}},
hx:{"^":"c:7;a,b",
$1:function(a){var z
J.cL(this.a,a,new V.dH())
z=this.b
if(z!=null)z.$0()}},
hy:{"^":"c:0;",
$1:function(a){P.bL(J.V(a))}},
hA:{"^":"c:4;",
$1:function(a){var z,y,x
z=$.$get$c9()
y=J.q(a)
x=y.gbB(a)
return y.aH(a,z.as(x.a.a.getAttribute("data-"+x.a0("exp"))),new V.dH())}},
dH:{"^":"b;",
aa:function(a){return!0},
a1:function(a,b,c){return!0}}}],["","",,Z,{"^":"",dp:{"^":"b;a,b",
as:function(a){var z=this.a
return z.i(0,this.b).aX(a)?z.i(0,this.b).i(0,a):a}}}],["","",,L,{"^":"",hW:{"^":"b;a,b,c,d,e",
f8:[function(a){var z,y,x,w
z=this.b
for(y=this.d,x=z;x===z;){x=y.cL(10)
this.b=x}y=this.a
if(z<0||z>=10)return H.e(y,z)
w=y[z].style
if(x<0||x>=10)return H.e(y,x)
x=y[x].style;(x&&C.h).am(x,"opacity","0","");(w&&C.h).am(w,"opacity","0","")
P.cd(C.G,new L.hY(this,z))},"$1","geE",2,0,28],
dj:function(a){var z,y,x,w,v,u
z=this.a
y=this.e
C.b.H(z,J.eN(y))
x=y.style
x.position="relative"
x=y.style
x.marginBottom="1rem"
x=y.style
x.backgroundColor="white"
for(w=0;w<10;++w){v=z[w]
v.alt="slide-"+w
v.className="no-height"
x=v.style
x.display="block"
x=v.style
x.position="relative"
x=v.style;(x&&C.h).am(x,"transition","opacity 100ms ease","")
x=v.style
x.width="100%"
x=v.style
x.zIndex="1"
y.appendChild(v)}u=document.createElement("h2")
u.classList.add("lang-exp")
u.setAttribute("data-"+new W.ci(new W.by(u)).a0("exp"),"frontpage_title")
x=u.style
x.textTransform="inherit"
x=u.style
x.backgroundColor="rgba(0,0,0,0.6)"
x=u.style
x.color="white"
x=u.style
x.padding="0.4em 0.1em"
x=u.style
x.margin="-7rem auto 0 auto"
x=u.style
x.textAlign="center"
x=u.style
x.position="relative"
x=u.style
x.zIndex="2"
y.appendChild(u)
y=this.d.cL(10)
this.b=y
if(y<0||y>=10)return H.e(z,y)
z[y].classList.remove("no-height")
P.ii(C.F,this.geE())},
m:{
hX:function(a){var z,y,x,w,v,u,t,s,r,q,p
z=W.a1(null,"gfx/slide_1.jpg",null)
y=W.a1(null,"gfx/slide_2.jpg",null)
x=W.a1(null,"gfx/slide_3.jpg",null)
w=W.a1(null,"gfx/slide_4.jpg",null)
v=W.a1(null,"gfx/slide_5.jpg",null)
u=W.a1(null,"gfx/slide_6.jpg",null)
t=W.a1(null,"gfx/slide_7.jpg",null)
s=W.a1(null,"gfx/slide_8.jpg",null)
r=W.a1(null,"gfx/slide_9.jpg",null)
q=W.a1(null,"gfx/slide_10.jpg",null)
p=P.jw(Date.now())
z=new L.hW([z,y,x,w,v,u,t,s,r,q],null,"1400px",p,a)
z.dj(a)
return z}}},hY:{"^":"c:1;a,b",
$0:function(){var z,y,x
z=this.a
y=z.a
x=this.b
if(x<0||x>=10)return H.e(y,x)
y[x].classList.add("no-height")
x=z.b
if(x<0||x>=10)return H.e(y,x)
x=y[x].style;(x&&C.h).am(x,"opacity","1","")
z=z.b
if(z<0||z>=10)return H.e(y,z)
y[z].classList.remove("no-height")}}}]]
setupProgram(dart,0)
J.m=function(a){if(typeof a=="number"){if(Math.floor(a)==a)return J.dc.prototype
return J.h3.prototype}if(typeof a=="string")return J.b2.prototype
if(a==null)return J.h4.prototype
if(typeof a=="boolean")return J.h2.prototype
if(a.constructor==Array)return J.b0.prototype
if(typeof a!="object"){if(typeof a=="function")return J.b3.prototype
return a}if(a instanceof P.b)return a
return J.bE(a)}
J.w=function(a){if(typeof a=="string")return J.b2.prototype
if(a==null)return a
if(a.constructor==Array)return J.b0.prototype
if(typeof a!="object"){if(typeof a=="function")return J.b3.prototype
return a}if(a instanceof P.b)return a
return J.bE(a)}
J.Y=function(a){if(a==null)return a
if(a.constructor==Array)return J.b0.prototype
if(typeof a!="object"){if(typeof a=="function")return J.b3.prototype
return a}if(a instanceof P.b)return a
return J.bE(a)}
J.cz=function(a){if(typeof a=="number")return J.b1.prototype
if(a==null)return a
if(!(a instanceof P.b))return J.b9.prototype
return a}
J.ky=function(a){if(typeof a=="number")return J.b1.prototype
if(typeof a=="string")return J.b2.prototype
if(a==null)return a
if(!(a instanceof P.b))return J.b9.prototype
return a}
J.aT=function(a){if(typeof a=="string")return J.b2.prototype
if(a==null)return a
if(!(a instanceof P.b))return J.b9.prototype
return a}
J.q=function(a){if(a==null)return a
if(typeof a!="object"){if(typeof a=="function")return J.b3.prototype
return a}if(a instanceof P.b)return a
return J.bE(a)}
J.al=function(a,b){if(typeof a=="number"&&typeof b=="number")return a+b
return J.ky(a).X(a,b)}
J.z=function(a,b){if(a==null)return b==null
if(typeof a!="object")return b!=null&&a===b
return J.m(a).w(a,b)}
J.bN=function(a,b){if(typeof a=="number"&&typeof b=="number")return a>b
return J.cz(a).ak(a,b)}
J.cE=function(a,b){if(typeof a=="number"&&typeof b=="number")return a<b
return J.cz(a).I(a,b)}
J.bO=function(a,b){if(typeof b==="number")if(a.constructor==Array||typeof a=="string"||H.kO(a,a[init.dispatchPropertyName]))if(b>>>0===b&&b<a.length)return a[b]
return J.w(a).i(a,b)}
J.eK=function(a,b,c){return J.q(a).dV(a,b,c)}
J.cF=function(a,b){return J.Y(a).v(a,b)}
J.eL=function(a,b,c,d){return J.q(a).cw(a,b,c,d)}
J.bP=function(a,b,c){return J.w(a).eh(a,b,c)}
J.aV=function(a,b){return J.Y(a).G(a,b)}
J.eM=function(a,b,c,d){return J.Y(a).ar(a,b,c,d)}
J.eN=function(a){return J.q(a).ge9(a)}
J.cG=function(a){return J.q(a).gea(a)}
J.cH=function(a){return J.q(a).gbA(a)}
J.a6=function(a){return J.q(a).ga2(a)}
J.eO=function(a){return J.q(a).gbB(a)}
J.aW=function(a){return J.q(a).gae(a)}
J.eP=function(a){return J.Y(a).gN(a)}
J.ac=function(a){return J.m(a).gC(a)}
J.cI=function(a){return J.w(a).gu(a)}
J.ad=function(a){return J.Y(a).gD(a)}
J.U=function(a){return J.w(a).gh(a)}
J.eQ=function(a){return J.q(a).geF(a)}
J.bh=function(a){return J.q(a).gaC(a)}
J.eR=function(a){return J.q(a).geI(a)}
J.eS=function(a){return J.q(a).geJ(a)}
J.eT=function(a){return J.q(a).geQ(a)}
J.cJ=function(a){return J.q(a).gbY(a)}
J.eU=function(a){return J.q(a).geT(a)}
J.bQ=function(a){return J.q(a).gai(a)}
J.eV=function(a,b){return J.Y(a).a4(a,b)}
J.cK=function(a){return J.Y(a).eL(a)}
J.eW=function(a,b){return J.Y(a).p(a,b)}
J.eX=function(a,b,c,d){return J.q(a).cN(a,b,c,d)}
J.eY=function(a,b){return J.q(a).eP(a,b)}
J.aC=function(a,b){return J.q(a).aG(a,b)}
J.eZ=function(a,b){return J.q(a).seb(a,b)}
J.f_=function(a,b){return J.q(a).saZ(a,b)}
J.bR=function(a,b){return J.q(a).b8(a,b)}
J.cL=function(a,b,c){return J.q(a).aH(a,b,c)}
J.cM=function(a,b,c,d){return J.q(a).am(a,b,c,d)}
J.f0=function(a,b){return J.aT(a).L(a,b)}
J.f1=function(a){return J.q(a).d7(a)}
J.f2=function(a,b,c){return J.Y(a).bZ(a,b,c)}
J.cN=function(a){return J.aT(a).eU(a)}
J.V=function(a){return J.m(a).j(a)}
J.f3=function(a){return J.aT(a).eV(a)}
J.cO=function(a){return J.aT(a).eW(a)}
I.F=function(a){a.immutable$list=Array
a.fixed$length=Array
return a}
var $=I.p
C.m=W.bV.prototype
C.h=W.fj.prototype
C.H=W.aY.prototype
C.I=J.i.prototype
C.b=J.b0.prototype
C.c=J.dc.prototype
C.e=J.b1.prototype
C.a=J.b2.prototype
C.P=J.b3.prototype
C.X=W.hq.prototype
C.y=J.hI.prototype
C.z=W.i8.prototype
C.q=J.b9.prototype
C.f=W.iu.prototype
C.B=new P.f7(!1)
C.A=new P.f6(C.B)
C.C=new P.hw()
C.D=new P.iT()
C.d=new P.jx()
C.r=new P.ao(0)
C.E=new P.ao(1e5)
C.F=new P.ao(3e7)
C.G=new P.ao(6e5)
C.n=new A.d8(0,"HeaderState.top")
C.i=new A.d8(1,"HeaderState.follow")
C.J=function() {  var toStringFunction = Object.prototype.toString;  function getTag(o) {    var s = toStringFunction.call(o);    return s.substring(8, s.length - 1);  }  function getUnknownTag(object, tag) {    if (/^HTML[A-Z].*Element$/.test(tag)) {      var name = toStringFunction.call(object);      if (name == "[object Object]") return null;      return "HTMLElement";    }  }  function getUnknownTagGenericBrowser(object, tag) {    if (self.HTMLElement && object instanceof HTMLElement) return "HTMLElement";    return getUnknownTag(object, tag);  }  function prototypeForTag(tag) {    if (typeof window == "undefined") return null;    if (typeof window[tag] == "undefined") return null;    var constructor = window[tag];    if (typeof constructor != "function") return null;    return constructor.prototype;  }  function discriminator(tag) { return null; }  var isBrowser = typeof navigator == "object";  return {    getTag: getTag,    getUnknownTag: isBrowser ? getUnknownTagGenericBrowser : getUnknownTag,    prototypeForTag: prototypeForTag,    discriminator: discriminator };}
C.t=function(hooks) { return hooks; }
C.K=function(hooks) {  if (typeof dartExperimentalFixupGetTag != "function") return hooks;  hooks.getTag = dartExperimentalFixupGetTag(hooks.getTag);}
C.L=function(hooks) {  var getTag = hooks.getTag;  var prototypeForTag = hooks.prototypeForTag;  function getTagFixed(o) {    var tag = getTag(o);    if (tag == "Document") {      // "Document", so we check for the xmlVersion property, which is the empty      if (!!o.xmlVersion) return "!Document";      return "!HTMLDocument";    }    return tag;  }  function prototypeForTagFixed(tag) {    if (tag == "Document") return null;    return prototypeForTag(tag);  }  hooks.getTag = getTagFixed;  hooks.prototypeForTag = prototypeForTagFixed;}
C.M=function(hooks) {  var userAgent = typeof navigator == "object" ? navigator.userAgent : "";  if (userAgent.indexOf("Firefox") == -1) return hooks;  var getTag = hooks.getTag;  var quickMap = {    "BeforeUnloadEvent": "Event",    "DataTransfer": "Clipboard",    "GeoGeolocation": "Geolocation",    "Location": "!Location",    "WorkerMessageEvent": "MessageEvent",    "XMLDocument": "!Document"};  function getTagFirefox(o) {    var tag = getTag(o);    return quickMap[tag] || tag;  }  hooks.getTag = getTagFirefox;}
C.u=function getTagFallback(o) {  var s = Object.prototype.toString.call(o);  return s.substring(8, s.length - 1);}
C.N=function(hooks) {  var userAgent = typeof navigator == "object" ? navigator.userAgent : "";  if (userAgent.indexOf("Trident/") == -1) return hooks;  var getTag = hooks.getTag;  var quickMap = {    "BeforeUnloadEvent": "Event",    "DataTransfer": "Clipboard",    "HTMLDDElement": "HTMLElement",    "HTMLDTElement": "HTMLElement",    "HTMLPhraseElement": "HTMLElement",    "Position": "Geoposition"  };  function getTagIE(o) {    var tag = getTag(o);    var newTag = quickMap[tag];    if (newTag) return newTag;    if (tag == "Object") {      if (window.DataView && (o instanceof window.DataView)) return "DataView";    }    return tag;  }  function prototypeForTagIE(tag) {    var constructor = window[tag];    if (constructor == null) return null;    return constructor.prototype;  }  hooks.getTag = getTagIE;  hooks.prototypeForTag = prototypeForTagIE;}
C.O=function(getTagFallback) {  return function(hooks) {    if (typeof navigator != "object") return hooks;    var ua = navigator.userAgent;    if (ua.indexOf("DumpRenderTree") >= 0) return hooks;    if (ua.indexOf("Chrome") >= 0) {      function confirm(p) {        return typeof window == "object" && window[p] && window[p].name == p;      }      if (confirm("Window") && confirm("HTMLElement")) return hooks;    }    hooks.getTag = getTagFallback;  };}
C.j=I.F([0,0,32776,33792,1,10240,0,0])
C.Q=H.u(I.F(["*::class","*::dir","*::draggable","*::hidden","*::id","*::inert","*::itemprop","*::itemref","*::itemscope","*::lang","*::spellcheck","*::title","*::translate","A::accesskey","A::coords","A::hreflang","A::name","A::shape","A::tabindex","A::target","A::type","AREA::accesskey","AREA::alt","AREA::coords","AREA::nohref","AREA::shape","AREA::tabindex","AREA::target","AUDIO::controls","AUDIO::loop","AUDIO::mediagroup","AUDIO::muted","AUDIO::preload","BDO::dir","BODY::alink","BODY::bgcolor","BODY::link","BODY::text","BODY::vlink","BR::clear","BUTTON::accesskey","BUTTON::disabled","BUTTON::name","BUTTON::tabindex","BUTTON::type","BUTTON::value","CANVAS::height","CANVAS::width","CAPTION::align","COL::align","COL::char","COL::charoff","COL::span","COL::valign","COL::width","COLGROUP::align","COLGROUP::char","COLGROUP::charoff","COLGROUP::span","COLGROUP::valign","COLGROUP::width","COMMAND::checked","COMMAND::command","COMMAND::disabled","COMMAND::label","COMMAND::radiogroup","COMMAND::type","DATA::value","DEL::datetime","DETAILS::open","DIR::compact","DIV::align","DL::compact","FIELDSET::disabled","FONT::color","FONT::face","FONT::size","FORM::accept","FORM::autocomplete","FORM::enctype","FORM::method","FORM::name","FORM::novalidate","FORM::target","FRAME::name","H1::align","H2::align","H3::align","H4::align","H5::align","H6::align","HR::align","HR::noshade","HR::size","HR::width","HTML::version","IFRAME::align","IFRAME::frameborder","IFRAME::height","IFRAME::marginheight","IFRAME::marginwidth","IFRAME::width","IMG::align","IMG::alt","IMG::border","IMG::height","IMG::hspace","IMG::ismap","IMG::name","IMG::usemap","IMG::vspace","IMG::width","INPUT::accept","INPUT::accesskey","INPUT::align","INPUT::alt","INPUT::autocomplete","INPUT::autofocus","INPUT::checked","INPUT::disabled","INPUT::inputmode","INPUT::ismap","INPUT::list","INPUT::max","INPUT::maxlength","INPUT::min","INPUT::multiple","INPUT::name","INPUT::placeholder","INPUT::readonly","INPUT::required","INPUT::size","INPUT::step","INPUT::tabindex","INPUT::type","INPUT::usemap","INPUT::value","INS::datetime","KEYGEN::disabled","KEYGEN::keytype","KEYGEN::name","LABEL::accesskey","LABEL::for","LEGEND::accesskey","LEGEND::align","LI::type","LI::value","LINK::sizes","MAP::name","MENU::compact","MENU::label","MENU::type","METER::high","METER::low","METER::max","METER::min","METER::value","OBJECT::typemustmatch","OL::compact","OL::reversed","OL::start","OL::type","OPTGROUP::disabled","OPTGROUP::label","OPTION::disabled","OPTION::label","OPTION::selected","OPTION::value","OUTPUT::for","OUTPUT::name","P::align","PRE::width","PROGRESS::max","PROGRESS::min","PROGRESS::value","SELECT::autocomplete","SELECT::disabled","SELECT::multiple","SELECT::name","SELECT::required","SELECT::size","SELECT::tabindex","SOURCE::type","TABLE::align","TABLE::bgcolor","TABLE::border","TABLE::cellpadding","TABLE::cellspacing","TABLE::frame","TABLE::rules","TABLE::summary","TABLE::width","TBODY::align","TBODY::char","TBODY::charoff","TBODY::valign","TD::abbr","TD::align","TD::axis","TD::bgcolor","TD::char","TD::charoff","TD::colspan","TD::headers","TD::height","TD::nowrap","TD::rowspan","TD::scope","TD::valign","TD::width","TEXTAREA::accesskey","TEXTAREA::autocomplete","TEXTAREA::cols","TEXTAREA::disabled","TEXTAREA::inputmode","TEXTAREA::name","TEXTAREA::placeholder","TEXTAREA::readonly","TEXTAREA::required","TEXTAREA::rows","TEXTAREA::tabindex","TEXTAREA::wrap","TFOOT::align","TFOOT::char","TFOOT::charoff","TFOOT::valign","TH::abbr","TH::align","TH::axis","TH::bgcolor","TH::char","TH::charoff","TH::colspan","TH::headers","TH::height","TH::nowrap","TH::rowspan","TH::scope","TH::valign","TH::width","THEAD::align","THEAD::char","THEAD::charoff","THEAD::valign","TR::align","TR::bgcolor","TR::char","TR::charoff","TR::valign","TRACK::default","TRACK::kind","TRACK::label","TRACK::srclang","UL::compact","UL::type","VIDEO::controls","VIDEO::height","VIDEO::loop","VIDEO::mediagroup","VIDEO::muted","VIDEO::preload","VIDEO::width"]),[P.o])
C.R=I.F(["A","FORM"])
C.S=I.F(["A::href","FORM::action"])
C.k=I.F([0,0,65490,45055,65535,34815,65534,18431])
C.l=I.F([0,0,26624,1023,65534,2047,65534,2047])
C.T=I.F(["HEAD","AREA","BASE","BASEFONT","BR","COL","COLGROUP","EMBED","FRAME","FRAMESET","HR","IMAGE","IMG","INPUT","ISINDEX","LINK","META","PARAM","SOURCE","STYLE","TITLE","WBR"])
C.U=I.F([])
C.V=I.F([0,0,32722,12287,65534,34815,65534,18431])
C.W=I.F(["A::accesskey","A::coords","A::hreflang","A::name","A::shape","A::tabindex","A::target","A::type","FORM::accept","FORM::autocomplete","FORM::enctype","FORM::method","FORM::name","FORM::novalidate","FORM::target"])
C.v=I.F([0,0,24576,1023,65534,34815,65534,18431])
C.w=I.F([0,0,32754,11263,65534,34815,65534,18431])
C.x=I.F([0,0,65490,12287,65535,34815,65534,18431])
C.o=H.u(I.F(["bind","if","ref","repeat","syntax"]),[P.o])
C.p=H.u(I.F(["A::href","AREA::href","BLOCKQUOTE::cite","BODY::background","COMMAND::icon","DEL::cite","FORM::action","IMG::src","INPUT::src","INS::cite","Q::cite","VIDEO::poster"]),[P.o])
$.dr="$cachedFunction"
$.ds="$cachedInvocation"
$.a0=0
$.aF=null
$.cQ=null
$.cA=null
$.eq=null
$.eF=null
$.bD=null
$.bI=null
$.cB=null
$.aw=null
$.aP=null
$.aQ=null
$.cs=!1
$.n=C.d
$.d4=0
$.a7=null
$.bZ=null
$.d2=null
$.d1=null
$.d_=null
$.cZ=null
$.cY=null
$.cX=null
$=null
init.isHunkLoaded=function(a){return!!$dart_deferred_initializers$[a]}
init.deferredInitialized=new Object(null)
init.isHunkInitialized=function(a){return init.deferredInitialized[a]}
init.initializeLoadedHunk=function(a){$dart_deferred_initializers$[a]($globals$,$)
init.deferredInitialized[a]=true}
init.deferredLibraryUris={}
init.deferredLibraryHashes={};(function(a){for(var z=0;z<a.length;){var y=a[z++]
var x=a[z++]
var w=a[z++]
I.$lazy(y,x,w)}})(["cW","$get$cW",function(){return H.ey("_$dart_dartClosure")},"c_","$get$c_",function(){return H.ey("_$dart_js")},"d9","$get$d9",function(){return H.fZ()},"da","$get$da",function(){if(typeof WeakMap=="function")var z=new WeakMap()
else{z=$.d4
$.d4=z+1
z="expando$key$"+z}return new P.fv(null,z)},"dI","$get$dI",function(){return H.a4(H.bv({
toString:function(){return"$receiver$"}}))},"dJ","$get$dJ",function(){return H.a4(H.bv({$method$:null,
toString:function(){return"$receiver$"}}))},"dK","$get$dK",function(){return H.a4(H.bv(null))},"dL","$get$dL",function(){return H.a4(function(){var $argumentsExpr$='$arguments$'
try{null.$method$($argumentsExpr$)}catch(z){return z.message}}())},"dP","$get$dP",function(){return H.a4(H.bv(void 0))},"dQ","$get$dQ",function(){return H.a4(function(){var $argumentsExpr$='$arguments$'
try{(void 0).$method$($argumentsExpr$)}catch(z){return z.message}}())},"dN","$get$dN",function(){return H.a4(H.dO(null))},"dM","$get$dM",function(){return H.a4(function(){try{null.$method$}catch(z){return z.message}}())},"dS","$get$dS",function(){return H.a4(H.dO(void 0))},"dR","$get$dR",function(){return H.a4(function(){try{(void 0).$method$}catch(z){return z.message}}())},"cg","$get$cg",function(){return P.ix()},"aH","$get$aH",function(){var z,y
z=P.br
y=new P.X(0,P.iv(),null,[z])
y.dr(null,z)
return y},"aR","$get$aR",function(){return[]},"dX","$get$dX",function(){return H.hp([-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-1,-2,-2,-2,-2,-2,62,-2,62,-2,63,52,53,54,55,56,57,58,59,60,61,-2,-2,-2,-1,-2,-2,-2,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,-2,-2,-2,-2,63,-2,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,-2,-2,-2,-2,-2])},"en","$get$en",function(){return P.k8()},"cV","$get$cV",function(){return{}},"e3","$get$e3",function(){return P.df(["A","ABBR","ACRONYM","ADDRESS","AREA","ARTICLE","ASIDE","AUDIO","B","BDI","BDO","BIG","BLOCKQUOTE","BR","BUTTON","CANVAS","CAPTION","CENTER","CITE","CODE","COL","COLGROUP","COMMAND","DATA","DATALIST","DD","DEL","DETAILS","DFN","DIR","DIV","DL","DT","EM","FIELDSET","FIGCAPTION","FIGURE","FONT","FOOTER","FORM","H1","H2","H3","H4","H5","H6","HEADER","HGROUP","HR","I","IFRAME","IMG","INPUT","INS","KBD","LABEL","LEGEND","LI","MAP","MARK","MENU","METER","NAV","NOBR","OL","OPTGROUP","OPTION","OUTPUT","P","PRE","PROGRESS","Q","S","SAMP","SECTION","SELECT","SMALL","SOURCE","SPAN","STRIKE","STRONG","SUB","SUMMARY","SUP","TABLE","TBODY","TD","TEXTAREA","TFOOT","TH","THEAD","TIME","TR","TRACK","TT","U","UL","VAR","VIDEO","WBR"],null)},"cn","$get$cn",function(){return P.de()},"cT","$get$cT",function(){return P.hQ("^\\S+$",!0,!1)},"bK","$get$bK",function(){return new Z.dp(P.P(["en",P.P(["address_copenhagen","c/o Scillani Information AB<br />Vestergade 16<br />1456 Copenhagen<br />Denmark","address_gothenburg","Hibis AB<br />Kronhusgatan 11<br />411 05 G\xf6teborg<br />Sweden","address_helsinki","Hibis Associates<br />Centry Ltd","address_london","Hibis Europe Ltd","address_malmo","Hibis AB","address_oslo","Hibis AS<br /> Meltzersgt. 4<br/> 0275 Oslo<br/> Norway","address_rome","Hibis Associates","address_stockholm","Hibis AB","contact","Contact","contact_us","Contact us","contact_copenhagen","<strong>John Wallhoff</strong><br /><a href='mailto:john.wallhoff@hibis.com'>john.wallhoff@hibis.com</a><br />+ 45 70 77 43 131","contact_gothenburg","<strong>Carina S\xf6rqvist</strong><br /><a href='mailto:carina.sorqvist@hibis.com'>carina.sorqvist@hibis.com</a><br />+ 46 707 97 97 64","contact_helsinki","<strong>Petri Kelo</strong><br /><a href='mailto:petri.kelo@centry.global'>petri.kelo@centry.global</a><br />+ 358 40 50 001 068","contact_london","<strong>Allan McDonagh</strong><br /><a href='mailto:allan.mcdonagh@hibis.com'>allan.mcdonagh@hibis.com</a><br />+ 44 77 68 32 0161","contact_malmo","<strong>Richard Minogue</strong><br /><a href='mailto:richard.minogue@hibis.com'>richard.minogue@hibis.com</a><br />+ 46 761 882 497","contact_oslo","<strong>Veronica Morino</strong><br /><a href='mailto:veronica.morino@hibis.com'>veronica.morino@hibis.com</a><br />+ 47 91 86 32 19<br/><br/><strong>Nigel Krishna Iyer</strong><br /><a href='mailto:nigel.iyer@hibis.com'>nigel.iyer@hibis.com</a><br />+ 47 90 65 44 10<br/>+ 44 7523 570004 (UK)","contact_rome","<strong>Maurizio Carmignani</strong><br /><a href='mailto:maurizio.carmignani@hibis.com'>maurizio.carmignani@hibis.com</a><br />+ 39 3489501126","contact_stockholm","<strong>Richard Minogue</strong><br /><a href='mailto:richard.minogue@hibis.com'>richard.minogue@hibis.com</a><br />+ 46 761 882 497","copenhagen","Copenhagen","copyright","&copy;2017 Hibis. All rights reserved. Design by SoiaDg. Images by Floral Zu.","frontpage_title","<strong>Fraud and corruption <span class='orange-text'>can</span> be stopped</strong>","gothenburg","Gothenburg","hibis_associates","hibis associates","hibis_people","hibis people","helsinki","Helsinki","lang_en","English (english)","lang_no","Norwegian (norsk)","lang_it","Italian (italian)","language","Language","london","London","malmo","Malm\xf6","oslo","Oslo","our_history","Our history","our_history_text","<p><strong>Hibis</strong> was founded in 1998 by Martin Samociuk. Many of the people who joined at the start came from Network Security Management in London, a company which pioneered fraud investigation and prevention in the 1980\u2019s and 90\u2019s. In 1999, Martin was joined by Nigel Krishna Iyer and one year later by Allan McDonagh. Veronica Morino became part of the group in 2001 followed by Richard Minogue in 2002.The mission of Hibis has always been to put prevention and early detection FIRST. We share with clients the need to dramatically raise awareness of fraud and corruption, give them the ability to spot it early and provide advice and resources for well managed investigations. This includes training workshops, seminars, books, publications and films all with the purpose of stimulating this greater awareness and self-reliance.</p><p>Hibis' founder, Martin Samociuk, passed away in 2013 at the age of 62 from pancreatic cancer. He will be missed by all that knew him but we are grateful for the important work he left behind.</p><p>Today Hibis is an advisory organisation which we hope will help open people\u2019s eyes to the fact that even though fraud and corruption is all around us, it can be kept under control. Our aim is to provide innovative tools and techniques to deal with it, as well as the confidence to spot it early. We aim to support those people who wish to take a stand against fraud and corruption.</p><p>Finally, if you like what you have read, and feel that you are our sort of person, then do take contact with us. We don\u2019t recruit in the traditional manner \u2013 like-minded people usually find us\u2026</p>","profile_allan","Allan\u2019s long experience from 1967 includes UK Customs and Excise Investigations and New Scotland Yard, where he specialized in narcotics and organised crime. Between 1985 and 1997 Allan worked as Deputy Managing Director with Martin Samociuk at Network Security Management Limited, Europe\u2019s leading fraud investigation consultancy. Apart from leading hundreds of investigations and recovery projects throughout the world for both commercial and government clients, he created the highly successful Forensic Laboratories which were eventually acquired by Control Risks Group. Allan has project managed many successful investigations around the world.","profile_carina","Carina S\xf6rqvist has over 15 years of experience of preventing and investigating fraud and corruption. She has acted as the investigator and project leader in investigations for clients in various different industries. Her long experience of structured investigations of real fraud and corruption cases is used in seminars and trainings regarding investigation technique. She has, for several clients, developed action plans for how to handle incidents such as suspected fraud and/or corruption. She has worked as a Senior Consultant since 2003 and before that she worked with compliance as the manager of the Internal Control department in a multinational company. Carina has a financial background and her specialities are forensic accounting and interview techniques.","profile_jan","Jan has performed a number of forensic investigations and fraud detection projects, as well as held courses in red flag detection within fraud and corruption and corporate governance.  He holds an MBA and CPA degree from the Norwegian School of Economics and Business Administration in Bergen. After spending 4 years as an external auditor he was Chief Financial Officer for 9 years in an international construction company with operations in East Africa. After that he worked for over 20 years as advisor (on, among others, business development, sustainability evaluations, performance audit and background checks) for the Norwegian Ministry of Foreign Affairs (NORAD, Embassies and Norfund) and private sector companies operating in East-Africa, The Balkans, Baltic states, Georgia, Sri Lanka, Nepal and the Palestine Territories.","profile_john","John Wallhoff, a computer security and data-analysis expert for many years, develops and implements data models to detect patterns of fraud and corruption. John participates in investigations, leads trainings and supports his colleagues through development of leading edge models to pinpoint patterns of malpractice and unethical business behavior. In addition John has built information security strategies and contingency plans for a number of companies and as a compliment to fraud detection, develops data-analysis solutions for continuous monitoring of internal controls.","profile_martina","Martina has a combined Masters degree in Business and Economics (majoring in finance) from the Norwegian Business School (BI) and the University of Ljubljana (Slovenia). Right from an early age she wanted to play an active part in eradicating systematic inefficiencies. She recognized that corruption and fraud is one of the major obstacles to sustainability and growth and was able to apply her passion at Hibis. Martina specializes in identifying red flags of corruption through internal and external analysis, and understanding and investigating them across a wide range of countries and languages-zones.","profile_fridtjof","Fridtjof Klareng Dale's passion for fighting corruption and fraud started while studying for his bachelor in European Studies at the Norwegian University of Science and Technology (NTNU). Through his strong engagement in volunteerism, he joined the newly founded student organisation Anti-Corruption International (ACI) and helped build the organisation, spearheading projects showing that \u201cyoung people not only can play a part in eradicating a global problem, but can also take the lead.\u201d Through ACI he got to know Hibis, where he is now successfully working as a fraud investigator combining this with his anti-corruption activities.","profile_maurizio","Maurizio has 18 years\u2019 experience in innovation and organisational development in a wide variety of sectors which include telecommunications and technology, banking, retail and consumer products, culture, education and government, in primarily Italy, Switzerland and Brazil. He provides training to achieve fulfilment of goals both at a personal and organisational level. Finding fraud and corruption early, dealing with it responsibly to foster organisational robustness is an important cornerstone of his work today.","profile_nigel","Nigel has over 20 years experience investigating and detecting fraud and corruption. A computer scientist and qualified chartered accountant Nigel soon found that his true passion lay in rooting out corruption and fraud. Nigel is also today a qualified dramatist and has written a number of films and plays based on experiences, many of which are used in teaching worldwide. He has written several books and papers, and teaches widely how to defend organisations against the \u201ccommercial dark arts\u201d. He is also a fellow of the University of Leicester School of Business.","profile_petri","Petri Kelo is Hibis\u2019 associated partner in Finland. His academic background includes a Masters of Security from Helsinki University of Technology. Petri has worked for over 25 years with logistics, service quality and security as well as managing the risk of fraud and corruption. Petri is also one of the founders of Centry Ltd, a security company specialized in logistics & transportation security, cyber security, security risk management and compliance & investigative services. Petri is a well-known speaker and trainer in TAPA (Transportation Asset Protection Association), AEO (Authorized Economic Operator), ISO 28000 (Supply Chain Security Management) and logistics security.","profile_richard","Since his first full time job as internal auditor starting in 1975, Richard has accumulated experience in audit, investigation, financial control, and general management. Inquisitive by nature, he knows there is usually more than one right way to do things, and many wrong ways. Richard\u2019s talent for penetrating complexity and understanding his clients\u2019 business processes makes him a valuable resource for assessment, investigation and improvement projects. Richard graduated BSc in Accountancy, and is qualified CPA and CIA.","profile_veronica","Veronica has over 15 years\u2019 experience investigating, finding and training others on how to prevent and manage fraud and corruption around the world. A sociologist of work and economics with a master in organisational science, she has developed holistic desktop investigative research and analysis tools to explore organisations, business partners, suppliers, customers and key individuals and discover what is really going on at a fraction of the resources normally associated with investigation. Veronica has also worked for several years with the assessment of the effectiveness of organisations\u2019 anti-fraud and corruption programs and is currently completing a PhD degree on that subject.","red_flag_game","The <span class='red-text'>red</span><br />flag Game","rome","Rome","rulebending_final_question","It would assist our research if you could provide us with details of your job functions (anonymously)","rules_game","How far can you bend the rules?","search","Search","send","send","stockholm","Stockholm","the_fraud_academy","The Fraud Academy","what_we_do","What we do","what_we_do_collapsed_text_1",'<p>There is plenty of fraud and corruption around that can be found (preferably in the early stages) and stopped. Usually fraudulent and corrupt activities are cloaked in legitimacy, and finding the truth requires experience, effort and specialist knowledge.</p><p>Our proven structured methodology "B4" (which is short for "Finding fraud before it finds you") has been developed to efficiently find and effectively deal with fraud. B4 includes activities such as:</p><ul><li>Following the money, performing structured analysis, and running B4 algorithms on transactions to find the red flags.</li><li>Convening \u201cthinking like a thief\u201d sessions (an approach invented in the 1980\u2019s by Martin Samociuk, Hibis\u2019 founder) to anticipate how the fraudsters\u2019 mind works and build a profile of the types of frauds that are occurring or likely to occur.</li><li>Finding behavioural red flags by performing holistic desktop investigative research and analysis of organisations, business partners, suppliers, customers and key individuals. All with a special focus on opportunities, motives and how people rationalize dishonest or unethical behaviour.</li><li>Analysing indications of fraud and corruption to understand which issues are the most important, and condensing them into a manageable list for our clients to resolve.</li><li>Working together with our clients to find the most effective course of action to resolve problems. Long experience gives us an overview of different approaches, which ones are appropriate in different situations, and how they should be implemented.</li></li></ul><p>If not detected early, fraud and corruption will spread. Eventually, the problem will be discovered when it becomes too large to ignore, or is reported by whistle-blowers, or both. But why wait for the whistle-blower when you can use fraud detective techniques and uncover where early stage fraud and corruption is developing now? It\u2019s better to stay ahead of the game!</p>',"what_we_do_collapsed_text_2",'<p>We probably will never totally eradicate fraud and corruption. But by raising awareness and managing the risks we can control the cost and make corrupt behaviour less acceptable. Surprisingly, much fraud and corruption involves normal, good people such as valuable and trusted employees or business partners. Awareness is a powerful tool to help good people avoid bad mistakes they will later regret, and to show them how to protect the organisation against career fraudsters. As Nelson Mandela said, education is one of the most powerful ways to change the world. We have developed courses and techniques to bridge the skills gap and constantly look for innovative new ways to raise the awareness, spread knowledge and bring people together in the fight of corruption and fraud. Examples (details can be found in our Fraud Academy page) include:</p><ul><li>Practical open courses and workshops (including our "think like a thief methodology" and "fraud detective school")</li><li>Accredited management courses</li><li>On the job-training, in-house workshops and clinics</li><li>Multimedia based training delivered over the internet (or intranet)</li><li>Experiential learning, including drama, scenarios, live simulations, \u201ccorruption-theatre\u201d and films</li><li>Publications and books</li></ul>',"what_we_do_collapsed_text_3","<p>When it is required by the client, we investigate fraud and corruption constructively and effectively.</p><p>We believe in the beauty of small investigations that win back value. We have a track record of solving our client\u2019s problems efficiently and in a way which both identifies root causes and prevents recurrence.</p><p>Exceptional situations do occur from time to time for which a deep investigation may be required, such as when an organisation needs to prepare legal actions to recover major assets or salvage parts of a business. We manage all investigations in a controlled way avoiding unnecessary expenditure and ensuring that our client is always in the driver\u2019s seat.</p>","what_we_do_collapsed_text_4","<p>The scope and complexity of external regulation, designed to protect the public and punish corporate offenders is increasing. This absorbs management attention and leaves less room for more practical programs designed to protect the organisation. Management can fall into the trap of accepting bureaucratic solutions that appear to fulfil regulatory requirements, but which do not effectively address the issue of fraudulent and corrupt behaviour. Compliance programs based on checklists are unlikely to be effective!</p><p>We are able to measure the impact and effectiveness of your existing anti-fraud and corruption activities, identifying gaps and potential improvements that will bring down the cost of fraud and corruption and strengthen the ethical culture.</p><p>Our holistic framework and assessment tool brings together years of practical experience with a distillation of the most essential knowledge from widely used existing frameworks.</p>","what_we_do_collapsed_title_1","We find early fraud and help you resolve it","what_we_do_collapsed_title_2","We raise awareness, share knowledge and transfer skills","what_we_do_collapsed_title_3","We investigate fraud and corruption responsibly","what_we_do_collapsed_title_4","We assess effectiveness of existing anti-fraud and corruption programs","what_we_do_list_1_item_1","<strong>Finding</strong> and interpreting the many <strong>red flags</strong>","what_we_do_list_1_item_2","<strong>Investigations</strong> carried out in an efficient, responsible manner","what_we_do_list_1_item_3","<strong>Analysing</strong> the root causes of incidents to identify improvement opportunities","what_we_do_list_1_item_4","<strong>Providing</strong> (through practical workshops, training and other innovative devices) the <strong>skills</strong> to turn what looks like \"bad news\" into an opportunity to save money (see <a href='http://fraudacademy.hibis.com' target='_blank'>Hibis Fraud Academy</a>)","what_we_do_list_1_item_5","<strong>Assessing</strong> and <strong>measuring</strong> the <strong>effectiveness</strong>, strengths and weaknesses of existing anti-fraud and corruption programmes","what_we_do_paragraph_1","Fraud and corruption happens all the time and is arguably one of the greatest unmanaged costs in organisations and society today. Yet most management and employees have not had any practical training in this area. Our aim is to significantly raise awareness of fraud and corruption and its consequences. We assist and advise organisations, companies and everyone else concerned by:","who_we_are","Who we are"]),"it",P.P(["address_copenhagen","c/o Scillani Information AB<br />Vestergade 16<br />1456 Copenhagen<br />Danimarca","address_gothenburg","Hibis AB<br />Kronhusgatan 11<br />411 05 G\xf6teborg<br />Svezia","address_helsinki","Hibis Associates<br />Centry Ltd","address_london","Hibis Europe Ltd","address_malmo","Hibis AB","address_oslo","Hibis AS<br /> Meltzersgt. 4<br/> 0275 Oslo<br/> Norvegia","address_rome","Hibis Associates","address_stockholm","Hibis AB","contact","Contatti","contact_us","Contatti","contact_copenhagen","<strong>John Wallhoff</strong><br /><a href='mailto:john.wallhoff@hibis.com'>john.wallhoff@hibis.com</a><br />+ 45 70 77 43 131","contact_gothenburg","<strong>Carina S\xf6rqvist</strong><br /><a href='mailto:carina.sorqvist@hibis.com'>carina.sorqvist@hibis.com</a><br />+ 46 707 97 97 64","contact_helsinki","<strong>Petri Kelo</strong><br /><a href='mailto:petri.kelo@centry.global'>petri.kelo@centry.global</a><br />+ 358 40 50 001 068","contact_london","<strong>Allan McDonagh</strong><br /><a href='mailto:allan.mcdonagh@hibis.com'>allan.mcdonagh@hibis.com</a><br />+ 44 77 68 32 0161","contact_malmo","<strong>Richard Minogue</strong><br /><a href='mailto:richard.minogue@hibis.com'>richard.minogue@hibis.com</a><br />+ 46 761 882 497","contact_oslo","<strong>Veronica Morino</strong><br /><a href='mailto:veronica.morino@hibis.com'>veronica.morino@hibis.com</a><br />+ 47 91 86 32 19<br/><br/><strong>Nigel Krishna Iyer</strong><br /><a href='mailto:nigel.iyer@hibis.com'>nigel.iyer@hibis.com</a><br />+ 47 90 65 44 10<br/>+ 44 7523 570004 (UK)","contact_rome","<strong>Maurizio Carmignani</strong><br /><a href='mailto:maurizio.carmignani@hibis.com'>maurizio.carmignani@hibis.com</a><br />+ 39 3489501126","contact_stockholm","<strong>Richard Minogue</strong><br /><a href='mailto:richard.minogue@hibis.com'>richard.minogue@hibis.com</a><br />+ 46 761 882 497","copenhagen","Copenhagen","copyright","&copy;2017 Hibis. All rights reserved. Design by SoiaDg. Images by Floral Zu.","frontpage_title","<strong>Fraud and corruption <span class='orange-text'>can</span> be stopped</strong>","gothenburg","Gothenburg","hibis_associates","Hibis associates","hibis_people","Hibis team","helsinki","Helsinki","language","Lingua","lang_en","Inglese (english)","lang_no","Norvegese (norsk)","lang_it","Italiano (italian)","london","Londra","malmo","Malm\xf6","oslo","Oslo","our_history","La nostra storia","our_history_text","<p><strong>Hibis</strong> nasce nel 1998 grazie a un'idea di Martin Samociuk. La sua visione viene accolta entusiasticamente da un team che aveva lavorato precedentemente per Network Security Management a Londra, un'azienda all'avanguardia nel campo delle investigazioni e della prevenzione della frode negli anni Ottanta e Novanta. Nel 1999, Martin viene affiancato da Nigel Krishna Iyer e, un anno dopo, da Allan McDonagh. Veronica Morino li raggiunge nel 2001, subito seguita da Richard Minogue nel 2002. Hibis ha da sempre deciso di porre al primo posto la prevenzione e la rilevazione precoce di frodi. Avvertiamo, insieme ai nostri clienti, il bisogno di richiamare drasticamente l'attenzione sulla frode e la corruzione, formandoli su come scovare gli illeciti per tempo, oltre a fornire consulenze e risorse per gestire al meglio eventuali investigazioni. Abbiamo sviluppato apposite attivit\xe0 di formazione quali workshop e seminari, libri, articoli e film, il tutto con lo scopo di sensibilizzare garantire l'autosufficienza nel campo per i nostri clienti.</p> <p>Hibis opera nel Regno Unito e in Scandinavia dal 1999</p><p>Hibis \xe8 un'organizzazione di esperti dedicati a dimostrare che, sebbene frode e corruzione permeino l'ambiente in cui viviamo, \xe8 comunque possibile tenerli sotto controllo e arginare o evitare i danni. Il nostro obiettivo \xe8 fornire strumenti e tecniche all'avanguardia per gestire il rischio di frode, insieme alla certezza della prevenzione. Offriamo il miglior supporto a chi intende darci un taglio con frode e corruzione.</p><p>Se avete trovato la nostra presentazione di vostro gradimento, e ritenete che potrebbe essere l'ambiente lavorativo giusto per voi, non esitate a contattarci. </p> ","profile_allan","Dal 1967 ad oggi, Allan ha lavorato a New Scotland Yard occupandosi di investigazioni doganali nel Regno Unito, e in particolare di droga e criminalit\xe0 organizzata. Tra il 1985 e il 1997 Allan ha lavorato come vice-direttore di Network Secutiry Management Limited (assieme a Martin Samociuk, fondatore di Hibis), una tra le migliori ditte di consulenza a livello Europeo in materia di investigazioni anti-frode. Oltre ad aver condotto con successo centinaia di investigazioni in tutto il mondo sia per clienti privati che per aziende pubbliche, ha inoltre fondato i Forensic Laboratories, successivamente acquisiti da Control Risks Group.","profile_carina","Carina S\xf6rqvist da oltre 15 anni previene e ricerca episodi di frode e corruzione. Ha ricoperto ruoli di investigatrice a capo di inchieste per diversi clienti in vari settori. La sua pluriennale esperienza in materia di investigazioni complesse di casi di frode e corruzione \xe8 oggi sfruttata in seminari e training sulle tecniche investigative. Ha sviluppato piani d'azione per svariati clienti, suggerendo come comportarsi in caso di incidenti di sospetta natura fraudolenta. Dal 2003 ha lavorato come consulente, dopo essersi cimentata nel ramo della compliance per il dipartimento di controllo di una multinazionale. Carina ha completato studi di ragioneria e finanza, specializzandosi nell'ambito della revisione contabile e delle tecniche di interrogazione.","profile_jan","Jan ha svolto diverse investigazioni forensi e ha partecipato a una moltitudine di progetti anti-frode, oltre ad aver condotto svariati corsi di detezione dei segnali della frode nell'ambito della corporate governance. Ha ottenuto i titoli di MBA e CPA dalla Norwegian School of Economics and Business Administration di Bergen. Dopo 4 anni come revisore dei conti esterno, \xe8 stato per 9 anni CFO di una ditta di costruzioni internazionale, con operazioni nell'Africa orientale. Successivamente ha ricoperto per oltre 20 anni il ruolo di consulente (in materie quali sviluppo, valutazioni di sostenibilit\xe0, controlli di gestione, controllo dei precedenti) presso il Ministero Norvegese degli Affari Esteri (NORAD, Ambasciate e Norfund), oltre ad assistere nella medesima funzione aziende del settore privato operanti nell'Africa orientale, nei Balcani, nei paesi Baltici, Georgia, Sri Lanka, Nepal, e Palestina.","profile_john","John Wallhoff \xe8 un esperto nel settore della sicurezza digitale e nell'analisi dei dati, campi in cui ha lavorato per anni. Con Hibis in particolare, sviluppa e raffina modelli in grado di analizzare grandi quantit\xe0 di dati e ricostruire \u201cpattern\u201d fraudolenti. John partecipa a investigazioni, conduce training, e fornisce attivit\xe0 di supporto ai colleghi grazie al costante raffinamento e adattamento dei modelli agli scenari che i nostri clienti si trovano ad affrontare, per scovare qualsiasi tipo di comportamento \u201cindesiderato\u201d. Inoltre, John ha costruito strategie di sicurezza per network interni, oltre a piani d'azione in caso di emergenze per svariate organizzazioni. Complementando l'attivit\xe0 di detezione della frode, John offre anche soluzioni di analisi dei dati per monitorare periodicamente l'efficacia dei controlli interni.","profile_martina","Martina ha ottenuto una laurea magistrale in finanza e gestione aziendale presso la BI Norwegian Business School di Oslo e l'universit\xe0 di Ljubljana, in Slovenia. In quanto economista di formazione, si interessa alla frode come spreco di risorse, che potrebbero essere altrimenti allocate in maniera ottimale, favorendo una crescita e uno sviluppo sostenibile. Grazie a Hibis ha avuto modo di applicare la sua passione a diversi scenari: in particolare, si occupa di identificare le \u201cred flag\u201d attraverso analisi interne e investigazioni esterne, e si avvale spesso della propria conoscenza delle lingue per tracciare flussi monetari in vari paesi.","profile_fridtjof","Fridtjof Klareng Dale ha sviluppato uno spiccato interesse per la lotta alla corruzione mentre frequentava la facolt\xe0 di studi europei presso l'universit\xe0 norvegese della scienza e della tecnica di Trondheim (NTNU). Attraverso numerosi impegni di volontariato, si \xe8 unito al neo-fondato gruppo \"Anti-Corruption International (ACI)\", contribuendo a trasformarlo in una vera e propria organizzazione internazionale che finora, attraverso numerosi progetti, ha dimostrato come i giovani possano non solo contribuire a eradicare un problema globale, ma possano anche assumere un ruolo di guida nella lotta alla corruzione. Proprio attraverso ACI \xe8 entrato in contatto con Hibis, dove ora pu\xf2 affiancare l'attivismo anti-frode alle investigazioni.","profile_maurizio","Da 18 anni lavora come libero professionista e consulente direzionale, advisor, mentor e trainer. Ha maturato esperienze in diversi ed eterogenei settori: sviluppo e innovazione, telecomunicazioni e tecnologie per le imprese, banche e assicurazioni, moda, industria degli occhiali, industria culturale e della formazione, settore farmaceutico e sanitario, beni culturali e turismo. Ha lavorato in Italia, Svizzera e Brasile. Le aree di maggiore interesse ed esperienza sono: creazione e gestione di impresa, innovazione e gestione del cambiamento, marketing e comunicazione, formazione e sviluppo organizzativo. All'interno di questi ambiti, la detezione precoce e la gestione responsabile della frode svolgono un ruolo fondamentale.","profile_nigel","Nigel ha pi\xf9 di 20 anni di esperienza nel campo dell'investigazione della frode. Ha ottenuto un Bachelor Degree in informatica, e subito dopo ha superato l'esame nazionale per dottori commercialisti nel Regno Unito. Fin dalle prime esperienze lavorative, ha scoperto la propria vocazione di \u201cfraud detective\u201d. Successivamente si \xe8 interessato anche alla produzione teatrale, ottenendo un Master of Arts in sceneggiatura e regia teatrale. Ha scritto e prodotto numerosi testi teatrali e film basati su esperienze personali, che poi vengono utilizzati per la formazione. Sulla frode ha scritto diversi articoli e pubblicato 3 libri, e, oltre a insegnare le proprie tecniche in diversi paesi, ricopre il ruolo di Fellow presso la Leicester School of Business.","profile_petri","Petri Kelo \xe8 il partner Hibis in Finlandia. Ha ottenuto un Master's Degree in Security presso la Helsinki University of Technology. Negli ultimi 25 anni si \xe8 occupato di logistica, qualit\xe0 del servizio, sicurezza, oltre alla gestione del rischio di frode. Petri ha inoltre fondato Centry Ltd, una realt\xe0 che si occupa di sicurezza nel settore della logistica, supply chain, gestione dei rischi, compliance e servizi investigativi. Svolge tutt'ora attivit\xe0 di training in materia di AEO (Authorized Economic Operator), TAPA (Transportation Asset Protection Association) e sicurezza nella logistica (ISO 28000 \u2013 Supply chain security management).","profile_richard","Richard ha maturato decenni di esperienza nel settore dell'audit, investigazione, controllo e gestione a partire dal 1975, quando ha iniziato a lavorare come revisore dei conti (internal auditor). Curioso di natura, ha la capacit\xe0 innata di risolvere situazioni complesse e comprendere a fondo i processi dei propri clienti, offrendo loro la soluzione pi\xf9 adatta, ben consapevole che esista pi\xf9 di una risposta esatta, e allo stesso tempo molte risposte sbagliate. Richard ha conseguito un Bachelor Degree in economia aziendale, superando gli esami CPA e CIA. In tempi recenti si \xe8 dedicato alla valutazione, all'investigazione, e al miglioramento dei sistemi di controllo in vigore in varie organizzazioni.","profile_veronica","Veronica ha oltre 15 anni di esperienza nell'investigazione e prevenzione della frode, e in particolare nella formazione anti-frode e nella gestione dei rischi associati. Laureata in sociologia del lavoro presso l\u2019Universit\xe0 di Roma \u201cLa Sapienza\u201d, ha sviluppato una metodologia di ricerca olistica che permette di analizzare organizzazioni, aziende, soci in affari, fornitori, clienti, e personaggi chiave per capire che cosa vi sia davvero dietro. Inoltre, Veronica da diversi anni valuta ed esamina l'efficacia dei programmi anti-frode e corruzione adottati da varie organizzazioni, e al momento sta completando il proprio dottorato di ricerca in materia.","red_flag_game","The <span class='red-text'>red</span><br />flag Game","rome","Roma","rulebending_final_question","Ai fini della nostra ricerca, vi saremmo molto grati se poteste fornirci (in modo anonimo) una descrizione dettagliata delle vostre mansioni","rules_game","Quanto \xe8 flessibile la vostra morale?","search","Cerca","send","Invia","stockholm","Stoccolma","the_fraud_academy","Fraud Academy","what_we_do","Attivit\xe0","what_we_do_collapsed_text_1",'<p>Gran parte delle frodi di cui sentiamo parlare quotidianamente potrebbe essere segnalata (anche se in fase iniziale) e fermata. Spesso, attivit\xe0 illegittime hanno parvenza di legalit\xe0 e trovare la verit\xe0 richiede esperienza, fatica, e l\'aiuto di esperti.</p><p>La nostra soluzione "B4" (o "before" nel senso di "Finding fraud before it finds you") \xe8 stata sviluppata apposta per scovare qualsiasi frode in maniera efficiente ed eliminarla efficacemente. La soluzione "B4" si fa carico di attivit\xe0 quali:</p><ul><li>Analisi dei flussi monetari, divisi per categorie, ed esecuzione degli algoritmi della suite B4 sulle singole transazioni</li><li>Ricostruzioni \u201cthink like a thief\u201d (un approccio inventato negli anni Ottanta da Martin Samociuk, il fondatore di Hibis), per vestire i panni di un malintenzionato e profilare i diversi tipi di frode, sia quelli in corso che quelli potenzialmente pericolosi</li><li>Identificare comportamenti a rischio attraverso un approccio integrato che prevede l\'uso di \u201cdesktop research\u201d per analizzare organizzazioni, soci in affari, fornitori, clienti e figure chiave, il tutto tenendo sempre a mente l\'opportunit\xe0, le motivazioni, e il fenomeno della razionalizzazione del comportamento disonesto</li><li>Dopo aver identificato e classificato i segnali di frode, stilare una lista che permetta poi ai nostri clienti di avere una visione chiara dei problemi pi\xf9 importanti da risolvere</li><li>Collaborare con i nostri clienti per giungere al corso d\'azione pi\xf9 efficace per risolvere problemi. La nostra pluriennale esperienza ci pone in una posizione unica per valutare e suggerire soluzioni commisurate alla gravit\xe0 di ciascuna situazione.</li></li></ul><p>Se non si agisce per tempo, si rischia che i segnali iniziali si sviluppino in vere e proprie frodi, diffondendosi attraverso intere organizzazioni. A quel punto, il problema emerger\xe0 nuovamente quando sar\xe0 ormai impossibile ignorarlo, o per le dimensioni raggiunte o perch\xe9 denunciato anonimamente (o entrambi). Perch\xe9 dunque attendere inerti che ci\xf2 accada quando si possono usare tecniche di investigazione per scoprire ora le aree affette dai primi segni di frode? \xc8 meglio giocare d\'anticipo!</p>',"what_we_do_collapsed_text_2",'<p>Pensare di riuscire a eliminare del tutto le frodi \xe8 senz\'altro un\'utopia. Tuttavia, prestando attenzione al problema e gestendone il rischio in maniera appropriata, sar\xe0 possibile controllarne il costo e rendere i comportamenti disonesti meno accettabili. Non \xe8 un caso che le frodi pi\xf9 comuni siano di solito perpetrate da persone \u201cnormali\u201d, nella media, quali potrebbero essere impiegati o soci d\'affari fidati. Aumentare la consapevolezza del fenomeno potr\xe0 aiutare chiunque a evitare errori di cui poi si pentir\xe0, oltre a formarvi per difendere la vostra organizzazione da malintenzionati. Citando Nelson Mandela, \u201cl\'istruzione \xe8 uno dei modi pi\xf9 potenti per cambiare il mondo\u201d. Abbiamo sviluppato metodi per facilitare il \u201cknowledge transfer\u201d nei confronti dei nostri clienti, e siamo costantemente alla ricerca di modi innovativi per sensibilizzare, diffondere il know-how necessario e permettere un confronto aperto e costruttivo in materia di frode e corruzione. Alcuni esempi sono (per una descrizione pi\xf9 dettagliata si veda la pagina Fraud Academy):</p><ul><li>Corsi pratici e laboratori (tra cui il metodo "Think like a thief" e la "fraud detective school")</li><li>Corsi certificati per il management</li><li>Training sul luogo di lavoro, laboratori "in-house" e workshop a tema</li><li>Corsi multimediali tenuti via internet (o intranet)</li><li>Corsi interattivi con drammi teatrali, allestimento di scenari e giochi di ruolo per i partecipanti, film a tema</li><li>Libri e altre pubblicazioni su riviste specializzate</li></ul>',"what_we_do_collapsed_text_3","<p>Aiutiamo i nostri clienti a investigare i comportamenti illeciti in maniera costruttiva ed efficace.</p><p>Siamo fautori di piccole investigazioni che aiutano a recuperare le risorse perdute. Abbiamo un comprovato numero di situazioni risolte con successo ed efficienza, in cui siamo riusciti a identificare le mancanze alla radice e correggerle, impedendo che il problema si ripetesse. Talvolta, grandi investigazioni sono necessarie, ad esempio qualora un'organizzazione avesse bisogno di prepararsi ad azioni legali per recuperare beni o salvare parte del proprio business. Gestiamo ogni investigazione in maniera discreta, evitando costi superflui e accertandoci allo stesso tempo di mantenere il cliente sempre al corrente.</p>","what_we_do_collapsed_text_4","<p>La mole e la portata dei regolamenti esterni, studiati per proteggere i consumatori e dissuadere potenziali criminali, \xe8 sempre in aumento. Ci\xf2 richiede sempre pi\xf9 attenzione da parte del management, a scapito di programmi pi\xf9 pratici, disegnati specificatamente per proteggere l'azienda. Di conseguenza, la direzione potrebbe cadere nella trappola di voler assecondare soluzioni \u201cburocratiche\u201d in conformit\xe0 con la legge, ma nella realt\xe0 poco adatte a prevenire azioni fraudolente. Le attivit\xe0 di \"compliance\", intesa come una lista di controlli da manuale, difficilmente daranno risultati concreti.</p><p>Siamo lieti di mettere al vostro servizio la nostra esperienza, offrendovi una valutazione dei vostri sistemi di controllo per far emergere potenziali debolezze. Insieme potremo migliorarli per abbattere il costo della frode e riaffermare i valori e l'etica della vostra azienda.</p><p>Partendo dai framework pi\xf9 comuni in uso, abbiamo selezionato i punti chiave, combinandoli con anni di esperienza sul campo per offrirvi uno strumento di valutazione complessivo, frutto di un approccio olistico.</p>","what_we_do_collapsed_title_1","Scoviamo i primi segni di frode e ti aiutiamo a risolverli","what_we_do_collapsed_title_2","Mettiamo la nostra esperienza al vostro servizio, sensibilizzando in materia di frode","what_we_do_collapsed_title_3","Investighiamo la frode responsabilmente","what_we_do_collapsed_title_4","Testiamo l'efficacia dei vostri programmi anti-frode","what_we_do_list_1_item_1","<strong>Trovare</strong> e interpretare i primi segnali (Le <strong>red flags</strong>)","what_we_do_list_1_item_2","<strong>Investigare</strong> in modo efficiente, competente e responsabile","what_we_do_list_1_item_3","<strong>Analizzare</strong> i problemi alla radice per identificare aree di miglioramento","what_we_do_list_1_item_4","<strong>Formare</strong> attraverso workshop pratici, conferenze, training e altri strumenti innovativi, le <strong>competenze necessarie</strong> per trasformare le \"brutte notizie\" in opportunit\xe0 di risparmio (si veda anche <a href='http://fraudacademy.hibis.com' target='_blank'>Hibis Fraud Academy</a>)","what_we_do_list_1_item_5","<strong>Testare</strong> e <strong>misurare</strong> l'<strong>efficacia</strong>, i punti di forza e le debolezze dei programmi antifrode gi\xe0 presenti","what_we_do_paragraph_1","Frodi e corruzione avvengono costantemente e sono tra i costi pi\xf9 difficili da gestire per aziende e organizzazioni. Gran parte dei dirigenti e degli impiegati per\xf2 non ha mai ricevuto alcuna formazione pratica su questo tema. Il nostro obiettivo \xe8 richiamare l'attenzione su frodi e corruzione e sulle conseguenze che possono comportare. Da anni assistiamo e consigliamo aziende, organizzazioni e chiunque abbia bisogno di aiuto pratico per","who_we_are","Chi siamo"]),"no",P.P(["address_copenhagen","c/o Scillani Information AB<br />Vestergade 16<br />1456 Kj\xf8benhavn<br />Danmark","address_gothenburg","Hibis AB<br />Kronhusgatan 11<br />411 05 G\xf6teborg<br />Sverige","address_helsinki","Hibis Associates<br />Centry Ltd","address_london","Hibis Europe Ltd","address_malmo","Hibis AB","address_oslo","Hibis AS<br /> Meltzersgt. 4<br/> 0275 Oslo<br/> Norge","address_rome","Hibis Associates","address_stockholm","Hibis AB","contact","Kontakt","contact_us","Kontakt oss","contact_copenhagen","<strong>John Wallhoff</strong><br /><a href='mailto:john.wallhoff@hibis.com'>john.wallhoff@hibis.com</a><br />+ 45 70 77 43 131","contact_gothenburg","<strong>Carina S\xf6rqvist</strong><br /><a href='mailto:carina.sorqvist@hibis.com'>carina.sorqvist@hibis.com</a><br />+ 46 707 97 97 64","contact_helsinki","<strong>Petri Kelo</strong><br /><a href='mailto:petri.kelo@centry.global'>petri.kelo@centry.global</a><br />+ 358 40 50 001 068","contact_london","<strong>Allan McDonagh</strong><br /><a href='mailto:allan.mcdonagh@hibis.com'>allan.mcdonagh@hibis.com</a><br />+ 44 77 68 32 0161","contact_malmo","<strong>Richard Minogue</strong><br /><a href='mailto:richard.minogue@hibis.com'>richard.minogue@hibis.com</a><br />+ 46 761 882 497","contact_oslo","<strong>Veronica Morino</strong><br /><a href='mailto:veronica.morino@hibis.com'>veronica.morino@hibis.com</a><br />+ 47 91 86 32 19<br/><br/><strong>Nigel Krishna Iyer</strong><br /><a href='mailto:nigel.iyer@hibis.com'>nigel.iyer@hibis.com</a><br />+ 47 90 65 44 10<br/>+ 44 7523 570004 (UK)","contact_rome","<strong>Maurizio Carmignani</strong><br /><a href='mailto:maurizio.carmignani@hibis.com'>maurizio.carmignani@hibis.com</a><br />+ 39 3489501126","contact_stockholm","<strong>Richard Minogue</strong><br /><a href='mailto:richard.minogue@hibis.com'>richard.minogue@hibis.com</a><br />+ 46 761 882 497","copenhagen","Kj\xf8benhavn","copyright","&copy;2017 Hibis. All rights reserved. Design by SoiaDg. Images by Floral Zu.","frontpage_title","<strong>Fraud and corruption <span class='orange-text'>can</span> be stopped</strong>","gothenburg","G\xf6teborg","hibis_associates","Hibis assosierte","hibis_people","Hibis ansatte","helsinki","Helsinki","language","Spr\xe5k","lang_en","Engelsk (english)","lang_no","Norsk (norwegian)","lang_it","Italiensk (italian)","london","London","malmo","Malm\xf6","oslo","Oslo","our_history","V\xe5r historie","our_history_text","<p><strong>Hibis</strong> ble grunnlagt i 1998 av Martin Samociuk. Mange av dem som ble med i starten kom fra Network Security Management i London, et selskap som var pionerer forebygging og etterforsking av bedrageri p\xe5 1980og -90-tallet. I 1999 sluttet Nigel Krishna Iyer seg til Martin og et \xe5r senere ble ogs\xe5 Allan McDonagh med. Veronica Morino ble en del av gruppen i 2001, etterfulgt av Richard Minogue i 2002. Hibis sitt oppdrag har alltid v\xe6rt \xe5 sette forebygging og tidlig oppdagelse F\xd8RST. Vi deler med v\xe5re kunder n\xf8dvendigheten av dramatisk \xf8kning av for \xe5 vesentlig \xf8ke bevisstheten rundt misligheter og korrupsjon, gi dem muligheten til \xe5 oppdage det tidlig og bist\xe5 med r\xe5d ressurser til vellykkede etterforskinger. Dette inkluderer trening i workshops, seminarer, b\xf8ker, publikasjoner og filmer alle med det form\xe5let \xe5 stimulere til st\xf8rre bevissthet og selvtillit.</p><p>Hibis grunnlegger, Martin Samociuk, d\xf8de i 2013 i en alder av 62 \xe5r fra bukspyttkjertels kreft. Han vil bli savnet av alle som kjente ham og vi er takknemlige for det viktige arbeidet han etterlot seg.</p><p>I dag er Hibis en r\xe5dgivende organisasjon som vi h\xe5per vil bidra til \xe5 \xe5pne folks \xf8yne for det faktum at selv om misligheter og korrupsjon er rundt oss, kan den holdes under kontroll. V\xe5rt m\xe5l er \xe5 tilby nyskapende verkt\xf8y og teknikker for \xe5 h\xe5ndtere dette, samt mulighet til \xe5 oppdage det tidlig. V\xe5rt m\xe5l er \xe5 st\xf8tte de menneskene som \xf8nsker \xe5 st\xe5 opp mot misligheter og korrupsjon.</p><p>I dag er Hibis en r\xe5dgivende organisasjon som vi h\xe5per vil bidra til \xe5 \xe5pne folks \xf8yne for det faktum at selv om misligheter og korrupsjon er rundt oss, kan den holdes under kontroll. V\xe5rt m\xe5l er \xe5 tilby nyskapende verkt\xf8y og teknikker for \xe5 h\xe5ndtere dette, samt mulighet til \xe5 oppdage det tidlig. V\xe5rt m\xe5l er \xe5 st\xf8tte de menneskene som \xf8nsker \xe5 st\xe5 opp mot misligheter og korrupsjon.</p><p>Til slutt, hvis du liker det du har lest, og tenker som oss, s\xe5 ta gjerne kontakt. Vi rekrutterer ikke p\xe5 tradisjonell m\xe5te - likesinnede mennesker finner oss vanligvis...</p>","profile_allan","Allans lange erfaring fra 1967 inkluderer britiske toll- og fortollingsetterforskning og New Scotland Yard, der han spesialiserte seg p\xe5 narkotikakriminalitet og organisert kriminalitet. Mellom 1985 og 1997 jobbet Allan som assisterende direkt\xf8r med Martin Samociuk p\xe5 Network Security Management Limited, Europas ledende konsultasjonssjef for etterforsking av svindel. I tillegg til \xe5 ha ledet hundrevis av etterforskinger og gjenopprettingsprosjekter over hele verden for b\xe5de kommersielle og offentlige kunder, skapte han de sv\xe6rt vellykkede \xabForensic Laboratories\xbb som til slutt ble kj\xf8pt av Control Risks Group. Allan har v\xe6rt prosjektleder for mange vellykkede etterforskinger rundt om i verden.","profile_carina","Carina S\xf6rqvist har over 15 \xe5rs erfaring med \xe5 forebygge og etterforske misligheter og korrupsjon. Hun har opptr\xe5dt som etterforsker og prosjektleder i etterforskinger for kunder i ulike bransjer. Hennes lange erfaring med strukturerte etterforskinger av mislighet- og korrupsjonssaker blir brukt i seminarer og oppl\xe6ring i forbindelse med etterforskningsteknikker. Hun har, for flere kunder, utviklet handlingsplaner for hvordan man skal h\xe5ndtere hendelser hvor man mistenker misligheter og/eller korrupsjon. Hun har jobbet som seniorkonsulent siden 2003 og f\xf8r det arbeidet hun med compliance som leder av internkontrollavdelingen i et multinasjonalt selskap. Carina har \xf8konomisk bakgrunn og hennes spesialiteter er regnskapsetterforskning og intervjueteknikker.","profile_jan","Jan har utf\xf8rt en rekke etterforskinger og prosjekter for \xe5 oppdage misligheter, samt holdt kurs i r\xf8d-flaggs-avdekking innen bedrageri, korrupsjon og bedriftsstyring. Han har en MBA og CPA-grad fra Handelsh\xf8yskolen i Bergen. Etter \xe5 ha v\xe6rt 4 \xe5r som ekstern revisor var han finansdirekt\xf8r i 9 \xe5r i et internasjonalt byggefirma med virksomhet i \xd8st-Afrika. Deretter jobbet han i over 20 \xe5r som r\xe5dgiver innen forretningsutvikling, b\xe6rekraftevalueringer, performance audit og bakgrunn analyser for Utenriksdepartementet (bl.a. oppdrag for NORAD, ambassader og Norfund) og private n\xe6ringsselskaper som opererer i \xd8st-Afrika, Balkan, Baltikum, Georgia, Sri Lanka, Nepal og Palestina. Han leder ogs\xe5 Styrenettverket i Econa Oslo/Akershus.","profile_john","John Wallhoff har mange \xe5rs erfaring som datasikkerhet- og dataanalyseekspert, og utvikler og implementerer datamodeller for \xe5 oppdage m\xf8nstre av misligheter og korrupsjon. John deltar i etterforskinger, leder oppl\xe6ring og st\xf8tter sine kolleger gjennom utvikling av ledende modeller for \xe5 finne frem til misligheter og uetisk forretningsadferd. I tillegg har John bygget informasjonssikkerhetsstrategier og beredskapsplaner for en rekke selskaper,  deltar i etterforskinger og utvikler dataanalysel\xf8sninger for kontinuerlig overv\xe5king av interne kontroller.","profile_martina","Martina har en mastergrad i business og \xf8konomi med finans som hovedprofil fra handelsh\xf8yskolen BI og universitetet i Ljubljana (Slovenia). Hun bestemte seg tidlig for at hun \xf8nsket \xe5 spille en aktiv rolle i \xe5 utrydde systematisk ineffektivitet. Hun inns\xe5 at korrupsjon og misligheter er noen av de st\xf8rste hindringene for b\xe6rekraftighet og vekst, og f\xe5r bruke sin lidenskap for temaet her hos oss i Hibis. Martina spesialiserer seg p\xe5 \xe5 identifisere r\xf8de flagg i relasjon til korrupsjon gjennom intern og ekstern analyse, og forst\xe5 og etterforske dem over et bredt spekter av land og spr\xe5k-soner.","profile_fridtjof","Fridtjof Klareng Dale's passion for fighting corruption and fraud started while studying for his bachelor in European Studies at the Norwegian University of Science and Technology (NTNU). Through his strong engagement in volunteerism, he joined the newly founded student organisation Anti-Corruption International (ACI) and helped build the organisation, spearheading projects showing that \u201cyoung people not only can play a part in eradicating a global problem, but can also take the lead.\u201d Through ACI he got to know Hibis, where he is now successfully working as a fraud investigator combining this with his anti-corruption activities.","profile_maurizio","Maurizio har 18 \xe5rs erfaring innen innovasjon og organisasjonsutvikling i et bredt spekter av sektorer som inkluderer telekommunikasjon og teknologi, bank, detaljhandel og forbrukerprodukter, kultur, utdanning og regjering, i hovedsak i Italia, Sveits og Brasil. Han gir oppl\xe6ring for \xe5 oppn\xe5 oppfyllelse av m\xe5l b\xe5de p\xe5 personlig og organisatorisk niv\xe5. Han bist\xe5r i \xe5 finne misligheter og korrupsjon tidlig, og h\xe5ndterer det p\xe5 en ansvarlig m\xe5te for \xe5 fremme organisatorisk robusthet.","profile_nigel","Nigel har over 20 \xe5rs erfaring med \xe5 unders\xf8ke og oppdage misligheter og korrupsjon. Som datavitenskapsmann og statsautorisert revisor, fant Nigel snart at hans sanne lidenskap l\xe5 i \xe5 bekjempe korrupsjon og misligheter. Nigel er ogs\xe5 i dag en kvalifisert dramatiker og har skrevet en rekke filmer og skuespill basert p\xe5 erfaringer, hvorav mange brukes i undervisning over hele verden. Han har skrevet flere b\xf8ker og vitenskapsartikler, og underviser i Norge og internasjonalt i hvordan man kan forsvare organisasjoner mot \xabkommersielle m\xf8rkekunster\xbb. Han er ogs\xe5 fellow ved University of Leicester School of Business.","profile_petri","Petri Kelo er Hibis tilknyttede partner i Finland. Hans faglige bakgrunn inkluderer en mastergrad i sikkerhet fra Helsinki University of Technology. Petri har jobbet i over 25 \xe5r med logistikk, kvalitet, sikkerhet, samt med \xe5 h\xe5ndtere risikoen for misligheter og korrupsjon. Petri er ogs\xe5 en av grunnleggerne av Centry Ltd. et sikkerhetsselskap spesialisert innen logistikk, forsyningskjede, sikkerhetsrisikostyring, etterlevelse og etterforskningstjenester. Petri er en velkjent foredragsholder og underviser  i TAPA (Transportation Asset Protection Association), AEO (Authorized Economic Operator), ISO 28000 (Supply Chain Security Management) og logistisk sikkerhet.","profile_richard","Siden sin f\xf8rste heltidsjobb som internrevisor i 1975, har Richard opparbeidet seg erfaring innen revisjon, etterforskning, finansiell kontroll og generell ledelseskompetanse. Nysgjerrig av naturen han vet at det er vanligvis er mer enn \xe8n m\xe5te \xe5 gj\xf8re ting riktig p\xe5, og mange feil m\xe5ter. Richards talent for \xe5 trenge inn i komplekse situasjoner samt forst\xe5 kundens forretningsprosesser gj\xf8r ham til en verdifull ressurs for vurderings-, etterforsknings- og forbedringsprosjekter. Richard har uteksaminert seg med BSc i regnskap, og er kvalifisert CPA og CIA.","profile_veronica","Veronica har over 15 \xe5rs erfaring med \xe5 etterforske, finne og trene andre i hvordan man kan forebygge og h\xe5ndtere misligheter og korrupsjon over hele verden. Hun er utdannet \xf8konomi-og arbeidssosiologi og har en mastergrad i organisasjonsbygging og ledelse har hun utviklet helhetlige unders\xf8kelses- og analyseverkt\xf8y for \xe5 etterforske organisasjoner, samarbeidspartnere, leverand\xf8rer, kunder og n\xf8kkelpersoner, og oppdage hva som egentlig foreg\xe5r med bare en br\xf8kdel av ressursene som normalt er forbundet med en etterforskning. Veronica har ogs\xe5 jobbet i flere \xe5r med vurdering av effektiviteten av organisasjons anti-mislighet og korrupsjonsprogrammer og fullf\xf8rer for tiden en doktorgradsutdanning p\xe5 dette emnet.","red_flag_game","The <span class='red-text'>red</span><br />flag Game","rome","Roma","rulebending_final_question","It would assist our research if you could provide us with details of your job functions (anonymously)","rules_game","Hvor mye kan du b\xf8ye reglene?","search","S\xf8ke","send","send inn","stockholm","Stockholm","the_fraud_academy","The fraud academy","what_we_do","Hva vi gj\xf8r","what_we_do_collapsed_text_1",'<p>I de fleste virksomheter er det mange muligheter for misligheter og korrupsjon som kan spores, avdekkes (helst i de tidlige stadiene) og stoppes. Vanligvis er handlinger som misligheter og korrupsjon skjult bak tilsynelatende legitime handlinger. \xc5 finne sannheten krever erfaring, innsats og spesialkunnskap.</p><p>V\xe5r strukturerte "B4- metodikk" (kort for "Find fraud before it finds you") er utviklet for effektivt \xe5 avdekke og h\xe5ndtere misligheter. B4 inkluderer aktiviteter som:</p><ul><li>F\xf8lge pengestr\xf8mmene, utf\xf8re strukturerte analyser og kj\xf8re B4-algoritmer p\xe5 transaksjoner for \xe5 finne de r\xf8de flaggene.</li><li>\xd8velsen \u201ctenk som en tyv\u201d (en \xf8velse oppfunnet p\xe5 1980-tallet av Martin Samociuk, Hibis grunnlegger) for \xe5 forutse hvordan bedragere tenker og for \xe5 bygge opp en profil av de typer misligheter som oppst\xe5r eller som det kan v\xe6re risiko for at de vil kunne oppst\xe5.</li><li>Finne atferdsmessige r\xf8de flagg ved \xe5 utf\xf8re helhetlige unders\xf8kelser og analyse av organisasjoner, forretningspartnere, leverand\xf8rer, kunder og andre n\xf8kkelpersoner. Alle med et spesielt fokus p\xe5 muligheter, motiver og hvordan folk rasjonaliserer rundt u\xe6rlig eller uetisk oppf\xf8rsel.</li><li>Analysere indikasjoner p\xe5 bedrageri og korrupsjon for \xe5 f\xe5 frem de viktigste omr\xe5der, for s\xe5 \xe5 strukturere disse til en h\xe5ndterlig liste som v\xe5re kunder kan arbeide videre med.</li><li>Samarbeide med v\xe5re oppdragsgivere for \xe5 finne den mest effektive l\xf8sningen p\xe5 utfordringene. Lang erfaring har gitt oss en oversikt over ulike tiln\xe6rminger, hvilke som passer i ulike situasjoner, og hvordan de kan implementeres.</li></li></ul><p>Hvis det ikke oppdages tidlig, vil misligheter og korrupsjon spre seg. Til slutt vil problemet bli oppdaget n\xe5r det blir for stort til \xe5 ignoreres, eller rapporteres av varslere, eller begge deler. Men hvorfor vente p\xe5 varslere n\xe5r du kan bruke etterforskningsteknikker og avdekke der hvor misligheter og korrupsjon i tidlig stadium utvikler seg n\xe5? Det er bedre \xe5 v\xe6re f\xf8re var og holde seg i forkant!</p>',"what_we_do_collapsed_text_2","<p>Vi vil nok aldri helt utrydde misligheter og korrupsjon, men ved \xe5 \xf8ke bevisstheten og h\xe5ndtere risikoen kan vi kontrollere kostnadene og gj\xf8re korrupte handlinger mindre akseptable. Overraskende nok beg\xe5s mye av misligheter og korrupsjon av helt normale, gode mennesker som regnes som verdifulle og p\xe5litelige ansatte eller forretningspartnere. Bevisstgj\xf8ring, er et kraftig verkt\xf8y for \xe5 hjelpe de gode menneskene til \xe5 unng\xe5 og beg\xe5 feil de senere vil kunne angre p\xe5, og samtidig vise dem hvordan de skal beskytte organisasjonen mot karrierekriminelle. Som Nelson Mandela sa, er utdanning en av de beste m\xe5tene \xe5 forandre verden p\xe5. Vi har utviklet kurs og teknikker for \xe5 minimere dette kompetansegapet samt stadig og kontinuerlig p\xe5 s\xf8kt etter nye innovative m\xe5ter \xe5 \xf8ke bevisstheten, spre kunnskapen og f\xf8re folk sammen i kampen mot korrupsjon og misligheter. Eksempler (detaljer finner du under Fraud Academy-siden v\xe5r) som inkluderer:</p><ul><li>Praktiske kurs og workshops (inkludert v\xe5r \u201ctenk-som-en-tyv-metodikken\u201d og \u201cfraud detective school\u201d)</li><li>Akkrediterte ledelses kurs</li><li>Jobb, in-house og laboratorier treining</li><li>Multimediabasert oppl\xe6ring over internett (eller intranett)</li><li>Ekspertoppl\xe6ring, inkludert drama, scenariooppgaver, live-simuleringer, \u201ckorrupsjonsteater\u201d og filmer</li><li>Publikasjoner og b\xf8ker</li></ul>","what_we_do_collapsed_text_3","<p>Dersom kunden har behov, etterforsker vi ogs\xe5 misligheter og korrupsjon konstruktivt og effektivt.</p><p>Vi tror p\xe5 filosofien med sm\xe5 etterforskinger som \u201cwin value back\u201d. V\xe5r portef\xf8lje viser til kunder som har f\xe5tt l\xf8st sine problemer p\xe5 en effektiv m\xe5te som b\xe5de identifiserer grunnleggende \xe5rsaker og hindrer gjentakelse.</p><p>Spesielle situasjoner forekommer fra tid til annen, hvor en s\xe5kalt dypdykketterforskning kan v\xe6re n\xf8dvendig, for eksempel n\xe5r en organisasjon m\xe5 g\xe5 rettens vei for \xe5 f\xe5 erstattet store verdier eller redde deler av virksomheten. Vi h\xe5ndterer alle etterforskinger p\xe5 en kontrollert m\xe5te, unng\xe5r un\xf8dvendige kostnader og sikrer at kunden alltid er i f\xf8rersetet under prosessen.</p>","what_we_do_collapsed_text_4","<p>Omfang og kompleksitet i regelverk knyttet til samfunnsansvar og straffeansvar p\xe5 brudd p\xe5 dette er \xf8kende. Dette krever ledelsens oppmerksomhet og gir mindre plass til mer praktiske tiltak som er designet for \xe5 beskytte organisasjonen. Det kan v\xe6re fristende for en ledelse \xe5 g\xe5 i den fellen og velge enkle l\xf8sninger som ser ut til \xe5 oppfylle lovkrav, men som ikke l\xf8ser problemet med misligheter og korrupsjon p\xe5 en effektivt m\xe5te. Complianceprogrammer basert p\xe5 sjekklister viser seg ofte ikke \xe5 v\xe6re effektive!</p><p>Vi er i stand til \xe5 m\xe5le resultatet og effekten av dine eksisterende anti-mislighet og korrupsjonsprogrammer, identifisere smutthull og potensielle forbedringer som vil kunne redusere kostnadene av misligheter og korrupsjon og styrke den etiske kulturen.</p><p>V\xe5rt helhetlige rammeverk og vurderingsverkt\xf8y sammenfattet mange \xe5rs praktisk erfaring med den beste kunnskapen fra en omfattende bruk av tilgjengelige rammeverk.</p>","what_we_do_collapsed_title_1","Vi avdekker misligheter tidlig og hjelper deg med l\xe5 finne l\xf8sninger og motvirkende tiltak","what_we_do_collapsed_title_2","Vi \xf8ker bevisstheten, deler kunnskap og overf\xf8rer ferdigheter","what_we_do_collapsed_title_3","Vi etterforsker misligheter og korrupsjon p\xe5 en ansvarlig m\xe5te","what_we_do_collapsed_title_4","Vi vurderer effektiviteten av eksisterende antimislighet- og korrupsjonsprogrammer","what_we_do_list_1_item_1","<strong>Finne</strong> og tolke de mange <strong>r\xf8de flaggene</strong>","what_we_do_list_1_item_2","<strong>Utf\xf8re granskninger</strong> p\xe5 en effektiv, ansvarlig og omsorgsfull m\xe5te","what_we_do_list_1_item_3","<strong>Analysere</strong> \xe5rsakene til forskjellige hendelser for \xe5 identifisere forbedringsmuligheter","what_we_do_list_1_item_4","<strong>Tilby</strong> (gjennom praktiske workshops, oppl\xe6ring og andre innovative teknikker) <strong>ferdighetene</strong> til \xe5 omgj\xf8re det som ser ut til \xe5 v\xe6re \"d\xe5rlige nyheter\" til en mulighet til \xe5 spare penger (se <a href='http://fraudacademy.hibis.com' target='_blank'>Hibis Fraud Academy</a>)","what_we_do_list_1_item_5","<strong>Vurdere</strong> og <strong>m\xe5le effektivitet</strong>, <strong>styrker</strong> og <strong>svakheter</strong> i eksisterende anti-mislighet og korrupsjonsprogrammer","what_we_do_paragraph_1","Misligheter og korrupsjon skjer hele tiden og utgj\xf8r muligens noen av de st\xf8rste ukontrollerte kostnadene for organisasjoner og samfunnet for\xf8vrig. Til tross for dette har flesteparten av ledere og ansatte ikke hatt praktisk oppl\xe6ring innenfor dette omr\xe5det. V\xe5rt m\xe5l er \xe5 betraktelig \xf8ke bevisstheten om misligheter og korrupsjon og de p\xe5f\xf8lgende konsekvensene. Vi bist\xe5r og gir r\xe5d til organisasjoner, bedrifter og alle andre som er interessert i \xe5:","who_we_are","Hvem vi er"])]),"en")},"ev","$get$ev",function(){return W.aU(".body")},"cw","$get$cw",function(){return W.aU(".contact-button")},"cx","$get$cx",function(){return W.aU(".node")},"ew","$get$ew",function(){return W.aU(".city-output")},"ep","$get$ep",function(){return W.aU(".address-output")},"ex","$get$ex",function(){return W.aU(".contact-output")},"eJ","$get$eJ",function(){var z=W.hr()
z.v(0,W.jC(new F.ft(),C.W,C.R,C.S))
return z},"c9","$get$c9",function(){return new Z.dp(P.P(["en",P.P(["address_copenhagen","c/o Scillani Information AB<br />Vestergade 16<br />1456 Copenhagen<br />Denmark","address_gothenburg","Hibis AB<br />Kronhusgatan 11<br />411 05 G\xf6teborg<br />Sweden","address_helsinki","Hibis Associates<br />Centry Ltd","address_london","Hibis Europe Ltd","address_malmo","Hibis AB","address_oslo","Hibis AS<br /> Meltzersgt. 4<br/> 0275 Oslo<br/> Norway","address_rome","Hibis Associates","address_stockholm","Hibis AB","contact","Contact","contact_us","Contact us","contact_copenhagen","<strong>John Wallhoff</strong><br /><a href='mailto:john.wallhoff@hibis.com'>john.wallhoff@hibis.com</a><br />+ 45 70 77 43 131","contact_gothenburg","<strong>Carina S\xf6rqvist</strong><br /><a href='mailto:carina.sorqvist@hibis.com'>carina.sorqvist@hibis.com</a><br />+ 46 707 97 97 64","contact_helsinki","<strong>Petri Kelo</strong><br /><a href='mailto:petri.kelo@centry.global'>petri.kelo@centry.global</a><br />+ 358 40 50 001 068","contact_london","<strong>Allan McDonagh</strong><br /><a href='mailto:allan.mcdonagh@hibis.com'>allan.mcdonagh@hibis.com</a><br />+ 44 77 68 32 0161","contact_malmo","<strong>Richard Minogue</strong><br /><a href='mailto:richard.minogue@hibis.com'>richard.minogue@hibis.com</a><br />+ 46 761 882 497","contact_oslo","<strong>Veronica Morino</strong><br /><a href='mailto:veronica.morino@hibis.com'>veronica.morino@hibis.com</a><br />+ 47 91 86 32 19<br/><br/><strong>Nigel Krishna Iyer</strong><br /><a href='mailto:nigel.iyer@hibis.com'>nigel.iyer@hibis.com</a><br />+ 47 90 65 44 10<br/>+ 44 7523 570004 (UK)","contact_rome","<strong>Maurizio Carmignani</strong><br /><a href='mailto:maurizio.carmignani@hibis.com'>maurizio.carmignani@hibis.com</a><br />+ 39 3489501126","contact_stockholm","<strong>Richard Minogue</strong><br /><a href='mailto:richard.minogue@hibis.com'>richard.minogue@hibis.com</a><br />+ 46 761 882 497","copenhagen","Copenhagen","copyright","&copy;2017 Hibis. All rights reserved. Design by SoiaDg. Images by Floral Zu.","frontpage_title","<strong>Fraud and corruption <span class='orange-text'>can</span> be stopped</strong>","gothenburg","Gothenburg","hibis_associates","hibis associates","hibis_people","hibis people","helsinki","Helsinki","lang_en","English (english)","lang_no","Norwegian (norsk)","lang_it","Italian (italian)","language","Language","london","London","malmo","Malm\xf6","oslo","Oslo","our_history","Our history","our_history_text","<p><strong>Hibis</strong> was founded in 1998 by Martin Samociuk. Many of the people who joined at the start came from Network Security Management in London, a company which pioneered fraud investigation and prevention in the 1980\u2019s and 90\u2019s. In 1999, Martin was joined by Nigel Krishna Iyer and one year later by Allan McDonagh. Veronica Morino became part of the group in 2001 followed by Richard Minogue in 2002.The mission of Hibis has always been to put prevention and early detection FIRST. We share with clients the need to dramatically raise awareness of fraud and corruption, give them the ability to spot it early and provide advice and resources for well managed investigations. This includes training workshops, seminars, books, publications and films all with the purpose of stimulating this greater awareness and self-reliance.</p><p>Hibis' founder, Martin Samociuk, passed away in 2013 at the age of 62 from pancreatic cancer. He will be missed by all that knew him but we are grateful for the important work he left behind.</p><p>Today Hibis is an advisory organisation which we hope will help open people\u2019s eyes to the fact that even though fraud and corruption is all around us, it can be kept under control. Our aim is to provide innovative tools and techniques to deal with it, as well as the confidence to spot it early. We aim to support those people who wish to take a stand against fraud and corruption.</p><p>Finally, if you like what you have read, and feel that you are our sort of person, then do take contact with us. We don\u2019t recruit in the traditional manner \u2013 like-minded people usually find us\u2026</p>","profile_allan","Allan\u2019s long experience from 1967 includes UK Customs and Excise Investigations and New Scotland Yard, where he specialized in narcotics and organised crime. Between 1985 and 1997 Allan worked as Deputy Managing Director with Martin Samociuk at Network Security Management Limited, Europe\u2019s leading fraud investigation consultancy. Apart from leading hundreds of investigations and recovery projects throughout the world for both commercial and government clients, he created the highly successful Forensic Laboratories which were eventually acquired by Control Risks Group. Allan has project managed many successful investigations around the world.","profile_carina","Carina S\xf6rqvist has over 15 years of experience of preventing and investigating fraud and corruption. She has acted as the investigator and project leader in investigations for clients in various different industries. Her long experience of structured investigations of real fraud and corruption cases is used in seminars and trainings regarding investigation technique. She has, for several clients, developed action plans for how to handle incidents such as suspected fraud and/or corruption. She has worked as a Senior Consultant since 2003 and before that she worked with compliance as the manager of the Internal Control department in a multinational company. Carina has a financial background and her specialities are forensic accounting and interview techniques.","profile_jan","Jan has performed a number of forensic investigations and fraud detection projects, as well as held courses in red flag detection within fraud and corruption and corporate governance.  He holds an MBA and CPA degree from the Norwegian School of Economics and Business Administration in Bergen. After spending 4 years as an external auditor he was Chief Financial Officer for 9 years in an international construction company with operations in East Africa. After that he worked for over 20 years as advisor (on, among others, business development, sustainability evaluations, performance audit and background checks) for the Norwegian Ministry of Foreign Affairs (NORAD, Embassies and Norfund) and private sector companies operating in East-Africa, The Balkans, Baltic states, Georgia, Sri Lanka, Nepal and the Palestine Territories.","profile_john","John Wallhoff, a computer security and data-analysis expert for many years, develops and implements data models to detect patterns of fraud and corruption. John participates in investigations, leads trainings and supports his colleagues through development of leading edge models to pinpoint patterns of malpractice and unethical business behavior. In addition John has built information security strategies and contingency plans for a number of companies and as a compliment to fraud detection, develops data-analysis solutions for continuous monitoring of internal controls.","profile_martina","Martina has a combined Masters degree in Business and Economics (majoring in finance) from the Norwegian Business School (BI) and the University of Ljubljana (Slovenia). Right from an early age she wanted to play an active part in eradicating systematic inefficiencies. She recognized that corruption and fraud is one of the major obstacles to sustainability and growth and was able to apply her passion at Hibis. Martina specializes in identifying red flags of corruption through internal and external analysis, and understanding and investigating them across a wide range of countries and languages-zones.","profile_fridtjof","Fridtjof Klareng Dale's passion for fighting corruption and fraud started while studying for his bachelor in European Studies at the Norwegian University of Science and Technology (NTNU). Through his strong engagement in volunteerism, he joined the newly founded student organisation Anti-Corruption International (ACI) and helped build the organisation, spearheading projects showing that \u201cyoung people not only can play a part in eradicating a global problem, but can also take the lead.\u201d Through ACI he got to know Hibis, where he is now successfully working as a fraud investigator combining this with his anti-corruption activities.","profile_maurizio","Maurizio has 18 years\u2019 experience in innovation and organisational development in a wide variety of sectors which include telecommunications and technology, banking, retail and consumer products, culture, education and government, in primarily Italy, Switzerland and Brazil. He provides training to achieve fulfilment of goals both at a personal and organisational level. Finding fraud and corruption early, dealing with it responsibly to foster organisational robustness is an important cornerstone of his work today.","profile_nigel","Nigel has over 20 years experience investigating and detecting fraud and corruption. A computer scientist and qualified chartered accountant Nigel soon found that his true passion lay in rooting out corruption and fraud. Nigel is also today a qualified dramatist and has written a number of films and plays based on experiences, many of which are used in teaching worldwide. He has written several books and papers, and teaches widely how to defend organisations against the \u201ccommercial dark arts\u201d. He is also a fellow of the University of Leicester School of Business.","profile_petri","Petri Kelo is Hibis\u2019 associated partner in Finland. His academic background includes a Masters of Security from Helsinki University of Technology. Petri has worked for over 25 years with logistics, service quality and security as well as managing the risk of fraud and corruption. Petri is also one of the founders of Centry Ltd, a security company specialized in logistics & transportation security, cyber security, security risk management and compliance & investigative services. Petri is a well-known speaker and trainer in TAPA (Transportation Asset Protection Association), AEO (Authorized Economic Operator), ISO 28000 (Supply Chain Security Management) and logistics security.","profile_richard","Since his first full time job as internal auditor starting in 1975, Richard has accumulated experience in audit, investigation, financial control, and general management. Inquisitive by nature, he knows there is usually more than one right way to do things, and many wrong ways. Richard\u2019s talent for penetrating complexity and understanding his clients\u2019 business processes makes him a valuable resource for assessment, investigation and improvement projects. Richard graduated BSc in Accountancy, and is qualified CPA and CIA.","profile_veronica","Veronica has over 15 years\u2019 experience investigating, finding and training others on how to prevent and manage fraud and corruption around the world. A sociologist of work and economics with a master in organisational science, she has developed holistic desktop investigative research and analysis tools to explore organisations, business partners, suppliers, customers and key individuals and discover what is really going on at a fraction of the resources normally associated with investigation. Veronica has also worked for several years with the assessment of the effectiveness of organisations\u2019 anti-fraud and corruption programs and is currently completing a PhD degree on that subject.","red_flag_game","The <span class='red-text'>red</span><br />flag Game","rome","Rome","rulebending_final_question","It would assist our research if you could provide us with details of your job functions (anonymously)","rules_game","How far can you bend the rules?","search","Search","send","send","stockholm","Stockholm","the_fraud_academy","The Fraud Academy","what_we_do","What we do","what_we_do_collapsed_text_1",'<p>There is plenty of fraud and corruption around that can be found (preferably in the early stages) and stopped. Usually fraudulent and corrupt activities are cloaked in legitimacy, and finding the truth requires experience, effort and specialist knowledge.</p><p>Our proven structured methodology "B4" (which is short for "Finding fraud before it finds you") has been developed to efficiently find and effectively deal with fraud. B4 includes activities such as:</p><ul><li>Following the money, performing structured analysis, and running B4 algorithms on transactions to find the red flags.</li><li>Convening \u201cthinking like a thief\u201d sessions (an approach invented in the 1980\u2019s by Martin Samociuk, Hibis\u2019 founder) to anticipate how the fraudsters\u2019 mind works and build a profile of the types of frauds that are occurring or likely to occur.</li><li>Finding behavioural red flags by performing holistic desktop investigative research and analysis of organisations, business partners, suppliers, customers and key individuals. All with a special focus on opportunities, motives and how people rationalize dishonest or unethical behaviour.</li><li>Analysing indications of fraud and corruption to understand which issues are the most important, and condensing them into a manageable list for our clients to resolve.</li><li>Working together with our clients to find the most effective course of action to resolve problems. Long experience gives us an overview of different approaches, which ones are appropriate in different situations, and how they should be implemented.</li></li></ul><p>If not detected early, fraud and corruption will spread. Eventually, the problem will be discovered when it becomes too large to ignore, or is reported by whistle-blowers, or both. But why wait for the whistle-blower when you can use fraud detective techniques and uncover where early stage fraud and corruption is developing now? It\u2019s better to stay ahead of the game!</p>',"what_we_do_collapsed_text_2",'<p>We probably will never totally eradicate fraud and corruption. But by raising awareness and managing the risks we can control the cost and make corrupt behaviour less acceptable. Surprisingly, much fraud and corruption involves normal, good people such as valuable and trusted employees or business partners. Awareness is a powerful tool to help good people avoid bad mistakes they will later regret, and to show them how to protect the organisation against career fraudsters. As Nelson Mandela said, education is one of the most powerful ways to change the world. We have developed courses and techniques to bridge the skills gap and constantly look for innovative new ways to raise the awareness, spread knowledge and bring people together in the fight of corruption and fraud. Examples (details can be found in our Fraud Academy page) include:</p><ul><li>Practical open courses and workshops (including our "think like a thief methodology" and "fraud detective school")</li><li>Accredited management courses</li><li>On the job-training, in-house workshops and clinics</li><li>Multimedia based training delivered over the internet (or intranet)</li><li>Experiential learning, including drama, scenarios, live simulations, \u201ccorruption-theatre\u201d and films</li><li>Publications and books</li></ul>',"what_we_do_collapsed_text_3","<p>When it is required by the client, we investigate fraud and corruption constructively and effectively.</p><p>We believe in the beauty of small investigations that win back value. We have a track record of solving our client\u2019s problems efficiently and in a way which both identifies root causes and prevents recurrence.</p><p>Exceptional situations do occur from time to time for which a deep investigation may be required, such as when an organisation needs to prepare legal actions to recover major assets or salvage parts of a business. We manage all investigations in a controlled way avoiding unnecessary expenditure and ensuring that our client is always in the driver\u2019s seat.</p>","what_we_do_collapsed_text_4","<p>The scope and complexity of external regulation, designed to protect the public and punish corporate offenders is increasing. This absorbs management attention and leaves less room for more practical programs designed to protect the organisation. Management can fall into the trap of accepting bureaucratic solutions that appear to fulfil regulatory requirements, but which do not effectively address the issue of fraudulent and corrupt behaviour. Compliance programs based on checklists are unlikely to be effective!</p><p>We are able to measure the impact and effectiveness of your existing anti-fraud and corruption activities, identifying gaps and potential improvements that will bring down the cost of fraud and corruption and strengthen the ethical culture.</p><p>Our holistic framework and assessment tool brings together years of practical experience with a distillation of the most essential knowledge from widely used existing frameworks.</p>","what_we_do_collapsed_title_1","We find early fraud and help you resolve it","what_we_do_collapsed_title_2","We raise awareness, share knowledge and transfer skills","what_we_do_collapsed_title_3","We investigate fraud and corruption responsibly","what_we_do_collapsed_title_4","We assess effectiveness of existing anti-fraud and corruption programs","what_we_do_list_1_item_1","<strong>Finding</strong> and interpreting the many <strong>red flags</strong>","what_we_do_list_1_item_2","<strong>Investigations</strong> carried out in an efficient, responsible manner","what_we_do_list_1_item_3","<strong>Analysing</strong> the root causes of incidents to identify improvement opportunities","what_we_do_list_1_item_4","<strong>Providing</strong> (through practical workshops, training and other innovative devices) the <strong>skills</strong> to turn what looks like \"bad news\" into an opportunity to save money (see <a href='http://fraudacademy.hibis.com' target='_blank'>Hibis Fraud Academy</a>)","what_we_do_list_1_item_5","<strong>Assessing</strong> and <strong>measuring</strong> the <strong>effectiveness</strong>, strengths and weaknesses of existing anti-fraud and corruption programmes","what_we_do_paragraph_1","Fraud and corruption happens all the time and is arguably one of the greatest unmanaged costs in organisations and society today. Yet most management and employees have not had any practical training in this area. Our aim is to significantly raise awareness of fraud and corruption and its consequences. We assist and advise organisations, companies and everyone else concerned by:","who_we_are","Who we are"]),"it",P.P(["address_copenhagen","c/o Scillani Information AB<br />Vestergade 16<br />1456 Copenhagen<br />Danimarca","address_gothenburg","Hibis AB<br />Kronhusgatan 11<br />411 05 G\xf6teborg<br />Svezia","address_helsinki","Hibis Associates<br />Centry Ltd","address_london","Hibis Europe Ltd","address_malmo","Hibis AB","address_oslo","Hibis AS<br /> Meltzersgt. 4<br/> 0275 Oslo<br/> Norvegia","address_rome","Hibis Associates","address_stockholm","Hibis AB","contact","Contatti","contact_us","Contatti","contact_copenhagen","<strong>John Wallhoff</strong><br /><a href='mailto:john.wallhoff@hibis.com'>john.wallhoff@hibis.com</a><br />+ 45 70 77 43 131","contact_gothenburg","<strong>Carina S\xf6rqvist</strong><br /><a href='mailto:carina.sorqvist@hibis.com'>carina.sorqvist@hibis.com</a><br />+ 46 707 97 97 64","contact_helsinki","<strong>Petri Kelo</strong><br /><a href='mailto:petri.kelo@centry.global'>petri.kelo@centry.global</a><br />+ 358 40 50 001 068","contact_london","<strong>Allan McDonagh</strong><br /><a href='mailto:allan.mcdonagh@hibis.com'>allan.mcdonagh@hibis.com</a><br />+ 44 77 68 32 0161","contact_malmo","<strong>Richard Minogue</strong><br /><a href='mailto:richard.minogue@hibis.com'>richard.minogue@hibis.com</a><br />+ 46 761 882 497","contact_oslo","<strong>Veronica Morino</strong><br /><a href='mailto:veronica.morino@hibis.com'>veronica.morino@hibis.com</a><br />+ 47 91 86 32 19<br/><br/><strong>Nigel Krishna Iyer</strong><br /><a href='mailto:nigel.iyer@hibis.com'>nigel.iyer@hibis.com</a><br />+ 47 90 65 44 10<br/>+ 44 7523 570004 (UK)","contact_rome","<strong>Maurizio Carmignani</strong><br /><a href='mailto:maurizio.carmignani@hibis.com'>maurizio.carmignani@hibis.com</a><br />+ 39 3489501126","contact_stockholm","<strong>Richard Minogue</strong><br /><a href='mailto:richard.minogue@hibis.com'>richard.minogue@hibis.com</a><br />+ 46 761 882 497","copenhagen","Copenhagen","copyright","&copy;2017 Hibis. All rights reserved. Design by SoiaDg. Images by Floral Zu.","frontpage_title","<strong>Fraud and corruption <span class='orange-text'>can</span> be stopped</strong>","gothenburg","Gothenburg","hibis_associates","Hibis associates","hibis_people","Hibis team","helsinki","Helsinki","language","Lingua","lang_en","Inglese (english)","lang_no","Norvegese (norsk)","lang_it","Italiano (italian)","london","Londra","malmo","Malm\xf6","oslo","Oslo","our_history","La nostra storia","our_history_text","<p><strong>Hibis</strong> nasce nel 1998 grazie a un'idea di Martin Samociuk. La sua visione viene accolta entusiasticamente da un team che aveva lavorato precedentemente per Network Security Management a Londra, un'azienda all'avanguardia nel campo delle investigazioni e della prevenzione della frode negli anni Ottanta e Novanta. Nel 1999, Martin viene affiancato da Nigel Krishna Iyer e, un anno dopo, da Allan McDonagh. Veronica Morino li raggiunge nel 2001, subito seguita da Richard Minogue nel 2002. Hibis ha da sempre deciso di porre al primo posto la prevenzione e la rilevazione precoce di frodi. Avvertiamo, insieme ai nostri clienti, il bisogno di richiamare drasticamente l'attenzione sulla frode e la corruzione, formandoli su come scovare gli illeciti per tempo, oltre a fornire consulenze e risorse per gestire al meglio eventuali investigazioni. Abbiamo sviluppato apposite attivit\xe0 di formazione quali workshop e seminari, libri, articoli e film, il tutto con lo scopo di sensibilizzare garantire l'autosufficienza nel campo per i nostri clienti.</p> <p>Hibis opera nel Regno Unito e in Scandinavia dal 1999</p><p>Hibis \xe8 un'organizzazione di esperti dedicati a dimostrare che, sebbene frode e corruzione permeino l'ambiente in cui viviamo, \xe8 comunque possibile tenerli sotto controllo e arginare o evitare i danni. Il nostro obiettivo \xe8 fornire strumenti e tecniche all'avanguardia per gestire il rischio di frode, insieme alla certezza della prevenzione. Offriamo il miglior supporto a chi intende darci un taglio con frode e corruzione.</p><p>Se avete trovato la nostra presentazione di vostro gradimento, e ritenete che potrebbe essere l'ambiente lavorativo giusto per voi, non esitate a contattarci. </p> ","profile_allan","Dal 1967 ad oggi, Allan ha lavorato a New Scotland Yard occupandosi di investigazioni doganali nel Regno Unito, e in particolare di droga e criminalit\xe0 organizzata. Tra il 1985 e il 1997 Allan ha lavorato come vice-direttore di Network Secutiry Management Limited (assieme a Martin Samociuk, fondatore di Hibis), una tra le migliori ditte di consulenza a livello Europeo in materia di investigazioni anti-frode. Oltre ad aver condotto con successo centinaia di investigazioni in tutto il mondo sia per clienti privati che per aziende pubbliche, ha inoltre fondato i Forensic Laboratories, successivamente acquisiti da Control Risks Group.","profile_carina","Carina S\xf6rqvist da oltre 15 anni previene e ricerca episodi di frode e corruzione. Ha ricoperto ruoli di investigatrice a capo di inchieste per diversi clienti in vari settori. La sua pluriennale esperienza in materia di investigazioni complesse di casi di frode e corruzione \xe8 oggi sfruttata in seminari e training sulle tecniche investigative. Ha sviluppato piani d'azione per svariati clienti, suggerendo come comportarsi in caso di incidenti di sospetta natura fraudolenta. Dal 2003 ha lavorato come consulente, dopo essersi cimentata nel ramo della compliance per il dipartimento di controllo di una multinazionale. Carina ha completato studi di ragioneria e finanza, specializzandosi nell'ambito della revisione contabile e delle tecniche di interrogazione.","profile_jan","Jan ha svolto diverse investigazioni forensi e ha partecipato a una moltitudine di progetti anti-frode, oltre ad aver condotto svariati corsi di detezione dei segnali della frode nell'ambito della corporate governance. Ha ottenuto i titoli di MBA e CPA dalla Norwegian School of Economics and Business Administration di Bergen. Dopo 4 anni come revisore dei conti esterno, \xe8 stato per 9 anni CFO di una ditta di costruzioni internazionale, con operazioni nell'Africa orientale. Successivamente ha ricoperto per oltre 20 anni il ruolo di consulente (in materie quali sviluppo, valutazioni di sostenibilit\xe0, controlli di gestione, controllo dei precedenti) presso il Ministero Norvegese degli Affari Esteri (NORAD, Ambasciate e Norfund), oltre ad assistere nella medesima funzione aziende del settore privato operanti nell'Africa orientale, nei Balcani, nei paesi Baltici, Georgia, Sri Lanka, Nepal, e Palestina.","profile_john","John Wallhoff \xe8 un esperto nel settore della sicurezza digitale e nell'analisi dei dati, campi in cui ha lavorato per anni. Con Hibis in particolare, sviluppa e raffina modelli in grado di analizzare grandi quantit\xe0 di dati e ricostruire \u201cpattern\u201d fraudolenti. John partecipa a investigazioni, conduce training, e fornisce attivit\xe0 di supporto ai colleghi grazie al costante raffinamento e adattamento dei modelli agli scenari che i nostri clienti si trovano ad affrontare, per scovare qualsiasi tipo di comportamento \u201cindesiderato\u201d. Inoltre, John ha costruito strategie di sicurezza per network interni, oltre a piani d'azione in caso di emergenze per svariate organizzazioni. Complementando l'attivit\xe0 di detezione della frode, John offre anche soluzioni di analisi dei dati per monitorare periodicamente l'efficacia dei controlli interni.","profile_martina","Martina ha ottenuto una laurea magistrale in finanza e gestione aziendale presso la BI Norwegian Business School di Oslo e l'universit\xe0 di Ljubljana, in Slovenia. In quanto economista di formazione, si interessa alla frode come spreco di risorse, che potrebbero essere altrimenti allocate in maniera ottimale, favorendo una crescita e uno sviluppo sostenibile. Grazie a Hibis ha avuto modo di applicare la sua passione a diversi scenari: in particolare, si occupa di identificare le \u201cred flag\u201d attraverso analisi interne e investigazioni esterne, e si avvale spesso della propria conoscenza delle lingue per tracciare flussi monetari in vari paesi.","profile_fridtjof","Fridtjof Klareng Dale ha sviluppato uno spiccato interesse per la lotta alla corruzione mentre frequentava la facolt\xe0 di studi europei presso l'universit\xe0 norvegese della scienza e della tecnica di Trondheim (NTNU). Attraverso numerosi impegni di volontariato, si \xe8 unito al neo-fondato gruppo \"Anti-Corruption International (ACI)\", contribuendo a trasformarlo in una vera e propria organizzazione internazionale che finora, attraverso numerosi progetti, ha dimostrato come i giovani possano non solo contribuire a eradicare un problema globale, ma possano anche assumere un ruolo di guida nella lotta alla corruzione. Proprio attraverso ACI \xe8 entrato in contatto con Hibis, dove ora pu\xf2 affiancare l'attivismo anti-frode alle investigazioni.","profile_maurizio","Da 18 anni lavora come libero professionista e consulente direzionale, advisor, mentor e trainer. Ha maturato esperienze in diversi ed eterogenei settori: sviluppo e innovazione, telecomunicazioni e tecnologie per le imprese, banche e assicurazioni, moda, industria degli occhiali, industria culturale e della formazione, settore farmaceutico e sanitario, beni culturali e turismo. Ha lavorato in Italia, Svizzera e Brasile. Le aree di maggiore interesse ed esperienza sono: creazione e gestione di impresa, innovazione e gestione del cambiamento, marketing e comunicazione, formazione e sviluppo organizzativo. All'interno di questi ambiti, la detezione precoce e la gestione responsabile della frode svolgono un ruolo fondamentale.","profile_nigel","Nigel ha pi\xf9 di 20 anni di esperienza nel campo dell'investigazione della frode. Ha ottenuto un Bachelor Degree in informatica, e subito dopo ha superato l'esame nazionale per dottori commercialisti nel Regno Unito. Fin dalle prime esperienze lavorative, ha scoperto la propria vocazione di \u201cfraud detective\u201d. Successivamente si \xe8 interessato anche alla produzione teatrale, ottenendo un Master of Arts in sceneggiatura e regia teatrale. Ha scritto e prodotto numerosi testi teatrali e film basati su esperienze personali, che poi vengono utilizzati per la formazione. Sulla frode ha scritto diversi articoli e pubblicato 3 libri, e, oltre a insegnare le proprie tecniche in diversi paesi, ricopre il ruolo di Fellow presso la Leicester School of Business.","profile_petri","Petri Kelo \xe8 il partner Hibis in Finlandia. Ha ottenuto un Master's Degree in Security presso la Helsinki University of Technology. Negli ultimi 25 anni si \xe8 occupato di logistica, qualit\xe0 del servizio, sicurezza, oltre alla gestione del rischio di frode. Petri ha inoltre fondato Centry Ltd, una realt\xe0 che si occupa di sicurezza nel settore della logistica, supply chain, gestione dei rischi, compliance e servizi investigativi. Svolge tutt'ora attivit\xe0 di training in materia di AEO (Authorized Economic Operator), TAPA (Transportation Asset Protection Association) e sicurezza nella logistica (ISO 28000 \u2013 Supply chain security management).","profile_richard","Richard ha maturato decenni di esperienza nel settore dell'audit, investigazione, controllo e gestione a partire dal 1975, quando ha iniziato a lavorare come revisore dei conti (internal auditor). Curioso di natura, ha la capacit\xe0 innata di risolvere situazioni complesse e comprendere a fondo i processi dei propri clienti, offrendo loro la soluzione pi\xf9 adatta, ben consapevole che esista pi\xf9 di una risposta esatta, e allo stesso tempo molte risposte sbagliate. Richard ha conseguito un Bachelor Degree in economia aziendale, superando gli esami CPA e CIA. In tempi recenti si \xe8 dedicato alla valutazione, all'investigazione, e al miglioramento dei sistemi di controllo in vigore in varie organizzazioni.","profile_veronica","Veronica ha oltre 15 anni di esperienza nell'investigazione e prevenzione della frode, e in particolare nella formazione anti-frode e nella gestione dei rischi associati. Laureata in sociologia del lavoro presso l\u2019Universit\xe0 di Roma \u201cLa Sapienza\u201d, ha sviluppato una metodologia di ricerca olistica che permette di analizzare organizzazioni, aziende, soci in affari, fornitori, clienti, e personaggi chiave per capire che cosa vi sia davvero dietro. Inoltre, Veronica da diversi anni valuta ed esamina l'efficacia dei programmi anti-frode e corruzione adottati da varie organizzazioni, e al momento sta completando il proprio dottorato di ricerca in materia.","red_flag_game","The <span class='red-text'>red</span><br />flag Game","rome","Roma","rulebending_final_question","Ai fini della nostra ricerca, vi saremmo molto grati se poteste fornirci (in modo anonimo) una descrizione dettagliata delle vostre mansioni","rules_game","Quanto \xe8 flessibile la vostra morale?","search","Cerca","send","Invia","stockholm","Stoccolma","the_fraud_academy","Fraud Academy","what_we_do","Attivit\xe0","what_we_do_collapsed_text_1",'<p>Gran parte delle frodi di cui sentiamo parlare quotidianamente potrebbe essere segnalata (anche se in fase iniziale) e fermata. Spesso, attivit\xe0 illegittime hanno parvenza di legalit\xe0 e trovare la verit\xe0 richiede esperienza, fatica, e l\'aiuto di esperti.</p><p>La nostra soluzione "B4" (o "before" nel senso di "Finding fraud before it finds you") \xe8 stata sviluppata apposta per scovare qualsiasi frode in maniera efficiente ed eliminarla efficacemente. La soluzione "B4" si fa carico di attivit\xe0 quali:</p><ul><li>Analisi dei flussi monetari, divisi per categorie, ed esecuzione degli algoritmi della suite B4 sulle singole transazioni</li><li>Ricostruzioni \u201cthink like a thief\u201d (un approccio inventato negli anni Ottanta da Martin Samociuk, il fondatore di Hibis), per vestire i panni di un malintenzionato e profilare i diversi tipi di frode, sia quelli in corso che quelli potenzialmente pericolosi</li><li>Identificare comportamenti a rischio attraverso un approccio integrato che prevede l\'uso di \u201cdesktop research\u201d per analizzare organizzazioni, soci in affari, fornitori, clienti e figure chiave, il tutto tenendo sempre a mente l\'opportunit\xe0, le motivazioni, e il fenomeno della razionalizzazione del comportamento disonesto</li><li>Dopo aver identificato e classificato i segnali di frode, stilare una lista che permetta poi ai nostri clienti di avere una visione chiara dei problemi pi\xf9 importanti da risolvere</li><li>Collaborare con i nostri clienti per giungere al corso d\'azione pi\xf9 efficace per risolvere problemi. La nostra pluriennale esperienza ci pone in una posizione unica per valutare e suggerire soluzioni commisurate alla gravit\xe0 di ciascuna situazione.</li></li></ul><p>Se non si agisce per tempo, si rischia che i segnali iniziali si sviluppino in vere e proprie frodi, diffondendosi attraverso intere organizzazioni. A quel punto, il problema emerger\xe0 nuovamente quando sar\xe0 ormai impossibile ignorarlo, o per le dimensioni raggiunte o perch\xe9 denunciato anonimamente (o entrambi). Perch\xe9 dunque attendere inerti che ci\xf2 accada quando si possono usare tecniche di investigazione per scoprire ora le aree affette dai primi segni di frode? \xc8 meglio giocare d\'anticipo!</p>',"what_we_do_collapsed_text_2",'<p>Pensare di riuscire a eliminare del tutto le frodi \xe8 senz\'altro un\'utopia. Tuttavia, prestando attenzione al problema e gestendone il rischio in maniera appropriata, sar\xe0 possibile controllarne il costo e rendere i comportamenti disonesti meno accettabili. Non \xe8 un caso che le frodi pi\xf9 comuni siano di solito perpetrate da persone \u201cnormali\u201d, nella media, quali potrebbero essere impiegati o soci d\'affari fidati. Aumentare la consapevolezza del fenomeno potr\xe0 aiutare chiunque a evitare errori di cui poi si pentir\xe0, oltre a formarvi per difendere la vostra organizzazione da malintenzionati. Citando Nelson Mandela, \u201cl\'istruzione \xe8 uno dei modi pi\xf9 potenti per cambiare il mondo\u201d. Abbiamo sviluppato metodi per facilitare il \u201cknowledge transfer\u201d nei confronti dei nostri clienti, e siamo costantemente alla ricerca di modi innovativi per sensibilizzare, diffondere il know-how necessario e permettere un confronto aperto e costruttivo in materia di frode e corruzione. Alcuni esempi sono (per una descrizione pi\xf9 dettagliata si veda la pagina Fraud Academy):</p><ul><li>Corsi pratici e laboratori (tra cui il metodo "Think like a thief" e la "fraud detective school")</li><li>Corsi certificati per il management</li><li>Training sul luogo di lavoro, laboratori "in-house" e workshop a tema</li><li>Corsi multimediali tenuti via internet (o intranet)</li><li>Corsi interattivi con drammi teatrali, allestimento di scenari e giochi di ruolo per i partecipanti, film a tema</li><li>Libri e altre pubblicazioni su riviste specializzate</li></ul>',"what_we_do_collapsed_text_3","<p>Aiutiamo i nostri clienti a investigare i comportamenti illeciti in maniera costruttiva ed efficace.</p><p>Siamo fautori di piccole investigazioni che aiutano a recuperare le risorse perdute. Abbiamo un comprovato numero di situazioni risolte con successo ed efficienza, in cui siamo riusciti a identificare le mancanze alla radice e correggerle, impedendo che il problema si ripetesse. Talvolta, grandi investigazioni sono necessarie, ad esempio qualora un'organizzazione avesse bisogno di prepararsi ad azioni legali per recuperare beni o salvare parte del proprio business. Gestiamo ogni investigazione in maniera discreta, evitando costi superflui e accertandoci allo stesso tempo di mantenere il cliente sempre al corrente.</p>","what_we_do_collapsed_text_4","<p>La mole e la portata dei regolamenti esterni, studiati per proteggere i consumatori e dissuadere potenziali criminali, \xe8 sempre in aumento. Ci\xf2 richiede sempre pi\xf9 attenzione da parte del management, a scapito di programmi pi\xf9 pratici, disegnati specificatamente per proteggere l'azienda. Di conseguenza, la direzione potrebbe cadere nella trappola di voler assecondare soluzioni \u201cburocratiche\u201d in conformit\xe0 con la legge, ma nella realt\xe0 poco adatte a prevenire azioni fraudolente. Le attivit\xe0 di \"compliance\", intesa come una lista di controlli da manuale, difficilmente daranno risultati concreti.</p><p>Siamo lieti di mettere al vostro servizio la nostra esperienza, offrendovi una valutazione dei vostri sistemi di controllo per far emergere potenziali debolezze. Insieme potremo migliorarli per abbattere il costo della frode e riaffermare i valori e l'etica della vostra azienda.</p><p>Partendo dai framework pi\xf9 comuni in uso, abbiamo selezionato i punti chiave, combinandoli con anni di esperienza sul campo per offrirvi uno strumento di valutazione complessivo, frutto di un approccio olistico.</p>","what_we_do_collapsed_title_1","Scoviamo i primi segni di frode e ti aiutiamo a risolverli","what_we_do_collapsed_title_2","Mettiamo la nostra esperienza al vostro servizio, sensibilizzando in materia di frode","what_we_do_collapsed_title_3","Investighiamo la frode responsabilmente","what_we_do_collapsed_title_4","Testiamo l'efficacia dei vostri programmi anti-frode","what_we_do_list_1_item_1","<strong>Trovare</strong> e interpretare i primi segnali (Le <strong>red flags</strong>)","what_we_do_list_1_item_2","<strong>Investigare</strong> in modo efficiente, competente e responsabile","what_we_do_list_1_item_3","<strong>Analizzare</strong> i problemi alla radice per identificare aree di miglioramento","what_we_do_list_1_item_4","<strong>Formare</strong> attraverso workshop pratici, conferenze, training e altri strumenti innovativi, le <strong>competenze necessarie</strong> per trasformare le \"brutte notizie\" in opportunit\xe0 di risparmio (si veda anche <a href='http://fraudacademy.hibis.com' target='_blank'>Hibis Fraud Academy</a>)","what_we_do_list_1_item_5","<strong>Testare</strong> e <strong>misurare</strong> l'<strong>efficacia</strong>, i punti di forza e le debolezze dei programmi antifrode gi\xe0 presenti","what_we_do_paragraph_1","Frodi e corruzione avvengono costantemente e sono tra i costi pi\xf9 difficili da gestire per aziende e organizzazioni. Gran parte dei dirigenti e degli impiegati per\xf2 non ha mai ricevuto alcuna formazione pratica su questo tema. Il nostro obiettivo \xe8 richiamare l'attenzione su frodi e corruzione e sulle conseguenze che possono comportare. Da anni assistiamo e consigliamo aziende, organizzazioni e chiunque abbia bisogno di aiuto pratico per","who_we_are","Chi siamo"]),"no",P.P(["address_copenhagen","c/o Scillani Information AB<br />Vestergade 16<br />1456 Kj\xf8benhavn<br />Danmark","address_gothenburg","Hibis AB<br />Kronhusgatan 11<br />411 05 G\xf6teborg<br />Sverige","address_helsinki","Hibis Associates<br />Centry Ltd","address_london","Hibis Europe Ltd","address_malmo","Hibis AB","address_oslo","Hibis AS<br /> Meltzersgt. 4<br/> 0275 Oslo<br/> Norge","address_rome","Hibis Associates","address_stockholm","Hibis AB","contact","Kontakt","contact_us","Kontakt oss","contact_copenhagen","<strong>John Wallhoff</strong><br /><a href='mailto:john.wallhoff@hibis.com'>john.wallhoff@hibis.com</a><br />+ 45 70 77 43 131","contact_gothenburg","<strong>Carina S\xf6rqvist</strong><br /><a href='mailto:carina.sorqvist@hibis.com'>carina.sorqvist@hibis.com</a><br />+ 46 707 97 97 64","contact_helsinki","<strong>Petri Kelo</strong><br /><a href='mailto:petri.kelo@centry.global'>petri.kelo@centry.global</a><br />+ 358 40 50 001 068","contact_london","<strong>Allan McDonagh</strong><br /><a href='mailto:allan.mcdonagh@hibis.com'>allan.mcdonagh@hibis.com</a><br />+ 44 77 68 32 0161","contact_malmo","<strong>Richard Minogue</strong><br /><a href='mailto:richard.minogue@hibis.com'>richard.minogue@hibis.com</a><br />+ 46 761 882 497","contact_oslo","<strong>Veronica Morino</strong><br /><a href='mailto:veronica.morino@hibis.com'>veronica.morino@hibis.com</a><br />+ 47 91 86 32 19<br/><br/><strong>Nigel Krishna Iyer</strong><br /><a href='mailto:nigel.iyer@hibis.com'>nigel.iyer@hibis.com</a><br />+ 47 90 65 44 10<br/>+ 44 7523 570004 (UK)","contact_rome","<strong>Maurizio Carmignani</strong><br /><a href='mailto:maurizio.carmignani@hibis.com'>maurizio.carmignani@hibis.com</a><br />+ 39 3489501126","contact_stockholm","<strong>Richard Minogue</strong><br /><a href='mailto:richard.minogue@hibis.com'>richard.minogue@hibis.com</a><br />+ 46 761 882 497","copenhagen","Kj\xf8benhavn","copyright","&copy;2017 Hibis. All rights reserved. Design by SoiaDg. Images by Floral Zu.","frontpage_title","<strong>Fraud and corruption <span class='orange-text'>can</span> be stopped</strong>","gothenburg","G\xf6teborg","hibis_associates","Hibis assosierte","hibis_people","Hibis ansatte","helsinki","Helsinki","language","Spr\xe5k","lang_en","Engelsk (english)","lang_no","Norsk (norwegian)","lang_it","Italiensk (italian)","london","London","malmo","Malm\xf6","oslo","Oslo","our_history","V\xe5r historie","our_history_text","<p><strong>Hibis</strong> ble grunnlagt i 1998 av Martin Samociuk. Mange av dem som ble med i starten kom fra Network Security Management i London, et selskap som var pionerer forebygging og etterforsking av bedrageri p\xe5 1980og -90-tallet. I 1999 sluttet Nigel Krishna Iyer seg til Martin og et \xe5r senere ble ogs\xe5 Allan McDonagh med. Veronica Morino ble en del av gruppen i 2001, etterfulgt av Richard Minogue i 2002. Hibis sitt oppdrag har alltid v\xe6rt \xe5 sette forebygging og tidlig oppdagelse F\xd8RST. Vi deler med v\xe5re kunder n\xf8dvendigheten av dramatisk \xf8kning av for \xe5 vesentlig \xf8ke bevisstheten rundt misligheter og korrupsjon, gi dem muligheten til \xe5 oppdage det tidlig og bist\xe5 med r\xe5d ressurser til vellykkede etterforskinger. Dette inkluderer trening i workshops, seminarer, b\xf8ker, publikasjoner og filmer alle med det form\xe5let \xe5 stimulere til st\xf8rre bevissthet og selvtillit.</p><p>Hibis grunnlegger, Martin Samociuk, d\xf8de i 2013 i en alder av 62 \xe5r fra bukspyttkjertels kreft. Han vil bli savnet av alle som kjente ham og vi er takknemlige for det viktige arbeidet han etterlot seg.</p><p>I dag er Hibis en r\xe5dgivende organisasjon som vi h\xe5per vil bidra til \xe5 \xe5pne folks \xf8yne for det faktum at selv om misligheter og korrupsjon er rundt oss, kan den holdes under kontroll. V\xe5rt m\xe5l er \xe5 tilby nyskapende verkt\xf8y og teknikker for \xe5 h\xe5ndtere dette, samt mulighet til \xe5 oppdage det tidlig. V\xe5rt m\xe5l er \xe5 st\xf8tte de menneskene som \xf8nsker \xe5 st\xe5 opp mot misligheter og korrupsjon.</p><p>I dag er Hibis en r\xe5dgivende organisasjon som vi h\xe5per vil bidra til \xe5 \xe5pne folks \xf8yne for det faktum at selv om misligheter og korrupsjon er rundt oss, kan den holdes under kontroll. V\xe5rt m\xe5l er \xe5 tilby nyskapende verkt\xf8y og teknikker for \xe5 h\xe5ndtere dette, samt mulighet til \xe5 oppdage det tidlig. V\xe5rt m\xe5l er \xe5 st\xf8tte de menneskene som \xf8nsker \xe5 st\xe5 opp mot misligheter og korrupsjon.</p><p>Til slutt, hvis du liker det du har lest, og tenker som oss, s\xe5 ta gjerne kontakt. Vi rekrutterer ikke p\xe5 tradisjonell m\xe5te - likesinnede mennesker finner oss vanligvis...</p>","profile_allan","Allans lange erfaring fra 1967 inkluderer britiske toll- og fortollingsetterforskning og New Scotland Yard, der han spesialiserte seg p\xe5 narkotikakriminalitet og organisert kriminalitet. Mellom 1985 og 1997 jobbet Allan som assisterende direkt\xf8r med Martin Samociuk p\xe5 Network Security Management Limited, Europas ledende konsultasjonssjef for etterforsking av svindel. I tillegg til \xe5 ha ledet hundrevis av etterforskinger og gjenopprettingsprosjekter over hele verden for b\xe5de kommersielle og offentlige kunder, skapte han de sv\xe6rt vellykkede \xabForensic Laboratories\xbb som til slutt ble kj\xf8pt av Control Risks Group. Allan har v\xe6rt prosjektleder for mange vellykkede etterforskinger rundt om i verden.","profile_carina","Carina S\xf6rqvist har over 15 \xe5rs erfaring med \xe5 forebygge og etterforske misligheter og korrupsjon. Hun har opptr\xe5dt som etterforsker og prosjektleder i etterforskinger for kunder i ulike bransjer. Hennes lange erfaring med strukturerte etterforskinger av mislighet- og korrupsjonssaker blir brukt i seminarer og oppl\xe6ring i forbindelse med etterforskningsteknikker. Hun har, for flere kunder, utviklet handlingsplaner for hvordan man skal h\xe5ndtere hendelser hvor man mistenker misligheter og/eller korrupsjon. Hun har jobbet som seniorkonsulent siden 2003 og f\xf8r det arbeidet hun med compliance som leder av internkontrollavdelingen i et multinasjonalt selskap. Carina har \xf8konomisk bakgrunn og hennes spesialiteter er regnskapsetterforskning og intervjueteknikker.","profile_jan","Jan har utf\xf8rt en rekke etterforskinger og prosjekter for \xe5 oppdage misligheter, samt holdt kurs i r\xf8d-flaggs-avdekking innen bedrageri, korrupsjon og bedriftsstyring. Han har en MBA og CPA-grad fra Handelsh\xf8yskolen i Bergen. Etter \xe5 ha v\xe6rt 4 \xe5r som ekstern revisor var han finansdirekt\xf8r i 9 \xe5r i et internasjonalt byggefirma med virksomhet i \xd8st-Afrika. Deretter jobbet han i over 20 \xe5r som r\xe5dgiver innen forretningsutvikling, b\xe6rekraftevalueringer, performance audit og bakgrunn analyser for Utenriksdepartementet (bl.a. oppdrag for NORAD, ambassader og Norfund) og private n\xe6ringsselskaper som opererer i \xd8st-Afrika, Balkan, Baltikum, Georgia, Sri Lanka, Nepal og Palestina. Han leder ogs\xe5 Styrenettverket i Econa Oslo/Akershus.","profile_john","John Wallhoff har mange \xe5rs erfaring som datasikkerhet- og dataanalyseekspert, og utvikler og implementerer datamodeller for \xe5 oppdage m\xf8nstre av misligheter og korrupsjon. John deltar i etterforskinger, leder oppl\xe6ring og st\xf8tter sine kolleger gjennom utvikling av ledende modeller for \xe5 finne frem til misligheter og uetisk forretningsadferd. I tillegg har John bygget informasjonssikkerhetsstrategier og beredskapsplaner for en rekke selskaper,  deltar i etterforskinger og utvikler dataanalysel\xf8sninger for kontinuerlig overv\xe5king av interne kontroller.","profile_martina","Martina har en mastergrad i business og \xf8konomi med finans som hovedprofil fra handelsh\xf8yskolen BI og universitetet i Ljubljana (Slovenia). Hun bestemte seg tidlig for at hun \xf8nsket \xe5 spille en aktiv rolle i \xe5 utrydde systematisk ineffektivitet. Hun inns\xe5 at korrupsjon og misligheter er noen av de st\xf8rste hindringene for b\xe6rekraftighet og vekst, og f\xe5r bruke sin lidenskap for temaet her hos oss i Hibis. Martina spesialiserer seg p\xe5 \xe5 identifisere r\xf8de flagg i relasjon til korrupsjon gjennom intern og ekstern analyse, og forst\xe5 og etterforske dem over et bredt spekter av land og spr\xe5k-soner.","profile_fridtjof","Fridtjof Klareng Dale's passion for fighting corruption and fraud started while studying for his bachelor in European Studies at the Norwegian University of Science and Technology (NTNU). Through his strong engagement in volunteerism, he joined the newly founded student organisation Anti-Corruption International (ACI) and helped build the organisation, spearheading projects showing that \u201cyoung people not only can play a part in eradicating a global problem, but can also take the lead.\u201d Through ACI he got to know Hibis, where he is now successfully working as a fraud investigator combining this with his anti-corruption activities.","profile_maurizio","Maurizio har 18 \xe5rs erfaring innen innovasjon og organisasjonsutvikling i et bredt spekter av sektorer som inkluderer telekommunikasjon og teknologi, bank, detaljhandel og forbrukerprodukter, kultur, utdanning og regjering, i hovedsak i Italia, Sveits og Brasil. Han gir oppl\xe6ring for \xe5 oppn\xe5 oppfyllelse av m\xe5l b\xe5de p\xe5 personlig og organisatorisk niv\xe5. Han bist\xe5r i \xe5 finne misligheter og korrupsjon tidlig, og h\xe5ndterer det p\xe5 en ansvarlig m\xe5te for \xe5 fremme organisatorisk robusthet.","profile_nigel","Nigel har over 20 \xe5rs erfaring med \xe5 unders\xf8ke og oppdage misligheter og korrupsjon. Som datavitenskapsmann og statsautorisert revisor, fant Nigel snart at hans sanne lidenskap l\xe5 i \xe5 bekjempe korrupsjon og misligheter. Nigel er ogs\xe5 i dag en kvalifisert dramatiker og har skrevet en rekke filmer og skuespill basert p\xe5 erfaringer, hvorav mange brukes i undervisning over hele verden. Han har skrevet flere b\xf8ker og vitenskapsartikler, og underviser i Norge og internasjonalt i hvordan man kan forsvare organisasjoner mot \xabkommersielle m\xf8rkekunster\xbb. Han er ogs\xe5 fellow ved University of Leicester School of Business.","profile_petri","Petri Kelo er Hibis tilknyttede partner i Finland. Hans faglige bakgrunn inkluderer en mastergrad i sikkerhet fra Helsinki University of Technology. Petri har jobbet i over 25 \xe5r med logistikk, kvalitet, sikkerhet, samt med \xe5 h\xe5ndtere risikoen for misligheter og korrupsjon. Petri er ogs\xe5 en av grunnleggerne av Centry Ltd. et sikkerhetsselskap spesialisert innen logistikk, forsyningskjede, sikkerhetsrisikostyring, etterlevelse og etterforskningstjenester. Petri er en velkjent foredragsholder og underviser  i TAPA (Transportation Asset Protection Association), AEO (Authorized Economic Operator), ISO 28000 (Supply Chain Security Management) og logistisk sikkerhet.","profile_richard","Siden sin f\xf8rste heltidsjobb som internrevisor i 1975, har Richard opparbeidet seg erfaring innen revisjon, etterforskning, finansiell kontroll og generell ledelseskompetanse. Nysgjerrig av naturen han vet at det er vanligvis er mer enn \xe8n m\xe5te \xe5 gj\xf8re ting riktig p\xe5, og mange feil m\xe5ter. Richards talent for \xe5 trenge inn i komplekse situasjoner samt forst\xe5 kundens forretningsprosesser gj\xf8r ham til en verdifull ressurs for vurderings-, etterforsknings- og forbedringsprosjekter. Richard har uteksaminert seg med BSc i regnskap, og er kvalifisert CPA og CIA.","profile_veronica","Veronica har over 15 \xe5rs erfaring med \xe5 etterforske, finne og trene andre i hvordan man kan forebygge og h\xe5ndtere misligheter og korrupsjon over hele verden. Hun er utdannet \xf8konomi-og arbeidssosiologi og har en mastergrad i organisasjonsbygging og ledelse har hun utviklet helhetlige unders\xf8kelses- og analyseverkt\xf8y for \xe5 etterforske organisasjoner, samarbeidspartnere, leverand\xf8rer, kunder og n\xf8kkelpersoner, og oppdage hva som egentlig foreg\xe5r med bare en br\xf8kdel av ressursene som normalt er forbundet med en etterforskning. Veronica har ogs\xe5 jobbet i flere \xe5r med vurdering av effektiviteten av organisasjons anti-mislighet og korrupsjonsprogrammer og fullf\xf8rer for tiden en doktorgradsutdanning p\xe5 dette emnet.","red_flag_game","The <span class='red-text'>red</span><br />flag Game","rome","Roma","rulebending_final_question","It would assist our research if you could provide us with details of your job functions (anonymously)","rules_game","Hvor mye kan du b\xf8ye reglene?","search","S\xf8ke","send","send inn","stockholm","Stockholm","the_fraud_academy","The fraud academy","what_we_do","Hva vi gj\xf8r","what_we_do_collapsed_text_1",'<p>I de fleste virksomheter er det mange muligheter for misligheter og korrupsjon som kan spores, avdekkes (helst i de tidlige stadiene) og stoppes. Vanligvis er handlinger som misligheter og korrupsjon skjult bak tilsynelatende legitime handlinger. \xc5 finne sannheten krever erfaring, innsats og spesialkunnskap.</p><p>V\xe5r strukturerte "B4- metodikk" (kort for "Find fraud before it finds you") er utviklet for effektivt \xe5 avdekke og h\xe5ndtere misligheter. B4 inkluderer aktiviteter som:</p><ul><li>F\xf8lge pengestr\xf8mmene, utf\xf8re strukturerte analyser og kj\xf8re B4-algoritmer p\xe5 transaksjoner for \xe5 finne de r\xf8de flaggene.</li><li>\xd8velsen \u201ctenk som en tyv\u201d (en \xf8velse oppfunnet p\xe5 1980-tallet av Martin Samociuk, Hibis grunnlegger) for \xe5 forutse hvordan bedragere tenker og for \xe5 bygge opp en profil av de typer misligheter som oppst\xe5r eller som det kan v\xe6re risiko for at de vil kunne oppst\xe5.</li><li>Finne atferdsmessige r\xf8de flagg ved \xe5 utf\xf8re helhetlige unders\xf8kelser og analyse av organisasjoner, forretningspartnere, leverand\xf8rer, kunder og andre n\xf8kkelpersoner. Alle med et spesielt fokus p\xe5 muligheter, motiver og hvordan folk rasjonaliserer rundt u\xe6rlig eller uetisk oppf\xf8rsel.</li><li>Analysere indikasjoner p\xe5 bedrageri og korrupsjon for \xe5 f\xe5 frem de viktigste omr\xe5der, for s\xe5 \xe5 strukturere disse til en h\xe5ndterlig liste som v\xe5re kunder kan arbeide videre med.</li><li>Samarbeide med v\xe5re oppdragsgivere for \xe5 finne den mest effektive l\xf8sningen p\xe5 utfordringene. Lang erfaring har gitt oss en oversikt over ulike tiln\xe6rminger, hvilke som passer i ulike situasjoner, og hvordan de kan implementeres.</li></li></ul><p>Hvis det ikke oppdages tidlig, vil misligheter og korrupsjon spre seg. Til slutt vil problemet bli oppdaget n\xe5r det blir for stort til \xe5 ignoreres, eller rapporteres av varslere, eller begge deler. Men hvorfor vente p\xe5 varslere n\xe5r du kan bruke etterforskningsteknikker og avdekke der hvor misligheter og korrupsjon i tidlig stadium utvikler seg n\xe5? Det er bedre \xe5 v\xe6re f\xf8re var og holde seg i forkant!</p>',"what_we_do_collapsed_text_2","<p>Vi vil nok aldri helt utrydde misligheter og korrupsjon, men ved \xe5 \xf8ke bevisstheten og h\xe5ndtere risikoen kan vi kontrollere kostnadene og gj\xf8re korrupte handlinger mindre akseptable. Overraskende nok beg\xe5s mye av misligheter og korrupsjon av helt normale, gode mennesker som regnes som verdifulle og p\xe5litelige ansatte eller forretningspartnere. Bevisstgj\xf8ring, er et kraftig verkt\xf8y for \xe5 hjelpe de gode menneskene til \xe5 unng\xe5 og beg\xe5 feil de senere vil kunne angre p\xe5, og samtidig vise dem hvordan de skal beskytte organisasjonen mot karrierekriminelle. Som Nelson Mandela sa, er utdanning en av de beste m\xe5tene \xe5 forandre verden p\xe5. Vi har utviklet kurs og teknikker for \xe5 minimere dette kompetansegapet samt stadig og kontinuerlig p\xe5 s\xf8kt etter nye innovative m\xe5ter \xe5 \xf8ke bevisstheten, spre kunnskapen og f\xf8re folk sammen i kampen mot korrupsjon og misligheter. Eksempler (detaljer finner du under Fraud Academy-siden v\xe5r) som inkluderer:</p><ul><li>Praktiske kurs og workshops (inkludert v\xe5r \u201ctenk-som-en-tyv-metodikken\u201d og \u201cfraud detective school\u201d)</li><li>Akkrediterte ledelses kurs</li><li>Jobb, in-house og laboratorier treining</li><li>Multimediabasert oppl\xe6ring over internett (eller intranett)</li><li>Ekspertoppl\xe6ring, inkludert drama, scenariooppgaver, live-simuleringer, \u201ckorrupsjonsteater\u201d og filmer</li><li>Publikasjoner og b\xf8ker</li></ul>","what_we_do_collapsed_text_3","<p>Dersom kunden har behov, etterforsker vi ogs\xe5 misligheter og korrupsjon konstruktivt og effektivt.</p><p>Vi tror p\xe5 filosofien med sm\xe5 etterforskinger som \u201cwin value back\u201d. V\xe5r portef\xf8lje viser til kunder som har f\xe5tt l\xf8st sine problemer p\xe5 en effektiv m\xe5te som b\xe5de identifiserer grunnleggende \xe5rsaker og hindrer gjentakelse.</p><p>Spesielle situasjoner forekommer fra tid til annen, hvor en s\xe5kalt dypdykketterforskning kan v\xe6re n\xf8dvendig, for eksempel n\xe5r en organisasjon m\xe5 g\xe5 rettens vei for \xe5 f\xe5 erstattet store verdier eller redde deler av virksomheten. Vi h\xe5ndterer alle etterforskinger p\xe5 en kontrollert m\xe5te, unng\xe5r un\xf8dvendige kostnader og sikrer at kunden alltid er i f\xf8rersetet under prosessen.</p>","what_we_do_collapsed_text_4","<p>Omfang og kompleksitet i regelverk knyttet til samfunnsansvar og straffeansvar p\xe5 brudd p\xe5 dette er \xf8kende. Dette krever ledelsens oppmerksomhet og gir mindre plass til mer praktiske tiltak som er designet for \xe5 beskytte organisasjonen. Det kan v\xe6re fristende for en ledelse \xe5 g\xe5 i den fellen og velge enkle l\xf8sninger som ser ut til \xe5 oppfylle lovkrav, men som ikke l\xf8ser problemet med misligheter og korrupsjon p\xe5 en effektivt m\xe5te. Complianceprogrammer basert p\xe5 sjekklister viser seg ofte ikke \xe5 v\xe6re effektive!</p><p>Vi er i stand til \xe5 m\xe5le resultatet og effekten av dine eksisterende anti-mislighet og korrupsjonsprogrammer, identifisere smutthull og potensielle forbedringer som vil kunne redusere kostnadene av misligheter og korrupsjon og styrke den etiske kulturen.</p><p>V\xe5rt helhetlige rammeverk og vurderingsverkt\xf8y sammenfattet mange \xe5rs praktisk erfaring med den beste kunnskapen fra en omfattende bruk av tilgjengelige rammeverk.</p>","what_we_do_collapsed_title_1","Vi avdekker misligheter tidlig og hjelper deg med l\xe5 finne l\xf8sninger og motvirkende tiltak","what_we_do_collapsed_title_2","Vi \xf8ker bevisstheten, deler kunnskap og overf\xf8rer ferdigheter","what_we_do_collapsed_title_3","Vi etterforsker misligheter og korrupsjon p\xe5 en ansvarlig m\xe5te","what_we_do_collapsed_title_4","Vi vurderer effektiviteten av eksisterende antimislighet- og korrupsjonsprogrammer","what_we_do_list_1_item_1","<strong>Finne</strong> og tolke de mange <strong>r\xf8de flaggene</strong>","what_we_do_list_1_item_2","<strong>Utf\xf8re granskninger</strong> p\xe5 en effektiv, ansvarlig og omsorgsfull m\xe5te","what_we_do_list_1_item_3","<strong>Analysere</strong> \xe5rsakene til forskjellige hendelser for \xe5 identifisere forbedringsmuligheter","what_we_do_list_1_item_4","<strong>Tilby</strong> (gjennom praktiske workshops, oppl\xe6ring og andre innovative teknikker) <strong>ferdighetene</strong> til \xe5 omgj\xf8re det som ser ut til \xe5 v\xe6re \"d\xe5rlige nyheter\" til en mulighet til \xe5 spare penger (se <a href='http://fraudacademy.hibis.com' target='_blank'>Hibis Fraud Academy</a>)","what_we_do_list_1_item_5","<strong>Vurdere</strong> og <strong>m\xe5le effektivitet</strong>, <strong>styrker</strong> og <strong>svakheter</strong> i eksisterende anti-mislighet og korrupsjonsprogrammer","what_we_do_paragraph_1","Misligheter og korrupsjon skjer hele tiden og utgj\xf8r muligens noen av de st\xf8rste ukontrollerte kostnadene for organisasjoner og samfunnet for\xf8vrig. Til tross for dette har flesteparten av ledere og ansatte ikke hatt praktisk oppl\xe6ring innenfor dette omr\xe5det. V\xe5rt m\xe5l er \xe5 betraktelig \xf8ke bevisstheten om misligheter og korrupsjon og de p\xe5f\xf8lgende konsekvensene. Vi bist\xe5r og gir r\xe5d til organisasjoner, bedrifter og alle andre som er interessert i \xe5:","who_we_are","Hvem vi er"])]),"en")}])
I=I.$finishIsolateConstructor(I)
$=new I()
init.metadata=[null,0]
init.types=[{func:1,args:[,]},{func:1},{func:1,v:true},{func:1,v:true,args:[P.b],opt:[P.b6]},{func:1,args:[W.A]},{func:1,v:true,args:[{func:1,v:true}]},{func:1,v:true,args:[W.ae]},{func:1,args:[P.o]},{func:1,ret:P.o,args:[P.j]},{func:1,v:true,args:[P.b7,P.o,P.j]},{func:1,args:[P.an]},{func:1,ret:P.aS,args:[W.A,P.o,P.o,W.cl]},{func:1,args:[,P.o]},{func:1,args:[{func:1,v:true}]},{func:1,args:[,],opt:[,]},{func:1,v:true,args:[,P.b6]},{func:1,args:[,,]},{func:1,v:true,args:[P.o,P.j]},{func:1,v:true,args:[P.o],opt:[,]},{func:1,ret:P.j,args:[P.j,P.j]},{func:1,ret:P.b7,args:[,,]},{func:1,args:[W.aY]},{func:1,ret:W.k,args:[W.k]},{func:1,args:[P.o,P.o]},{func:1,args:[P.aS,P.an]},{func:1,v:true,args:[W.k,W.k]},{func:1,v:true,args:[W.a3]},{func:1,args:[W.c2]},{func:1,v:true,args:[P.dE]},{func:1,v:true,args:[P.b]}]
function convertToFastObject(a){function MyClass(){}MyClass.prototype=a
new MyClass()
return a}function convertToSlowObject(a){a.__MAGIC_SLOW_PROPERTY=1
delete a.__MAGIC_SLOW_PROPERTY
return a}A=convertToFastObject(A)
B=convertToFastObject(B)
C=convertToFastObject(C)
D=convertToFastObject(D)
E=convertToFastObject(E)
F=convertToFastObject(F)
G=convertToFastObject(G)
H=convertToFastObject(H)
J=convertToFastObject(J)
K=convertToFastObject(K)
L=convertToFastObject(L)
M=convertToFastObject(M)
N=convertToFastObject(N)
O=convertToFastObject(O)
P=convertToFastObject(P)
Q=convertToFastObject(Q)
R=convertToFastObject(R)
S=convertToFastObject(S)
T=convertToFastObject(T)
U=convertToFastObject(U)
V=convertToFastObject(V)
W=convertToFastObject(W)
X=convertToFastObject(X)
Y=convertToFastObject(Y)
Z=convertToFastObject(Z)
function init(){I.p=Object.create(null)
init.allClasses=map()
init.getTypeFromName=function(a){return init.allClasses[a]}
init.interceptorsByTag=map()
init.leafTags=map()
init.finishedClasses=map()
I.$lazy=function(a,b,c,d,e){if(!init.lazies)init.lazies=Object.create(null)
init.lazies[a]=b
e=e||I.p
var z={}
var y={}
e[a]=z
e[b]=function(){var x=this[a]
if(x==y)H.l2(d||a)
try{if(x===z){this[a]=y
try{x=this[a]=c()}finally{if(x===z)this[a]=null}}return x}finally{this[b]=function(){return this[a]}}}}
I.$finishIsolateConstructor=function(a){var z=a.p
function Isolate(){var y=Object.keys(z)
for(var x=0;x<y.length;x++){var w=y[x]
this[w]=z[w]}var v=init.lazies
var u=v?Object.keys(v):[]
for(var x=0;x<u.length;x++)this[v[u[x]]]=null
function ForceEfficientMap(){}ForceEfficientMap.prototype=this
new ForceEfficientMap()
for(var x=0;x<u.length;x++){var t=v[u[x]]
this[t]=z[t]}}Isolate.prototype=a.prototype
Isolate.prototype.constructor=Isolate
Isolate.p=z
Isolate.F=a.F
Isolate.L=a.L
return Isolate}}!function(){var z=function(a){var t={}
t[a]=1
return Object.keys(convertToFastObject(t))[0]}
init.getIsolateTag=function(a){return z("___dart_"+a+init.isolateTag)}
var y="___dart_isolate_tags_"
var x=Object[y]||(Object[y]=Object.create(null))
var w="_ZxYxX"
for(var v=0;;v++){var u=z(w+"_"+v+"_")
if(!(u in x)){x[u]=1
init.isolateTag=u
break}}init.dispatchPropertyName=init.getIsolateTag("dispatch_record")}();(function(a){if(typeof document==="undefined"){a(null)
return}if(typeof document.currentScript!='undefined'){a(document.currentScript)
return}var z=document.scripts
function onLoad(b){for(var x=0;x<z.length;++x)z[x].removeEventListener("load",onLoad,false)
a(b.target)}for(var y=0;y<z.length;++y)z[y].addEventListener("load",onLoad,false)})(function(a){init.currentScript=a
if(typeof dartMainRunner==="function")dartMainRunner(function(b){H.eH(F.eC(),b)},[])
else (function(b){H.eH(F.eC(),b)})([])})})()