(function(){var supportsDirectProtoAccess=function(){var z=function(){}
z.prototype={p:{}}
var y=new z()
if(!(y.__proto__&&y.__proto__.p===z.prototype.p))return false
try{if(typeof navigator!="undefined"&&typeof navigator.userAgent=="string"&&navigator.userAgent.indexOf("Chrome/")>=0)return true
if(typeof version=="function"&&version.length==0){var x=version()
if(/^\d+\.\d+\.\d+\.\d+$/.test(x))return true}}catch(w){}return false}()
function map(a){a=Object.create(null)
a.x=0
delete a.x
return a}var A=map()
var B=map()
var C=map()
var D=map()
var E=map()
var F=map()
var G=map()
var H=map()
var J=map()
var K=map()
var L=map()
var M=map()
var N=map()
var O=map()
var P=map()
var Q=map()
var R=map()
var S=map()
var T=map()
var U=map()
var V=map()
var W=map()
var X=map()
var Y=map()
var Z=map()
function I(){}init()
function setupProgram(a,b){"use strict"
function generateAccessor(a9,b0,b1){var g=a9.split("-")
var f=g[0]
var e=f.length
var d=f.charCodeAt(e-1)
var c
if(g.length>1)c=true
else c=false
d=d>=60&&d<=64?d-59:d>=123&&d<=126?d-117:d>=37&&d<=43?d-27:0
if(d){var a0=d&3
var a1=d>>2
var a2=f=f.substring(0,e-1)
var a3=f.indexOf(":")
if(a3>0){a2=f.substring(0,a3)
f=f.substring(a3+1)}if(a0){var a4=a0&2?"r":""
var a5=a0&1?"this":"r"
var a6="return "+a5+"."+f
var a7=b1+".prototype.g"+a2+"="
var a8="function("+a4+"){"+a6+"}"
if(c)b0.push(a7+"$reflectable("+a8+");\n")
else b0.push(a7+a8+";\n")}if(a1){var a4=a1&2?"r,v":"v"
var a5=a1&1?"this":"r"
var a6=a5+"."+f+"=v"
var a7=b1+".prototype.s"+a2+"="
var a8="function("+a4+"){"+a6+"}"
if(c)b0.push(a7+"$reflectable("+a8+");\n")
else b0.push(a7+a8+";\n")}}return f}function defineClass(a2,a3){var g=[]
var f="function "+a2+"("
var e=""
var d=""
for(var c=0;c<a3.length;c++){if(c!=0)f+=", "
var a0=generateAccessor(a3[c],g,a2)
d+="'"+a0+"',"
var a1="p_"+a0
f+=a1
e+="this."+a0+" = "+a1+";\n"}if(supportsDirectProtoAccess)e+="this."+"$deferredAction"+"();"
f+=") {\n"+e+"}\n"
f+=a2+".builtin$cls=\""+a2+"\";\n"
f+="$desc=$collectedClasses."+a2+"[1];\n"
f+=a2+".prototype = $desc;\n"
if(typeof defineClass.name!="string")f+=a2+".name=\""+a2+"\";\n"
f+=a2+"."+"$__fields__"+"=["+d+"];\n"
f+=g.join("")
return f}init.createNewIsolate=function(){return new I()}
init.classIdExtractor=function(c){return c.constructor.name}
init.classFieldsExtractor=function(c){var g=c.constructor.$__fields__
if(!g)return[]
var f=[]
f.length=g.length
for(var e=0;e<g.length;e++)f[e]=c[g[e]]
return f}
init.instanceFromClassId=function(c){return new init.allClasses[c]()}
init.initializeEmptyInstance=function(c,d,e){init.allClasses[c].apply(d,e)
return d}
var z=supportsDirectProtoAccess?function(c,d){var g=c.prototype
g.__proto__=d.prototype
g.constructor=c
g["$is"+c.name]=c
return convertToFastObject(g)}:function(){function tmp(){}return function(a0,a1){tmp.prototype=a1.prototype
var g=new tmp()
convertToSlowObject(g)
var f=a0.prototype
var e=Object.keys(f)
for(var d=0;d<e.length;d++){var c=e[d]
g[c]=f[c]}g["$is"+a0.name]=a0
g.constructor=a0
a0.prototype=g
return g}}()
function finishClasses(a4){var g=init.allClasses
a4.combinedConstructorFunction+="return [\n"+a4.constructorsList.join(",\n  ")+"\n]"
var f=new Function("$collectedClasses",a4.combinedConstructorFunction)(a4.collected)
a4.combinedConstructorFunction=null
for(var e=0;e<f.length;e++){var d=f[e]
var c=d.name
var a0=a4.collected[c]
var a1=a0[0]
a0=a0[1]
g[c]=d
a1[c]=d}f=null
var a2=init.finishedClasses
function finishClass(c1){if(a2[c1])return
a2[c1]=true
var a5=a4.pending[c1]
if(a5&&a5.indexOf("+")>0){var a6=a5.split("+")
a5=a6[0]
var a7=a6[1]
finishClass(a7)
var a8=g[a7]
var a9=a8.prototype
var b0=g[c1].prototype
var b1=Object.keys(a9)
for(var b2=0;b2<b1.length;b2++){var b3=b1[b2]
if(!u.call(b0,b3))b0[b3]=a9[b3]}}if(!a5||typeof a5!="string"){var b4=g[c1]
var b5=b4.prototype
b5.constructor=b4
b5.$isb=b4
b5.$deferredAction=function(){}
return}finishClass(a5)
var b6=g[a5]
if(!b6)b6=existingIsolateProperties[a5]
var b4=g[c1]
var b5=z(b4,b6)
if(a9)b5.$deferredAction=mixinDeferredActionHelper(a9,b5)
if(Object.prototype.hasOwnProperty.call(b5,"%")){var b7=b5["%"].split(";")
if(b7[0]){var b8=b7[0].split("|")
for(var b2=0;b2<b8.length;b2++){init.interceptorsByTag[b8[b2]]=b4
init.leafTags[b8[b2]]=true}}if(b7[1]){b8=b7[1].split("|")
if(b7[2]){var b9=b7[2].split("|")
for(var b2=0;b2<b9.length;b2++){var c0=g[b9[b2]]
c0.$nativeSuperclassTag=b8[0]}}for(b2=0;b2<b8.length;b2++){init.interceptorsByTag[b8[b2]]=b4
init.leafTags[b8[b2]]=false}}b5.$deferredAction()}if(b5.$isi)b5.$deferredAction()}var a3=Object.keys(a4.pending)
for(var e=0;e<a3.length;e++)finishClass(a3[e])}function finishAddStubsHelper(){var g=this
while(!g.hasOwnProperty("$deferredAction"))g=g.__proto__
delete g.$deferredAction
var f=Object.keys(g)
for(var e=0;e<f.length;e++){var d=f[e]
var c=d.charCodeAt(0)
var a0
if(d!=="^"&&d!=="$reflectable"&&c!==43&&c!==42&&(a0=g[d])!=null&&a0.constructor===Array&&d!=="<>")addStubs(g,a0,d,false,[])}convertToFastObject(g)
g=g.__proto__
g.$deferredAction()}function mixinDeferredActionHelper(c,d){var g
if(d.hasOwnProperty("$deferredAction"))g=d.$deferredAction
return function foo(){if(!supportsDirectProtoAccess)return
var f=this
while(!f.hasOwnProperty("$deferredAction"))f=f.__proto__
if(g)f.$deferredAction=g
else{delete f.$deferredAction
convertToFastObject(f)}c.$deferredAction()
f.$deferredAction()}}function processClassData(b1,b2,b3){b2=convertToSlowObject(b2)
var g
var f=Object.keys(b2)
var e=false
var d=supportsDirectProtoAccess&&b1!="b"
for(var c=0;c<f.length;c++){var a0=f[c]
var a1=a0.charCodeAt(0)
if(a0==="m"){processStatics(init.statics[b1]=b2.m,b3)
delete b2.m}else if(a1===43){w[g]=a0.substring(1)
var a2=b2[a0]
if(a2>0)b2[g].$reflectable=a2}else if(a1===42){b2[g].$D=b2[a0]
var a3=b2.$methodsWithOptionalArguments
if(!a3)b2.$methodsWithOptionalArguments=a3={}
a3[a0]=g}else{var a4=b2[a0]
if(a0!=="^"&&a4!=null&&a4.constructor===Array&&a0!=="<>")if(d)e=true
else addStubs(b2,a4,a0,false,[])
else g=a0}}if(e)b2.$deferredAction=finishAddStubsHelper
var a5=b2["^"],a6,a7,a8=a5
var a9=a8.split(";")
a8=a9[1]?a9[1].split(","):[]
a7=a9[0]
a6=a7.split(":")
if(a6.length==2){a7=a6[0]
var b0=a6[1]
if(b0)b2.$S=function(b4){return function(){return init.types[b4]}}(b0)}if(a7)b3.pending[b1]=a7
b3.combinedConstructorFunction+=defineClass(b1,a8)
b3.constructorsList.push(b1)
b3.collected[b1]=[m,b2]
i.push(b1)}function processStatics(a3,a4){var g=Object.keys(a3)
for(var f=0;f<g.length;f++){var e=g[f]
if(e==="^")continue
var d=a3[e]
var c=e.charCodeAt(0)
var a0
if(c===43){v[a0]=e.substring(1)
var a1=a3[e]
if(a1>0)a3[a0].$reflectable=a1
if(d&&d.length)init.typeInformation[a0]=d}else if(c===42){m[a0].$D=d
var a2=a3.$methodsWithOptionalArguments
if(!a2)a3.$methodsWithOptionalArguments=a2={}
a2[e]=a0}else if(typeof d==="function"){m[a0=e]=d
h.push(e)
init.globalFunctions[e]=d}else if(d.constructor===Array)addStubs(m,d,e,true,h)
else{a0=e
processClassData(e,d,a4)}}}function addStubs(b2,b3,b4,b5,b6){var g=0,f=b3[g],e
if(typeof f=="string")e=b3[++g]
else{e=f
f=b4}var d=[b2[b4]=b2[f]=e]
e.$stubName=b4
b6.push(b4)
for(g++;g<b3.length;g++){e=b3[g]
if(typeof e!="function")break
if(!b5)e.$stubName=b3[++g]
d.push(e)
if(e.$stubName){b2[e.$stubName]=e
b6.push(e.$stubName)}}for(var c=0;c<d.length;g++,c++)d[c].$callName=b3[g]
var a0=b3[g]
b3=b3.slice(++g)
var a1=b3[0]
var a2=a1>>1
var a3=(a1&1)===1
var a4=a1===3
var a5=a1===1
var a6=b3[1]
var a7=a6>>1
var a8=(a6&1)===1
var a9=a2+a7!=d[0].length
var b0=b3[2]
if(typeof b0=="number")b3[2]=b0+b
var b1=2*a7+a2+3
if(a0){e=tearOff(d,b3,b5,b4,a9)
b2[b4].$getter=e
e.$getterStub=true
if(b5){init.globalFunctions[b4]=e
b6.push(a0)}b2[a0]=e
d.push(e)
e.$stubName=a0
e.$callName=null}}function tearOffGetter(c,d,e,f){return f?new Function("funcs","reflectionInfo","name","H","c","return function tearOff_"+e+y+++"(x) {"+"if (c === null) c = "+"H.cx"+"("+"this, funcs, reflectionInfo, false, [x], name);"+"return new c(this, funcs[0], x, name);"+"}")(c,d,e,H,null):new Function("funcs","reflectionInfo","name","H","c","return function tearOff_"+e+y+++"() {"+"if (c === null) c = "+"H.cx"+"("+"this, funcs, reflectionInfo, false, [], name);"+"return new c(this, funcs[0], null, name);"+"}")(c,d,e,H,null)}function tearOff(c,d,e,f,a0){var g
return e?function(){if(g===void 0)g=H.cx(this,c,d,true,[],f).prototype
return g}:tearOffGetter(c,d,f,a0)}var y=0
if(!init.libraries)init.libraries=[]
if(!init.mangledNames)init.mangledNames=map()
if(!init.mangledGlobalNames)init.mangledGlobalNames=map()
if(!init.statics)init.statics=map()
if(!init.typeInformation)init.typeInformation=map()
if(!init.globalFunctions)init.globalFunctions=map()
var x=init.libraries
var w=init.mangledNames
var v=init.mangledGlobalNames
var u=Object.prototype.hasOwnProperty
var t=a.length
var s=map()
s.collected=map()
s.pending=map()
s.constructorsList=[]
s.combinedConstructorFunction="function $reflectable(fn){fn.$reflectable=1;return fn};\n"+"var $desc;\n"
for(var r=0;r<t;r++){var q=a[r]
var p=q[0]
var o=q[1]
var n=q[2]
var m=q[3]
var l=q[4]
var k=!!q[5]
var j=l&&l["^"]
if(j instanceof Array)j=j[0]
var i=[]
var h=[]
processStatics(l,s)
x.push([p,o,i,h,n,j,k,m])}finishClasses(s)}I.L=function(){}
var dart=[["","",,H,{"^":"",lZ:{"^":"b;a"}}],["","",,J,{"^":"",
l:function(a){return void 0},
bR:function(a,b,c,d){return{i:a,p:b,e:c,x:d}},
bM:function(a){var z,y,x,w,v
z=a[init.dispatchPropertyName]
if(z==null)if($.cA==null){H.l3()
z=a[init.dispatchPropertyName]}if(z!=null){y=z.p
if(!1===y)return z.i
if(!0===y)return a
x=Object.getPrototypeOf(a)
if(y===x)return z.i
if(z.e===x)throw H.a(new P.bh("Return interceptor for "+H.e(y(a,z))))}w=a.constructor
v=w==null?null:w[$.$get$c0()]
if(v!=null)return v
v=H.lc(a)
if(v!=null)return v
if(typeof a=="function")return C.U
y=Object.getPrototypeOf(a)
if(y==null)return C.A
if(y===Object.prototype)return C.A
if(typeof w=="function"){Object.defineProperty(w,$.$get$c0(),{value:C.q,enumerable:false,writable:true,configurable:true})
return C.q}return C.q},
i:{"^":"b;",
C:function(a,b){return a===b},
gF:function(a){return H.ad(a)},
j:["dn",function(a){return H.bz(a)}],
"%":"Blob|Client|DOMError|DOMImplementation|File|FileError|MediaError|NavigatorUserMediaError|PositionError|PushMessageData|Range|SQLError|SVGAnimatedLength|SVGAnimatedLengthList|SVGAnimatedNumber|SVGAnimatedNumberList|SVGAnimatedString|SVGAnimatedTransformList|WindowClient"},
hd:{"^":"i;",
j:function(a){return String(a)},
gF:function(a){return a?519018:218159},
$isb1:1},
hf:{"^":"i;",
C:function(a,b){return null==b},
j:function(a){return"null"},
gF:function(a){return 0}},
c1:{"^":"i;",
gF:function(a){return 0},
j:["dr",function(a){return String(a)}],
$ishg:1},
hW:{"^":"c1;"},
bi:{"^":"c1;"},
bd:{"^":"c1;",
j:function(a){var z=a[$.$get$cY()]
return z==null?this.dr(a):J.X(z)},
$S:function(){return{func:1,opt:[,,,,,,,,,,,,,,,,]}}},
ba:{"^":"i;$ti",
bF:function(a,b){if(!!a.immutable$list)throw H.a(new P.k(b))},
bE:function(a,b){if(!!a.fixed$length)throw H.a(new P.k(b))},
v:function(a,b){var z
this.bE(a,"remove")
for(z=0;z<a.length;++z)if(J.C(a[z],b)){a.splice(z,1)
return!0}return!1},
L:function(a,b){var z,y
z=a.length
for(y=0;y<z;++y){b.$1(a[y])
if(a.length!==z)throw H.a(new P.R(a))}},
aa:function(a,b){return new H.bf(a,b,[H.F(a,0),null])},
ak:function(a,b){var z,y,x,w
z=a.length
y=new Array(z)
y.fixed$length=Array
for(x=0;x<a.length;++x){w=H.e(a[x])
if(x>=z)return H.f(y,x)
y[x]=w}return y.join(b)},
aH:function(a,b,c){var z,y,x
z=a.length
for(y=0;y<z;++y){x=a[y]
if(b.$1(x)===!0)return x
if(a.length!==z)throw H.a(new P.R(a))}throw H.a(H.S())},
aw:function(a,b){return this.aH(a,b,null)},
B:function(a,b){if(b>>>0!==b||b>=a.length)return H.f(a,b)
return a[b]},
dm:function(a,b,c){if(b<0||b>a.length)throw H.a(P.x(b,0,a.length,"start",null))
if(c==null)c=a.length
else{if(typeof c!=="number"||Math.floor(c)!==c)throw H.a(H.E(c))
if(c<b||c>a.length)throw H.a(P.x(c,b,a.length,"end",null))}if(b===c)return H.v([],[H.F(a,0)])
return H.v(a.slice(b,c),[H.F(a,0)])},
gt:function(a){if(a.length>0)return a[0]
throw H.a(H.S())},
gb6:function(a){var z=a.length
if(z>0)return a[z-1]
throw H.a(H.S())},
D:function(a,b,c,d,e){var z,y,x
this.bF(a,"setRange")
P.a1(b,c,a.length,null,null,null)
z=c-b
if(z===0)return
if(e<0)H.w(P.x(e,0,null,"skipCount",null))
if(e+z>d.length)throw H.a(H.dg())
if(e<b)for(y=z-1;y>=0;--y){x=e+y
if(x>>>0!==x||x>=d.length)return H.f(d,x)
a[b+y]=d[x]}else for(y=0;y<z;++y){x=e+y
if(x>>>0!==x||x>=d.length)return H.f(d,x)
a[b+y]=d[x]}},
T:function(a,b,c,d){return this.D(a,b,c,d,0)},
av:function(a,b,c,d){var z
this.bF(a,"fill range")
P.a1(b,c,a.length,null,null,null)
for(z=b;z<c;++z)a[z]=d},
R:function(a,b,c,d){var z,y,x,w,v,u
this.bE(a,"replaceRange")
P.a1(b,c,a.length,null,null,null)
d=C.a.am(d)
if(typeof c!=="number")return c.ar()
z=c-b
y=d.length
x=b+y
w=a.length
if(z>=y){v=z-y
u=w-v
this.T(a,b,x,d)
if(v!==0){this.D(a,x,u,a,c)
this.sh(a,u)}}else{u=w+(y-z)
this.sh(a,u)
this.D(a,x,u,a,c)
this.T(a,b,x,d)}},
cF:function(a,b){var z,y
z=a.length
for(y=0;y<z;++y){if(b.$1(a[y])===!0)return!0
if(a.length!==z)throw H.a(new P.R(a))}return!1},
b5:function(a,b,c){var z
if(c>=a.length)return-1
if(c<0)c=0
for(z=c;z<a.length;++z)if(J.C(a[z],b))return z
return-1},
H:function(a,b){var z
for(z=0;z<a.length;++z)if(J.C(a[z],b))return!0
return!1},
gu:function(a){return a.length===0},
j:function(a){return P.bu(a,"[","]")},
gw:function(a){return new J.bp(a,a.length,0,null)},
gF:function(a){return H.ad(a)},
gh:function(a){return a.length},
sh:function(a,b){this.bE(a,"set length")
if(typeof b!=="number"||Math.floor(b)!==b)throw H.a(P.aQ(b,"newLength",null))
if(b<0)throw H.a(P.x(b,0,null,"newLength",null))
a.length=b},
i:function(a,b){if(typeof b!=="number"||Math.floor(b)!==b)throw H.a(H.D(a,b))
if(b>=a.length||b<0)throw H.a(H.D(a,b))
return a[b]},
n:function(a,b,c){this.bF(a,"indexed set")
if(typeof b!=="number"||Math.floor(b)!==b)throw H.a(H.D(a,b))
if(b>=a.length||b<0)throw H.a(H.D(a,b))
a[b]=c},
$isG:1,
$asG:I.L,
$ish:1,
$ash:null,
$isd:1,
$asd:null},
lY:{"^":"ba;$ti"},
bp:{"^":"b;a,b,c,d",
gq:function(){return this.d},
l:function(){var z,y,x
z=this.a
y=z.length
if(this.b!==y)throw H.a(H.a7(z))
x=this.c
if(x>=y){this.d=null
return!1}this.d=z[x]
this.c=x+1
return!0}},
bb:{"^":"i;",
d_:function(a){var z
if(a>=-2147483648&&a<=2147483647)return a|0
if(isFinite(a)){z=a<0?Math.ceil(a):Math.floor(a)
return z+0}throw H.a(new P.k(""+a+".toInt()"))},
bP:function(a){if(a>0){if(a!==1/0)return Math.round(a)}else if(a>-1/0)return 0-Math.round(0-a)
throw H.a(new P.k(""+a+".round()"))},
j:function(a){if(a===0&&1/a<0)return"-0.0"
else return""+a},
gF:function(a){return a&0x1FFFFFFF},
P:function(a,b){if(typeof b!=="number")throw H.a(H.E(b))
return a+b},
bb:function(a,b){var z=a%b
if(z===0)return 0
if(z>0)return z
if(b<0)return z-b
else return z+b},
aS:function(a,b){if(typeof b!=="number")throw H.a(H.E(b))
if((a|0)===a)if(b>=1||b<-1)return a/b|0
return this.cv(a,b)},
a7:function(a,b){return(a|0)===a?a/b|0:this.cv(a,b)},
cv:function(a,b){var z=a/b
if(z>=-2147483648&&z<=2147483647)return z|0
if(z>0){if(z!==1/0)return Math.floor(z)}else if(z>-1/0)return Math.ceil(z)
throw H.a(new P.k("Result of truncating division is "+H.e(z)+": "+H.e(a)+" ~/ "+H.e(b)))},
ae:function(a,b){var z
if(a>0)z=b>31?0:a>>>b
else{z=b>31?31:b
z=a>>z>>>0}return z},
ei:function(a,b){if(b<0)throw H.a(H.E(b))
return b>31?0:a>>>b},
I:function(a,b){if(typeof b!=="number")throw H.a(H.E(b))
return a<b},
ao:function(a,b){if(typeof b!=="number")throw H.a(H.E(b))
return a>b},
$isbm:1},
dh:{"^":"bb;",$isbm:1,$isj:1},
he:{"^":"bb;",$isbm:1},
bc:{"^":"i;",
G:function(a,b){if(typeof b!=="number"||Math.floor(b)!==b)throw H.a(H.D(a,b))
if(b<0)throw H.a(H.D(a,b))
if(b>=a.length)H.w(H.D(a,b))
return a.charCodeAt(b)},
E:function(a,b){if(b>=a.length)throw H.a(H.D(a,b))
return a.charCodeAt(b)},
P:function(a,b){if(typeof b!=="string")throw H.a(P.aQ(b,null,null))
return a+b},
R:function(a,b,c,d){var z,y
H.cw(b)
c=P.a1(b,c,a.length,null,null,null)
H.cw(c)
z=a.substring(0,b)
y=a.substring(c)
return z+d+y},
X:function(a,b,c){var z
H.cw(c)
if(typeof c!=="number")return c.I()
if(c<0||c>a.length)throw H.a(P.x(c,0,a.length,null,null))
z=c+b.length
if(z>a.length)return!1
return b===a.substring(c,z)},
O:function(a,b){return this.X(a,b,0)},
k:function(a,b,c){if(typeof b!=="number"||Math.floor(b)!==b)H.w(H.E(b))
if(c==null)c=a.length
if(typeof c!=="number"||Math.floor(c)!==c)H.w(H.E(c))
if(typeof b!=="number")return b.I()
if(b<0)throw H.a(P.bC(b,null,null))
if(typeof c!=="number")return H.p(c)
if(b>c)throw H.a(P.bC(b,null,null))
if(c>a.length)throw H.a(P.bC(c,null,null))
return a.substring(b,c)},
ay:function(a,b){return this.k(a,b,null)},
fe:function(a){return a.toLowerCase()},
ff:function(a){return a.toUpperCase()},
fg:function(a){var z,y,x,w,v
z=a.trim()
y=z.length
if(y===0)return z
if(this.E(z,0)===133){x=J.hh(z,1)
if(x===y)return""}else x=0
w=y-1
v=this.G(z,w)===133?J.hi(z,w):y
if(x===0&&v===y)return z
return z.substring(x,v)},
d7:function(a,b){var z,y
if(0>=b)return""
if(b===1||a.length===0)return a
if(b!==b>>>0)throw H.a(C.F)
for(z=a,y="";!0;){if((b&1)===1)y=z+y
b=b>>>1
if(b===0)break
z+=z}return y},
b5:function(a,b,c){var z
if(c<0||c>a.length)throw H.a(P.x(c,0,a.length,null,null))
z=a.indexOf(b,c)
return z},
aJ:function(a,b){return this.b5(a,b,0)},
eA:function(a,b,c){if(c>a.length)throw H.a(P.x(c,0,a.length,null,null))
return H.lk(a,b,c)},
gu:function(a){return a.length===0},
j:function(a){return a},
gF:function(a){var z,y,x
for(z=a.length,y=0,x=0;x<z;++x){y=536870911&y+a.charCodeAt(x)
y=536870911&y+((524287&y)<<10)
y^=y>>6}y=536870911&y+((67108863&y)<<3)
y^=y>>11
return 536870911&y+((16383&y)<<15)},
gh:function(a){return a.length},
i:function(a,b){if(typeof b!=="number"||Math.floor(b)!==b)throw H.a(H.D(a,b))
if(b>=a.length||b<0)throw H.a(H.D(a,b))
return a[b]},
$isG:1,
$asG:I.L,
$isn:1,
m:{
di:function(a){if(a<256)switch(a){case 9:case 10:case 11:case 12:case 13:case 32:case 133:case 160:return!0
default:return!1}switch(a){case 5760:case 8192:case 8193:case 8194:case 8195:case 8196:case 8197:case 8198:case 8199:case 8200:case 8201:case 8202:case 8232:case 8233:case 8239:case 8287:case 12288:case 65279:return!0
default:return!1}},
hh:function(a,b){var z,y
for(z=a.length;b<z;){y=C.a.E(a,b)
if(y!==32&&y!==13&&!J.di(y))break;++b}return b},
hi:function(a,b){var z,y
for(;b>0;b=z){z=b-1
y=C.a.G(a,z)
if(y!==32&&y!==13&&!J.di(y))break}return b}}}}],["","",,H,{"^":"",
bO:function(a){var z,y
z=a^48
if(z<=9)return z
y=a|32
if(97<=y&&y<=102)return y-87
return-1},
ek:function(a){if(typeof a!=="number"||Math.floor(a)!==a)throw H.a(P.aQ(a,"count","is not an integer"))
if(a<0)H.w(P.x(a,0,null,"count",null))
return a},
S:function(){return new P.t("No element")},
hc:function(){return new P.t("Too many elements")},
dg:function(){return new P.t("Too few elements")},
d:{"^":"H;$ti",$asd:null},
ak:{"^":"d;$ti",
gw:function(a){return new H.c4(this,this.gh(this),0,null)},
L:function(a,b){var z,y
z=this.gh(this)
for(y=0;y<z;++y){b.$1(this.B(0,y))
if(z!==this.gh(this))throw H.a(new P.R(this))}},
gu:function(a){return this.gh(this)===0},
gt:function(a){if(this.gh(this)===0)throw H.a(H.S())
return this.B(0,0)},
aH:function(a,b,c){var z,y,x
z=this.gh(this)
for(y=0;y<z;++y){x=this.B(0,y)
if(b.$1(x)===!0)return x
if(z!==this.gh(this))throw H.a(new P.R(this))}throw H.a(H.S())},
aw:function(a,b){return this.aH(a,b,null)},
bU:function(a,b){return this.dq(0,b)},
aa:function(a,b){return new H.bf(this,b,[H.B(this,"ak",0),null])},
ab:function(a,b){var z,y,x
z=H.v([],[H.B(this,"ak",0)])
C.b.sh(z,this.gh(this))
for(y=0;y<this.gh(this);++y){x=this.B(0,y)
if(y>=z.length)return H.f(z,y)
z[y]=x}return z},
am:function(a){return this.ab(a,!0)}},
iu:{"^":"ak;a,b,c,$ti",
gdV:function(){var z,y
z=J.Q(this.a)
y=this.c
if(y==null||y>z)return z
return y},
gej:function(){var z,y
z=J.Q(this.a)
y=this.b
if(y>z)return z
return y},
gh:function(a){var z,y,x
z=J.Q(this.a)
y=this.b
if(y>=z)return 0
x=this.c
if(x==null||x>=z)return z-y
if(typeof x!=="number")return x.ar()
return x-y},
B:function(a,b){var z,y
z=this.gej()
if(typeof b!=="number")return H.p(b)
y=z+b
if(!(b<0)){z=this.gdV()
if(typeof z!=="number")return H.p(z)
z=y>=z}else z=!0
if(z)throw H.a(P.Y(b,this,"index",null,null))
return J.b4(this.a,y)},
ab:function(a,b){var z,y,x,w,v,u,t,s,r
z=this.b
y=this.a
x=J.y(y)
w=x.gh(y)
v=this.c
if(v!=null&&v<w)w=v
if(typeof w!=="number")return w.ar()
u=w-z
if(u<0)u=0
t=H.v(new Array(u),this.$ti)
for(s=0;s<u;++s){r=x.B(y,z+s)
if(s>=t.length)return H.f(t,s)
t[s]=r
if(x.gh(y)<w)throw H.a(new P.R(this))}return t},
dD:function(a,b,c,d){var z,y
z=this.b
if(z<0)H.w(P.x(z,0,null,"start",null))
y=this.c
if(y!=null){if(y<0)H.w(P.x(y,0,null,"end",null))
if(z>y)throw H.a(P.x(z,0,y,"start",null))}},
m:{
iv:function(a,b,c,d){var z=new H.iu(a,b,c,[d])
z.dD(a,b,c,d)
return z}}},
c4:{"^":"b;a,b,c,d",
gq:function(){return this.d},
l:function(){var z,y,x,w
z=this.a
y=J.y(z)
x=y.gh(z)
if(this.b!==x)throw H.a(new P.R(z))
w=this.c
if(w>=x){this.d=null
return!1}this.d=y.B(z,w);++this.c
return!0}},
bw:{"^":"H;a,b,$ti",
gw:function(a){return new H.hz(null,J.ah(this.a),this.b,this.$ti)},
gh:function(a){return J.Q(this.a)},
gu:function(a){return J.as(this.a)},
gt:function(a){return this.b.$1(J.bo(this.a))},
B:function(a,b){return this.b.$1(J.b4(this.a,b))},
$asH:function(a,b){return[b]},
m:{
be:function(a,b,c,d){if(!!J.l(a).$isd)return new H.bZ(a,b,[c,d])
return new H.bw(a,b,[c,d])}}},
bZ:{"^":"bw;a,b,$ti",$isd:1,
$asd:function(a,b){return[b]}},
hz:{"^":"bv;a,b,c,$ti",
l:function(){var z=this.b
if(z.l()){this.a=this.c.$1(z.gq())
return!0}this.a=null
return!1},
gq:function(){return this.a}},
bf:{"^":"ak;a,b,$ti",
gh:function(a){return J.Q(this.a)},
B:function(a,b){return this.b.$1(J.b4(this.a,b))},
$asak:function(a,b){return[b]},
$asd:function(a,b){return[b]},
$asH:function(a,b){return[b]}},
cg:{"^":"H;a,b,$ti",
gw:function(a){return new H.iN(J.ah(this.a),this.b,this.$ti)},
aa:function(a,b){return new H.bw(this,b,[H.F(this,0),null])}},
iN:{"^":"bv;a,b,$ti",
l:function(){var z,y
for(z=this.a,y=this.b;z.l();)if(y.$1(z.gq())===!0)return!0
return!1},
gq:function(){return this.a.gq()}},
dI:{"^":"H;a,b,$ti",
gw:function(a){return new H.iy(J.ah(this.a),this.b,this.$ti)},
m:{
ix:function(a,b,c){if(typeof b!=="number"||Math.floor(b)!==b||b<0)throw H.a(P.aP(b))
if(!!J.l(a).$isd)return new H.fl(a,b,[c])
return new H.dI(a,b,[c])}}},
fl:{"^":"dI;a,b,$ti",
gh:function(a){var z,y
z=J.Q(this.a)
y=this.b
if(z>y)return y
return z},
$isd:1,
$asd:null},
iy:{"^":"bv;a,b,$ti",
l:function(){if(--this.b>=0)return this.a.l()
this.b=-1
return!1},
gq:function(){if(this.b<0)return
return this.a.gq()}},
dE:{"^":"H;a,b,$ti",
gw:function(a){return new H.ib(J.ah(this.a),this.b,this.$ti)},
m:{
ia:function(a,b,c){if(!!J.l(a).$isd)return new H.fk(a,H.ek(b),[c])
return new H.dE(a,H.ek(b),[c])}}},
fk:{"^":"dE;a,b,$ti",
gh:function(a){var z=J.Q(this.a)-this.b
if(z>=0)return z
return 0},
$isd:1,
$asd:null},
ib:{"^":"bv;a,b,$ti",
l:function(){var z,y
for(z=this.a,y=0;y<this.b;++y)z.l()
this.b=0
return z.l()},
gq:function(){return this.a.gq()}},
d9:{"^":"b;$ti",
sh:function(a,b){throw H.a(new P.k("Cannot change the length of a fixed-length list"))},
v:function(a,b){throw H.a(new P.k("Cannot remove from a fixed-length list"))},
R:function(a,b,c,d){throw H.a(new P.k("Cannot remove from a fixed-length list"))}}}],["","",,H,{"^":"",
bk:function(a,b){var z=a.aG(b)
if(!init.globalState.d.cy)init.globalState.f.aO()
return z},
eH:function(a,b){var z,y,x,w,v,u
z={}
z.a=b
if(b==null){b=[]
z.a=b
y=b}else y=b
if(!J.l(y).$ish)throw H.a(P.aP("Arguments to main must be a List: "+H.e(y)))
init.globalState=new H.jM(0,0,1,null,null,null,null,null,null,null,null,null,a)
y=init.globalState
x=self.window==null
w=self.Worker
v=x&&!!self.postMessage
y.x=v
v=!v
if(v)w=w!=null&&$.$get$de()!=null
else w=!0
y.y=w
y.r=x&&v
y.f=new H.jj(P.c5(null,H.bj),0)
x=P.j
y.z=new H.ab(0,null,null,null,null,null,0,[x,H.cp])
y.ch=new H.ab(0,null,null,null,null,null,0,[x,null])
if(y.x===!0){w=new H.jL()
y.Q=w
self.onmessage=function(c,d){return function(e){c(d,e)}}(H.h5,w)
self.dartPrint=self.dartPrint||function(c){return function(d){if(self.console&&self.console.log)self.console.log(d)
else self.postMessage(c(d))}}(H.jN)}if(init.globalState.x===!0)return
y=init.globalState.a++
w=P.Z(null,null,null,x)
v=new H.bD(0,null,!1)
u=new H.cp(y,new H.ab(0,null,null,null,null,null,0,[x,H.bD]),w,init.createNewIsolate(),v,new H.at(H.bS()),new H.at(H.bS()),!1,!1,[],P.Z(null,null,null,null),null,null,!1,!0,P.Z(null,null,null,null))
w.A(0,0)
u.c4(0,v)
init.globalState.e=u
init.globalState.d=u
if(H.aJ(a,{func:1,args:[,]}))u.aG(new H.li(z,a))
else if(H.aJ(a,{func:1,args:[,,]}))u.aG(new H.lj(z,a))
else u.aG(a)
init.globalState.f.aO()},
h9:function(){var z=init.currentScript
if(z!=null)return String(z.src)
if(init.globalState.x===!0)return H.ha()
return},
ha:function(){var z,y
z=new Error().stack
if(z==null){z=function(){try{throw new Error()}catch(x){return x.stack}}()
if(z==null)throw H.a(new P.k("No stack trace"))}y=z.match(new RegExp("^ *at [^(]*\\((.*):[0-9]*:[0-9]*\\)$","m"))
if(y!=null)return y[1]
y=z.match(new RegExp("^[^@]*@(.*):[0-9]*$","m"))
if(y!=null)return y[1]
throw H.a(new P.k('Cannot extract URI from "'+z+'"'))},
h5:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n
z=new H.bF(!0,[]).ag(b.data)
y=J.y(z)
switch(y.i(z,"command")){case"start":init.globalState.b=y.i(z,"id")
x=y.i(z,"functionName")
w=x==null?init.globalState.cx:init.globalFunctions[x]()
v=y.i(z,"args")
u=new H.bF(!0,[]).ag(y.i(z,"msg"))
t=y.i(z,"isSpawnUri")
s=y.i(z,"startPaused")
r=new H.bF(!0,[]).ag(y.i(z,"replyTo"))
y=init.globalState.a++
q=P.j
p=P.Z(null,null,null,q)
o=new H.bD(0,null,!1)
n=new H.cp(y,new H.ab(0,null,null,null,null,null,0,[q,H.bD]),p,init.createNewIsolate(),o,new H.at(H.bS()),new H.at(H.bS()),!1,!1,[],P.Z(null,null,null,null),null,null,!1,!0,P.Z(null,null,null,null))
p.A(0,0)
n.c4(0,o)
init.globalState.f.a.a5(new H.bj(n,new H.h6(w,v,u,t,s,r),"worker-start"))
init.globalState.d=n
init.globalState.f.aO()
break
case"spawn-worker":break
case"message":if(y.i(z,"port")!=null)J.aO(y.i(z,"port"),y.i(z,"msg"))
init.globalState.f.aO()
break
case"close":init.globalState.ch.v(0,$.$get$df().i(0,a))
a.terminate()
init.globalState.f.aO()
break
case"log":H.h4(y.i(z,"msg"))
break
case"print":if(init.globalState.x===!0){y=init.globalState.Q
q=P.a5(["command","print","msg",z])
q=new H.aC(!0,P.aX(null,P.j)).W(q)
y.toString
self.postMessage(q)}else P.bn(y.i(z,"msg"))
break
case"error":throw H.a(y.i(z,"msg"))}},
h4:function(a){var z,y,x,w
if(init.globalState.x===!0){y=init.globalState.Q
x=P.a5(["command","log","msg",a])
x=new H.aC(!0,P.aX(null,P.j)).W(x)
y.toString
self.postMessage(x)}else try{self.console.log(a)}catch(w){H.z(w)
z=H.M(w)
y=P.bt(z)
throw H.a(y)}},
h7:function(a,b,c,d,e,f){var z,y,x,w
z=init.globalState.d
y=z.a
$.dy=$.dy+("_"+y)
$.dz=$.dz+("_"+y)
y=z.e
x=init.globalState.d.a
w=z.f
J.aO(f,["spawned",new H.bJ(y,x),w,z.r])
x=new H.h8(a,b,c,d,z)
if(e===!0){z.cE(w,w)
init.globalState.f.a.a5(new H.bj(z,x,"start isolate"))}else x.$0()},
ku:function(a){return new H.bF(!0,[]).ag(new H.aC(!1,P.aX(null,P.j)).W(a))},
li:{"^":"c:1;a,b",
$0:function(){this.b.$1(this.a.a)}},
lj:{"^":"c:1;a,b",
$0:function(){this.b.$2(this.a.a,null)}},
jM:{"^":"b;a,b,c,d,e,f,r,x,y,z,Q,ch,cx",m:{
jN:function(a){var z=P.a5(["command","print","msg",a])
return new H.aC(!0,P.aX(null,P.j)).W(z)}}},
cp:{"^":"b;a,b,c,eX:d<,eB:e<,f,r,x,y,z,Q,ch,cx,cy,db,dx",
cE:function(a,b){if(!this.f.C(0,a))return
if(this.Q.A(0,b)&&!this.y)this.y=!0
this.bB()},
f7:function(a){var z,y,x,w,v,u
if(!this.y)return
z=this.Q
z.v(0,a)
if(z.a===0){for(z=this.z;y=z.length,y!==0;){if(0>=y)return H.f(z,-1)
x=z.pop()
y=init.globalState.f.a
w=y.b
v=y.a
u=v.length
w=(w-1&u-1)>>>0
y.b=w
if(w<0||w>=u)return H.f(v,w)
v[w]=x
if(w===y.c)y.cf();++y.d}this.y=!1}this.bB()},
ep:function(a,b){var z,y,x
if(this.ch==null)this.ch=[]
for(z=J.l(a),y=0;x=this.ch,y<x.length;y+=2)if(z.C(a,x[y])){z=this.ch
x=y+1
if(x>=z.length)return H.f(z,x)
z[x]=b
return}x.push(a)
this.ch.push(b)},
f6:function(a){var z,y,x
if(this.ch==null)return
for(z=J.l(a),y=0;x=this.ch,y<x.length;y+=2)if(z.C(a,x[y])){z=this.ch
x=y+2
z.toString
if(typeof z!=="object"||z===null||!!z.fixed$length)H.w(new P.k("removeRange"))
P.a1(y,x,z.length,null,null,null)
z.splice(y,x-y)
return}},
di:function(a,b){if(!this.r.C(0,a))return
this.db=b},
eP:function(a,b,c){var z=J.l(b)
if(!z.C(b,0))z=z.C(b,1)&&!this.cy
else z=!0
if(z){J.aO(a,c)
return}z=this.cx
if(z==null){z=P.c5(null,null)
this.cx=z}z.a5(new H.jC(a,c))},
eO:function(a,b){var z
if(!this.r.C(0,a))return
z=J.l(b)
if(!z.C(b,0))z=z.C(b,1)&&!this.cy
else z=!0
if(z){this.bG()
return}z=this.cx
if(z==null){z=P.c5(null,null)
this.cx=z}z.a5(this.geY())},
eQ:function(a,b){var z,y,x
z=this.dx
if(z.a===0){if(this.db===!0&&this===init.globalState.e)return
if(self.console&&self.console.error)self.console.error(a,b)
else{P.bn(a)
if(b!=null)P.bn(b)}return}y=new Array(2)
y.fixed$length=Array
y[0]=J.X(a)
y[1]=b==null?null:J.X(b)
for(x=new P.aW(z,z.r,null,null),x.c=z.e;x.l();)J.aO(x.d,y)},
aG:function(a){var z,y,x,w,v,u,t
z=init.globalState.d
init.globalState.d=this
$=this.d
y=null
x=this.cy
this.cy=!0
try{y=a.$0()}catch(u){w=H.z(u)
v=H.M(u)
this.eQ(w,v)
if(this.db===!0){this.bG()
if(this===init.globalState.e)throw u}}finally{this.cy=x
init.globalState.d=z
if(z!=null)$=z.geX()
if(this.cx!=null)for(;t=this.cx,!t.gu(t);)this.cx.cV().$0()}return y},
bI:function(a){return this.b.i(0,a)},
c4:function(a,b){var z=this.b
if(z.J(a))throw H.a(P.bt("Registry: ports must be registered only once."))
z.n(0,a,b)},
bB:function(){var z=this.b
if(z.gh(z)-this.c.a>0||this.y||!this.x)init.globalState.z.n(0,this.a,this)
else this.bG()},
bG:[function(){var z,y,x,w,v
z=this.cx
if(z!=null)z.U(0)
for(z=this.b,y=z.ga2(z),y=y.gw(y);y.l();)y.gq().dR()
z.U(0)
this.c.U(0)
init.globalState.z.v(0,this.a)
this.dx.U(0)
if(this.ch!=null){for(x=0;z=this.ch,y=z.length,x<y;x+=2){w=z[x]
v=x+1
if(v>=y)return H.f(z,v)
J.aO(w,z[v])}this.ch=null}},"$0","geY",0,0,2]},
jC:{"^":"c:2;a,b",
$0:function(){J.aO(this.a,this.b)}},
jj:{"^":"b;a,b",
eH:function(){var z=this.a
if(z.b===z.c)return
return z.cV()},
cY:function(){var z,y,x
z=this.eH()
if(z==null){if(init.globalState.e!=null)if(init.globalState.z.J(init.globalState.e.a))if(init.globalState.r===!0){y=init.globalState.e.b
y=y.gu(y)}else y=!1
else y=!1
else y=!1
if(y)H.w(P.bt("Program exited with open ReceivePorts."))
y=init.globalState
if(y.x===!0){x=y.z
x=x.gu(x)&&y.f.b===0}else x=!1
if(x){y=y.Q
x=P.a5(["command","close"])
x=new H.aC(!0,new P.e9(0,null,null,null,null,null,0,[null,P.j])).W(x)
y.toString
self.postMessage(x)}return!1}z.f5()
return!0},
cr:function(){if(self.window!=null)new H.jk(this).$0()
else for(;this.cY(););},
aO:function(){var z,y,x,w,v
if(init.globalState.x!==!0)this.cr()
else try{this.cr()}catch(x){z=H.z(x)
y=H.M(x)
w=init.globalState.Q
v=P.a5(["command","error","msg",H.e(z)+"\n"+H.e(y)])
v=new H.aC(!0,P.aX(null,P.j)).W(v)
w.toString
self.postMessage(v)}}},
jk:{"^":"c:2;a",
$0:function(){if(!this.a.cY())return
P.az(C.t,this)}},
bj:{"^":"b;a,b,c",
f5:function(){var z=this.a
if(z.y){z.z.push(this)
return}z.aG(this.b)}},
jL:{"^":"b;"},
h6:{"^":"c:1;a,b,c,d,e,f",
$0:function(){H.h7(this.a,this.b,this.c,this.d,this.e,this.f)}},
h8:{"^":"c:2;a,b,c,d,e",
$0:function(){var z,y
z=this.e
z.x=!0
if(this.d!==!0)this.a.$1(this.c)
else{y=this.a
if(H.aJ(y,{func:1,args:[,,]}))y.$2(this.b,this.c)
else if(H.aJ(y,{func:1,args:[,]}))y.$1(this.b)
else y.$0()}z.bB()}},
e0:{"^":"b;"},
bJ:{"^":"e0;b,a",
aR:function(a,b){var z,y,x
z=init.globalState.z.i(0,this.a)
if(z==null)return
y=this.b
if(y.gck())return
x=H.ku(b)
if(z.geB()===y){y=J.y(x)
switch(y.i(x,0)){case"pause":z.cE(y.i(x,1),y.i(x,2))
break
case"resume":z.f7(y.i(x,1))
break
case"add-ondone":z.ep(y.i(x,1),y.i(x,2))
break
case"remove-ondone":z.f6(y.i(x,1))
break
case"set-errors-fatal":z.di(y.i(x,1),y.i(x,2))
break
case"ping":z.eP(y.i(x,1),y.i(x,2),y.i(x,3))
break
case"kill":z.eO(y.i(x,1),y.i(x,2))
break
case"getErrors":y=y.i(x,1)
z.dx.A(0,y)
break
case"stopErrors":y=y.i(x,1)
z.dx.v(0,y)
break}return}init.globalState.f.a.a5(new H.bj(z,new H.jP(this,x),"receive"))},
C:function(a,b){if(b==null)return!1
return b instanceof H.bJ&&J.C(this.b,b.b)},
gF:function(a){return this.b.gbr()}},
jP:{"^":"c:1;a,b",
$0:function(){var z=this.a.b
if(!z.gck())z.dL(this.b)}},
cr:{"^":"e0;b,c,a",
aR:function(a,b){var z,y,x
z=P.a5(["command","message","port",this,"msg",b])
y=new H.aC(!0,P.aX(null,P.j)).W(z)
if(init.globalState.x===!0){init.globalState.Q.toString
self.postMessage(y)}else{x=init.globalState.ch.i(0,this.b)
if(x!=null)x.postMessage(y)}},
C:function(a,b){if(b==null)return!1
return b instanceof H.cr&&J.C(this.b,b.b)&&J.C(this.a,b.a)&&J.C(this.c,b.c)},
gF:function(a){var z,y,x
z=this.b
if(typeof z!=="number")return z.be()
y=this.a
if(typeof y!=="number")return y.be()
x=this.c
if(typeof x!=="number")return H.p(x)
return(z<<16^y<<8^x)>>>0}},
bD:{"^":"b;br:a<,b,ck:c<",
dR:function(){this.c=!0
this.b=null},
dL:function(a){if(this.c)return
this.b.$1(a)},
$isi3:1},
iA:{"^":"b;a,b,c",
a0:function(){if(self.setTimeout!=null){if(this.b)throw H.a(new P.k("Timer in event loop cannot be canceled."))
var z=this.c
if(z==null)return;--init.globalState.f.b
self.clearTimeout(z)
this.c=null}else throw H.a(new P.k("Canceling a timer."))},
dE:function(a,b){var z,y
if(a===0)z=self.setTimeout==null||init.globalState.x===!0
else z=!1
if(z){this.c=1
z=init.globalState.f
y=init.globalState.d
z.a.a5(new H.bj(y,new H.iC(this,b),"timer"))
this.b=!0}else if(self.setTimeout!=null){++init.globalState.f.b
this.c=self.setTimeout(H.b2(new H.iD(this,b),0),a)}else throw H.a(new P.k("Timer greater than 0."))},
m:{
iB:function(a,b){var z=new H.iA(!0,!1,null)
z.dE(a,b)
return z}}},
iC:{"^":"c:2;a,b",
$0:function(){this.a.c=null
this.b.$0()}},
iD:{"^":"c:2;a,b",
$0:function(){this.a.c=null;--init.globalState.f.b
this.b.$0()}},
at:{"^":"b;br:a<",
gF:function(a){var z=this.a
if(typeof z!=="number")return z.dj()
z=C.e.ae(z,0)^C.e.a7(z,4294967296)
z=(~z>>>0)+(z<<15>>>0)&4294967295
z=((z^z>>>12)>>>0)*5&4294967295
z=((z^z>>>4)>>>0)*2057&4294967295
return(z^z>>>16)>>>0},
C:function(a,b){var z,y
if(b==null)return!1
if(b===this)return!0
if(b instanceof H.at){z=this.a
y=b.a
return z==null?y==null:z===y}return!1}},
aC:{"^":"b;a,b",
W:[function(a){var z,y,x,w,v
if(a==null||typeof a==="string"||typeof a==="number"||typeof a==="boolean")return a
z=this.b
y=z.i(0,a)
if(y!=null)return["ref",y]
z.n(0,a,z.gh(z))
z=J.l(a)
if(!!z.$isdm)return["buffer",a]
if(!!z.$isc7)return["typed",a]
if(!!z.$isG)return this.de(a)
if(!!z.$ish3){x=this.gda()
w=a.gK()
w=H.be(w,x,H.B(w,"H",0),null)
w=P.ax(w,!0,H.B(w,"H",0))
z=z.ga2(a)
z=H.be(z,x,H.B(z,"H",0),null)
return["map",w,P.ax(z,!0,H.B(z,"H",0))]}if(!!z.$ishg)return this.df(a)
if(!!z.$isi)this.d0(a)
if(!!z.$isi3)this.aP(a,"RawReceivePorts can't be transmitted:")
if(!!z.$isbJ)return this.dg(a)
if(!!z.$iscr)return this.dh(a)
if(!!z.$isc){v=a.$static_name
if(v==null)this.aP(a,"Closures can't be transmitted:")
return["function",v]}if(!!z.$isat)return["capability",a.a]
if(!(a instanceof P.b))this.d0(a)
return["dart",init.classIdExtractor(a),this.dd(init.classFieldsExtractor(a))]},"$1","gda",2,0,0],
aP:function(a,b){throw H.a(new P.k((b==null?"Can't transmit:":b)+" "+H.e(a)))},
d0:function(a){return this.aP(a,null)},
de:function(a){var z=this.dc(a)
if(!!a.fixed$length)return["fixed",z]
if(!a.fixed$length)return["extendable",z]
if(!a.immutable$list)return["mutable",z]
if(a.constructor===Array)return["const",z]
this.aP(a,"Can't serialize indexable: ")},
dc:function(a){var z,y,x
z=[]
C.b.sh(z,a.length)
for(y=0;y<a.length;++y){x=this.W(a[y])
if(y>=z.length)return H.f(z,y)
z[y]=x}return z},
dd:function(a){var z
for(z=0;z<a.length;++z)C.b.n(a,z,this.W(a[z]))
return a},
df:function(a){var z,y,x,w
if(!!a.constructor&&a.constructor!==Object)this.aP(a,"Only plain JS Objects are supported:")
z=Object.keys(a)
y=[]
C.b.sh(y,z.length)
for(x=0;x<z.length;++x){w=this.W(a[z[x]])
if(x>=y.length)return H.f(y,x)
y[x]=w}return["js-object",z,y]},
dh:function(a){if(this.a)return["sendport",a.b,a.a,a.c]
return["raw sendport",a]},
dg:function(a){if(this.a)return["sendport",init.globalState.b,a.a,a.b.gbr()]
return["raw sendport",a]}},
bF:{"^":"b;a,b",
ag:[function(a){var z,y,x,w,v,u
if(a==null||typeof a==="string"||typeof a==="number"||typeof a==="boolean")return a
if(typeof a!=="object"||a===null||a.constructor!==Array)throw H.a(P.aP("Bad serialized message: "+H.e(a)))
switch(C.b.gt(a)){case"ref":if(1>=a.length)return H.f(a,1)
z=a[1]
y=this.b
if(z>>>0!==z||z>=y.length)return H.f(y,z)
return y[z]
case"buffer":if(1>=a.length)return H.f(a,1)
x=a[1]
this.b.push(x)
return x
case"typed":if(1>=a.length)return H.f(a,1)
x=a[1]
this.b.push(x)
return x
case"fixed":if(1>=a.length)return H.f(a,1)
x=a[1]
this.b.push(x)
y=H.v(this.aF(x),[null])
y.fixed$length=Array
return y
case"extendable":if(1>=a.length)return H.f(a,1)
x=a[1]
this.b.push(x)
return H.v(this.aF(x),[null])
case"mutable":if(1>=a.length)return H.f(a,1)
x=a[1]
this.b.push(x)
return this.aF(x)
case"const":if(1>=a.length)return H.f(a,1)
x=a[1]
this.b.push(x)
y=H.v(this.aF(x),[null])
y.fixed$length=Array
return y
case"map":return this.eK(a)
case"sendport":return this.eL(a)
case"raw sendport":if(1>=a.length)return H.f(a,1)
x=a[1]
this.b.push(x)
return x
case"js-object":return this.eJ(a)
case"function":if(1>=a.length)return H.f(a,1)
x=init.globalFunctions[a[1]]()
this.b.push(x)
return x
case"capability":if(1>=a.length)return H.f(a,1)
return new H.at(a[1])
case"dart":y=a.length
if(1>=y)return H.f(a,1)
w=a[1]
if(2>=y)return H.f(a,2)
v=a[2]
u=init.instanceFromClassId(w)
this.b.push(u)
this.aF(v)
return init.initializeEmptyInstance(w,u,v)
default:throw H.a("couldn't deserialize: "+H.e(a))}},"$1","geI",2,0,0],
aF:function(a){var z,y,x
z=J.y(a)
y=0
while(!0){x=z.gh(a)
if(typeof x!=="number")return H.p(x)
if(!(y<x))break
z.n(a,y,this.ag(z.i(a,y)));++y}return a},
eK:function(a){var z,y,x,w,v,u
z=a.length
if(1>=z)return H.f(a,1)
y=a[1]
if(2>=z)return H.f(a,2)
x=a[2]
w=P.dj()
this.b.push(w)
y=J.eV(y,this.geI()).am(0)
for(z=J.y(y),v=J.y(x),u=0;u<z.gh(y);++u){if(u>=y.length)return H.f(y,u)
w.n(0,y[u],this.ag(v.i(x,u)))}return w},
eL:function(a){var z,y,x,w,v,u,t
z=a.length
if(1>=z)return H.f(a,1)
y=a[1]
if(2>=z)return H.f(a,2)
x=a[2]
if(3>=z)return H.f(a,3)
w=a[3]
if(J.C(y,init.globalState.b)){v=init.globalState.z.i(0,x)
if(v==null)return
u=v.bI(w)
if(u==null)return
t=new H.bJ(u,x)}else t=new H.cr(y,w,x)
this.b.push(t)
return t},
eJ:function(a){var z,y,x,w,v,u,t
z=a.length
if(1>=z)return H.f(a,1)
y=a[1]
if(2>=z)return H.f(a,2)
x=a[2]
w={}
this.b.push(w)
z=J.y(y)
v=J.y(x)
u=0
while(!0){t=z.gh(y)
if(typeof t!=="number")return H.p(t)
if(!(u<t))break
w[z.i(y,u)]=this.ag(v.i(x,u));++u}return w}}}],["","",,H,{"^":"",
kX:function(a){return init.types[a]},
lb:function(a,b){var z
if(b!=null){z=b.x
if(z!=null)return z}return!!J.l(a).$isK},
e:function(a){var z
if(typeof a==="string")return a
if(typeof a==="number"){if(a!==0)return""+a}else if(!0===a)return"true"
else if(!1===a)return"false"
else if(a==null)return"null"
z=J.X(a)
if(typeof z!=="string")throw H.a(H.E(a))
return z},
ad:function(a){var z=a.$identityHash
if(z==null){z=Math.random()*0x3fffffff|0
a.$identityHash=z}return z},
ca:function(a,b){if(b==null)throw H.a(new P.J(a,null,null))
return b.$1(a)},
al:function(a,b,c){var z,y,x,w,v,u
H.ez(a)
z=/^\s*[+-]?((0x[a-f0-9]+)|(\d+)|([a-z0-9]+))\s*$/i.exec(a)
if(z==null)return H.ca(a,c)
if(3>=z.length)return H.f(z,3)
y=z[3]
if(b==null){if(y!=null)return parseInt(a,10)
if(z[2]!=null)return parseInt(a,16)
return H.ca(a,c)}if(b<2||b>36)throw H.a(P.x(b,2,36,"radix",null))
if(b===10&&y!=null)return parseInt(a,10)
if(b<10||y==null){x=b<=10?47+b:86+b
w=z[1]
for(v=w.length,u=0;u<v;++u)if((C.a.E(w,u)|32)>x)return H.ca(a,c)}return parseInt(a,b)},
bA:function(a){var z,y,x,w,v,u,t,s
z=J.l(a)
y=z.constructor
if(typeof y=="function"){x=y.name
w=typeof x==="string"?x:null}else w=null
if(w==null||z===C.N||!!J.l(a).$isbi){v=C.w(a)
if(v==="Object"){u=a.constructor
if(typeof u=="function"){t=String(u).match(/^\s*function\s*([\w$]*)\s*\(/)
s=t==null?null:t[1]
if(typeof s==="string"&&/^\w+$/.test(s))w=s}if(w==null)w=v}else w=v}w=w
if(w.length>1&&C.a.E(w,0)===36)w=C.a.ay(w,1)
return function(b,c){return b.replace(/[^<,> ]+/g,function(d){return c[d]||d})}(w+H.cB(H.bN(a),0,null),init.mangledGlobalNames)},
bz:function(a){return"Instance of '"+H.bA(a)+"'"},
hX:function(){if(!!self.location)return self.location.href
return},
dx:function(a){var z,y,x,w,v
z=a.length
if(z<=500)return String.fromCharCode.apply(null,a)
for(y="",x=0;x<z;x=w){w=x+500
v=w<z?w:z
y+=String.fromCharCode.apply(null,a.slice(x,v))}return y},
hY:function(a){var z,y,x,w
z=H.v([],[P.j])
for(y=a.length,x=0;x<a.length;a.length===y||(0,H.a7)(a),++x){w=a[x]
if(typeof w!=="number"||Math.floor(w)!==w)throw H.a(H.E(w))
if(w<=65535)z.push(w)
else if(w<=1114111){z.push(55296+(C.c.ae(w-65536,10)&1023))
z.push(56320+(w&1023))}else throw H.a(H.E(w))}return H.dx(z)},
dC:function(a){var z,y,x,w
for(z=a.length,y=0;x=a.length,y<x;x===z||(0,H.a7)(a),++y){w=a[y]
if(typeof w!=="number"||Math.floor(w)!==w)throw H.a(H.E(w))
if(w<0)throw H.a(H.E(w))
if(w>65535)return H.hY(a)}return H.dx(a)},
hZ:function(a,b,c){var z,y,x,w
if(typeof c!=="number")return c.d6()
if(c<=500&&b===0&&c===a.length)return String.fromCharCode.apply(null,a)
for(z=b,y="";z<c;z=x){x=z+500
if(x<c)w=x
else w=c
y+=String.fromCharCode.apply(null,a.subarray(z,w))}return y},
dB:function(a){var z
if(0<=a){if(a<=65535)return String.fromCharCode(a)
if(a<=1114111){z=a-65536
return String.fromCharCode((55296|C.c.ae(z,10))>>>0,56320|z&1023)}}throw H.a(P.x(a,0,1114111,null,null))},
cb:function(a,b){if(a==null||typeof a==="boolean"||typeof a==="number"||typeof a==="string")throw H.a(H.E(a))
return a[b]},
dA:function(a,b,c){if(a==null||typeof a==="boolean"||typeof a==="number"||typeof a==="string")throw H.a(H.E(a))
a[b]=c},
p:function(a){throw H.a(H.E(a))},
f:function(a,b){if(a==null)J.Q(a)
throw H.a(H.D(a,b))},
D:function(a,b){var z,y
if(typeof b!=="number"||Math.floor(b)!==b)return new P.a8(!0,b,"index",null)
z=J.Q(a)
if(!(b<0)){if(typeof z!=="number")return H.p(z)
y=b>=z}else y=!0
if(y)return P.Y(b,a,"index",null,z)
return P.bC(b,"index",null)},
E:function(a){return new P.a8(!0,a,null,null)},
cw:function(a){if(typeof a!=="number"||Math.floor(a)!==a)throw H.a(H.E(a))
return a},
ez:function(a){if(typeof a!=="string")throw H.a(H.E(a))
return a},
a:function(a){var z
if(a==null)a=new P.c8()
z=new Error()
z.dartException=a
if("defineProperty" in Object){Object.defineProperty(z,"message",{get:H.eI})
z.name=""}else z.toString=H.eI
return z},
eI:function(){return J.X(this.dartException)},
w:function(a){throw H.a(a)},
a7:function(a){throw H.a(new P.R(a))},
z:function(a){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l
z=new H.ln(a)
if(a==null)return
if(typeof a!=="object")return a
if("dartException" in a)return z.$1(a.dartException)
else if(!("message" in a))return a
y=a.message
if("number" in a&&typeof a.number=="number"){x=a.number
w=x&65535
if((C.c.ae(x,16)&8191)===10)switch(w){case 438:return z.$1(H.c2(H.e(y)+" (Error "+w+")",null))
case 445:case 5007:v=H.e(y)+" (Error "+w+")"
return z.$1(new H.dv(v,null))}}if(a instanceof TypeError){u=$.$get$dM()
t=$.$get$dN()
s=$.$get$dO()
r=$.$get$dP()
q=$.$get$dT()
p=$.$get$dU()
o=$.$get$dR()
$.$get$dQ()
n=$.$get$dW()
m=$.$get$dV()
l=u.Z(y)
if(l!=null)return z.$1(H.c2(y,l))
else{l=t.Z(y)
if(l!=null){l.method="call"
return z.$1(H.c2(y,l))}else{l=s.Z(y)
if(l==null){l=r.Z(y)
if(l==null){l=q.Z(y)
if(l==null){l=p.Z(y)
if(l==null){l=o.Z(y)
if(l==null){l=r.Z(y)
if(l==null){l=n.Z(y)
if(l==null){l=m.Z(y)
v=l!=null}else v=!0}else v=!0}else v=!0}else v=!0}else v=!0}else v=!0}else v=!0
if(v)return z.$1(new H.dv(y,l==null?null:l.method))}}return z.$1(new H.iG(typeof y==="string"?y:""))}if(a instanceof RangeError){if(typeof y==="string"&&y.indexOf("call stack")!==-1)return new P.dF()
y=function(b){try{return String(b)}catch(k){}return null}(a)
return z.$1(new P.a8(!1,null,null,typeof y==="string"?y.replace(/^RangeError:\s*/,""):y))}if(typeof InternalError=="function"&&a instanceof InternalError)if(typeof y==="string"&&y==="too much recursion")return new P.dF()
return a},
M:function(a){var z
if(a==null)return new H.ea(a,null)
z=a.$cachedTrace
if(z!=null)return z
return a.$cachedTrace=new H.ea(a,null)},
le:function(a){if(a==null||typeof a!='object')return J.ag(a)
else return H.ad(a)},
kV:function(a,b){var z,y,x,w
z=a.length
for(y=0;y<z;y=w){x=y+1
w=x+1
b.n(0,a[y],a[x])}return b},
l5:function(a,b,c,d,e,f,g){switch(c){case 0:return H.bk(b,new H.l6(a))
case 1:return H.bk(b,new H.l7(a,d))
case 2:return H.bk(b,new H.l8(a,d,e))
case 3:return H.bk(b,new H.l9(a,d,e,f))
case 4:return H.bk(b,new H.la(a,d,e,f,g))}throw H.a(P.bt("Unsupported number of arguments for wrapped closure"))},
b2:function(a,b){var z
if(a==null)return
z=a.$identity
if(!!z)return z
z=function(c,d,e,f){return function(g,h,i,j){return f(c,e,d,g,h,i,j)}}(a,b,init.globalState.d,H.l5)
a.$identity=z
return z},
fd:function(a,b,c,d,e,f){var z,y,x,w,v,u,t,s,r,q,p,o,n,m
z=b[0]
y=z.$callName
if(!!J.l(c).$ish){z.$reflectionInfo=c
x=H.i5(z).r}else x=c
w=d?Object.create(new H.id().constructor.prototype):Object.create(new H.bX(null,null,null,null).constructor.prototype)
w.$initialize=w.constructor
if(d)v=function(){this.$initialize()}
else{u=$.a3
$.a3=J.aq(u,1)
v=new Function("a,b,c,d"+u,"this.$initialize(a,b,c,d"+u+")")}w.constructor=v
v.prototype=w
if(!d){t=e.length==1&&!0
s=H.cR(a,z,t)
s.$reflectionInfo=c}else{w.$static_name=f
s=z
t=!1}if(typeof x=="number")r=function(g,h){return function(){return g(h)}}(H.kX,x)
else if(typeof x=="function")if(d)r=x
else{q=t?H.cP:H.bY
r=function(g,h){return function(){return g.apply({$receiver:h(this)},arguments)}}(x,q)}else throw H.a("Error in reflectionInfo.")
w.$S=r
w[y]=s
for(u=b.length,p=1;p<u;++p){o=b[p]
n=o.$callName
if(n!=null){m=d?o:H.cR(a,o,t)
w[n]=m}}w["call*"]=s
w.$R=z.$R
w.$D=z.$D
return v},
fa:function(a,b,c,d){var z=H.bY
switch(b?-1:a){case 0:return function(e,f){return function(){return f(this)[e]()}}(c,z)
case 1:return function(e,f){return function(g){return f(this)[e](g)}}(c,z)
case 2:return function(e,f){return function(g,h){return f(this)[e](g,h)}}(c,z)
case 3:return function(e,f){return function(g,h,i){return f(this)[e](g,h,i)}}(c,z)
case 4:return function(e,f){return function(g,h,i,j){return f(this)[e](g,h,i,j)}}(c,z)
case 5:return function(e,f){return function(g,h,i,j,k){return f(this)[e](g,h,i,j,k)}}(c,z)
default:return function(e,f){return function(){return e.apply(f(this),arguments)}}(d,z)}},
cR:function(a,b,c){var z,y,x,w,v,u,t
if(c)return H.fc(a,b)
z=b.$stubName
y=b.length
x=a[z]
w=b==null?x==null:b===x
v=!w||y>=27
if(v)return H.fa(y,!w,z,b)
if(y===0){w=$.a3
$.a3=J.aq(w,1)
u="self"+H.e(w)
w="return function(){var "+u+" = this."
v=$.aR
if(v==null){v=H.br("self")
$.aR=v}return new Function(w+H.e(v)+";return "+u+"."+H.e(z)+"();}")()}t="abcdefghijklmnopqrstuvwxyz".split("").splice(0,y).join(",")
w=$.a3
$.a3=J.aq(w,1)
t+=H.e(w)
w="return function("+t+"){return this."
v=$.aR
if(v==null){v=H.br("self")
$.aR=v}return new Function(w+H.e(v)+"."+H.e(z)+"("+t+");}")()},
fb:function(a,b,c,d){var z,y
z=H.bY
y=H.cP
switch(b?-1:a){case 0:throw H.a(new H.i7("Intercepted function with no arguments."))
case 1:return function(e,f,g){return function(){return f(this)[e](g(this))}}(c,z,y)
case 2:return function(e,f,g){return function(h){return f(this)[e](g(this),h)}}(c,z,y)
case 3:return function(e,f,g){return function(h,i){return f(this)[e](g(this),h,i)}}(c,z,y)
case 4:return function(e,f,g){return function(h,i,j){return f(this)[e](g(this),h,i,j)}}(c,z,y)
case 5:return function(e,f,g){return function(h,i,j,k){return f(this)[e](g(this),h,i,j,k)}}(c,z,y)
case 6:return function(e,f,g){return function(h,i,j,k,l){return f(this)[e](g(this),h,i,j,k,l)}}(c,z,y)
default:return function(e,f,g,h){return function(){h=[g(this)]
Array.prototype.push.apply(h,arguments)
return e.apply(f(this),h)}}(d,z,y)}},
fc:function(a,b){var z,y,x,w,v,u,t,s
z=H.f7()
y=$.cO
if(y==null){y=H.br("receiver")
$.cO=y}x=b.$stubName
w=b.length
v=a[x]
u=b==null?v==null:b===v
t=!u||w>=28
if(t)return H.fb(w,!u,x,b)
if(w===1){y="return function(){return this."+H.e(z)+"."+H.e(x)+"(this."+H.e(y)+");"
u=$.a3
$.a3=J.aq(u,1)
return new Function(y+H.e(u)+"}")()}s="abcdefghijklmnopqrstuvwxyz".split("").splice(0,w-1).join(",")
y="return function("+s+"){return this."+H.e(z)+"."+H.e(x)+"(this."+H.e(y)+", "+s+");"
u=$.a3
$.a3=J.aq(u,1)
return new Function(y+H.e(u)+"}")()},
cx:function(a,b,c,d,e,f){var z
b.fixed$length=Array
if(!!J.l(c).$ish){c.fixed$length=Array
z=c}else z=c
return H.fd(a,b,z,!!d,e,f)},
lh:function(a,b){var z=J.y(b)
throw H.a(H.cQ(H.bA(a),z.k(b,3,z.gh(b))))},
bP:function(a,b){var z
if(a!=null)z=(typeof a==="object"||typeof a==="function")&&J.l(a)[b]
else z=!0
if(z)return a
H.lh(a,b)},
kT:function(a){var z=J.l(a)
return"$S" in z?z.$S():null},
aJ:function(a,b){var z
if(a==null)return!1
z=H.kT(a)
return z==null?!1:H.eC(z,b)},
lm:function(a){throw H.a(new P.fg(a))},
bS:function(){return(Math.random()*0x100000000>>>0)+(Math.random()*0x100000000>>>0)*4294967296},
eA:function(a){return init.getIsolateTag(a)},
v:function(a,b){a.$ti=b
return a},
bN:function(a){if(a==null)return
return a.$ti},
eB:function(a,b){return H.cD(a["$as"+H.e(b)],H.bN(a))},
B:function(a,b,c){var z=H.eB(a,b)
return z==null?null:z[c]},
F:function(a,b){var z=H.bN(a)
return z==null?null:z[b]},
aK:function(a,b){var z
if(a==null)return"dynamic"
if(typeof a==="object"&&a!==null&&a.constructor===Array)return a[0].builtin$cls+H.cB(a,1,b)
if(typeof a=="function")return a.builtin$cls
if(typeof a==="number"&&Math.floor(a)===a)return H.e(a)
if(typeof a.func!="undefined"){z=a.typedef
if(z!=null)return H.aK(z,b)
return H.kC(a,b)}return"unknown-reified-type"},
kC:function(a,b){var z,y,x,w,v,u,t,s,r,q,p
z=!!a.v?"void":H.aK(a.ret,b)
if("args" in a){y=a.args
for(x=y.length,w="",v="",u=0;u<x;++u,v=", "){t=y[u]
w=w+v+H.aK(t,b)}}else{w=""
v=""}if("opt" in a){s=a.opt
w+=v+"["
for(x=s.length,v="",u=0;u<x;++u,v=", "){t=s[u]
w=w+v+H.aK(t,b)}w+="]"}if("named" in a){r=a.named
w+=v+"{"
for(x=H.kU(r),q=x.length,v="",u=0;u<q;++u,v=", "){p=x[u]
w=w+v+H.aK(r[p],b)+(" "+H.e(p))}w+="}"}return"("+w+") => "+z},
cB:function(a,b,c){var z,y,x,w,v,u
if(a==null)return""
z=new P.am("")
for(y=b,x=!0,w=!0,v="";y<a.length;++y){if(x)x=!1
else z.p=v+", "
u=a[y]
if(u!=null)w=!1
v=z.p+=H.aK(u,c)}return w?"":"<"+z.j(0)+">"},
cD:function(a,b){if(a==null)return b
a=a.apply(null,b)
if(a==null)return
if(typeof a==="object"&&a!==null&&a.constructor===Array)return a
if(typeof a=="function")return a.apply(null,b)
return b},
aH:function(a,b,c,d){var z,y
if(a==null)return!1
z=H.bN(a)
y=J.l(a)
if(y[b]==null)return!1
return H.ew(H.cD(y[d],z),c)},
ll:function(a,b,c,d){if(a==null)return a
if(H.aH(a,b,c,d))return a
throw H.a(H.cQ(H.bA(a),function(e,f){return e.replace(/[^<,> ]+/g,function(g){return f[g]||g})}(b.substring(3)+H.cB(c,0,null),init.mangledGlobalNames)))},
ew:function(a,b){var z,y
if(a==null||b==null)return!0
z=a.length
for(y=0;y<z;++y)if(!H.W(a[y],b[y]))return!1
return!0},
aI:function(a,b,c){return a.apply(b,H.eB(b,c))},
W:function(a,b){var z,y,x,w,v,u
if(a===b)return!0
if(a==null||b==null)return!0
if(a.builtin$cls==="by")return!0
if('func' in b)return H.eC(a,b)
if('func' in a)return b.builtin$cls==="lS"||b.builtin$cls==="b"
z=typeof a==="object"&&a!==null&&a.constructor===Array
y=z?a[0]:a
x=typeof b==="object"&&b!==null&&b.constructor===Array
w=x?b[0]:b
if(w!==y){v=H.aK(w,null)
if(!('$is'+v in y.prototype))return!1
u=y.prototype["$as"+v]}else u=null
if(!z&&u==null||!x)return!0
z=z?a.slice(1):null
x=b.slice(1)
return H.ew(H.cD(u,z),x)},
ev:function(a,b,c){var z,y,x,w,v
z=b==null
if(z&&a==null)return!0
if(z)return c
if(a==null)return!1
y=a.length
x=b.length
if(c){if(y<x)return!1}else if(y!==x)return!1
for(w=0;w<x;++w){z=a[w]
v=b[w]
if(!(H.W(z,v)||H.W(v,z)))return!1}return!0},
kL:function(a,b){var z,y,x,w,v,u
if(b==null)return!0
if(a==null)return!1
z=Object.getOwnPropertyNames(b)
z.fixed$length=Array
y=z
for(z=y.length,x=0;x<z;++x){w=y[x]
if(!Object.hasOwnProperty.call(a,w))return!1
v=b[w]
u=a[w]
if(!(H.W(v,u)||H.W(u,v)))return!1}return!0},
eC:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l
if(!('func' in a))return!1
if("v" in a){if(!("v" in b)&&"ret" in b)return!1}else if(!("v" in b)){z=a.ret
y=b.ret
if(!(H.W(z,y)||H.W(y,z)))return!1}x=a.args
w=b.args
v=a.opt
u=b.opt
t=x!=null?x.length:0
s=w!=null?w.length:0
r=v!=null?v.length:0
q=u!=null?u.length:0
if(t>s)return!1
if(t+r<s+q)return!1
if(t===s){if(!H.ev(x,w,!1))return!1
if(!H.ev(v,u,!0))return!1}else{for(p=0;p<t;++p){o=x[p]
n=w[p]
if(!(H.W(o,n)||H.W(n,o)))return!1}for(m=p,l=0;m<s;++l,++m){o=v[l]
n=w[m]
if(!(H.W(o,n)||H.W(n,o)))return!1}for(m=0;m<q;++l,++m){o=v[l]
n=u[m]
if(!(H.W(o,n)||H.W(n,o)))return!1}}return H.kL(a.named,b.named)},
n0:function(a){var z=$.cz
return"Instance of "+(z==null?"<Unknown>":z.$1(a))},
mZ:function(a){return H.ad(a)},
mY:function(a,b,c){Object.defineProperty(a,b,{value:c,enumerable:false,writable:true,configurable:true})},
lc:function(a){var z,y,x,w,v,u
z=$.cz.$1(a)
y=$.bL[z]
if(y!=null){Object.defineProperty(a,init.dispatchPropertyName,{value:y,enumerable:false,writable:true,configurable:true})
return y.i}x=$.bQ[z]
if(x!=null)return x
w=init.interceptorsByTag[z]
if(w==null){z=$.eu.$2(a,z)
if(z!=null){y=$.bL[z]
if(y!=null){Object.defineProperty(a,init.dispatchPropertyName,{value:y,enumerable:false,writable:true,configurable:true})
return y.i}x=$.bQ[z]
if(x!=null)return x
w=init.interceptorsByTag[z]}}if(w==null)return
x=w.prototype
v=z[0]
if(v==="!"){y=H.cC(x)
$.bL[z]=y
Object.defineProperty(a,init.dispatchPropertyName,{value:y,enumerable:false,writable:true,configurable:true})
return y.i}if(v==="~"){$.bQ[z]=x
return x}if(v==="-"){u=H.cC(x)
Object.defineProperty(Object.getPrototypeOf(a),init.dispatchPropertyName,{value:u,enumerable:false,writable:true,configurable:true})
return u.i}if(v==="+")return H.eD(a,x)
if(v==="*")throw H.a(new P.bh(z))
if(init.leafTags[z]===true){u=H.cC(x)
Object.defineProperty(Object.getPrototypeOf(a),init.dispatchPropertyName,{value:u,enumerable:false,writable:true,configurable:true})
return u.i}else return H.eD(a,x)},
eD:function(a,b){var z=Object.getPrototypeOf(a)
Object.defineProperty(z,init.dispatchPropertyName,{value:J.bR(b,z,null,null),enumerable:false,writable:true,configurable:true})
return b},
cC:function(a){return J.bR(a,!1,null,!!a.$isK)},
ld:function(a,b,c){var z=b.prototype
if(init.leafTags[a]===true)return J.bR(z,!1,null,!!z.$isK)
else return J.bR(z,c,null,null)},
l3:function(){if(!0===$.cA)return
$.cA=!0
H.l4()},
l4:function(){var z,y,x,w,v,u,t,s
$.bL=Object.create(null)
$.bQ=Object.create(null)
H.l_()
z=init.interceptorsByTag
y=Object.getOwnPropertyNames(z)
if(typeof window!="undefined"){window
x=function(){}
for(w=0;w<y.length;++w){v=y[w]
u=$.eE.$1(v)
if(u!=null){t=H.ld(v,z[v],u)
if(t!=null){Object.defineProperty(u,init.dispatchPropertyName,{value:t,enumerable:false,writable:true,configurable:true})
x.prototype=u}}}}for(w=0;w<y.length;++w){v=y[w]
if(/^[A-Za-z_]/.test(v)){s=z[v]
z["!"+v]=s
z["~"+v]=s
z["-"+v]=s
z["+"+v]=s
z["*"+v]=s}}},
l_:function(){var z,y,x,w,v,u,t
z=C.O()
z=H.aG(C.P,H.aG(C.Q,H.aG(C.v,H.aG(C.v,H.aG(C.S,H.aG(C.R,H.aG(C.T(C.w),z)))))))
if(typeof dartNativeDispatchHooksTransformer!="undefined"){y=dartNativeDispatchHooksTransformer
if(typeof y=="function")y=[y]
if(y.constructor==Array)for(x=0;x<y.length;++x){w=y[x]
if(typeof w=="function")z=w(z)||z}}v=z.getTag
u=z.getUnknownTag
t=z.prototypeForTag
$.cz=new H.l0(v)
$.eu=new H.l1(u)
$.eE=new H.l2(t)},
aG:function(a,b){return a(b)||b},
lk:function(a,b,c){var z=a.indexOf(b,c)
return z>=0},
i4:{"^":"b;a,b,c,d,e,f,r,x",m:{
i5:function(a){var z,y,x
z=a.$reflectionInfo
if(z==null)return
z.fixed$length=Array
z=z
y=z[0]
x=z[1]
return new H.i4(a,z,(y&1)===1,y>>1,x>>1,(x&1)===1,z[2],null)}}},
iE:{"^":"b;a,b,c,d,e,f",
Z:function(a){var z,y,x
z=new RegExp(this.a).exec(a)
if(z==null)return
y=Object.create(null)
x=this.b
if(x!==-1)y.arguments=z[x+1]
x=this.c
if(x!==-1)y.argumentsExpr=z[x+1]
x=this.d
if(x!==-1)y.expr=z[x+1]
x=this.e
if(x!==-1)y.method=z[x+1]
x=this.f
if(x!==-1)y.receiver=z[x+1]
return y},
m:{
a6:function(a){var z,y,x,w,v,u
a=a.replace(String({}),'$receiver$').replace(/[[\]{}()*+?.\\^$|]/g,"\\$&")
z=a.match(/\\\$[a-zA-Z]+\\\$/g)
if(z==null)z=[]
y=z.indexOf("\\$arguments\\$")
x=z.indexOf("\\$argumentsExpr\\$")
w=z.indexOf("\\$expr\\$")
v=z.indexOf("\\$method\\$")
u=z.indexOf("\\$receiver\\$")
return new H.iE(a.replace(new RegExp('\\\\\\$arguments\\\\\\$','g'),'((?:x|[^x])*)').replace(new RegExp('\\\\\\$argumentsExpr\\\\\\$','g'),'((?:x|[^x])*)').replace(new RegExp('\\\\\\$expr\\\\\\$','g'),'((?:x|[^x])*)').replace(new RegExp('\\\\\\$method\\\\\\$','g'),'((?:x|[^x])*)').replace(new RegExp('\\\\\\$receiver\\\\\\$','g'),'((?:x|[^x])*)'),y,x,w,v,u)},
bE:function(a){return function($expr$){var $argumentsExpr$='$arguments$'
try{$expr$.$method$($argumentsExpr$)}catch(z){return z.message}}(a)},
dS:function(a){return function($expr$){try{$expr$.$method$}catch(z){return z.message}}(a)}}},
dv:{"^":"I;a,b",
j:function(a){var z=this.b
if(z==null)return"NullError: "+H.e(this.a)
return"NullError: method not found: '"+H.e(z)+"' on null"}},
hm:{"^":"I;a,b,c",
j:function(a){var z,y
z=this.b
if(z==null)return"NoSuchMethodError: "+H.e(this.a)
y=this.c
if(y==null)return"NoSuchMethodError: method not found: '"+z+"' ("+H.e(this.a)+")"
return"NoSuchMethodError: method not found: '"+z+"' on '"+y+"' ("+H.e(this.a)+")"},
m:{
c2:function(a,b){var z,y
z=b==null
y=z?null:b.method
return new H.hm(a,y,z?null:b.receiver)}}},
iG:{"^":"I;a",
j:function(a){var z=this.a
return z.length===0?"Error":"Error: "+z}},
ln:{"^":"c:0;a",
$1:function(a){if(!!J.l(a).$isI)if(a.$thrownJsError==null)a.$thrownJsError=this.a
return a}},
ea:{"^":"b;a,b",
j:function(a){var z,y
z=this.b
if(z!=null)return z
z=this.a
y=z!==null&&typeof z==="object"?z.stack:null
z=y==null?"":y
this.b=z
return z}},
l6:{"^":"c:1;a",
$0:function(){return this.a.$0()}},
l7:{"^":"c:1;a,b",
$0:function(){return this.a.$1(this.b)}},
l8:{"^":"c:1;a,b,c",
$0:function(){return this.a.$2(this.b,this.c)}},
l9:{"^":"c:1;a,b,c,d",
$0:function(){return this.a.$3(this.b,this.c,this.d)}},
la:{"^":"c:1;a,b,c,d,e",
$0:function(){return this.a.$4(this.b,this.c,this.d,this.e)}},
c:{"^":"b;",
j:function(a){return"Closure '"+H.bA(this).trim()+"'"},
gd4:function(){return this},
gd4:function(){return this}},
dJ:{"^":"c;"},
id:{"^":"dJ;",
j:function(a){var z=this.$static_name
if(z==null)return"Closure of unknown static method"
return"Closure '"+z+"'"}},
bX:{"^":"dJ;a,b,c,d",
C:function(a,b){if(b==null)return!1
if(this===b)return!0
if(!(b instanceof H.bX))return!1
return this.a===b.a&&this.b===b.b&&this.c===b.c},
gF:function(a){var z,y
z=this.c
if(z==null)y=H.ad(this.a)
else y=typeof z!=="object"?J.ag(z):H.ad(z)
z=H.ad(this.b)
if(typeof y!=="number")return y.fk()
return(y^z)>>>0},
j:function(a){var z=this.c
if(z==null)z=this.a
return"Closure '"+H.e(this.d)+"' of "+H.bz(z)},
m:{
bY:function(a){return a.a},
cP:function(a){return a.c},
f7:function(){var z=$.aR
if(z==null){z=H.br("self")
$.aR=z}return z},
br:function(a){var z,y,x,w,v
z=new H.bX("self","target","receiver","name")
y=Object.getOwnPropertyNames(z)
y.fixed$length=Array
x=y
for(y=x.length,w=0;w<y;++w){v=x[w]
if(z[v]===a)return v}}}},
f8:{"^":"I;a",
j:function(a){return this.a},
m:{
cQ:function(a,b){return new H.f8("CastError: Casting value of type '"+a+"' to incompatible type '"+b+"'")}}},
i7:{"^":"I;a",
j:function(a){return"RuntimeError: "+H.e(this.a)}},
ab:{"^":"b;a,b,c,d,e,f,r,$ti",
gh:function(a){return this.a},
gu:function(a){return this.a===0},
gK:function(){return new H.hu(this,[H.F(this,0)])},
ga2:function(a){return H.be(this.gK(),new H.hl(this),H.F(this,0),H.F(this,1))},
J:function(a){var z,y
if(typeof a==="string"){z=this.b
if(z==null)return!1
return this.ca(z,a)}else if(typeof a==="number"&&(a&0x3ffffff)===a){y=this.c
if(y==null)return!1
return this.ca(y,a)}else return this.eU(a)},
eU:function(a){var z=this.d
if(z==null)return!1
return this.aL(this.aW(z,this.aK(a)),a)>=0},
i:function(a,b){var z,y,x
if(typeof b==="string"){z=this.b
if(z==null)return
y=this.aB(z,b)
return y==null?null:y.gai()}else if(typeof b==="number"&&(b&0x3ffffff)===b){x=this.c
if(x==null)return
y=this.aB(x,b)
return y==null?null:y.gai()}else return this.eV(b)},
eV:function(a){var z,y,x
z=this.d
if(z==null)return
y=this.aW(z,this.aK(a))
x=this.aL(y,a)
if(x<0)return
return y[x].gai()},
n:function(a,b,c){var z,y,x,w,v,u
if(typeof b==="string"){z=this.b
if(z==null){z=this.bu()
this.b=z}this.c3(z,b,c)}else if(typeof b==="number"&&(b&0x3ffffff)===b){y=this.c
if(y==null){y=this.bu()
this.c=y}this.c3(y,b,c)}else{x=this.d
if(x==null){x=this.bu()
this.d=x}w=this.aK(b)
v=this.aW(x,w)
if(v==null)this.bz(x,w,[this.bv(b,c)])
else{u=this.aL(v,b)
if(u>=0)v[u].sai(c)
else v.push(this.bv(b,c))}}},
v:function(a,b){if(typeof b==="string")return this.cp(this.b,b)
else if(typeof b==="number"&&(b&0x3ffffff)===b)return this.cp(this.c,b)
else return this.eW(b)},
eW:function(a){var z,y,x,w
z=this.d
if(z==null)return
y=this.aW(z,this.aK(a))
x=this.aL(y,a)
if(x<0)return
w=y.splice(x,1)[0]
this.cA(w)
return w.gai()},
U:function(a){if(this.a>0){this.f=null
this.e=null
this.d=null
this.c=null
this.b=null
this.a=0
this.r=this.r+1&67108863}},
L:function(a,b){var z,y
z=this.e
y=this.r
for(;z!=null;){b.$2(z.a,z.b)
if(y!==this.r)throw H.a(new P.R(this))
z=z.c}},
c3:function(a,b,c){var z=this.aB(a,b)
if(z==null)this.bz(a,b,this.bv(b,c))
else z.sai(c)},
cp:function(a,b){var z
if(a==null)return
z=this.aB(a,b)
if(z==null)return
this.cA(z)
this.cb(a,b)
return z.gai()},
bv:function(a,b){var z,y
z=new H.ht(a,b,null,null)
if(this.e==null){this.f=z
this.e=z}else{y=this.f
z.d=y
y.c=z
this.f=z}++this.a
this.r=this.r+1&67108863
return z},
cA:function(a){var z,y
z=a.ge6()
y=a.c
if(z==null)this.e=y
else z.c=y
if(y==null)this.f=z
else y.d=z;--this.a
this.r=this.r+1&67108863},
aK:function(a){return J.ag(a)&0x3ffffff},
aL:function(a,b){var z,y
if(a==null)return-1
z=a.length
for(y=0;y<z;++y)if(J.C(a[y].gcQ(),b))return y
return-1},
j:function(a){return P.dl(this)},
aB:function(a,b){return a[b]},
aW:function(a,b){return a[b]},
bz:function(a,b,c){a[b]=c},
cb:function(a,b){delete a[b]},
ca:function(a,b){return this.aB(a,b)!=null},
bu:function(){var z=Object.create(null)
this.bz(z,"<non-identifier-key>",z)
this.cb(z,"<non-identifier-key>")
return z},
$ish3:1},
hl:{"^":"c:0;a",
$1:function(a){return this.a.i(0,a)}},
ht:{"^":"b;cQ:a<,ai:b@,c,e6:d<"},
hu:{"^":"d;a,$ti",
gh:function(a){return this.a.a},
gu:function(a){return this.a.a===0},
gw:function(a){var z,y
z=this.a
y=new H.hv(z,z.r,null,null)
y.c=z.e
return y}},
hv:{"^":"b;a,b,c,d",
gq:function(){return this.d},
l:function(){var z=this.a
if(this.b!==z.r)throw H.a(new P.R(z))
else{z=this.c
if(z==null){this.d=null
return!1}else{this.d=z.a
this.c=z.c
return!0}}}},
l0:{"^":"c:0;a",
$1:function(a){return this.a(a)}},
l1:{"^":"c:11;a",
$2:function(a,b){return this.a(a,b)}},
l2:{"^":"c:3;a",
$1:function(a){return this.a(a)}},
hj:{"^":"b;a,b,c,d",
j:function(a){return"RegExp/"+this.a+"/"},
m:{
hk:function(a,b,c,d){var z,y,x,w
z=b?"m":""
y=c?"":"i"
x=d?"g":""
w=function(e,f){try{return new RegExp(e,f)}catch(v){return v}}(a,z+y+x)
if(w instanceof RegExp)return w
throw H.a(new P.J("Illegal RegExp pattern ("+String(w)+")",a,null))}}}}],["","",,H,{"^":"",
kU:function(a){var z=H.v(a?Object.keys(a):[],[null])
z.fixed$length=Array
return z}}],["","",,H,{"^":"",
lg:function(a){if(typeof dartPrint=="function"){dartPrint(a)
return}if(typeof console=="object"&&typeof console.log!="undefined"){console.log(a)
return}if(typeof window=="object")return
if(typeof print=="function"){print(a)
return}throw"Unable to print message: "+String(a)}}],["","",,H,{"^":"",
el:function(a){return a},
kB:function(a){return a},
hC:function(a){return new Int8Array(H.kB(a))},
dm:{"^":"i;",$isdm:1,"%":"ArrayBuffer"},
c7:{"^":"i;",
e1:function(a,b,c,d){if(typeof b!=="number"||Math.floor(b)!==b)throw H.a(P.aQ(b,d,"Invalid list position"))
else throw H.a(P.x(b,0,c,d,null))},
c6:function(a,b,c,d){if(b>>>0!==b||b>c)this.e1(a,b,c,d)},
$isc7:1,
"%":"DataView;ArrayBufferView;c6|dn|dq|bx|dp|dr|ac"},
c6:{"^":"c7;",
gh:function(a){return a.length},
cu:function(a,b,c,d,e){var z,y,x
z=a.length
this.c6(a,b,z,"start")
this.c6(a,c,z,"end")
if(b>c)throw H.a(P.x(b,0,c,null,null))
y=c-b
if(e<0)throw H.a(P.aP(e))
x=d.length
if(x-e<y)throw H.a(new P.t("Not enough elements"))
if(e!==0||x!==y)d=d.subarray(e,e+y)
a.set(d,b)},
$isK:1,
$asK:I.L,
$isG:1,
$asG:I.L},
bx:{"^":"dq;",
i:function(a,b){if(b>>>0!==b||b>=a.length)H.w(H.D(a,b))
return a[b]},
n:function(a,b,c){if(b>>>0!==b||b>=a.length)H.w(H.D(a,b))
a[b]=c},
D:function(a,b,c,d,e){if(!!J.l(d).$isbx){this.cu(a,b,c,d,e)
return}this.c1(a,b,c,d,e)},
T:function(a,b,c,d){return this.D(a,b,c,d,0)}},
dn:{"^":"c6+O;",$asK:I.L,$asG:I.L,
$ash:function(){return[P.ap]},
$asd:function(){return[P.ap]},
$ish:1,
$isd:1},
dq:{"^":"dn+d9;",$asK:I.L,$asG:I.L,
$ash:function(){return[P.ap]},
$asd:function(){return[P.ap]}},
ac:{"^":"dr;",
n:function(a,b,c){if(b>>>0!==b||b>=a.length)H.w(H.D(a,b))
a[b]=c},
D:function(a,b,c,d,e){if(!!J.l(d).$isac){this.cu(a,b,c,d,e)
return}this.c1(a,b,c,d,e)},
T:function(a,b,c,d){return this.D(a,b,c,d,0)},
$ish:1,
$ash:function(){return[P.j]},
$isd:1,
$asd:function(){return[P.j]}},
dp:{"^":"c6+O;",$asK:I.L,$asG:I.L,
$ash:function(){return[P.j]},
$asd:function(){return[P.j]},
$ish:1,
$isd:1},
dr:{"^":"dp+d9;",$asK:I.L,$asG:I.L,
$ash:function(){return[P.j]},
$asd:function(){return[P.j]}},
ma:{"^":"bx;",$ish:1,
$ash:function(){return[P.ap]},
$isd:1,
$asd:function(){return[P.ap]},
"%":"Float32Array"},
mb:{"^":"bx;",$ish:1,
$ash:function(){return[P.ap]},
$isd:1,
$asd:function(){return[P.ap]},
"%":"Float64Array"},
mc:{"^":"ac;",
i:function(a,b){if(b>>>0!==b||b>=a.length)H.w(H.D(a,b))
return a[b]},
$ish:1,
$ash:function(){return[P.j]},
$isd:1,
$asd:function(){return[P.j]},
"%":"Int16Array"},
md:{"^":"ac;",
i:function(a,b){if(b>>>0!==b||b>=a.length)H.w(H.D(a,b))
return a[b]},
$ish:1,
$ash:function(){return[P.j]},
$isd:1,
$asd:function(){return[P.j]},
"%":"Int32Array"},
me:{"^":"ac;",
i:function(a,b){if(b>>>0!==b||b>=a.length)H.w(H.D(a,b))
return a[b]},
$ish:1,
$ash:function(){return[P.j]},
$isd:1,
$asd:function(){return[P.j]},
"%":"Int8Array"},
mf:{"^":"ac;",
i:function(a,b){if(b>>>0!==b||b>=a.length)H.w(H.D(a,b))
return a[b]},
$ish:1,
$ash:function(){return[P.j]},
$isd:1,
$asd:function(){return[P.j]},
"%":"Uint16Array"},
mg:{"^":"ac;",
i:function(a,b){if(b>>>0!==b||b>=a.length)H.w(H.D(a,b))
return a[b]},
$ish:1,
$ash:function(){return[P.j]},
$isd:1,
$asd:function(){return[P.j]},
"%":"Uint32Array"},
mh:{"^":"ac;",
gh:function(a){return a.length},
i:function(a,b){if(b>>>0!==b||b>=a.length)H.w(H.D(a,b))
return a[b]},
$ish:1,
$ash:function(){return[P.j]},
$isd:1,
$asd:function(){return[P.j]},
"%":"CanvasPixelArray|Uint8ClampedArray"},
ds:{"^":"ac;",
gh:function(a){return a.length},
i:function(a,b){if(b>>>0!==b||b>=a.length)H.w(H.D(a,b))
return a[b]},
$isds:1,
$ish:1,
$ash:function(){return[P.j]},
$isd:1,
$asd:function(){return[P.j]},
"%":";Uint8Array"}}],["","",,P,{"^":"",
iR:function(){var z,y,x
z={}
if(self.scheduleImmediate!=null)return P.kM()
if(self.MutationObserver!=null&&self.document!=null){y=self.document.createElement("div")
x=self.document.createElement("span")
z.a=null
new self.MutationObserver(H.b2(new P.iT(z),1)).observe(y,{childList:true})
return new P.iS(z,y,x)}else if(self.setImmediate!=null)return P.kN()
return P.kO()},
mF:[function(a){++init.globalState.f.b
self.scheduleImmediate(H.b2(new P.iU(a),0))},"$1","kM",2,0,5],
mG:[function(a){++init.globalState.f.b
self.setImmediate(H.b2(new P.iV(a),0))},"$1","kN",2,0,5],
mH:[function(a){P.cd(C.t,a)},"$1","kO",2,0,5],
cv:function(a,b){if(H.aJ(a,{func:1,args:[P.by,P.by]})){b.toString
return a}else{b.toString
return a}},
em:function(a,b,c){$.o.toString
a.ac(b,c)},
kE:function(){var z,y
for(;z=$.aE,z!=null;){$.b_=null
y=z.b
$.aE=y
if(y==null)$.aZ=null
z.a.$0()}},
mX:[function(){$.ct=!0
try{P.kE()}finally{$.b_=null
$.ct=!1
if($.aE!=null)$.$get$ch().$1(P.ey())}},"$0","ey",0,0,2],
et:function(a){var z=new P.dZ(a,null)
if($.aE==null){$.aZ=z
$.aE=z
if(!$.ct)$.$get$ch().$1(P.ey())}else{$.aZ.b=z
$.aZ=z}},
kJ:function(a){var z,y,x
z=$.aE
if(z==null){P.et(a)
$.b_=$.aZ
return}y=new P.dZ(a,null)
x=$.b_
if(x==null){y.b=z
$.b_=y
$.aE=y}else{y.b=x.b
x.b=y
$.b_=y
if(y.b==null)$.aZ=y}},
eG:function(a){var z=$.o
if(C.d===z){P.ao(null,null,C.d,a)
return}z.toString
P.ao(null,null,z,z.bD(a,!0))},
eq:function(a){var z,y,x,w
if(a==null)return
try{a.$0()}catch(x){z=H.z(x)
y=H.M(x)
w=$.o
w.toString
P.aF(null,null,w,z,y)}},
mV:[function(a){},"$1","kP",2,0,28],
kF:[function(a,b){var z=$.o
z.toString
P.aF(null,null,z,a,b)},function(a){return P.kF(a,null)},"$2","$1","kQ",2,2,4,0],
mW:[function(){},"$0","ex",0,0,2],
kI:function(a,b,c){var z,y,x,w,v,u,t
try{b.$1(a.$0())}catch(u){z=H.z(u)
y=H.M(u)
$.o.toString
x=null
if(x==null)c.$2(z,y)
else{t=J.aM(x)
w=t
v=x.ga4()
c.$2(w,v)}}},
kp:function(a,b,c,d){var z=a.a0()
if(!!J.l(z).$isa4&&z!==$.$get$au())z.ba(new P.ks(b,c,d))
else b.ac(c,d)},
kq:function(a,b){return new P.kr(a,b)},
cs:function(a,b,c){var z=a.a0()
if(!!J.l(z).$isa4&&z!==$.$get$au())z.ba(new P.kt(b,c))
else b.as(c)},
ko:function(a,b,c){$.o.toString
a.bg(b,c)},
az:function(a,b){var z=$.o
if(z===C.d){z.toString
return P.cd(a,b)}return P.cd(a,z.bD(b,!0))},
cd:function(a,b){var z=C.c.a7(a.a,1000)
return H.iB(z<0?0:z,b)},
iP:function(){return $.o},
aF:function(a,b,c,d,e){var z={}
z.a=d
P.kJ(new P.kH(z,e))},
en:function(a,b,c,d){var z,y
y=$.o
if(y===c)return d.$0()
$.o=c
z=y
try{y=d.$0()
return y}finally{$.o=z}},
ep:function(a,b,c,d,e){var z,y
y=$.o
if(y===c)return d.$1(e)
$.o=c
z=y
try{y=d.$1(e)
return y}finally{$.o=z}},
eo:function(a,b,c,d,e,f){var z,y
y=$.o
if(y===c)return d.$2(e,f)
$.o=c
z=y
try{y=d.$2(e,f)
return y}finally{$.o=z}},
ao:function(a,b,c,d){var z=C.d!==c
if(z)d=c.bD(d,!(!z||!1))
P.et(d)},
iT:{"^":"c:0;a",
$1:function(a){var z,y;--init.globalState.f.b
z=this.a
y=z.a
z.a=null
y.$0()}},
iS:{"^":"c:12;a,b,c",
$1:function(a){var z,y;++init.globalState.f.b
this.a.a=a
z=this.b
y=this.c
z.firstChild?z.removeChild(y):z.appendChild(y)}},
iU:{"^":"c:1;a",
$0:function(){--init.globalState.f.b
this.a.$0()}},
iV:{"^":"c:1;a",
$0:function(){--init.globalState.f.b
this.a.$0()}},
iX:{"^":"e1;a,$ti"},
iY:{"^":"j3;y,e5:z<,Q,x,a,b,c,d,e,f,r,$ti",
aZ:[function(){},"$0","gaY",0,0,2],
b0:[function(){},"$0","gb_",0,0,2]},
ci:{"^":"b;at:c<,$ti",
gaX:function(){return this.c<4},
dW:function(){var z=this.r
if(z!=null)return z
z=new P.T(0,$.o,null,[null])
this.r=z
return z},
cq:function(a){var z,y
z=a.Q
y=a.z
if(z==null)this.d=y
else z.z=y
if(y==null)this.e=z
else y.Q=z
a.Q=a
a.z=a},
ek:function(a,b,c,d){var z,y,x,w
if((this.c&4)!==0){if(c==null)c=P.ex()
z=new P.jg($.o,0,c,this.$ti)
z.cs()
return z}z=$.o
y=d?1:0
x=new P.iY(0,null,null,this,null,null,null,z,y,null,null,this.$ti)
x.c2(a,b,c,d,H.F(this,0))
x.Q=x
x.z=x
x.y=this.c&1
w=this.e
this.e=x
x.z=null
x.Q=w
if(w==null)this.d=x
else w.z=x
if(this.d===x)P.eq(this.a)
return x},
e8:function(a){var z
if(a.ge5()===a)return
z=a.y
if((z&2)!==0)a.y=z|4
else{this.cq(a)
if((this.c&2)===0&&this.d==null)this.bk()}return},
e9:function(a){},
ea:function(a){},
bh:["ds",function(){if((this.c&4)!==0)return new P.t("Cannot add new events after calling close")
return new P.t("Cannot add new events while doing an addStream")}],
A:[function(a,b){if(!this.gaX())throw H.a(this.bh())
this.b3(b)},"$1","geo",2,0,function(){return H.aI(function(a){return{func:1,v:true,args:[a]}},this.$receiver,"ci")}],
cJ:function(a){var z
if((this.c&4)!==0)return this.r
if(!this.gaX())throw H.a(this.bh())
this.c|=4
z=this.dW()
this.aD()
return z},
ce:function(a){var z,y,x,w
z=this.c
if((z&2)!==0)throw H.a(new P.t("Cannot fire new event. Controller is already firing an event"))
y=this.d
if(y==null)return
x=z&1
this.c=z^3
for(;y!=null;){z=y.y
if((z&1)===x){y.y=z|2
a.$1(y)
z=y.y^=1
w=y.z
if((z&4)!==0)this.cq(y)
y.y&=4294967293
y=w}else y=y.z}this.c&=4294967293
if(this.d==null)this.bk()},
bk:function(){if((this.c&4)!==0&&this.r.a===0)this.r.bj(null)
P.eq(this.b)}},
cq:{"^":"ci;a,b,c,d,e,f,r,$ti",
gaX:function(){return P.ci.prototype.gaX.call(this)===!0&&(this.c&2)===0},
bh:function(){if((this.c&2)!==0)return new P.t("Cannot fire new event. Controller is already firing an event")
return this.ds()},
b3:function(a){var z=this.d
if(z==null)return
if(z===this.e){this.c|=2
z.az(a)
this.c&=4294967293
if(this.d==null)this.bk()
return}this.ce(new P.k5(this,a))},
aD:function(){if(this.d!=null)this.ce(new P.k6(this))
else this.r.bj(null)}},
k5:{"^":"c;a,b",
$1:function(a){a.az(this.b)},
$S:function(){return H.aI(function(a){return{func:1,args:[[P.aA,a]]}},this.a,"cq")}},
k6:{"^":"c;a",
$1:function(a){a.c5()},
$S:function(){return H.aI(function(a){return{func:1,args:[[P.aA,a]]}},this.a,"cq")}},
j2:{"^":"b;$ti",
ez:[function(a,b){var z
if(a==null)a=new P.c8()
z=this.a
if(z.a!==0)throw H.a(new P.t("Future already completed"))
$.o.toString
z.dN(a,b)},function(a){return this.ez(a,null)},"ey","$2","$1","gex",2,2,4,0]},
iQ:{"^":"j2;a,$ti",
ew:function(a,b){var z=this.a
if(z.a!==0)throw H.a(new P.t("Future already completed"))
z.bj(b)}},
cm:{"^":"b;bw:a<,b,c,d,e",
gen:function(){return this.b.b},
gcM:function(){return(this.c&1)!==0},
geT:function(){return(this.c&2)!==0},
gcL:function(){return this.c===8},
eR:function(a){return this.b.b.bR(this.d,a)},
eZ:function(a){if(this.c!==6)return!0
return this.b.b.bR(this.d,J.aM(a))},
eN:function(a){var z,y,x
z=this.e
y=J.q(a)
x=this.b.b
if(H.aJ(z,{func:1,args:[,,]}))return x.fb(z,y.gah(a),a.ga4())
else return x.bR(z,y.gah(a))},
eS:function(){return this.b.b.cX(this.d)}},
T:{"^":"b;at:a<,b,ed:c<,$ti",
ge2:function(){return this.a===2},
gbs:function(){return this.a>=4},
cZ:function(a,b){var z,y
z=$.o
if(z!==C.d){z.toString
if(b!=null)b=P.cv(b,z)}y=new P.T(0,z,null,[null])
this.aT(new P.cm(null,y,b==null?1:3,a,b))
return y},
a1:function(a){return this.cZ(a,null)},
eu:function(a,b){var z,y
z=$.o
y=new P.T(0,z,null,this.$ti)
if(z!==C.d)a=P.cv(a,z)
this.aT(new P.cm(null,y,2,b,a))
return y},
cH:function(a){return this.eu(a,null)},
ba:function(a){var z,y
z=$.o
y=new P.T(0,z,null,this.$ti)
if(z!==C.d)z.toString
this.aT(new P.cm(null,y,8,a,null))
return y},
aT:function(a){var z,y
z=this.a
if(z<=1){a.a=this.c
this.c=a}else{if(z===2){y=this.c
if(!y.gbs()){y.aT(a)
return}this.a=y.a
this.c=y.c}z=this.b
z.toString
P.ao(null,null,z,new P.jp(this,a))}},
cn:function(a){var z,y,x,w,v
z={}
z.a=a
if(a==null)return
y=this.a
if(y<=1){x=this.c
this.c=a
if(x!=null){for(w=a;w.gbw()!=null;)w=w.a
w.a=x}}else{if(y===2){v=this.c
if(!v.gbs()){v.cn(a)
return}this.a=v.a
this.c=v.c}z.a=this.b2(a)
y=this.b
y.toString
P.ao(null,null,y,new P.jw(z,this))}},
b1:function(){var z=this.c
this.c=null
return this.b2(z)},
b2:function(a){var z,y,x
for(z=a,y=null;z!=null;y=z,z=x){x=z.gbw()
z.a=y}return y},
as:function(a){var z,y
z=this.$ti
if(H.aH(a,"$isa4",z,"$asa4"))if(H.aH(a,"$isT",z,null))P.bI(a,this)
else P.e5(a,this)
else{y=this.b1()
this.a=4
this.c=a
P.aB(this,y)}},
ac:[function(a,b){var z=this.b1()
this.a=8
this.c=new P.bq(a,b)
P.aB(this,z)},function(a){return this.ac(a,null)},"fl","$2","$1","gaA",2,2,4,0],
bj:function(a){var z
if(H.aH(a,"$isa4",this.$ti,"$asa4")){this.dP(a)
return}this.a=1
z=this.b
z.toString
P.ao(null,null,z,new P.jr(this,a))},
dP:function(a){var z
if(H.aH(a,"$isT",this.$ti,null)){if(a.a===8){this.a=1
z=this.b
z.toString
P.ao(null,null,z,new P.jv(this,a))}else P.bI(a,this)
return}P.e5(a,this)},
dN:function(a,b){var z
this.a=1
z=this.b
z.toString
P.ao(null,null,z,new P.jq(this,a,b))},
dI:function(a,b){this.a=4
this.c=a},
$isa4:1,
m:{
e5:function(a,b){var z,y,x
b.a=1
try{a.cZ(new P.js(b),new P.jt(b))}catch(x){z=H.z(x)
y=H.M(x)
P.eG(new P.ju(b,z,y))}},
bI:function(a,b){var z,y,x
for(;a.ge2();)a=a.c
z=a.gbs()
y=b.c
if(z){b.c=null
x=b.b2(y)
b.a=a.a
b.c=a.c
P.aB(b,x)}else{b.a=2
b.c=a
a.cn(y)}},
aB:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n
z={}
z.a=a
for(y=a;!0;){x={}
w=y.a===8
if(b==null){if(w){v=y.c
y=y.b
u=J.aM(v)
t=v.ga4()
y.toString
P.aF(null,null,y,u,t)}return}for(;b.gbw()!=null;b=s){s=b.a
b.a=null
P.aB(z.a,b)}r=z.a.c
x.a=w
x.b=r
y=!w
if(!y||b.gcM()||b.gcL()){q=b.gen()
if(w){u=z.a.b
u.toString
u=u==null?q==null:u===q
if(!u)q.toString
else u=!0
u=!u}else u=!1
if(u){y=z.a
v=y.c
y=y.b
u=J.aM(v)
t=v.ga4()
y.toString
P.aF(null,null,y,u,t)
return}p=$.o
if(p==null?q!=null:p!==q)$.o=q
else p=null
if(b.gcL())new P.jz(z,x,w,b).$0()
else if(y){if(b.gcM())new P.jy(x,b,r).$0()}else if(b.geT())new P.jx(z,x,b).$0()
if(p!=null)$.o=p
y=x.b
if(!!J.l(y).$isa4){o=b.b
if(y.a>=4){n=o.c
o.c=null
b=o.b2(n)
o.a=y.a
o.c=y.c
z.a=y
continue}else P.bI(y,o)
return}}o=b.b
b=o.b1()
y=x.a
u=x.b
if(!y){o.a=4
o.c=u}else{o.a=8
o.c=u}z.a=o
y=o}}}},
jp:{"^":"c:1;a,b",
$0:function(){P.aB(this.a,this.b)}},
jw:{"^":"c:1;a,b",
$0:function(){P.aB(this.b,this.a.a)}},
js:{"^":"c:0;a",
$1:function(a){var z=this.a
z.a=0
z.as(a)}},
jt:{"^":"c:13;a",
$2:function(a,b){this.a.ac(a,b)},
$1:function(a){return this.$2(a,null)}},
ju:{"^":"c:1;a,b,c",
$0:function(){this.a.ac(this.b,this.c)}},
jr:{"^":"c:1;a,b",
$0:function(){var z,y
z=this.a
y=z.b1()
z.a=4
z.c=this.b
P.aB(z,y)}},
jv:{"^":"c:1;a,b",
$0:function(){P.bI(this.b,this.a)}},
jq:{"^":"c:1;a,b,c",
$0:function(){this.a.ac(this.b,this.c)}},
jz:{"^":"c:2;a,b,c,d",
$0:function(){var z,y,x,w,v,u,t
z=null
try{z=this.d.eS()}catch(w){y=H.z(w)
x=H.M(w)
if(this.c){v=J.aM(this.a.a.c)
u=y
u=v==null?u==null:v===u
v=u}else v=!1
u=this.b
if(v)u.b=this.a.a.c
else u.b=new P.bq(y,x)
u.a=!0
return}if(!!J.l(z).$isa4){if(z instanceof P.T&&z.gat()>=4){if(z.gat()===8){v=this.b
v.b=z.ged()
v.a=!0}return}t=this.a.a
v=this.b
v.b=z.a1(new P.jA(t))
v.a=!1}}},
jA:{"^":"c:0;a",
$1:function(a){return this.a}},
jy:{"^":"c:2;a,b,c",
$0:function(){var z,y,x,w
try{this.a.b=this.b.eR(this.c)}catch(x){z=H.z(x)
y=H.M(x)
w=this.a
w.b=new P.bq(z,y)
w.a=!0}}},
jx:{"^":"c:2;a,b,c",
$0:function(){var z,y,x,w,v,u,t,s
try{z=this.a.a.c
w=this.c
if(w.eZ(z)===!0&&w.e!=null){v=this.b
v.b=w.eN(z)
v.a=!1}}catch(u){y=H.z(u)
x=H.M(u)
w=this.a
v=J.aM(w.a.c)
t=y
s=this.b
if(v==null?t==null:v===t)s.b=w.a.c
else s.b=new P.bq(y,x)
s.a=!0}}},
dZ:{"^":"b;a,b"},
a_:{"^":"b;$ti",
aa:function(a,b){return new P.jO(b,this,[H.B(this,"a_",0),null])},
gh:function(a){var z,y
z={}
y=new P.T(0,$.o,null,[P.j])
z.a=0
this.N(new P.io(z),!0,new P.ip(z,y),y.gaA())
return y},
gu:function(a){var z,y
z={}
y=new P.T(0,$.o,null,[P.b1])
z.a=null
z.a=this.N(new P.il(z,y),!0,new P.im(y),y.gaA())
return y},
am:function(a){var z,y,x
z=H.B(this,"a_",0)
y=H.v([],[z])
x=new P.T(0,$.o,null,[[P.h,z]])
this.N(new P.iq(this,y),!0,new P.ir(y,x),x.gaA())
return x},
gt:function(a){var z,y
z={}
y=new P.T(0,$.o,null,[H.B(this,"a_",0)])
z.a=null
z.a=this.N(new P.ij(z,this,y),!0,new P.ik(y),y.gaA())
return y},
eM:function(a,b,c){var z,y
z={}
y=new P.T(0,$.o,null,[null])
z.a=null
z.a=this.N(new P.ih(z,this,b,y),!0,new P.ii(c,y),y.gaA())
return y},
aw:function(a,b){return this.eM(a,b,null)}},
io:{"^":"c:0;a",
$1:function(a){++this.a.a}},
ip:{"^":"c:1;a,b",
$0:function(){this.b.as(this.a.a)}},
il:{"^":"c:0;a,b",
$1:function(a){P.cs(this.a.a,this.b,!1)}},
im:{"^":"c:1;a",
$0:function(){this.a.as(!0)}},
iq:{"^":"c;a,b",
$1:function(a){this.b.push(a)},
$S:function(){return H.aI(function(a){return{func:1,args:[a]}},this.a,"a_")}},
ir:{"^":"c:1;a,b",
$0:function(){this.b.as(this.a)}},
ij:{"^":"c;a,b,c",
$1:function(a){P.cs(this.a.a,this.c,a)},
$S:function(){return H.aI(function(a){return{func:1,args:[a]}},this.b,"a_")}},
ik:{"^":"c:1;a",
$0:function(){var z,y,x,w
try{x=H.S()
throw H.a(x)}catch(w){z=H.z(w)
y=H.M(w)
P.em(this.a,z,y)}}},
ih:{"^":"c;a,b,c,d",
$1:function(a){var z,y
z=this.a
y=this.d
P.kI(new P.ie(this.c,a),new P.ig(z,y,a),P.kq(z.a,y))},
$S:function(){return H.aI(function(a){return{func:1,args:[a]}},this.b,"a_")}},
ie:{"^":"c:1;a,b",
$0:function(){return this.a.$1(this.b)}},
ig:{"^":"c:14;a,b,c",
$1:function(a){if(a===!0)P.cs(this.a.a,this.b,this.c)}},
ii:{"^":"c:1;a,b",
$0:function(){var z,y,x,w
try{x=H.S()
throw H.a(x)}catch(w){z=H.z(w)
y=H.M(w)
P.em(this.b,z,y)}}},
dG:{"^":"b;$ti"},
e1:{"^":"k1;a,$ti",
gF:function(a){return(H.ad(this.a)^892482866)>>>0},
C:function(a,b){if(b==null)return!1
if(this===b)return!0
if(!(b instanceof P.e1))return!1
return b.a===this.a}},
j3:{"^":"aA;$ti",
bx:function(){return this.x.e8(this)},
aZ:[function(){this.x.e9(this)},"$0","gaY",0,0,2],
b0:[function(){this.x.ea(this)},"$0","gb_",0,0,2]},
aA:{"^":"b;at:e<,$ti",
aN:function(a,b){var z=this.e
if((z&8)!==0)return
this.e=(z+128|4)>>>0
if(z<128&&this.r!=null)this.r.cG()
if((z&4)===0&&(this.e&32)===0)this.cg(this.gaY())},
bL:function(a){return this.aN(a,null)},
bO:function(){var z=this.e
if((z&8)!==0)return
if(z>=128){z-=128
this.e=z
if(z<128){if((z&64)!==0){z=this.r
z=!z.gu(z)}else z=!1
if(z)this.r.bc(this)
else{z=(this.e&4294967291)>>>0
this.e=z
if((z&32)===0)this.cg(this.gb_())}}}},
a0:function(){var z=(this.e&4294967279)>>>0
this.e=z
if((z&8)===0)this.bl()
z=this.f
return z==null?$.$get$au():z},
bl:function(){var z=(this.e|8)>>>0
this.e=z
if((z&64)!==0)this.r.cG()
if((this.e&32)===0)this.r=null
this.f=this.bx()},
az:["dt",function(a){var z=this.e
if((z&8)!==0)return
if(z<32)this.b3(a)
else this.bi(new P.jd(a,null,[H.B(this,"aA",0)]))}],
bg:["du",function(a,b){var z=this.e
if((z&8)!==0)return
if(z<32)this.ct(a,b)
else this.bi(new P.jf(a,b,null))}],
c5:function(){var z=this.e
if((z&8)!==0)return
z=(z|2)>>>0
this.e=z
if(z<32)this.aD()
else this.bi(C.G)},
aZ:[function(){},"$0","gaY",0,0,2],
b0:[function(){},"$0","gb_",0,0,2],
bx:function(){return},
bi:function(a){var z,y
z=this.r
if(z==null){z=new P.k2(null,null,0,[H.B(this,"aA",0)])
this.r=z}z.A(0,a)
y=this.e
if((y&64)===0){y=(y|64)>>>0
this.e=y
if(y<128)this.r.bc(this)}},
b3:function(a){var z=this.e
this.e=(z|32)>>>0
this.d.bS(this.a,a)
this.e=(this.e&4294967263)>>>0
this.bm((z&4)!==0)},
ct:function(a,b){var z,y
z=this.e
y=new P.j_(this,a,b)
if((z&1)!==0){this.e=(z|16)>>>0
this.bl()
z=this.f
if(!!J.l(z).$isa4&&z!==$.$get$au())z.ba(y)
else y.$0()}else{y.$0()
this.bm((z&4)!==0)}},
aD:function(){var z,y
z=new P.iZ(this)
this.bl()
this.e=(this.e|16)>>>0
y=this.f
if(!!J.l(y).$isa4&&y!==$.$get$au())y.ba(z)
else z.$0()},
cg:function(a){var z=this.e
this.e=(z|32)>>>0
a.$0()
this.e=(this.e&4294967263)>>>0
this.bm((z&4)!==0)},
bm:function(a){var z,y
if((this.e&64)!==0){z=this.r
z=z.gu(z)}else z=!1
if(z){z=(this.e&4294967231)>>>0
this.e=z
if((z&4)!==0)if(z<128){z=this.r
z=z==null||z.gu(z)}else z=!1
else z=!1
if(z)this.e=(this.e&4294967291)>>>0}for(;!0;a=y){z=this.e
if((z&8)!==0){this.r=null
return}y=(z&4)!==0
if(a===y)break
this.e=(z^32)>>>0
if(y)this.aZ()
else this.b0()
this.e=(this.e&4294967263)>>>0}z=this.e
if((z&64)!==0&&z<128)this.r.bc(this)},
c2:function(a,b,c,d,e){var z,y
z=a==null?P.kP():a
y=this.d
y.toString
this.a=z
this.b=P.cv(b==null?P.kQ():b,y)
this.c=c==null?P.ex():c}},
j_:{"^":"c:2;a,b,c",
$0:function(){var z,y,x,w,v,u
z=this.a
y=z.e
if((y&8)!==0&&(y&16)===0)return
z.e=(y|32)>>>0
y=z.b
x=H.aJ(y,{func:1,args:[P.b,P.ay]})
w=z.d
v=this.b
u=z.b
if(x)w.fc(u,v,this.c)
else w.bS(u,v)
z.e=(z.e&4294967263)>>>0}},
iZ:{"^":"c:2;a",
$0:function(){var z,y
z=this.a
y=z.e
if((y&16)===0)return
z.e=(y|42)>>>0
z.d.bQ(z.c)
z.e=(z.e&4294967263)>>>0}},
k1:{"^":"a_;$ti",
N:function(a,b,c,d){return this.a.ek(a,d,c,!0===b)},
b8:function(a,b,c){return this.N(a,null,b,c)}},
e3:{"^":"b;b9:a@"},
jd:{"^":"e3;b,a,$ti",
bM:function(a){a.b3(this.b)}},
jf:{"^":"e3;ah:b>,a4:c<,a",
bM:function(a){a.ct(this.b,this.c)}},
je:{"^":"b;",
bM:function(a){a.aD()},
gb9:function(){return},
sb9:function(a){throw H.a(new P.t("No events after a done."))}},
jQ:{"^":"b;at:a<",
bc:function(a){var z=this.a
if(z===1)return
if(z>=1){this.a=1
return}P.eG(new P.jR(this,a))
this.a=1},
cG:function(){if(this.a===1)this.a=3}},
jR:{"^":"c:1;a,b",
$0:function(){var z,y,x,w
z=this.a
y=z.a
z.a=0
if(y===3)return
x=z.b
w=x.gb9()
z.b=w
if(w==null)z.c=null
x.bM(this.b)}},
k2:{"^":"jQ;b,c,a,$ti",
gu:function(a){return this.c==null},
A:function(a,b){var z=this.c
if(z==null){this.c=b
this.b=b}else{z.sb9(b)
this.c=b}}},
jg:{"^":"b;a,at:b<,c,$ti",
cs:function(){if((this.b&2)!==0)return
var z=this.a
z.toString
P.ao(null,null,z,this.geg())
this.b=(this.b|2)>>>0},
aN:function(a,b){this.b+=4},
bL:function(a){return this.aN(a,null)},
bO:function(){var z=this.b
if(z>=4){z-=4
this.b=z
if(z<4&&(z&1)===0)this.cs()}},
a0:function(){return $.$get$au()},
aD:[function(){var z=(this.b&4294967293)>>>0
this.b=z
if(z>=4)return
this.b=(z|1)>>>0
z=this.c
if(z!=null)this.a.bQ(z)},"$0","geg",0,0,2]},
ks:{"^":"c:1;a,b,c",
$0:function(){return this.a.ac(this.b,this.c)}},
kr:{"^":"c:15;a,b",
$2:function(a,b){P.kp(this.a,this.b,a,b)}},
kt:{"^":"c:1;a,b",
$0:function(){return this.a.as(this.b)}},
ck:{"^":"a_;$ti",
N:function(a,b,c,d){return this.dU(a,d,c,!0===b)},
b8:function(a,b,c){return this.N(a,null,b,c)},
dU:function(a,b,c,d){return P.jo(this,a,b,c,d,H.B(this,"ck",0),H.B(this,"ck",1))},
ci:function(a,b){b.az(a)},
e0:function(a,b,c){c.bg(a,b)},
$asa_:function(a,b){return[b]}},
e4:{"^":"aA;x,y,a,b,c,d,e,f,r,$ti",
az:function(a){if((this.e&2)!==0)return
this.dt(a)},
bg:function(a,b){if((this.e&2)!==0)return
this.du(a,b)},
aZ:[function(){var z=this.y
if(z==null)return
z.bL(0)},"$0","gaY",0,0,2],
b0:[function(){var z=this.y
if(z==null)return
z.bO()},"$0","gb_",0,0,2],
bx:function(){var z=this.y
if(z!=null){this.y=null
return z.a0()}return},
fm:[function(a){this.x.ci(a,this)},"$1","gdY",2,0,function(){return H.aI(function(a,b){return{func:1,v:true,args:[a]}},this.$receiver,"e4")}],
fo:[function(a,b){this.x.e0(a,b,this)},"$2","ge_",4,0,16],
fn:[function(){this.c5()},"$0","gdZ",0,0,2],
dH:function(a,b,c,d,e,f,g){this.y=this.x.a.b8(this.gdY(),this.gdZ(),this.ge_())},
$asaA:function(a,b){return[b]},
m:{
jo:function(a,b,c,d,e,f,g){var z,y
z=$.o
y=e?1:0
y=new P.e4(a,null,null,null,null,z,y,null,null,[f,g])
y.c2(b,c,d,e,g)
y.dH(a,b,c,d,e,f,g)
return y}}},
jO:{"^":"ck;b,a,$ti",
ci:function(a,b){var z,y,x,w
z=null
try{z=this.b.$1(a)}catch(w){y=H.z(w)
x=H.M(w)
P.ko(b,y,x)
return}b.az(z)}},
bq:{"^":"b;ah:a>,a4:b<",
j:function(a){return H.e(this.a)},
$isI:1},
kn:{"^":"b;"},
kH:{"^":"c:1;a,b",
$0:function(){var z,y,x
z=this.a
y=z.a
if(y==null){x=new P.c8()
z.a=x
z=x}else z=y
y=this.b
if(y==null)throw H.a(z)
x=H.a(z)
x.stack=J.X(y)
throw x}},
jT:{"^":"kn;",
bQ:function(a){var z,y,x,w
try{if(C.d===$.o){x=a.$0()
return x}x=P.en(null,null,this,a)
return x}catch(w){z=H.z(w)
y=H.M(w)
x=P.aF(null,null,this,z,y)
return x}},
bS:function(a,b){var z,y,x,w
try{if(C.d===$.o){x=a.$1(b)
return x}x=P.ep(null,null,this,a,b)
return x}catch(w){z=H.z(w)
y=H.M(w)
x=P.aF(null,null,this,z,y)
return x}},
fc:function(a,b,c){var z,y,x,w
try{if(C.d===$.o){x=a.$2(b,c)
return x}x=P.eo(null,null,this,a,b,c)
return x}catch(w){z=H.z(w)
y=H.M(w)
x=P.aF(null,null,this,z,y)
return x}},
bD:function(a,b){if(b)return new P.jU(this,a)
else return new P.jV(this,a)},
es:function(a,b){return new P.jW(this,a)},
i:function(a,b){return},
cX:function(a){if($.o===C.d)return a.$0()
return P.en(null,null,this,a)},
bR:function(a,b){if($.o===C.d)return a.$1(b)
return P.ep(null,null,this,a,b)},
fb:function(a,b,c){if($.o===C.d)return a.$2(b,c)
return P.eo(null,null,this,a,b,c)}},
jU:{"^":"c:1;a,b",
$0:function(){return this.a.bQ(this.b)}},
jV:{"^":"c:1;a,b",
$0:function(){return this.a.cX(this.b)}},
jW:{"^":"c:0;a,b",
$1:function(a){return this.a.bS(this.b,a)}}}],["","",,P,{"^":"",
hw:function(a,b){return new H.ab(0,null,null,null,null,null,0,[a,b])},
dj:function(){return new H.ab(0,null,null,null,null,null,0,[null,null])},
a5:function(a){return H.kV(a,new H.ab(0,null,null,null,null,null,0,[null,null]))},
hb:function(a,b,c){var z,y
if(P.cu(a)){if(b==="("&&c===")")return"(...)"
return b+"..."+c}z=[]
y=$.$get$b0()
y.push(a)
try{P.kD(a,z)}finally{if(0>=y.length)return H.f(y,-1)
y.pop()}y=P.dH(b,z,", ")+c
return y.charCodeAt(0)==0?y:y},
bu:function(a,b,c){var z,y,x
if(P.cu(a))return b+"..."+c
z=new P.am(b)
y=$.$get$b0()
y.push(a)
try{x=z
x.p=P.dH(x.gp(),a,", ")}finally{if(0>=y.length)return H.f(y,-1)
y.pop()}y=z
y.p=y.gp()+c
y=z.gp()
return y.charCodeAt(0)==0?y:y},
cu:function(a){var z,y
for(z=0;y=$.$get$b0(),z<y.length;++z)if(a===y[z])return!0
return!1},
kD:function(a,b){var z,y,x,w,v,u,t,s,r,q
z=a.gw(a)
y=0
x=0
while(!0){if(!(y<80||x<3))break
if(!z.l())return
w=H.e(z.gq())
b.push(w)
y+=w.length+2;++x}if(!z.l()){if(x<=5)return
if(0>=b.length)return H.f(b,-1)
v=b.pop()
if(0>=b.length)return H.f(b,-1)
u=b.pop()}else{t=z.gq();++x
if(!z.l()){if(x<=4){b.push(H.e(t))
return}v=H.e(t)
if(0>=b.length)return H.f(b,-1)
u=b.pop()
y+=v.length+2}else{s=z.gq();++x
for(;z.l();t=s,s=r){r=z.gq();++x
if(x>100){while(!0){if(!(y>75&&x>3))break
if(0>=b.length)return H.f(b,-1)
y-=b.pop().length+2;--x}b.push("...")
return}}u=H.e(t)
v=H.e(s)
y+=v.length+u.length+4}}if(x>b.length+2){y+=5
q="..."}else q=null
while(!0){if(!(y>80&&b.length>3))break
if(0>=b.length)return H.f(b,-1)
y-=b.pop().length+2
if(q==null){y+=5
q="..."}}if(q!=null)b.push(q)
b.push(u)
b.push(v)},
Z:function(a,b,c,d){return new P.jH(0,null,null,null,null,null,0,[d])},
dk:function(a,b){var z,y,x
z=P.Z(null,null,null,b)
for(y=a.length,x=0;x<a.length;a.length===y||(0,H.a7)(a),++x)z.A(0,a[x])
return z},
dl:function(a){var z,y,x
z={}
if(P.cu(a))return"{...}"
y=new P.am("")
try{$.$get$b0().push(a)
x=y
x.p=x.gp()+"{"
z.a=!0
a.L(0,new P.hA(z,y))
z=y
z.p=z.gp()+"}"}finally{z=$.$get$b0()
if(0>=z.length)return H.f(z,-1)
z.pop()}z=y.gp()
return z.charCodeAt(0)==0?z:z},
e9:{"^":"ab;a,b,c,d,e,f,r,$ti",
aK:function(a){return H.le(a)&0x3ffffff},
aL:function(a,b){var z,y,x
if(a==null)return-1
z=a.length
for(y=0;y<z;++y){x=a[y].gcQ()
if(x==null?b==null:x===b)return y}return-1},
m:{
aX:function(a,b){return new P.e9(0,null,null,null,null,null,0,[a,b])}}},
jH:{"^":"jB;a,b,c,d,e,f,r,$ti",
gw:function(a){var z=new P.aW(this,this.r,null,null)
z.c=this.e
return z},
gh:function(a){return this.a},
gu:function(a){return this.a===0},
H:function(a,b){var z,y
if(typeof b==="string"&&b!=="__proto__"){z=this.b
if(z==null)return!1
return z[b]!=null}else if(typeof b==="number"&&(b&0x3ffffff)===b){y=this.c
if(y==null)return!1
return y[b]!=null}else return this.dT(b)},
dT:function(a){var z=this.d
if(z==null)return!1
return this.aV(z[this.aU(a)],a)>=0},
bI:function(a){var z
if(!(typeof a==="string"&&a!=="__proto__"))z=typeof a==="number"&&(a&0x3ffffff)===a
else z=!0
if(z)return this.H(0,a)?a:null
else return this.e4(a)},
e4:function(a){var z,y,x
z=this.d
if(z==null)return
y=z[this.aU(a)]
x=this.aV(y,a)
if(x<0)return
return J.aL(y,x).gcd()},
gt:function(a){var z=this.e
if(z==null)throw H.a(new P.t("No elements"))
return z.a},
A:function(a,b){var z,y,x
if(typeof b==="string"&&b!=="__proto__"){z=this.b
if(z==null){y=Object.create(null)
y["<non-identifier-key>"]=y
delete y["<non-identifier-key>"]
this.b=y
z=y}return this.c7(z,b)}else if(typeof b==="number"&&(b&0x3ffffff)===b){x=this.c
if(x==null){y=Object.create(null)
y["<non-identifier-key>"]=y
delete y["<non-identifier-key>"]
this.c=y
x=y}return this.c7(x,b)}else return this.a5(b)},
a5:function(a){var z,y,x
z=this.d
if(z==null){z=P.jJ()
this.d=z}y=this.aU(a)
x=z[y]
if(x==null)z[y]=[this.bn(a)]
else{if(this.aV(x,a)>=0)return!1
x.push(this.bn(a))}return!0},
v:function(a,b){if(typeof b==="string"&&b!=="__proto__")return this.c8(this.b,b)
else if(typeof b==="number"&&(b&0x3ffffff)===b)return this.c8(this.c,b)
else return this.by(b)},
by:function(a){var z,y,x
z=this.d
if(z==null)return!1
y=z[this.aU(a)]
x=this.aV(y,a)
if(x<0)return!1
this.c9(y.splice(x,1)[0])
return!0},
U:function(a){if(this.a>0){this.f=null
this.e=null
this.d=null
this.c=null
this.b=null
this.a=0
this.r=this.r+1&67108863}},
c7:function(a,b){if(a[b]!=null)return!1
a[b]=this.bn(b)
return!0},
c8:function(a,b){var z
if(a==null)return!1
z=a[b]
if(z==null)return!1
this.c9(z)
delete a[b]
return!0},
bn:function(a){var z,y
z=new P.jI(a,null,null)
if(this.e==null){this.f=z
this.e=z}else{y=this.f
z.c=y
y.b=z
this.f=z}++this.a
this.r=this.r+1&67108863
return z},
c9:function(a){var z,y
z=a.gdS()
y=a.b
if(z==null)this.e=y
else z.b=y
if(y==null)this.f=z
else y.c=z;--this.a
this.r=this.r+1&67108863},
aU:function(a){return J.ag(a)&0x3ffffff},
aV:function(a,b){var z,y
if(a==null)return-1
z=a.length
for(y=0;y<z;++y)if(J.C(a[y].gcd(),b))return y
return-1},
$isd:1,
$asd:null,
m:{
jJ:function(){var z=Object.create(null)
z["<non-identifier-key>"]=z
delete z["<non-identifier-key>"]
return z}}},
jI:{"^":"b;cd:a<,b,dS:c<"},
aW:{"^":"b;a,b,c,d",
gq:function(){return this.d},
l:function(){var z=this.a
if(this.b!==z.r)throw H.a(new P.R(z))
else{z=this.c
if(z==null){this.d=null
return!1}else{this.d=z.a
this.c=z.b
return!0}}}},
jB:{"^":"i8;$ti"},
aw:{"^":"hH;$ti"},
hH:{"^":"b+O;",$ash:null,$asd:null,$ish:1,$isd:1},
O:{"^":"b;$ti",
gw:function(a){return new H.c4(a,this.gh(a),0,null)},
B:function(a,b){return this.i(a,b)},
L:function(a,b){var z,y
z=this.gh(a)
for(y=0;y<z;++y){b.$1(this.i(a,y))
if(z!==this.gh(a))throw H.a(new P.R(a))}},
gu:function(a){return this.gh(a)===0},
gt:function(a){if(this.gh(a)===0)throw H.a(H.S())
return this.i(a,0)},
aa:function(a,b){return new H.bf(a,b,[H.B(a,"O",0),null])},
dk:function(a,b){return H.iv(a,b,null,H.B(a,"O",0))},
ab:function(a,b){var z,y,x
z=[H.B(a,"O",0)]
if(b){y=H.v([],z)
C.b.sh(y,this.gh(a))}else y=H.v(new Array(this.gh(a)),z)
for(x=0;x<this.gh(a);++x){z=this.i(a,x)
if(x>=y.length)return H.f(y,x)
y[x]=z}return y},
am:function(a){return this.ab(a,!0)},
v:function(a,b){var z
for(z=0;z<this.gh(a);++z)if(J.C(this.i(a,z),b)){this.D(a,z,this.gh(a)-1,a,z+1)
this.sh(a,this.gh(a)-1)
return!0}return!1},
av:function(a,b,c,d){var z
P.a1(b,c,this.gh(a),null,null,null)
for(z=b;z<c;++z)this.n(a,z,d)},
D:["c1",function(a,b,c,d,e){var z,y,x,w,v
P.a1(b,c,this.gh(a),null,null,null)
z=c-b
if(z===0)return
if(e<0)H.w(P.x(e,0,null,"skipCount",null))
if(H.aH(d,"$ish",[H.B(a,"O",0)],"$ash")){y=e
x=d}else{x=J.f0(d,e).ab(0,!1)
y=0}w=J.y(x)
if(y+z>w.gh(x))throw H.a(H.dg())
if(y<b)for(v=z-1;v>=0;--v)this.n(a,b+v,w.i(x,y+v))
else for(v=0;v<z;++v)this.n(a,b+v,w.i(x,y+v))},function(a,b,c,d){return this.D(a,b,c,d,0)},"T",null,null,"gfj",6,2,null,1],
R:function(a,b,c,d){var z,y,x,w,v
P.a1(b,c,this.gh(a),null,null,null)
d=C.a.am(d)
if(typeof c!=="number")return c.ar()
z=c-b
y=d.length
x=b+y
if(z>=y){w=z-y
v=this.gh(a)-w
this.T(a,b,x,d)
if(w!==0){this.D(a,x,v,a,c)
this.sh(a,v)}}else{v=this.gh(a)+(y-z)
this.sh(a,v)
this.D(a,x,v,a,c)
this.T(a,b,x,d)}},
b5:function(a,b,c){var z
if(c>=this.gh(a))return-1
if(c<0)c=0
for(z=c;z<this.gh(a);++z)if(J.C(this.i(a,z),b))return z
return-1},
j:function(a){return P.bu(a,"[","]")},
$ish:1,
$ash:null,
$isd:1,
$asd:null},
hA:{"^":"c:17;a,b",
$2:function(a,b){var z,y
z=this.a
if(!z.a)this.b.p+=", "
z.a=!1
z=this.b
y=z.p+=H.e(a)
z.p=y+": "
z.p+=H.e(b)}},
hx:{"^":"ak;a,b,c,d,$ti",
gw:function(a){return new P.jK(this,this.c,this.d,this.b,null)},
gu:function(a){return this.b===this.c},
gh:function(a){return(this.c-this.b&this.a.length-1)>>>0},
gt:function(a){var z,y
z=this.b
if(z===this.c)throw H.a(H.S())
y=this.a
if(z>=y.length)return H.f(y,z)
return y[z]},
B:function(a,b){var z,y,x,w
z=(this.c-this.b&this.a.length-1)>>>0
if(typeof b!=="number")return H.p(b)
if(0>b||b>=z)H.w(P.Y(b,this,"index",null,z))
y=this.a
x=y.length
w=(this.b+b&x-1)>>>0
if(w<0||w>=x)return H.f(y,w)
return y[w]},
v:function(a,b){var z,y
for(z=this.b;z!==this.c;z=(z+1&this.a.length-1)>>>0){y=this.a
if(z<0||z>=y.length)return H.f(y,z)
if(J.C(y[z],b)){this.by(z);++this.d
return!0}}return!1},
U:function(a){var z,y,x,w,v
z=this.b
y=this.c
if(z!==y){for(x=this.a,w=x.length,v=w-1;z!==y;z=(z+1&v)>>>0){if(z<0||z>=w)return H.f(x,z)
x[z]=null}this.c=0
this.b=0;++this.d}},
j:function(a){return P.bu(this,"{","}")},
cV:function(){var z,y,x,w
z=this.b
if(z===this.c)throw H.a(H.S());++this.d
y=this.a
x=y.length
if(z>=x)return H.f(y,z)
w=y[z]
y[z]=null
this.b=(z+1&x-1)>>>0
return w},
a5:function(a){var z,y,x
z=this.a
y=this.c
x=z.length
if(y<0||y>=x)return H.f(z,y)
z[y]=a
x=(y+1&x-1)>>>0
this.c=x
if(this.b===x)this.cf();++this.d},
by:function(a){var z,y,x,w,v,u,t,s
z=this.a
y=z.length
x=y-1
w=this.b
v=this.c
if((a-w&x)>>>0<(v-a&x)>>>0){for(u=a;u!==w;u=t){t=(u-1&x)>>>0
if(t<0||t>=y)return H.f(z,t)
v=z[t]
if(u<0||u>=y)return H.f(z,u)
z[u]=v}if(w>=y)return H.f(z,w)
z[w]=null
this.b=(w+1&x)>>>0
return(a+1&x)>>>0}else{w=(v-1&x)>>>0
this.c=w
for(u=a;u!==w;u=s){s=(u+1&x)>>>0
if(s<0||s>=y)return H.f(z,s)
v=z[s]
if(u<0||u>=y)return H.f(z,u)
z[u]=v}if(w<0||w>=y)return H.f(z,w)
z[w]=null
return a}},
cf:function(){var z,y,x,w
z=new Array(this.a.length*2)
z.fixed$length=Array
y=H.v(z,this.$ti)
z=this.a
x=this.b
w=z.length-x
C.b.D(y,0,w,z,x)
C.b.D(y,w,w+this.b,this.a,0)
this.b=0
this.c=this.a.length
this.a=y},
dB:function(a,b){var z=new Array(8)
z.fixed$length=Array
this.a=H.v(z,[b])},
$asd:null,
m:{
c5:function(a,b){var z=new P.hx(null,0,0,0,[b])
z.dB(a,b)
return z}}},
jK:{"^":"b;a,b,c,d,e",
gq:function(){return this.e},
l:function(){var z,y,x
z=this.a
if(this.c!==z.d)H.w(new P.R(z))
y=this.d
if(y===this.b){this.e=null
return!1}z=z.a
x=z.length
if(y>=x)return H.f(z,y)
this.e=z[y]
this.d=(y+1&x-1)>>>0
return!0}},
i9:{"^":"b;$ti",
gu:function(a){return this.a===0},
a8:function(a,b){var z
for(z=J.ah(b);z.l();)this.A(0,z.gq())},
aa:function(a,b){return new H.bZ(this,b,[H.F(this,0),null])},
j:function(a){return P.bu(this,"{","}")},
ak:function(a,b){var z,y
z=new P.aW(this,this.r,null,null)
z.c=this.e
if(!z.l())return""
if(b===""){y=""
do y+=H.e(z.d)
while(z.l())}else{y=H.e(z.d)
for(;z.l();)y=y+b+H.e(z.d)}return y.charCodeAt(0)==0?y:y},
gt:function(a){var z=new P.aW(this,this.r,null,null)
z.c=this.e
if(!z.l())throw H.a(H.S())
return z.d},
B:function(a,b){var z,y,x
if(typeof b!=="number"||Math.floor(b)!==b)throw H.a(P.b7("index"))
if(b<0)H.w(P.x(b,0,null,"index",null))
for(z=new P.aW(this,this.r,null,null),z.c=this.e,y=0;z.l();){x=z.d
if(b===y)return x;++y}throw H.a(P.Y(b,this,"index",null,y))},
$isd:1,
$asd:null},
i8:{"^":"i9;$ti"}}],["","",,P,{"^":"",
bK:function(a){var z
if(a==null)return
if(typeof a!="object")return a
if(Object.getPrototypeOf(a)!==Array.prototype)return new P.jE(a,Object.create(null),null)
for(z=0;z<a.length;++z)a[z]=P.bK(a[z])
return a},
kG:function(a,b){var z,y,x,w
if(typeof a!=="string")throw H.a(H.E(a))
z=null
try{z=JSON.parse(a)}catch(x){y=H.z(x)
w=String(y)
throw H.a(new P.J(w,null,null))}w=P.bK(z)
return w},
jE:{"^":"b;a,b,c",
i:function(a,b){var z,y
z=this.b
if(z==null)return this.c.i(0,b)
else if(typeof b!=="string")return
else{y=z[b]
return typeof y=="undefined"?this.e7(b):y}},
gh:function(a){var z
if(this.b==null){z=this.c
z=z.gh(z)}else z=this.a6().length
return z},
gu:function(a){var z
if(this.b==null){z=this.c
z=z.gh(z)}else z=this.a6().length
return z===0},
gK:function(){if(this.b==null)return this.c.gK()
return new P.jF(this)},
ga2:function(a){var z
if(this.b==null){z=this.c
return z.ga2(z)}return H.be(this.a6(),new P.jG(this),null,null)},
n:function(a,b,c){var z,y
if(this.b==null)this.c.n(0,b,c)
else if(this.J(b)){z=this.b
z[b]=c
y=this.a
if(y==null?z!=null:y!==z)y[b]=null}else this.cC().n(0,b,c)},
J:function(a){if(this.b==null)return this.c.J(a)
if(typeof a!=="string")return!1
return Object.prototype.hasOwnProperty.call(this.a,a)},
v:function(a,b){if(this.b!=null&&!this.J(b))return
return this.cC().v(0,b)},
L:function(a,b){var z,y,x,w
if(this.b==null)return this.c.L(0,b)
z=this.a6()
for(y=0;y<z.length;++y){x=z[y]
w=this.b[x]
if(typeof w=="undefined"){w=P.bK(this.a[x])
this.b[x]=w}b.$2(x,w)
if(z!==this.c)throw H.a(new P.R(this))}},
j:function(a){return P.dl(this)},
a6:function(){var z=this.c
if(z==null){z=Object.keys(this.a)
this.c=z}return z},
cC:function(){var z,y,x,w,v
if(this.b==null)return this.c
z=P.hw(P.n,null)
y=this.a6()
for(x=0;w=y.length,x<w;++x){v=y[x]
z.n(0,v,this.i(0,v))}if(w===0)y.push(null)
else C.b.sh(y,0)
this.b=null
this.a=null
this.c=z
return z},
e7:function(a){var z
if(!Object.prototype.hasOwnProperty.call(this.a,a))return
z=P.bK(this.a[a])
return this.b[a]=z}},
jG:{"^":"c:0;a",
$1:function(a){return this.a.i(0,a)}},
jF:{"^":"ak;a",
gh:function(a){var z=this.a
if(z.b==null){z=z.c
z=z.gh(z)}else z=z.a6().length
return z},
B:function(a,b){var z=this.a
if(z.b==null)z=z.gK().B(0,b)
else{z=z.a6()
if(b>>>0!==b||b>=z.length)return H.f(z,b)
z=z[b]}return z},
gw:function(a){var z=this.a
if(z.b==null){z=z.gK()
z=z.gw(z)}else{z=z.a6()
z=new J.bp(z,z.length,0,null)}return z},
$asak:function(){return[P.n]},
$asd:function(){return[P.n]},
$asH:function(){return[P.n]}},
f5:{"^":"cS;a",
f1:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i
z=J.y(a)
c=P.a1(b,c,z.gh(a),null,null,null)
y=$.$get$e_()
if(typeof c!=="number")return H.p(c)
x=b
w=x
v=null
u=-1
t=-1
s=0
for(;x<c;x=r){r=x+1
q=z.G(a,x)
if(q===37){p=r+2
if(p<=c){o=H.bO(C.a.E(a,r))
n=H.bO(C.a.E(a,r+1))
m=o*16+n-(n&256)
if(m===37)m=-1
r=p}else m=-1}else m=q
if(0<=m&&m<=127){if(m<0||m>=y.length)return H.f(y,m)
l=y[m]
if(l>=0){m=C.a.G("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",l)
if(m===q)continue
q=m}else{if(l===-1){if(u<0){k=v==null?v:v.p.length
if(k==null)k=0
if(typeof k!=="number")return k.P()
u=k+(x-w)
t=x}++s
if(q===61)continue}q=m}if(l!==-2){if(v==null)v=new P.am("")
v.p+=C.a.k(a,w,x)
v.p+=H.dB(q)
w=r
continue}}throw H.a(new P.J("Invalid base64 data",a,x))}if(v!=null){z=v.p+=z.k(a,w,c)
k=z.length
if(u>=0)P.cN(a,t,c,u,s,k)
else{j=C.c.bb(k-1,4)+1
if(j===1)throw H.a(new P.J("Invalid base64 encoding length ",a,c))
for(;j<4;){z+="="
v.p=z;++j}}z=v.p
return C.a.R(a,b,c,z.charCodeAt(0)==0?z:z)}i=c-b
if(u>=0)P.cN(a,t,c,u,s,i)
else{j=C.e.bb(i,4)
if(j===1)throw H.a(new P.J("Invalid base64 encoding length ",a,c))
if(j>1)a=z.R(a,c,c,j===2?"==":"=")}return a},
m:{
cN:function(a,b,c,d,e,f){if(C.e.bb(f,4)!==0)throw H.a(new P.J("Invalid base64 padding, padded length must be multiple of four, is "+H.e(f),a,c))
if(d+e!==f)throw H.a(new P.J("Invalid base64 padding, '=' not at the end",a,b))
if(e>2)throw H.a(new P.J("Invalid base64 padding, more than two '=' characters",a,b))}}},
f6:{"^":"bs;a",
$asbs:function(){return[[P.h,P.j],P.n]}},
cS:{"^":"b;"},
bs:{"^":"b;$ti"},
hn:{"^":"cS;a,b",
eF:function(a,b){var z=P.kG(a,this.geG().a)
return z},
eE:function(a){return this.eF(a,null)},
geG:function(){return C.W}},
ho:{"^":"bs;a",
$asbs:function(){return[P.n,P.b]}}}],["","",,P,{"^":"",
it:function(a,b,c){var z,y,x,w
if(b<0)throw H.a(P.x(b,0,a.length,null,null))
z=c==null
if(!z&&c<b)throw H.a(P.x(c,b,a.length,null,null))
y=J.ah(a)
for(x=0;x<b;++x)if(!y.l())throw H.a(P.x(b,0,x,null,null))
w=[]
if(z)for(;y.l();)w.push(y.gq())
else for(x=b;x<c;++x){if(!y.l())throw H.a(P.x(c,b,x,null,null))
w.push(y.gq())}return H.dC(w)},
d6:function(a){if(typeof a==="number"||typeof a==="boolean"||null==a)return J.X(a)
if(typeof a==="string")return JSON.stringify(a)
return P.fn(a)},
fn:function(a){var z=J.l(a)
if(!!z.$isc)return z.j(a)
return H.bz(a)},
bt:function(a){return new P.jn(a)},
ax:function(a,b,c){var z,y
z=H.v([],[c])
for(y=J.ah(a);y.l();)z.push(y.gq())
if(b)return z
z.fixed$length=Array
return z},
hy:function(a,b,c,d){var z,y,x
z=H.v([],[d])
C.b.sh(z,a)
for(y=0;y<a;++y){x=b.$1(y)
if(y>=z.length)return H.f(z,y)
z[y]=x}return z},
bn:function(a){H.lg(H.e(a))},
i6:function(a,b,c){return new H.hj(a,H.hk(a,!1,!0,!1),null,null)},
is:function(a,b,c){var z,y
if(typeof a==="object"&&a!==null&&a.constructor===Array){z=a.length
c=P.a1(b,c,z,null,null,null)
if(b<=0){if(typeof c!=="number")return c.I()
y=c<z}else y=!0
return H.dC(y?C.b.dm(a,b,c):a)}if(!!J.l(a).$isds)return H.hZ(a,b,P.a1(b,c,a.length,null,null,null))
return P.it(a,b,c)},
cf:function(){var z=H.hX()
if(z!=null)return P.iK(z,0,null)
throw H.a(new P.k("'Uri.base' is not supported"))},
iK:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n,m
c=a.length
z=b+5
if(c>=z){y=((C.a.E(a,b+4)^58)*3|C.a.E(a,b)^100|C.a.E(a,b+1)^97|C.a.E(a,b+2)^116|C.a.E(a,b+3)^97)>>>0
if(y===0)return P.dX(b>0||c<c?C.a.k(a,b,c):a,5,null).gd1()
else if(y===32)return P.dX(C.a.k(a,z,c),0,null).gd1()}x=H.v(new Array(8),[P.j])
x[0]=0
w=b-1
x[1]=w
x[2]=w
x[7]=w
x[3]=b
x[4]=b
x[5]=c
x[6]=c
if(P.er(a,b,c,0,x)>=14)x[7]=c
v=x[1]
if(typeof v!=="number")return v.aQ()
if(v>=b)if(P.er(a,b,v,20,x)===20)x[7]=v
w=x[2]
if(typeof w!=="number")return w.P()
u=w+1
t=x[3]
s=x[4]
r=x[5]
q=x[6]
if(typeof q!=="number")return q.I()
if(typeof r!=="number")return H.p(r)
if(q<r)r=q
if(typeof s!=="number")return s.I()
if(s<u||s<=v)s=r
if(typeof t!=="number")return t.I()
if(t<u)t=s
w=x[7]
if(typeof w!=="number")return w.I()
p=w<b
if(p)if(u>v+3){o=null
p=!1}else{w=t>b
if(w&&t+1===s){o=null
p=!1}else{if(!(r<c&&r===s+2&&C.a.X(a,"..",s)))n=r>s+2&&C.a.X(a,"/..",r-3)
else n=!0
if(n){o=null
p=!1}else{if(v===b+4)if(C.a.X(a,"file",b)){if(u<=b){if(!C.a.X(a,"/",s)){m="file:///"
y=3}else{m="file://"
y=2}a=m+C.a.k(a,s,c)
v-=b
z=y-b
r+=z
q+=z
c=a.length
b=0
u=7
t=7
s=7}else if(s===r)if(b===0&&!0){a=C.a.R(a,s,r,"/");++r;++q;++c}else{a=C.a.k(a,b,s)+"/"+C.a.k(a,r,c)
v-=b
u-=b
t-=b
s-=b
z=1-b
r+=z
q+=z
c=a.length
b=0}o="file"}else if(C.a.X(a,"http",b)){if(w&&t+3===s&&C.a.X(a,"80",t+1))if(b===0&&!0){a=C.a.R(a,t,s,"")
s-=3
r-=3
q-=3
c-=3}else{a=C.a.k(a,b,t)+C.a.k(a,s,c)
v-=b
u-=b
t-=b
z=3+b
s-=z
r-=z
q-=z
c=a.length
b=0}o="http"}else o=null
else if(v===z&&C.a.X(a,"https",b)){if(w&&t+4===s&&C.a.X(a,"443",t+1))if(b===0&&!0){a=C.a.R(a,t,s,"")
s-=4
r-=4
q-=4
c-=3}else{a=C.a.k(a,b,t)+C.a.k(a,s,c)
v-=b
u-=b
t-=b
z=4+b
s-=z
r-=z
q-=z
c=a.length
b=0}o="https"}else o=null
p=!0}}}else o=null
if(p){if(b>0||c<a.length){a=C.a.k(a,b,c)
v-=b
u-=b
t-=b
s-=b
r-=b
q-=b}return new P.k0(a,v,u,t,s,r,q,o,null)}return P.k9(a,b,c,v,u,t,s,r,q,o)},
iI:function(a,b,c){var z,y,x,w,v,u,t,s,r
z=new P.iJ(a)
y=H.el(4)
x=new Uint8Array(y)
for(w=b,v=w,u=0;w<c;++w){t=C.a.G(a,w)
if(t!==46){if((t^48)>9)z.$2("invalid character",w)}else{if(u===3)z.$2("IPv4 address should contain exactly 4 parts",w)
s=H.al(C.a.k(a,v,w),null,null)
if(J.bT(s,255))z.$2("each part must be in the range 0..255",v)
r=u+1
if(u>=y)return H.f(x,u)
x[u]=s
v=w+1
u=r}}if(u!==3)z.$2("IPv4 address should contain exactly 4 parts",c)
s=H.al(C.a.k(a,v,c),null,null)
if(J.bT(s,255))z.$2("each part must be in the range 0..255",v)
if(u>=y)return H.f(x,u)
x[u]=s
return x},
dY:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i
if(c==null)c=a.length
z=new P.iL(a)
y=new P.iM(a,z)
if(a.length<2)z.$1("address is too short")
x=[]
for(w=b,v=w,u=!1,t=!1;w<c;++w){s=C.a.G(a,w)
if(s===58){if(w===b){++w
if(C.a.G(a,w)!==58)z.$2("invalid start colon.",w)
v=w}if(w===v){if(u)z.$2("only one wildcard `::` is allowed",w)
x.push(-1)
u=!0}else x.push(y.$2(v,w))
v=w+1}else if(s===46)t=!0}if(x.length===0)z.$1("too few parts")
r=v===c
q=J.C(C.b.gb6(x),-1)
if(r&&!q)z.$2("expected a part after last `:`",c)
if(!r)if(!t)x.push(y.$2(v,c))
else{p=P.iI(a,v,c)
o=p[0]
if(typeof o!=="number")return o.be()
n=p[1]
if(typeof n!=="number")return H.p(n)
x.push((o<<8|n)>>>0)
n=p[2]
if(typeof n!=="number")return n.be()
o=p[3]
if(typeof o!=="number")return H.p(o)
x.push((n<<8|o)>>>0)}if(u){if(x.length>7)z.$1("an address with a wildcard must have less than 7 parts")}else if(x.length!==8)z.$1("an address without a wildcard must contain exactly 8 parts")
m=new Uint8Array(16)
for(w=0,l=0;w<x.length;++w){k=x[w]
if(J.l(k).C(k,-1)){j=9-x.length
for(i=0;i<j;++i){if(l<0||l>=16)return H.f(m,l)
m[l]=0
o=l+1
if(o>=16)return H.f(m,o)
m[o]=0
l+=2}}else{if(typeof k!=="number")return k.dj()
o=C.e.ae(k,8)
if(l<0||l>=16)return H.f(m,l)
m[l]=o
o=l+1
if(o>=16)return H.f(m,o)
m[o]=k&255
l+=2}}return m},
kw:function(){var z,y,x,w,v
z=P.hy(22,new P.ky(),!0,P.bg)
y=new P.kx(z)
x=new P.kz()
w=new P.kA()
v=y.$2(0,225)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",1)
x.$3(v,".",14)
x.$3(v,":",34)
x.$3(v,"/",3)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(14,225)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",1)
x.$3(v,".",15)
x.$3(v,":",34)
x.$3(v,"/",234)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(15,225)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",1)
x.$3(v,"%",225)
x.$3(v,":",34)
x.$3(v,"/",9)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(1,225)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",1)
x.$3(v,":",34)
x.$3(v,"/",10)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(2,235)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",139)
x.$3(v,"/",131)
x.$3(v,".",146)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(3,235)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",11)
x.$3(v,"/",68)
x.$3(v,".",18)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(4,229)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",5)
w.$3(v,"AZ",229)
x.$3(v,":",102)
x.$3(v,"@",68)
x.$3(v,"[",232)
x.$3(v,"/",138)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(5,229)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",5)
w.$3(v,"AZ",229)
x.$3(v,":",102)
x.$3(v,"@",68)
x.$3(v,"/",138)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(6,231)
w.$3(v,"19",7)
x.$3(v,"@",68)
x.$3(v,"/",138)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(7,231)
w.$3(v,"09",7)
x.$3(v,"@",68)
x.$3(v,"/",138)
x.$3(v,"?",172)
x.$3(v,"#",205)
x.$3(y.$2(8,8),"]",5)
v=y.$2(9,235)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",11)
x.$3(v,".",16)
x.$3(v,"/",234)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(16,235)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",11)
x.$3(v,".",17)
x.$3(v,"/",234)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(17,235)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",11)
x.$3(v,"/",9)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(10,235)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",11)
x.$3(v,".",18)
x.$3(v,"/",234)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(18,235)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",11)
x.$3(v,".",19)
x.$3(v,"/",234)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(19,235)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",11)
x.$3(v,"/",234)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(11,235)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",11)
x.$3(v,"/",10)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(12,236)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",12)
x.$3(v,"?",12)
x.$3(v,"#",205)
v=y.$2(13,237)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",13)
x.$3(v,"?",13)
w.$3(y.$2(20,245),"az",21)
v=y.$2(21,245)
w.$3(v,"az",21)
w.$3(v,"09",21)
x.$3(v,"+-.",21)
return z},
er:function(a,b,c,d,e){var z,y,x,w,v,u
z=$.$get$es()
for(y=b;y<c;++y){if(d<0||d>=z.length)return H.f(z,d)
x=z[d]
w=C.a.E(a,y)^96
v=J.aL(x,w>95?31:w)
if(typeof v!=="number")return v.fh()
d=v&31
u=C.e.ae(v,5)
if(u>=8)return H.f(e,u)
e[u]=y}return d},
b1:{"^":"b;"},
"+bool":0,
ap:{"^":"bm;"},
"+double":0,
a9:{"^":"b;a",
P:function(a,b){return new P.a9(C.c.P(this.a,b.gcc()))},
I:function(a,b){return C.c.I(this.a,b.gcc())},
ao:function(a,b){return C.c.ao(this.a,b.gcc())},
C:function(a,b){if(b==null)return!1
if(!(b instanceof P.a9))return!1
return this.a===b.a},
gF:function(a){return this.a&0x1FFFFFFF},
j:function(a){var z,y,x,w,v
z=new P.fj()
y=this.a
if(y<0)return"-"+new P.a9(0-y).j(0)
x=z.$1(C.c.a7(y,6e7)%60)
w=z.$1(C.c.a7(y,1e6)%60)
v=new P.fi().$1(y%1e6)
return""+C.c.a7(y,36e8)+":"+H.e(x)+":"+H.e(w)+"."+H.e(v)}},
fi:{"^":"c:6;",
$1:function(a){if(a>=1e5)return""+a
if(a>=1e4)return"0"+a
if(a>=1000)return"00"+a
if(a>=100)return"000"+a
if(a>=10)return"0000"+a
return"00000"+a}},
fj:{"^":"c:6;",
$1:function(a){if(a>=10)return""+a
return"0"+a}},
I:{"^":"b;",
ga4:function(){return H.M(this.$thrownJsError)}},
c8:{"^":"I;",
j:function(a){return"Throw of null."}},
a8:{"^":"I;a,b,c,d",
gbp:function(){return"Invalid argument"+(!this.a?"(s)":"")},
gbo:function(){return""},
j:function(a){var z,y,x,w,v,u
z=this.c
y=z!=null?" ("+z+")":""
z=this.d
x=z==null?"":": "+H.e(z)
w=this.gbp()+y+x
if(!this.a)return w
v=this.gbo()
u=P.d6(this.b)
return w+v+": "+H.e(u)},
m:{
aP:function(a){return new P.a8(!1,null,null,a)},
aQ:function(a,b,c){return new P.a8(!0,a,b,c)},
b7:function(a){return new P.a8(!1,null,a,"Must not be null")}}},
cc:{"^":"a8;e,f,a,b,c,d",
gbp:function(){return"RangeError"},
gbo:function(){var z,y,x
z=this.e
if(z==null){z=this.f
y=z!=null?": Not less than or equal to "+H.e(z):""}else{x=this.f
if(x==null)y=": Not greater than or equal to "+H.e(z)
else{if(typeof x!=="number")return x.ao()
if(x>z)y=": Not in range "+H.e(z)+".."+H.e(x)+", inclusive"
else y=x<z?": Valid value range is empty":": Only valid value is "+H.e(z)}}return y},
m:{
i2:function(a){return new P.cc(null,null,!1,null,null,a)},
bC:function(a,b,c){return new P.cc(null,null,!0,a,b,"Value not in range")},
x:function(a,b,c,d,e){return new P.cc(b,c,!0,a,d,"Invalid value")},
a1:function(a,b,c,d,e,f){var z
if(typeof a!=="number")return H.p(a)
if(!(0>a)){if(typeof c!=="number")return H.p(c)
z=a>c}else z=!0
if(z)throw H.a(P.x(a,0,c,"start",f))
if(b!=null){if(typeof b!=="number")return H.p(b)
if(!(a>b)){if(typeof c!=="number")return H.p(c)
z=b>c}else z=!0
if(z)throw H.a(P.x(b,a,c,"end",f))
return b}return c}}},
fO:{"^":"a8;e,h:f>,a,b,c,d",
gbp:function(){return"RangeError"},
gbo:function(){if(J.cE(this.b,0))return": index must not be negative"
var z=this.f
if(z===0)return": no indices are valid"
return": index should be less than "+H.e(z)},
m:{
Y:function(a,b,c,d,e){var z=e!=null?e:J.Q(b)
return new P.fO(b,z,!0,a,c,"Index out of range")}}},
k:{"^":"I;a",
j:function(a){return"Unsupported operation: "+this.a}},
bh:{"^":"I;a",
j:function(a){var z=this.a
return z!=null?"UnimplementedError: "+H.e(z):"UnimplementedError"}},
t:{"^":"I;a",
j:function(a){return"Bad state: "+this.a}},
R:{"^":"I;a",
j:function(a){var z=this.a
if(z==null)return"Concurrent modification during iteration."
return"Concurrent modification during iteration: "+H.e(P.d6(z))+"."}},
hI:{"^":"b;",
j:function(a){return"Out of Memory"},
ga4:function(){return},
$isI:1},
dF:{"^":"b;",
j:function(a){return"Stack Overflow"},
ga4:function(){return},
$isI:1},
fg:{"^":"I;a",
j:function(a){var z=this.a
return z==null?"Reading static variable during its initialization":"Reading static variable '"+H.e(z)+"' during its initialization"}},
jn:{"^":"b;a",
j:function(a){var z=this.a
if(z==null)return"Exception"
return"Exception: "+H.e(z)}},
J:{"^":"b;a,b,c",
j:function(a){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l
z=this.a
y=z!=null&&""!==z?"FormatException: "+H.e(z):"FormatException"
x=this.c
w=this.b
if(typeof w!=="string")return x!=null?y+(" (at offset "+H.e(x)+")"):y
if(x!=null){if(typeof x!=="number")return x.I()
z=x<0||x>w.length}else z=!1
if(z)x=null
if(x==null){if(w.length>78)w=C.a.k(w,0,75)+"..."
return y+"\n"+w}if(typeof x!=="number")return H.p(x)
v=1
u=0
t=!1
s=0
for(;s<x;++s){r=C.a.E(w,s)
if(r===10){if(u!==s||!t)++v
u=s+1
t=!1}else if(r===13){++v
u=s+1
t=!0}}y=v>1?y+(" (at line "+v+", character "+H.e(x-u+1)+")\n"):y+(" (at character "+H.e(x+1)+")\n")
q=w.length
for(s=x;s<w.length;++s){r=C.a.G(w,s)
if(r===10||r===13){q=s
break}}if(q-u>78)if(x-u<75){p=u+75
o=u
n=""
m="..."}else{if(q-x<75){o=q-75
p=q
m=""}else{o=x-36
p=x+36
m="..."}n="..."}else{p=q
o=u
n=""
m=""}l=C.a.k(w,o,p)
return y+n+l+m+"\n"+C.a.d7(" ",x-o+n.length)+"^\n"}},
fo:{"^":"b;a,cl",
j:function(a){return"Expando:"+H.e(this.a)},
i:function(a,b){var z,y
z=this.cl
if(typeof z!=="string"){if(b==null||typeof b==="boolean"||typeof b==="number"||typeof b==="string")H.w(P.aQ(b,"Expandos are not allowed on strings, numbers, booleans or null",null))
return z.get(b)}y=H.cb(b,"expando$values")
return y==null?null:H.cb(y,z)},
n:function(a,b,c){var z,y
z=this.cl
if(typeof z!=="string")z.set(b,c)
else{y=H.cb(b,"expando$values")
if(y==null){y=new P.b()
H.dA(b,"expando$values",y)}H.dA(y,z,c)}}},
j:{"^":"bm;"},
"+int":0,
H:{"^":"b;$ti",
aa:function(a,b){return H.be(this,b,H.B(this,"H",0),null)},
bU:["dq",function(a,b){return new H.cg(this,b,[H.B(this,"H",0)])}],
ab:function(a,b){return P.ax(this,!0,H.B(this,"H",0))},
am:function(a){return this.ab(a,!0)},
gh:function(a){var z,y
z=this.gw(this)
for(y=0;z.l();)++y
return y},
gu:function(a){return!this.gw(this).l()},
gt:function(a){var z=this.gw(this)
if(!z.l())throw H.a(H.S())
return z.gq()},
gaq:function(a){var z,y
z=this.gw(this)
if(!z.l())throw H.a(H.S())
y=z.gq()
if(z.l())throw H.a(H.hc())
return y},
aH:function(a,b,c){var z,y
for(z=this.gw(this);z.l();){y=z.gq()
if(b.$1(y)===!0)return y}throw H.a(H.S())},
aw:function(a,b){return this.aH(a,b,null)},
B:function(a,b){var z,y,x
if(typeof b!=="number"||Math.floor(b)!==b)throw H.a(P.b7("index"))
if(b<0)H.w(P.x(b,0,null,"index",null))
for(z=this.gw(this),y=0;z.l();){x=z.gq()
if(b===y)return x;++y}throw H.a(P.Y(b,this,"index",null,y))},
j:function(a){return P.hb(this,"(",")")}},
bv:{"^":"b;"},
h:{"^":"b;$ti",$ash:null,$isd:1,$asd:null},
"+List":0,
by:{"^":"b;",
gF:function(a){return P.b.prototype.gF.call(this,this)},
j:function(a){return"null"}},
"+Null":0,
bm:{"^":"b;"},
"+num":0,
b:{"^":";",
C:function(a,b){return this===b},
gF:function(a){return H.ad(this)},
j:function(a){return H.bz(this)},
toString:function(){return this.j(this)}},
ay:{"^":"b;"},
n:{"^":"b;"},
"+String":0,
am:{"^":"b;p<",
gh:function(a){return this.p.length},
gu:function(a){return this.p.length===0},
j:function(a){var z=this.p
return z.charCodeAt(0)==0?z:z},
m:{
dH:function(a,b,c){var z=J.ah(b)
if(!z.l())return a
if(c.length===0){do a+=H.e(z.gq())
while(z.l())}else{a+=H.e(z.gq())
for(;z.l();)a=a+c+H.e(z.gq())}return a}}},
iJ:{"^":"c:18;a",
$2:function(a,b){throw H.a(new P.J("Illegal IPv4 address, "+a,this.a,b))}},
iL:{"^":"c:19;a",
$2:function(a,b){throw H.a(new P.J("Illegal IPv6 address, "+a,this.a,b))},
$1:function(a){return this.$2(a,null)}},
iM:{"^":"c:20;a,b",
$2:function(a,b){var z,y
if(b-a>4)this.b.$2("an IPv6 part can only contain a maximum of 4 hex digits",a)
z=H.al(C.a.k(this.a,a,b),16,null)
y=J.cy(z)
if(y.I(z,0)||y.ao(z,65535))this.b.$2("each part must be in the range of `0x0..0xFFFF`",a)
return z}},
ec:{"^":"b;bZ:a<,b,c,d,bK:e>,f,r,x,y,z,Q,ch",
gd3:function(){return this.b},
gaI:function(a){var z=this.c
if(z==null)return""
if(C.a.O(z,"["))return C.a.k(z,1,z.length-1)
return z},
gbN:function(a){var z=this.d
if(z==null)return P.ed(this.a)
return z},
gcS:function(a){var z=this.f
return z==null?"":z},
gcK:function(){var z=this.r
return z==null?"":z},
gcN:function(){return this.c!=null},
gcP:function(){return this.f!=null},
gcO:function(){return this.r!=null},
j:function(a){var z=this.y
if(z==null){z=this.cj()
this.y=z}return z},
cj:function(){var z,y,x,w
z=this.a
y=z.length!==0?z+":":""
x=this.c
w=x==null
if(!w||z==="file"){z=y+"//"
y=this.b
if(y.length!==0)z=z+H.e(y)+"@"
if(!w)z+=x
y=this.d
if(y!=null)z=z+":"+H.e(y)}else z=y
z+=H.e(this.e)
y=this.f
if(y!=null)z=z+"?"+y
y=this.r
if(y!=null)z=z+"#"+y
return z.charCodeAt(0)==0?z:z},
C:function(a,b){var z,y,x
if(b==null)return!1
if(this===b)return!0
z=J.l(b)
if(!!z.$isce){if(this.a===b.gbZ())if(this.c!=null===b.gcN()){y=this.b
x=b.gd3()
if(y==null?x==null:y===x){y=this.gaI(this)
x=z.gaI(b)
if(y==null?x==null:y===x)if(J.C(this.gbN(this),z.gbN(b)))if(J.C(this.e,z.gbK(b))){y=this.f
x=y==null
if(!x===b.gcP()){if(x)y=""
if(y===z.gcS(b)){z=this.r
y=z==null
if(!y===b.gcO()){if(y)z=""
z=z===b.gcK()}else z=!1}else z=!1}else z=!1}else z=!1
else z=!1
else z=!1}else z=!1}else z=!1
else z=!1
return z}return!1},
gF:function(a){var z=this.z
if(z==null){z=this.y
if(z==null){z=this.cj()
this.y=z}z=C.a.gF(z)
this.z=z}return z},
$isce:1,
m:{
k9:function(a,b,c,d,e,f,g,h,i,j){var z,y,x,w,v,u,t
if(j==null)if(d>b)j=P.kg(a,b,d)
else{if(d===b)P.aY(a,b,"Invalid empty scheme")
j=""}if(e>b){z=d+3
y=z<e?P.kh(a,z,e-1):""
x=P.kc(a,e,f,!1)
if(typeof f!=="number")return f.P()
w=f+1
if(typeof g!=="number")return H.p(g)
v=w<g?P.ke(H.al(C.a.k(a,w,g),null,new P.kS(a,f)),j):null}else{y=""
x=null
v=null}u=P.kd(a,g,h,null,j,x!=null)
if(typeof h!=="number")return h.I()
t=h<i?P.kf(a,h+1,i,null):null
return new P.ec(j,y,x,v,u,t,i<c?P.kb(a,i+1,c):null,null,null,null,null,null)},
ed:function(a){if(a==="http")return 80
if(a==="https")return 443
return 0},
aY:function(a,b,c){throw H.a(new P.J(c,a,b))},
ke:function(a,b){if(a!=null&&J.C(a,P.ed(b)))return
return a},
kc:function(a,b,c,d){var z,y
if(b===c)return""
if(C.a.G(a,b)===91){if(typeof c!=="number")return c.ar()
z=c-1
if(C.a.G(a,z)!==93)P.aY(a,b,"Missing end `]` to match `[` in host")
P.dY(a,b+1,z)
return C.a.k(a,b,c).toLowerCase()}if(typeof c!=="number")return H.p(c)
y=b
for(;y<c;++y)if(C.a.G(a,y)===58){P.dY(a,b,c)
return"["+a+"]"}return P.kj(a,b,c)},
kj:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p
if(typeof c!=="number")return H.p(c)
z=b
y=z
x=null
w=!0
for(;z<c;){v=C.a.G(a,z)
if(v===37){u=P.ei(a,z,!0)
t=u==null
if(t&&w){z+=3
continue}if(x==null)x=new P.am("")
s=C.a.k(a,y,z)
r=x.p+=!w?s.toLowerCase():s
if(t){u=C.a.k(a,z,z+3)
q=3}else if(u==="%"){u="%25"
q=1}else q=3
x.p=r+u
z+=q
y=z
w=!0}else{if(v<127){t=v>>>4
if(t>=8)return H.f(C.y,t)
t=(C.y[t]&1<<(v&15))!==0}else t=!1
if(t){if(w&&65<=v&&90>=v){if(x==null)x=new P.am("")
if(y<z){x.p+=C.a.k(a,y,z)
y=z}w=!1}++z}else{if(v<=93){t=v>>>4
if(t>=8)return H.f(C.j,t)
t=(C.j[t]&1<<(v&15))!==0}else t=!1
if(t)P.aY(a,z,"Invalid character")
else{if((v&64512)===55296&&z+1<c){p=C.a.G(a,z+1)
if((p&64512)===56320){v=65536|(v&1023)<<10|p&1023
q=2}else q=1}else q=1
if(x==null)x=new P.am("")
s=C.a.k(a,y,z)
x.p+=!w?s.toLowerCase():s
x.p+=P.ee(v)
z+=q
y=z}}}}if(x==null)return C.a.k(a,b,c)
if(y<c){s=C.a.k(a,y,c)
x.p+=!w?s.toLowerCase():s}t=x.p
return t.charCodeAt(0)==0?t:t},
kg:function(a,b,c){var z,y,x,w
if(b===c)return""
if(!P.eg(C.a.E(a,b)))P.aY(a,b,"Scheme not starting with alphabetic character")
for(z=b,y=!1;z<c;++z){x=C.a.E(a,z)
if(x<128){w=x>>>4
if(w>=8)return H.f(C.l,w)
w=(C.l[w]&1<<(x&15))!==0}else w=!1
if(!w)P.aY(a,z,"Illegal scheme character")
if(65<=x&&x<=90)y=!0}a=C.a.k(a,b,c)
return P.ka(y?a.toLowerCase():a)},
ka:function(a){if(a==="http")return"http"
if(a==="file")return"file"
if(a==="https")return"https"
if(a==="package")return"package"
return a},
kh:function(a,b,c){var z=P.aD(a,b,c,C.a_,!1)
return z==null?C.a.k(a,b,c):z},
kd:function(a,b,c,d,e,f){var z,y,x
z=e==="file"
y=z||f
x=P.aD(a,b,c,C.z,!1)
if(x==null)x=C.a.k(a,b,c)
if(x.length===0){if(z)return"/"}else if(y&&!C.a.O(x,"/"))x="/"+x
return P.ki(x,e,f)},
ki:function(a,b,c){var z=b.length===0
if(z&&!c&&!C.a.O(a,"/"))return P.kk(a,!z||c)
return P.kl(a)},
kf:function(a,b,c,d){var z=P.aD(a,b,c,C.k,!1)
return z==null?C.a.k(a,b,c):z},
kb:function(a,b,c){var z=P.aD(a,b,c,C.k,!1)
return z==null?C.a.k(a,b,c):z},
ei:function(a,b,c){var z,y,x,w,v,u
z=b+2
if(z>=a.length)return"%"
y=C.a.G(a,b+1)
x=C.a.G(a,z)
w=H.bO(y)
v=H.bO(x)
if(w<0||v<0)return"%"
u=w*16+v
if(u<127){z=C.c.ae(u,4)
if(z>=8)return H.f(C.x,z)
z=(C.x[z]&1<<(u&15))!==0}else z=!1
if(z)return H.dB(c&&65<=u&&90>=u?(u|32)>>>0:u)
if(y>=97||x>=97)return C.a.k(a,b,b+3).toUpperCase()
return},
ee:function(a){var z,y,x,w,v,u,t,s
if(a<128){z=new Array(3)
z.fixed$length=Array
z[0]=37
z[1]=C.a.E("0123456789ABCDEF",a>>>4)
z[2]=C.a.E("0123456789ABCDEF",a&15)}else{if(a>2047)if(a>65535){y=240
x=4}else{y=224
x=3}else{y=192
x=2}w=3*x
z=new Array(w)
z.fixed$length=Array
for(v=0;--x,x>=0;y=128){u=C.c.ei(a,6*x)&63|y
if(v>=w)return H.f(z,v)
z[v]=37
t=v+1
s=C.a.E("0123456789ABCDEF",u>>>4)
if(t>=w)return H.f(z,t)
z[t]=s
s=v+2
t=C.a.E("0123456789ABCDEF",u&15)
if(s>=w)return H.f(z,s)
z[s]=t
v+=3}}return P.is(z,0,null)},
aD:function(a,b,c,d,e){var z,y,x,w,v,u,t,s,r,q
z=!e
y=J.b3(a)
x=b
w=x
v=null
while(!0){if(typeof x!=="number")return x.I()
if(typeof c!=="number")return H.p(c)
if(!(x<c))break
c$0:{u=y.G(a,x)
if(u<127){t=u>>>4
if(t>=8)return H.f(d,t)
t=(d[t]&1<<(u&15))!==0}else t=!1
if(t)++x
else{if(u===37){s=P.ei(a,x,!1)
if(s==null){x+=3
break c$0}if("%"===s){s="%25"
r=1}else r=3}else{if(z)if(u<=93){t=u>>>4
if(t>=8)return H.f(C.j,t)
t=(C.j[t]&1<<(u&15))!==0}else t=!1
else t=!1
if(t){P.aY(a,x,"Invalid character")
s=null
r=null}else{if((u&64512)===55296){t=x+1
if(t<c){q=C.a.G(a,t)
if((q&64512)===56320){u=65536|(u&1023)<<10|q&1023
r=2}else r=1}else r=1}else r=1
s=P.ee(u)}}if(v==null)v=new P.am("")
v.p+=C.a.k(a,w,x)
v.p+=H.e(s)
if(typeof r!=="number")return H.p(r)
x+=r
w=x}}}if(v==null)return
if(typeof w!=="number")return w.I()
if(w<c)v.p+=y.k(a,w,c)
z=v.p
return z.charCodeAt(0)==0?z:z},
eh:function(a){if(C.a.O(a,"."))return!0
return C.a.aJ(a,"/.")!==-1},
kl:function(a){var z,y,x,w,v,u,t
if(!P.eh(a))return a
z=[]
for(y=a.split("/"),x=y.length,w=!1,v=0;v<y.length;y.length===x||(0,H.a7)(y),++v){u=y[v]
if(J.C(u,"..")){t=z.length
if(t!==0){if(0>=t)return H.f(z,-1)
z.pop()
if(z.length===0)z.push("")}w=!0}else if("."===u)w=!0
else{z.push(u)
w=!1}}if(w)z.push("")
return C.b.ak(z,"/")},
kk:function(a,b){var z,y,x,w,v,u
if(!P.eh(a))return!b?P.ef(a):a
z=[]
for(y=a.split("/"),x=y.length,w=!1,v=0;v<y.length;y.length===x||(0,H.a7)(y),++v){u=y[v]
if(".."===u)if(z.length!==0&&!J.C(C.b.gb6(z),"..")){if(0>=z.length)return H.f(z,-1)
z.pop()
w=!0}else{z.push("..")
w=!1}else if("."===u)w=!0
else{z.push(u)
w=!1}}y=z.length
if(y!==0)if(y===1){if(0>=y)return H.f(z,0)
y=J.as(z[0])===!0}else y=!1
else y=!0
if(y)return"./"
if(w||J.C(C.b.gb6(z),".."))z.push("")
if(!b){if(0>=z.length)return H.f(z,0)
y=P.ef(z[0])
if(0>=z.length)return H.f(z,0)
z[0]=y}return C.b.ak(z,"/")},
ef:function(a){var z,y,x,w
z=J.y(a)
y=z.gh(a)
if(typeof y!=="number")return y.aQ()
if(y>=2&&P.eg(z.G(a,0))){x=1
while(!0){y=z.gh(a)
if(typeof y!=="number")return H.p(y)
if(!(x<y))break
w=z.G(a,x)
if(w===58)return C.a.k(a,0,x)+"%3A"+C.a.ay(a,x+1)
if(w<=127){y=w>>>4
if(y>=8)return H.f(C.l,y)
y=(C.l[y]&1<<(w&15))===0}else y=!0
if(y)break;++x}}return a},
eg:function(a){var z=a|32
return 97<=z&&z<=122}}},
kS:{"^":"c:0;a,b",
$1:function(a){throw H.a(new P.J("Invalid port",this.a,this.b+1))}},
iH:{"^":"b;a,b,c",
gd1:function(){var z,y,x,w,v,u,t,s
z=this.c
if(z!=null)return z
z=this.b
if(0>=z.length)return H.f(z,0)
y=this.a
z=z[0]+1
x=J.y(y)
w=x.b5(y,"?",z)
v=x.gh(y)
if(w>=0){u=w+1
t=P.aD(y,u,v,C.k,!1)
if(t==null)t=x.k(y,u,v)
v=w}else t=null
s=P.aD(y,z,v,C.z,!1)
z=new P.jc(this,"data",null,null,null,s==null?x.k(y,z,v):s,t,null,null,null,null,null,null)
this.c=z
return z},
j:function(a){var z,y
z=this.b
if(0>=z.length)return H.f(z,0)
y=this.a
return z[0]===-1?"data:"+H.e(y):y},
m:{
dX:function(a,b,c){var z,y,x,w,v,u,t,s,r
z=[b-1]
y=J.y(a)
x=b
w=-1
v=null
while(!0){u=y.gh(a)
if(typeof u!=="number")return H.p(u)
if(!(x<u))break
c$0:{v=y.G(a,x)
if(v===44||v===59)break
if(v===47){if(w<0){w=x
break c$0}throw H.a(new P.J("Invalid MIME type",a,x))}}++x}if(w<0&&x>b)throw H.a(new P.J("Invalid MIME type",a,x))
for(;v!==44;){z.push(x);++x
t=-1
while(!0){u=y.gh(a)
if(typeof u!=="number")return H.p(u)
if(!(x<u))break
v=y.G(a,x)
if(v===61){if(t<0)t=x}else if(v===59||v===44)break;++x}if(t>=0)z.push(t)
else{s=C.b.gb6(z)
if(v!==44||x!==s+7||!y.X(a,"base64",s+1))throw H.a(new P.J("Expecting '='",a,x))
break}}z.push(x)
u=x+1
if((z.length&1)===1)a=C.D.f1(a,u,y.gh(a))
else{r=P.aD(a,u,y.gh(a),C.k,!0)
if(r!=null)a=y.R(a,u,y.gh(a),r)}return new P.iH(a,z,c)}}},
ky:{"^":"c:0;",
$1:function(a){return new Uint8Array(H.el(96))}},
kx:{"^":"c:21;a",
$2:function(a,b){var z=this.a
if(a>=z.length)return H.f(z,a)
z=z[a]
J.eL(z,0,96,b)
return z}},
kz:{"^":"c:7;",
$3:function(a,b,c){var z,y,x
for(z=b.length,y=J.a2(a),x=0;x<z;++x)y.n(a,C.a.E(b,x)^96,c)}},
kA:{"^":"c:7;",
$3:function(a,b,c){var z,y,x
for(z=C.a.E(b,0),y=C.a.E(b,1),x=J.a2(a);z<=y;++z)x.n(a,(z^96)>>>0,c)}},
k0:{"^":"b;a,b,c,d,e,f,r,x,y",
gcN:function(){return this.c>0},
gcP:function(){var z=this.f
if(typeof z!=="number")return z.I()
return z<this.r},
gcO:function(){return this.r<this.a.length},
gbZ:function(){var z,y
z=this.b
if(z<=0)return""
y=this.x
if(y!=null)return y
y=z===4
if(y&&C.a.O(this.a,"http")){this.x="http"
z="http"}else if(z===5&&C.a.O(this.a,"https")){this.x="https"
z="https"}else if(y&&C.a.O(this.a,"file")){this.x="file"
z="file"}else if(z===7&&C.a.O(this.a,"package")){this.x="package"
z="package"}else{z=C.a.k(this.a,0,z)
this.x=z}return z},
gd3:function(){var z,y
z=this.c
y=this.b+3
return z>y?C.a.k(this.a,y,z-1):""},
gaI:function(a){var z=this.c
return z>0?C.a.k(this.a,z,this.d):""},
gbN:function(a){var z,y
if(this.c>0){z=this.d
if(typeof z!=="number")return z.P()
y=this.e
if(typeof y!=="number")return H.p(y)
y=z+1<y
z=y}else z=!1
if(z){z=this.d
if(typeof z!=="number")return z.P()
return H.al(C.a.k(this.a,z+1,this.e),null,null)}z=this.b
if(z===4&&C.a.O(this.a,"http"))return 80
if(z===5&&C.a.O(this.a,"https"))return 443
return 0},
gbK:function(a){return C.a.k(this.a,this.e,this.f)},
gcS:function(a){var z,y
z=this.f
y=this.r
if(typeof z!=="number")return z.I()
return z<y?C.a.k(this.a,z+1,y):""},
gcK:function(){var z,y
z=this.r
y=this.a
return z<y.length?C.a.ay(y,z+1):""},
gF:function(a){var z=this.y
if(z==null){z=C.a.gF(this.a)
this.y=z}return z},
C:function(a,b){var z
if(b==null)return!1
if(this===b)return!0
z=J.l(b)
if(!!z.$isce)return this.a===z.j(b)
return!1},
j:function(a){return this.a},
$isce:1},
jc:{"^":"ec;cx,a,b,c,d,e,f,r,x,y,z,Q,ch"}}],["","",,W,{"^":"",
cW:function(a){return a.replace(/^-ms-/,"ms-").replace(/-([\da-z])/ig,function(b,c){return c.toUpperCase()})},
fm:function(a,b,c){var z,y
z=document.body
y=(z&&C.r).Y(z,a,b,c)
y.toString
z=new H.cg(new W.V(y),new W.kR(),[W.m])
return z.gaq(z)},
aS:function(a){var z,y,x
z="element tag unavailable"
try{y=J.eS(a)
if(typeof y==="string")z=a.tagName}catch(x){H.z(x)}return z},
dc:function(a,b,c){return W.fM(a,null,null,b,null,null,null,c).a1(new W.fL())},
fM:function(a,b,c,d,e,f,g,h){var z,y,x,w
z=W.b9
y=new P.T(0,$.o,null,[z])
x=new P.iQ(y,[z])
w=new XMLHttpRequest()
C.M.f2(w,"GET",a,!0)
z=W.ms
W.ae(w,"load",new W.fN(x,w),!1,z)
W.ae(w,"error",x.gex(),!1,z)
w.send()
return y},
dd:function(a,b,c){var z=document.createElement("img")
z.src=b
return z},
an:function(a,b){a=536870911&a+b
a=536870911&a+((524287&a)<<10)
return a^a>>>6},
e8:function(a){a=536870911&a+((67108863&a)<<3)
a^=a>>>11
return 536870911&a+((16383&a)<<15)},
kv:function(a){var z
if(a==null)return
if("postMessage" in a){z=W.j9(a)
if(!!J.l(z).$isN)return z
return}else return a},
kK:function(a){var z=$.o
if(z===C.d)return a
return z.es(a,!0)},
r:{"^":"A;","%":"HTMLBRElement|HTMLCanvasElement|HTMLContentElement|HTMLDListElement|HTMLDataListElement|HTMLDetailsElement|HTMLDialogElement|HTMLDirectoryElement|HTMLDivElement|HTMLFontElement|HTMLFrameElement|HTMLHRElement|HTMLHeadElement|HTMLHeadingElement|HTMLHtmlElement|HTMLImageElement|HTMLLabelElement|HTMLLegendElement|HTMLMarqueeElement|HTMLMenuElement|HTMLMenuItemElement|HTMLModElement|HTMLOListElement|HTMLOptGroupElement|HTMLPictureElement|HTMLPreElement|HTMLQuoteElement|HTMLScriptElement|HTMLShadowElement|HTMLSourceElement|HTMLStyleElement|HTMLTableCaptionElement|HTMLTableCellElement|HTMLTableColElement|HTMLTableDataCellElement|HTMLTableHeaderCellElement|HTMLTitleElement|HTMLTrackElement|HTMLUListElement|HTMLUnknownElement;HTMLElement"},
bV:{"^":"r;al:target=,b4:href}",
j:function(a){return String(a)},
$isbV:1,
$isi:1,
"%":"HTMLAnchorElement"},
lq:{"^":"r;al:target=,b4:href}",
j:function(a){return String(a)},
$isi:1,
"%":"HTMLAreaElement"},
lr:{"^":"r;b4:href},al:target=","%":"HTMLBaseElement"},
bW:{"^":"r;",$isbW:1,$isN:1,$isi:1,"%":"HTMLBodyElement"},
ls:{"^":"r;M:name=,S:value=","%":"HTMLButtonElement"},
f9:{"^":"m;h:length=",$isi:1,"%":"CDATASection|Comment|Text;CharacterData"},
ff:{"^":"fP;h:length=",
d5:function(a,b){var z=this.dX(a,b)
return z!=null?z:""},
dX:function(a,b){if(W.cW(b) in a)return a.getPropertyValue(b)
else return a.getPropertyValue(P.d2()+b)},
a3:function(a,b,c,d){var z=this.dO(a,b)
a.setProperty(z,c,d)
return},
dO:function(a,b){var z,y
z=$.$get$cX()
y=z[b]
if(typeof y==="string")return y
y=W.cW(b) in a?b:P.d2()+b
z[b]=y
return y},
"%":"CSS2Properties|CSSStyleDeclaration|MSStyleCSSProperties"},
fP:{"^":"i+cV;"},
j4:{"^":"hG;a,b",
a3:function(a,b,c,d){this.b.L(0,new W.j7(b,c,d))},
dF:function(a){var z=P.ax(this.a,!0,null)
this.b=new H.bf(z,new W.j6(),[H.F(z,0),null])},
m:{
j5:function(a){var z=new W.j4(a,null)
z.dF(a)
return z}}},
hG:{"^":"b+cV;"},
j6:{"^":"c:0;",
$1:function(a){return J.cH(a)}},
j7:{"^":"c:0;a,b,c",
$1:function(a){return J.cK(a,this.a,this.b,this.c)}},
cV:{"^":"b;"},
lt:{"^":"m;",
gaM:function(a){return new W.bH(a,"click",!1,[W.a0])},
"%":"Document|HTMLDocument|XMLDocument"},
lu:{"^":"m;",
gaE:function(a){if(a._docChildren==null)a._docChildren=new P.d8(a,new W.V(a))
return a._docChildren},
$isi:1,
"%":"DocumentFragment|ShadowRoot"},
lv:{"^":"i;",
j:function(a){return String(a)},
"%":"DOMException"},
fh:{"^":"i;",
j:function(a){return"Rectangle ("+H.e(a.left)+", "+H.e(a.top)+") "+H.e(this.gan(a))+" x "+H.e(this.gaj(a))},
C:function(a,b){var z
if(b==null)return!1
z=J.l(b)
if(!z.$isP)return!1
return a.left===z.gb7(b)&&a.top===z.gbT(b)&&this.gan(a)===z.gan(b)&&this.gaj(a)===z.gaj(b)},
gF:function(a){var z,y,x,w
z=a.left
y=a.top
x=this.gan(a)
w=this.gaj(a)
return W.e8(W.an(W.an(W.an(W.an(0,z&0x1FFFFFFF),y&0x1FFFFFFF),x&0x1FFFFFFF),w&0x1FFFFFFF))},
gaj:function(a){return a.height},
gb7:function(a){return a.left},
gcW:function(a){return a.right},
gbT:function(a){return a.top},
gan:function(a){return a.width},
$isP:1,
$asP:I.L,
"%":";DOMRectReadOnly"},
lw:{"^":"i;h:length=",
v:function(a,b){return a.remove(b)},
"%":"DOMTokenList"},
j0:{"^":"aw;bq:a<,b",
gu:function(a){return this.a.firstElementChild==null},
gh:function(a){return this.b.length},
i:function(a,b){var z=this.b
if(b>>>0!==b||b>=z.length)return H.f(z,b)
return z[b]},
n:function(a,b,c){var z=this.b
if(b>>>0!==b||b>=z.length)return H.f(z,b)
this.a.replaceChild(c,z[b])},
sh:function(a,b){throw H.a(new P.k("Cannot resize element lists"))},
A:function(a,b){this.a.appendChild(b)
return b},
gw:function(a){var z=this.am(this)
return new J.bp(z,z.length,0,null)},
D:function(a,b,c,d,e){throw H.a(new P.bh(null))},
T:function(a,b,c,d){return this.D(a,b,c,d,0)},
R:function(a,b,c,d){throw H.a(new P.bh(null))},
av:function(a,b,c,d){throw H.a(new P.bh(null))},
v:function(a,b){var z
if(!!J.l(b).$isA){z=this.a
if(b.parentNode===z){z.removeChild(b)
return!0}}return!1},
U:function(a){J.cF(this.a)},
gt:function(a){var z=this.a.firstElementChild
if(z==null)throw H.a(new P.t("No elements"))
return z},
$asaw:function(){return[W.A]},
$ash:function(){return[W.A]},
$asd:function(){return[W.A]}},
cl:{"^":"aw;a,$ti",
gh:function(a){return this.a.length},
i:function(a,b){var z=this.a
if(b>>>0!==b||b>=z.length)return H.f(z,b)
return z[b]},
n:function(a,b,c){throw H.a(new P.k("Cannot modify list"))},
sh:function(a,b){throw H.a(new P.k("Cannot modify list"))},
gt:function(a){return C.a0.gt(this.a)},
gc0:function(a){return W.j5(this)},
gaM:function(a){return new W.ji(this,!1,"click",[W.a0])},
$ish:1,
$ash:null,
$isd:1,
$asd:null},
A:{"^":"m;c0:style=,bt:namespaceURI=,fd:tagName=",
ger:function(a){return new W.cj(a)},
gaE:function(a){return new W.j0(a,a.children)},
gcI:function(a){return new W.jh(a)},
geD:function(a){return new W.e2(new W.cj(a))},
j:function(a){return a.localName},
Y:["bf",function(a,b,c,d){var z,y,x,w,v
if(c==null){if(d==null){z=$.d5
if(z==null){z=H.v([],[W.dt])
y=new W.du(z)
z.push(W.e6(null))
z.push(W.eb())
$.d5=y
d=y}else d=z}z=$.d4
if(z==null){z=new W.ej(d)
$.d4=z
c=z}else{z.a=d
c=z}}else if(d!=null)throw H.a(P.aP("validator can only be passed if treeSanitizer is null"))
if($.aa==null){z=document
y=z.implementation.createHTMLDocument("")
$.aa=y
$.c_=y.createRange()
y=$.aa
y.toString
x=y.createElement("base")
J.eY(x,z.baseURI)
$.aa.head.appendChild(x)}z=$.aa
if(z.body==null){z.toString
y=z.createElement("body")
z.body=y}z=$.aa
if(!!this.$isbW)w=z.body
else{y=a.tagName
z.toString
w=z.createElement(y)
$.aa.body.appendChild(w)}if("createContextualFragment" in window.Range.prototype&&!C.b.H(C.Y,a.tagName)){$.c_.selectNodeContents(w)
v=$.c_.createContextualFragment(b)}else{w.innerHTML=b
v=$.aa.createDocumentFragment()
for(;z=w.firstChild,z!=null;)v.appendChild(z)}z=$.aa.body
if(w==null?z!=null:w!==z)J.aN(w)
c.bY(v)
document.adoptNode(v)
return v},function(a,b,c){return this.Y(a,b,c,null)},"eC",null,null,"gfs",2,5,null,0,0],
scR:function(a,b){this.a_(a,b)},
ax:function(a,b,c,d){a.textContent=null
a.appendChild(this.Y(a,b,c,d))},
a_:function(a,b){return this.ax(a,b,null,null)},
bd:function(a,b,c){return this.ax(a,b,null,c)},
gaM:function(a){return new W.bG(a,"click",!1,[W.a0])},
$isA:1,
$ism:1,
$isb:1,
$isi:1,
$isN:1,
"%":";Element"},
kR:{"^":"c:0;",
$1:function(a){return!!J.l(a).$isA}},
lx:{"^":"r;M:name=","%":"HTMLEmbedElement"},
ly:{"^":"aj;ah:error=","%":"ErrorEvent"},
aj:{"^":"i;",
gal:function(a){return W.kv(a.target)},
dl:function(a){return a.stopPropagation()},
$isaj:1,
$isb:1,
"%":"AnimationEvent|AnimationPlayerEvent|ApplicationCacheErrorEvent|AudioProcessingEvent|AutocompleteErrorEvent|BeforeInstallPromptEvent|BeforeUnloadEvent|BlobEvent|ClipboardEvent|CloseEvent|CustomEvent|DeviceLightEvent|DeviceMotionEvent|DeviceOrientationEvent|ExtendableEvent|ExtendableMessageEvent|FetchEvent|FontFaceSetLoadEvent|GamepadEvent|GeofencingEvent|HashChangeEvent|IDBVersionChangeEvent|InstallEvent|MIDIConnectionEvent|MIDIMessageEvent|MediaEncryptedEvent|MediaKeyMessageEvent|MediaQueryListEvent|MediaStreamEvent|MediaStreamTrackEvent|MessageEvent|NotificationEvent|OfflineAudioCompletionEvent|PageTransitionEvent|PopStateEvent|PresentationConnectionAvailableEvent|PresentationConnectionCloseEvent|ProgressEvent|PromiseRejectionEvent|PushEvent|RTCDTMFToneChangeEvent|RTCDataChannelEvent|RTCIceCandidateEvent|RTCPeerConnectionIceEvent|RelatedEvent|ResourceProgressEvent|SecurityPolicyViolationEvent|ServicePortConnectEvent|ServiceWorkerMessageEvent|SpeechRecognitionEvent|SpeechSynthesisEvent|StorageEvent|SyncEvent|TrackEvent|TransitionEvent|USBConnectionEvent|WebGLContextEvent|WebKitTransitionEvent;Event|InputEvent"},
N:{"^":"i;",
cD:function(a,b,c,d){if(c!=null)this.dM(a,b,c,!1)},
cU:function(a,b,c,d){if(c!=null)this.eb(a,b,c,!1)},
dM:function(a,b,c,d){return a.addEventListener(b,H.b2(c,1),!1)},
eb:function(a,b,c,d){return a.removeEventListener(b,H.b2(c,1),!1)},
$isN:1,
"%":"MediaStream|MessagePort;EventTarget"},
lP:{"^":"r;M:name=","%":"HTMLFieldSetElement"},
lR:{"^":"r;h:length=,M:name=,al:target=","%":"HTMLFormElement"},
lU:{"^":"fX;",
gh:function(a){return a.length},
i:function(a,b){if(b>>>0!==b||b>=a.length)throw H.a(P.Y(b,a,null,null,null))
return a[b]},
n:function(a,b,c){throw H.a(new P.k("Cannot assign element of immutable List."))},
sh:function(a,b){throw H.a(new P.k("Cannot resize immutable List."))},
gt:function(a){if(a.length>0)return a[0]
throw H.a(new P.t("No elements"))},
B:function(a,b){if(b>>>0!==b||b>=a.length)return H.f(a,b)
return a[b]},
$ish:1,
$ash:function(){return[W.m]},
$isd:1,
$asd:function(){return[W.m]},
$isK:1,
$asK:function(){return[W.m]},
$isG:1,
$asG:function(){return[W.m]},
"%":"HTMLCollection|HTMLFormControlsCollection|HTMLOptionsCollection"},
fQ:{"^":"i+O;",
$ash:function(){return[W.m]},
$asd:function(){return[W.m]},
$ish:1,
$isd:1},
fX:{"^":"fQ+av;",
$ash:function(){return[W.m]},
$asd:function(){return[W.m]},
$ish:1,
$isd:1},
b9:{"^":"fK;fa:responseText=",
ft:function(a,b,c,d,e,f){return a.open(b,c,!0,f,e)},
f2:function(a,b,c,d){return a.open(b,c,d)},
aR:function(a,b){return a.send(b)},
$isb9:1,
$isb:1,
"%":"XMLHttpRequest"},
fL:{"^":"c:22;",
$1:function(a){return J.eQ(a)}},
fN:{"^":"c:0;a,b",
$1:function(a){var z,y,x,w,v
z=this.b
y=z.status
if(typeof y!=="number")return y.aQ()
x=y>=200&&y<300
w=y>307&&y<400
y=x||y===0||y===304||w
v=this.a
if(y)v.ew(0,z)
else v.ey(a)}},
fK:{"^":"N;","%":";XMLHttpRequestEventTarget"},
lV:{"^":"r;M:name=","%":"HTMLIFrameElement"},
lX:{"^":"r;M:name=,S:value=",$isA:1,$isi:1,$isN:1,$ism:1,"%":"HTMLInputElement"},
m_:{"^":"r;M:name=","%":"HTMLKeygenElement"},
c3:{"^":"r;S:value=",$isc3:1,$isA:1,$ism:1,$isb:1,"%":"HTMLLIElement"},
m1:{"^":"r;b4:href}","%":"HTMLLinkElement"},
m2:{"^":"i;",
j:function(a){return String(a)},
"%":"Location"},
m3:{"^":"r;M:name=","%":"HTMLMapElement"},
m6:{"^":"r;ah:error=","%":"HTMLAudioElement|HTMLMediaElement|HTMLVideoElement"},
m7:{"^":"r;M:name=","%":"HTMLMetaElement"},
m8:{"^":"r;S:value=","%":"HTMLMeterElement"},
m9:{"^":"hB;",
fi:function(a,b,c){return a.send(b,c)},
aR:function(a,b){return a.send(b)},
"%":"MIDIOutput"},
hB:{"^":"N;","%":"MIDIInput;MIDIPort"},
a0:{"^":"iF;",$isa0:1,$isaj:1,$isb:1,"%":"DragEvent|MouseEvent|PointerEvent|WheelEvent"},
mi:{"^":"i;",$isi:1,"%":"Navigator"},
V:{"^":"aw;a",
gt:function(a){var z=this.a.firstChild
if(z==null)throw H.a(new P.t("No elements"))
return z},
gaq:function(a){var z,y
z=this.a
y=z.childNodes.length
if(y===0)throw H.a(new P.t("No elements"))
if(y>1)throw H.a(new P.t("More than one element"))
return z.firstChild},
a8:function(a,b){var z,y,x,w
z=b.a
y=this.a
if(z!==y)for(x=z.childNodes.length,w=0;w<x;++w)y.appendChild(z.firstChild)
return},
v:function(a,b){var z
if(!J.l(b).$ism)return!1
z=this.a
if(z!==b.parentNode)return!1
z.removeChild(b)
return!0},
n:function(a,b,c){var z,y
z=this.a
y=z.childNodes
if(b>>>0!==b||b>=y.length)return H.f(y,b)
z.replaceChild(c,y[b])},
gw:function(a){var z=this.a.childNodes
return new W.da(z,z.length,-1,null)},
D:function(a,b,c,d,e){throw H.a(new P.k("Cannot setRange on Node list"))},
T:function(a,b,c,d){return this.D(a,b,c,d,0)},
av:function(a,b,c,d){throw H.a(new P.k("Cannot fillRange on Node list"))},
gh:function(a){return this.a.childNodes.length},
sh:function(a,b){throw H.a(new P.k("Cannot set length on immutable List."))},
i:function(a,b){var z=this.a.childNodes
if(b>>>0!==b||b>=z.length)return H.f(z,b)
return z[b]},
$asaw:function(){return[W.m]},
$ash:function(){return[W.m]},
$asd:function(){return[W.m]}},
m:{"^":"N;f3:parentNode=,f4:previousSibling=",
gf0:function(a){return new W.V(a)},
cT:function(a){var z=a.parentNode
if(z!=null)z.removeChild(a)},
f9:function(a,b){var z,y
try{z=a.parentNode
J.eJ(z,b,a)}catch(y){H.z(y)}return a},
dQ:function(a){var z
for(;z=a.firstChild,z!=null;)a.removeChild(z)},
j:function(a){var z=a.nodeValue
return z==null?this.dn(a):z},
ec:function(a,b,c){return a.replaceChild(b,c)},
$ism:1,
$isb:1,
"%":";Node"},
hD:{"^":"fY;",
gh:function(a){return a.length},
i:function(a,b){if(b>>>0!==b||b>=a.length)throw H.a(P.Y(b,a,null,null,null))
return a[b]},
n:function(a,b,c){throw H.a(new P.k("Cannot assign element of immutable List."))},
sh:function(a,b){throw H.a(new P.k("Cannot resize immutable List."))},
gt:function(a){if(a.length>0)return a[0]
throw H.a(new P.t("No elements"))},
B:function(a,b){if(b>>>0!==b||b>=a.length)return H.f(a,b)
return a[b]},
$ish:1,
$ash:function(){return[W.m]},
$isd:1,
$asd:function(){return[W.m]},
$isK:1,
$asK:function(){return[W.m]},
$isG:1,
$asG:function(){return[W.m]},
"%":"NodeList|RadioNodeList"},
fR:{"^":"i+O;",
$ash:function(){return[W.m]},
$asd:function(){return[W.m]},
$ish:1,
$isd:1},
fY:{"^":"fR+av;",
$ash:function(){return[W.m]},
$asd:function(){return[W.m]},
$ish:1,
$isd:1},
mk:{"^":"r;M:name=","%":"HTMLObjectElement"},
ml:{"^":"r;c_:selected=,S:value=","%":"HTMLOptionElement"},
mm:{"^":"r;M:name=,S:value=","%":"HTMLOutputElement"},
hU:{"^":"r;","%":"HTMLParagraphElement"},
mo:{"^":"r;M:name=,S:value=","%":"HTMLParamElement"},
mq:{"^":"f9;al:target=","%":"ProcessingInstruction"},
mr:{"^":"r;S:value=","%":"HTMLProgressElement"},
mt:{"^":"r;h:length=,M:name=,S:value=","%":"HTMLSelectElement"},
mu:{"^":"r;M:name=","%":"HTMLSlotElement"},
ic:{"^":"r;","%":"HTMLSpanElement"},
mv:{"^":"aj;ah:error=","%":"SpeechRecognitionError"},
iw:{"^":"r;",
Y:function(a,b,c,d){var z,y
if("createContextualFragment" in window.Range.prototype)return this.bf(a,b,c,d)
z=W.fm("<table>"+H.e(b)+"</table>",c,d)
y=document.createDocumentFragment()
y.toString
new W.V(y).a8(0,J.eN(z))
return y},
"%":"HTMLTableElement"},
my:{"^":"r;",
Y:function(a,b,c,d){var z,y,x,w
if("createContextualFragment" in window.Range.prototype)return this.bf(a,b,c,d)
z=document
y=z.createDocumentFragment()
z=C.C.Y(z.createElement("table"),b,c,d)
z.toString
z=new W.V(z)
x=z.gaq(z)
x.toString
z=new W.V(x)
w=z.gaq(z)
y.toString
w.toString
new W.V(y).a8(0,new W.V(w))
return y},
"%":"HTMLTableRowElement"},
mz:{"^":"r;",
Y:function(a,b,c,d){var z,y,x
if("createContextualFragment" in window.Range.prototype)return this.bf(a,b,c,d)
z=document
y=z.createDocumentFragment()
z=C.C.Y(z.createElement("table"),b,c,d)
z.toString
z=new W.V(z)
x=z.gaq(z)
y.toString
x.toString
new W.V(y).a8(0,new W.V(x))
return y},
"%":"HTMLTableSectionElement"},
dK:{"^":"r;",
ax:function(a,b,c,d){var z
a.textContent=null
z=this.Y(a,b,c,d)
a.content.appendChild(z)},
a_:function(a,b){return this.ax(a,b,null,null)},
bd:function(a,b,c){return this.ax(a,b,null,c)},
$isdK:1,
"%":"HTMLTemplateElement"},
mA:{"^":"r;M:name=,S:value=","%":"HTMLTextAreaElement"},
iF:{"^":"aj;","%":"CompositionEvent|FocusEvent|KeyboardEvent|SVGZoomEvent|TextEvent|TouchEvent;UIEvent"},
iO:{"^":"N;",
d9:function(a,b,c,d){a.scrollTo(b,c)
return},
d8:function(a,b,c){return this.d9(a,b,c,null)},
gaM:function(a){return new W.bH(a,"click",!1,[W.a0])},
gap:function(a){return"scrollY" in a?C.e.bP(a.scrollY):C.e.bP(a.document.documentElement.scrollTop)},
$isi:1,
$isN:1,
"%":"DOMWindow|Window"},
mI:{"^":"m;M:name=,bt:namespaceURI=,S:value=","%":"Attr"},
mJ:{"^":"i;aj:height=,b7:left=,cW:right=,bT:top=,an:width=",
j:function(a){return"Rectangle ("+H.e(a.left)+", "+H.e(a.top)+") "+H.e(a.width)+" x "+H.e(a.height)},
C:function(a,b){var z,y,x
if(b==null)return!1
z=J.l(b)
if(!z.$isP)return!1
y=a.left
x=z.gb7(b)
if(y==null?x==null:y===x){y=a.top
x=z.gbT(b)
if(y==null?x==null:y===x){y=a.width
x=z.gan(b)
if(y==null?x==null:y===x){y=a.height
z=z.gaj(b)
z=y==null?z==null:y===z}else z=!1}else z=!1}else z=!1
return z},
gF:function(a){var z,y,x,w
z=J.ag(a.left)
y=J.ag(a.top)
x=J.ag(a.width)
w=J.ag(a.height)
return W.e8(W.an(W.an(W.an(W.an(0,z),y),x),w))},
$isP:1,
$asP:I.L,
"%":"ClientRect"},
j1:{"^":"fZ;",
gh:function(a){return a.length},
i:function(a,b){if(b>>>0!==b||b>=a.length)throw H.a(P.Y(b,a,null,null,null))
return a[b]},
n:function(a,b,c){throw H.a(new P.k("Cannot assign element of immutable List."))},
sh:function(a,b){throw H.a(new P.k("Cannot resize immutable List."))},
gt:function(a){if(a.length>0)return a[0]
throw H.a(new P.t("No elements"))},
B:function(a,b){if(b>>>0!==b||b>=a.length)return H.f(a,b)
return a[b]},
$isK:1,
$asK:function(){return[P.P]},
$isG:1,
$asG:function(){return[P.P]},
$ish:1,
$ash:function(){return[P.P]},
$isd:1,
$asd:function(){return[P.P]},
"%":"ClientRectList|DOMRectList"},
fS:{"^":"i+O;",
$ash:function(){return[P.P]},
$asd:function(){return[P.P]},
$ish:1,
$isd:1},
fZ:{"^":"fS+av;",
$ash:function(){return[P.P]},
$asd:function(){return[P.P]},
$ish:1,
$isd:1},
mK:{"^":"m;",$isi:1,"%":"DocumentType"},
mL:{"^":"fh;",
gaj:function(a){return a.height},
gan:function(a){return a.width},
"%":"DOMRect"},
mN:{"^":"r;",$isN:1,$isi:1,"%":"HTMLFrameSetElement"},
mQ:{"^":"h_;",
gh:function(a){return a.length},
i:function(a,b){if(b>>>0!==b||b>=a.length)throw H.a(P.Y(b,a,null,null,null))
return a[b]},
n:function(a,b,c){throw H.a(new P.k("Cannot assign element of immutable List."))},
sh:function(a,b){throw H.a(new P.k("Cannot resize immutable List."))},
gt:function(a){if(a.length>0)return a[0]
throw H.a(new P.t("No elements"))},
B:function(a,b){if(b>>>0!==b||b>=a.length)return H.f(a,b)
return a[b]},
$ish:1,
$ash:function(){return[W.m]},
$isd:1,
$asd:function(){return[W.m]},
$isK:1,
$asK:function(){return[W.m]},
$isG:1,
$asG:function(){return[W.m]},
"%":"MozNamedAttrMap|NamedNodeMap"},
fT:{"^":"i+O;",
$ash:function(){return[W.m]},
$asd:function(){return[W.m]},
$ish:1,
$isd:1},
h_:{"^":"fT+av;",
$ash:function(){return[W.m]},
$asd:function(){return[W.m]},
$ish:1,
$isd:1},
mU:{"^":"N;",$isN:1,$isi:1,"%":"ServiceWorker"},
iW:{"^":"b;bq:a<",
L:function(a,b){var z,y,x,w,v
for(z=this.gK(),y=z.length,x=this.a,w=0;w<z.length;z.length===y||(0,H.a7)(z),++w){v=z[w]
b.$2(v,x.getAttribute(v))}},
gK:function(){var z,y,x,w,v,u
z=this.a.attributes
y=H.v([],[P.n])
for(x=z.length,w=0;w<x;++w){if(w>=z.length)return H.f(z,w)
v=z[w]
u=J.q(v)
if(u.gbt(v)==null)y.push(u.gM(v))}return y},
ga2:function(a){var z,y,x,w,v,u
z=this.a.attributes
y=H.v([],[P.n])
for(x=z.length,w=0;w<x;++w){if(w>=z.length)return H.f(z,w)
v=z[w]
u=J.q(v)
if(u.gbt(v)==null)y.push(u.gS(v))}return y},
gu:function(a){return this.gK().length===0}},
cj:{"^":"iW;a",
J:function(a){return this.a.hasAttribute(a)},
i:function(a,b){return this.a.getAttribute(b)},
n:function(a,b,c){this.a.setAttribute(b,c)},
v:function(a,b){var z,y
z=this.a
y=z.getAttribute(b)
z.removeAttribute(b)
return y},
gh:function(a){return this.gK().length}},
e2:{"^":"b;a",
J:function(a){return this.a.a.hasAttribute("data-"+this.au(a))},
i:function(a,b){return this.a.a.getAttribute("data-"+this.au(b))},
n:function(a,b,c){this.a.a.setAttribute("data-"+this.au(b),c)},
v:function(a,b){var z,y,x
z="data-"+this.au(b)
y=this.a.a
x=y.getAttribute(z)
y.removeAttribute(z)
return x},
gK:function(){var z=H.v([],[P.n])
this.a.L(0,new W.ja(this,z))
return z},
ga2:function(a){var z=H.v([],[P.n])
this.a.L(0,new W.jb(this,z))
return z},
gh:function(a){return this.gK().length},
gu:function(a){return this.gK().length===0},
em:function(a,b){var z,y,x,w,v
z=a.split("-")
for(y=1;y<z.length;++y){x=z[y]
w=J.y(x)
v=w.gh(x)
if(typeof v!=="number")return v.ao()
if(v>0){w=J.f3(w.i(x,0))+w.ay(x,1)
if(y>=z.length)return H.f(z,y)
z[y]=w}}return C.b.ak(z,"")},
el:function(a){return this.em(a,!1)},
au:function(a){var z,y,x,w,v
z=J.y(a)
y=0
x=""
while(!0){w=z.gh(a)
if(typeof w!=="number")return H.p(w)
if(!(y<w))break
v=J.cL(z.i(a,y))
x=(!J.C(z.i(a,y),v)&&y>0?x+"-":x)+v;++y}return x.charCodeAt(0)==0?x:x}},
ja:{"^":"c:8;a,b",
$2:function(a,b){if(J.b3(a).O(a,"data-"))this.b.push(this.a.el(C.a.ay(a,5)))}},
jb:{"^":"c:8;a,b",
$2:function(a,b){if(J.f1(a,"data-"))this.b.push(b)}},
jh:{"^":"cT;bq:a<",
V:function(){var z,y,x,w,v
z=P.Z(null,null,null,P.n)
for(y=this.a.className.split(" "),x=y.length,w=0;w<y.length;y.length===x||(0,H.a7)(y),++w){v=J.cM(y[w])
if(v.length!==0)z.A(0,v)}return z},
bV:function(a){this.a.className=a.ak(0," ")},
gh:function(a){return this.a.classList.length},
gu:function(a){return this.a.classList.length===0},
H:function(a,b){return typeof b==="string"&&this.a.classList.contains(b)},
A:function(a,b){var z,y
z=this.a.classList
y=z.contains(b)
z.add(b)
return!y},
v:function(a,b){var z,y,x
if(typeof b==="string"){z=this.a.classList
y=z.contains(b)
z.remove(b)
x=y}else x=!1
return x}},
bH:{"^":"a_;a,b,c,$ti",
N:function(a,b,c,d){return W.ae(this.a,this.b,a,!1,H.F(this,0))},
b8:function(a,b,c){return this.N(a,null,b,c)},
bH:function(a){return this.N(a,null,null,null)}},
bG:{"^":"bH;a,b,c,$ti"},
ji:{"^":"a_;a,b,c,$ti",
N:function(a,b,c,d){var z,y,x,w
z=H.F(this,0)
y=this.$ti
x=new W.k3(null,new H.ab(0,null,null,null,null,null,0,[[P.a_,z],[P.dG,z]]),y)
x.a=new P.cq(null,x.gev(x),0,null,null,null,null,y)
for(z=this.a,z=new H.c4(z,z.gh(z),0,null),w=this.c;z.l();)x.A(0,new W.bH(z.d,w,!1,y))
z=x.a
z.toString
return new P.iX(z,[H.F(z,0)]).N(a,b,c,d)},
b8:function(a,b,c){return this.N(a,null,b,c)},
bH:function(a){return this.N(a,null,null,null)}},
jl:{"^":"dG;a,b,c,d,e,$ti",
a0:function(){if(this.b==null)return
this.cB()
this.b=null
this.d=null
return},
aN:function(a,b){if(this.b==null)return;++this.a
this.cB()},
bL:function(a){return this.aN(a,null)},
bO:function(){if(this.b==null||this.a<=0)return;--this.a
this.cz()},
cz:function(){var z=this.d
if(z!=null&&this.a<=0)J.eK(this.b,this.c,z,!1)},
cB:function(){var z=this.d
if(z!=null)J.eW(this.b,this.c,z,!1)},
dG:function(a,b,c,d,e){this.cz()},
m:{
ae:function(a,b,c,d,e){var z=c==null?null:W.kK(new W.jm(c))
z=new W.jl(0,a,b,z,!1,[e])
z.dG(a,b,c,!1,e)
return z}}},
jm:{"^":"c:0;a",
$1:function(a){return this.a.$1(a)}},
k3:{"^":"b;a,b,$ti",
A:function(a,b){var z,y
z=this.b
if(z.J(b))return
y=this.a
z.n(0,b,W.ae(b.a,b.b,y.geo(y),!1,H.F(b,0)))},
v:function(a,b){var z=this.b.v(0,b)
if(z!=null)z.a0()},
cJ:[function(a){var z,y
for(z=this.b,y=z.ga2(z),y=y.gw(y);y.l();)y.gq().a0()
z.U(0)
this.a.cJ(0)},"$0","gev",0,0,2]},
cn:{"^":"b;d2:a<",
af:function(a){return $.$get$e7().H(0,W.aS(a))},
a9:function(a,b,c){var z,y,x
z=W.aS(a)
y=$.$get$co()
x=y.i(0,H.e(z)+"::"+b)
if(x==null)x=y.i(0,"*::"+b)
if(x==null)return!1
return x.$4(a,b,c,this)},
dJ:function(a){var z,y
z=$.$get$co()
if(z.gu(z)){for(y=0;y<262;++y)z.n(0,C.X[y],W.kY())
for(y=0;y<12;++y)z.n(0,C.o[y],W.kZ())}},
m:{
e6:function(a){var z,y
z=document.createElement("a")
y=new W.jX(z,window.location)
y=new W.cn(y)
y.dJ(a)
return y},
mO:[function(a,b,c,d){return!0},"$4","kY",8,0,10],
mP:[function(a,b,c,d){var z,y,x,w,v
z=d.gd2()
y=z.a
y.href=c
x=y.hostname
z=z.b
w=z.hostname
if(x==null?w==null:x===w){w=y.port
v=z.port
if(w==null?v==null:w===v){w=y.protocol
z=z.protocol
z=w==null?z==null:w===z}else z=!1}else z=!1
if(!z)if(x==="")if(y.port===""){z=y.protocol
z=z===":"||z===""}else z=!1
else z=!1
else z=!0
return z},"$4","kZ",8,0,10]}},
av:{"^":"b;$ti",
gw:function(a){return new W.da(a,this.gh(a),-1,null)},
v:function(a,b){throw H.a(new P.k("Cannot remove from immutable List."))},
D:function(a,b,c,d,e){throw H.a(new P.k("Cannot setRange on immutable List."))},
T:function(a,b,c,d){return this.D(a,b,c,d,0)},
R:function(a,b,c,d){throw H.a(new P.k("Cannot modify an immutable List."))},
av:function(a,b,c,d){throw H.a(new P.k("Cannot modify an immutable List."))},
$ish:1,
$ash:null,
$isd:1,
$asd:null},
du:{"^":"b;a",
af:function(a){return C.b.cF(this.a,new W.hF(a))},
a9:function(a,b,c){return C.b.cF(this.a,new W.hE(a,b,c))}},
hF:{"^":"c:0;a",
$1:function(a){return a.af(this.a)}},
hE:{"^":"c:0;a,b,c",
$1:function(a){return a.a9(this.a,this.b,this.c)}},
jY:{"^":"b;d2:d<",
af:function(a){return this.a.H(0,W.aS(a))},
a9:["dv",function(a,b,c){var z,y
z=W.aS(a)
y=this.c
if(y.H(0,H.e(z)+"::"+b))return this.d.eq(c)
else if(y.H(0,"*::"+b))return this.d.eq(c)
else{y=this.b
if(y.H(0,H.e(z)+"::"+b))return!0
else if(y.H(0,"*::"+b))return!0
else if(y.H(0,H.e(z)+"::*"))return!0
else if(y.H(0,"*::*"))return!0}return!1}],
dK:function(a,b,c,d){var z,y,x
this.a.a8(0,c)
z=b.bU(0,new W.jZ())
y=b.bU(0,new W.k_())
this.b.a8(0,z)
x=this.c
x.a8(0,C.Z)
x.a8(0,y)}},
jZ:{"^":"c:0;",
$1:function(a){return!C.b.H(C.o,a)}},
k_:{"^":"c:0;",
$1:function(a){return C.b.H(C.o,a)}},
k7:{"^":"jY;e,a,b,c,d",
a9:function(a,b,c){if(this.dv(a,b,c))return!0
if(b==="template"&&c==="")return!0
if(J.cG(a).a.getAttribute("template")==="")return this.e.H(0,b)
return!1},
m:{
eb:function(){var z=P.n
z=new W.k7(P.dk(C.n,z),P.Z(null,null,null,z),P.Z(null,null,null,z),P.Z(null,null,null,z),null)
z.dK(null,new H.bf(C.n,new W.k8(),[H.F(C.n,0),null]),["TEMPLATE"],null)
return z}}},
k8:{"^":"c:0;",
$1:function(a){return"TEMPLATE::"+H.e(a)}},
k4:{"^":"b;",
af:function(a){var z=J.l(a)
if(!!z.$isdD)return!1
z=!!z.$isu
if(z&&W.aS(a)==="foreignObject")return!1
if(z)return!0
return!1},
a9:function(a,b,c){if(b==="is"||C.a.O(b,"on"))return!1
return this.af(a)}},
da:{"^":"b;a,b,c,d",
l:function(){var z,y
z=this.c+1
y=this.b
if(z<y){this.d=J.aL(this.a,z)
this.c=z
return!0}this.d=null
this.c=y
return!1},
gq:function(){return this.d}},
j8:{"^":"b;a",
cD:function(a,b,c,d){return H.w(new P.k("You can only attach EventListeners to your own window."))},
cU:function(a,b,c,d){return H.w(new P.k("You can only attach EventListeners to your own window."))},
$isN:1,
$isi:1,
m:{
j9:function(a){if(a===window)return a
else return new W.j8(a)}}},
dt:{"^":"b;"},
jX:{"^":"b;a,b"},
ej:{"^":"b;a",
bY:function(a){new W.km(this).$2(a,null)},
aC:function(a,b){var z
if(b==null){z=a.parentNode
if(z!=null)z.removeChild(a)}else b.removeChild(a)},
ef:function(a,b){var z,y,x,w,v,u,t,s
z=!0
y=null
x=null
try{y=J.cG(a)
x=y.gbq().getAttribute("is")
w=function(c){if(!(c.attributes instanceof NamedNodeMap))return true
var r=c.childNodes
if(c.lastChild&&c.lastChild!==r[r.length-1])return true
if(c.children)if(!(c.children instanceof HTMLCollection||c.children instanceof NodeList))return true
var q=0
if(c.children)q=c.children.length
for(var p=0;p<q;p++){var o=c.children[p]
if(o.id=='attributes'||o.name=='attributes'||o.id=='lastChild'||o.name=='lastChild'||o.id=='children'||o.name=='children')return true}return false}(a)
z=w===!0?!0:!(a.attributes instanceof NamedNodeMap)}catch(t){H.z(t)}v="element unprintable"
try{v=J.X(a)}catch(t){H.z(t)}try{u=W.aS(a)
this.ee(a,b,z,v,u,y,x)}catch(t){if(H.z(t) instanceof P.a8)throw t
else{this.aC(a,b)
window
s="Removing corrupted element "+H.e(v)
if(typeof console!="undefined")console.warn(s)}}},
ee:function(a,b,c,d,e,f,g){var z,y,x,w,v
if(c){this.aC(a,b)
window
z="Removing element due to corrupted attributes on <"+d+">"
if(typeof console!="undefined")console.warn(z)
return}if(!this.a.af(a)){this.aC(a,b)
window
z="Removing disallowed element <"+H.e(e)+"> from "+J.X(b)
if(typeof console!="undefined")console.warn(z)
return}if(g!=null)if(!this.a.a9(a,"is",g)){this.aC(a,b)
window
z="Removing disallowed type extension <"+H.e(e)+' is="'+g+'">'
if(typeof console!="undefined")console.warn(z)
return}z=f.gK()
y=H.v(z.slice(0),[H.F(z,0)])
for(x=f.gK().length-1,z=f.a;x>=0;--x){if(x>=y.length)return H.f(y,x)
w=y[x]
if(!this.a.a9(a,J.cL(w),z.getAttribute(w))){window
v="Removing disallowed attribute <"+H.e(e)+" "+w+'="'+H.e(z.getAttribute(w))+'">'
if(typeof console!="undefined")console.warn(v)
z.getAttribute(w)
z.removeAttribute(w)}}if(!!J.l(a).$isdK)this.bY(a.content)}},
km:{"^":"c:23;a",
$2:function(a,b){var z,y,x,w,v
x=this.a
switch(a.nodeType){case 1:x.ef(a,b)
break
case 8:case 11:case 3:case 4:break
default:x.aC(a,b)}z=a.lastChild
for(x=a==null;null!=z;){y=null
try{y=J.eP(z)}catch(w){H.z(w)
v=z
if(x){if(J.eO(v)!=null)v.parentNode.removeChild(v)}else a.removeChild(v)
z=null
y=a.lastChild}if(z!=null)this.$2(z,a)
z=y}}}}],["","",,P,{"^":"",
d3:function(){var z=$.d1
if(z==null){z=J.bU(window.navigator.userAgent,"Opera",0)
$.d1=z}return z},
d2:function(){var z,y
z=$.cZ
if(z!=null)return z
y=$.d_
if(y==null){y=J.bU(window.navigator.userAgent,"Firefox",0)
$.d_=y}if(y)z="-moz-"
else{y=$.d0
if(y==null){y=P.d3()!==!0&&J.bU(window.navigator.userAgent,"Trident/",0)
$.d0=y}if(y)z="-ms-"
else z=P.d3()===!0?"-o-":"-webkit-"}$.cZ=z
return z},
cT:{"^":"b;",
bC:function(a){if($.$get$cU().b.test(H.ez(a)))return a
throw H.a(P.aQ(a,"value","Not a valid class token"))},
j:function(a){return this.V().ak(0," ")},
gw:function(a){var z,y
z=this.V()
y=new P.aW(z,z.r,null,null)
y.c=z.e
return y},
aa:function(a,b){var z=this.V()
return new H.bZ(z,b,[H.F(z,0),null])},
gu:function(a){return this.V().a===0},
gh:function(a){return this.V().a},
H:function(a,b){if(typeof b!=="string")return!1
this.bC(b)
return this.V().H(0,b)},
bI:function(a){return this.H(0,a)?a:null},
A:function(a,b){this.bC(b)
return this.f_(new P.fe(b))},
v:function(a,b){var z,y
this.bC(b)
if(typeof b!=="string")return!1
z=this.V()
y=z.v(0,b)
this.bV(z)
return y},
gt:function(a){var z=this.V()
return z.gt(z)},
B:function(a,b){return this.V().B(0,b)},
f_:function(a){var z,y
z=this.V()
y=a.$1(z)
this.bV(z)
return y},
$isd:1,
$asd:function(){return[P.n]}},
fe:{"^":"c:0;a",
$1:function(a){return a.A(0,this.a)}},
d8:{"^":"aw;a,b",
gad:function(){var z,y
z=this.b
y=H.B(z,"O",0)
return new H.bw(new H.cg(z,new P.fp(),[y]),new P.fq(),[y,null])},
L:function(a,b){C.b.L(P.ax(this.gad(),!1,W.A),b)},
n:function(a,b,c){var z=this.gad()
J.eX(z.b.$1(J.b4(z.a,b)),c)},
sh:function(a,b){var z=J.Q(this.gad().a)
if(b>=z)return
else if(b<0)throw H.a(P.aP("Invalid list length"))
this.f8(0,b,z)},
A:function(a,b){this.b.a.appendChild(b)},
H:function(a,b){return b.parentNode===this.a},
D:function(a,b,c,d,e){throw H.a(new P.k("Cannot setRange on filtered list"))},
T:function(a,b,c,d){return this.D(a,b,c,d,0)},
av:function(a,b,c,d){throw H.a(new P.k("Cannot fillRange on filtered list"))},
R:function(a,b,c,d){throw H.a(new P.k("Cannot replaceRange on filtered list"))},
f8:function(a,b,c){var z=this.gad()
z=H.ia(z,b,H.B(z,"H",0))
C.b.L(P.ax(H.ix(z,c-b,H.B(z,"H",0)),!0,null),new P.fr())},
U:function(a){J.cF(this.b.a)},
v:function(a,b){var z=J.l(b)
if(!z.$isA)return!1
if(this.H(0,b)){z.cT(b)
return!0}else return!1},
gh:function(a){return J.Q(this.gad().a)},
i:function(a,b){var z=this.gad()
return z.b.$1(J.b4(z.a,b))},
gw:function(a){var z=P.ax(this.gad(),!1,W.A)
return new J.bp(z,z.length,0,null)},
$asaw:function(){return[W.A]},
$ash:function(){return[W.A]},
$asd:function(){return[W.A]}},
fp:{"^":"c:0;",
$1:function(a){return!!J.l(a).$isA}},
fq:{"^":"c:0;",
$1:function(a){return H.bP(a,"$isA")}},
fr:{"^":"c:0;",
$1:function(a){return J.aN(a)}}}],["","",,P,{"^":""}],["","",,P,{"^":"",jD:{"^":"b;",
bJ:function(a){if(typeof a!=="number")return a.d6()
if(a<=0||a>4294967296)throw H.a(P.i2("max must be in range 0 < max \u2264 2^32, was "+H.e(a)))
return Math.random()*a>>>0}},jS:{"^":"b;$ti"},P:{"^":"jS;$ti",$asP:null}}],["","",,P,{"^":"",lo:{"^":"b8;al:target=",$isi:1,"%":"SVGAElement"},lp:{"^":"u;",$isi:1,"%":"SVGAnimateElement|SVGAnimateMotionElement|SVGAnimateTransformElement|SVGAnimationElement|SVGSetElement"},lz:{"^":"u;",$isi:1,"%":"SVGFEBlendElement"},lA:{"^":"u;a2:values=",$isi:1,"%":"SVGFEColorMatrixElement"},lB:{"^":"u;",$isi:1,"%":"SVGFEComponentTransferElement"},lC:{"^":"u;",$isi:1,"%":"SVGFECompositeElement"},lD:{"^":"u;",$isi:1,"%":"SVGFEConvolveMatrixElement"},lE:{"^":"u;",$isi:1,"%":"SVGFEDiffuseLightingElement"},lF:{"^":"u;",$isi:1,"%":"SVGFEDisplacementMapElement"},lG:{"^":"u;",$isi:1,"%":"SVGFEFloodElement"},lH:{"^":"u;",$isi:1,"%":"SVGFEGaussianBlurElement"},lI:{"^":"u;",$isi:1,"%":"SVGFEImageElement"},lJ:{"^":"u;",$isi:1,"%":"SVGFEMergeElement"},lK:{"^":"u;",$isi:1,"%":"SVGFEMorphologyElement"},lL:{"^":"u;",$isi:1,"%":"SVGFEOffsetElement"},lM:{"^":"u;",$isi:1,"%":"SVGFESpecularLightingElement"},lN:{"^":"u;",$isi:1,"%":"SVGFETileElement"},lO:{"^":"u;",$isi:1,"%":"SVGFETurbulenceElement"},lQ:{"^":"u;",$isi:1,"%":"SVGFilterElement"},b8:{"^":"u;",$isi:1,"%":"SVGCircleElement|SVGClipPathElement|SVGDefsElement|SVGEllipseElement|SVGForeignObjectElement|SVGGElement|SVGGeometryElement|SVGLineElement|SVGPathElement|SVGPolygonElement|SVGPolylineElement|SVGRectElement|SVGSwitchElement;SVGGraphicsElement"},lW:{"^":"b8;",$isi:1,"%":"SVGImageElement"},aT:{"^":"i;",$isb:1,"%":"SVGLength"},m0:{"^":"h0;",
gh:function(a){return a.length},
i:function(a,b){if(b>>>0!==b||b>=a.length)throw H.a(P.Y(b,a,null,null,null))
return a.getItem(b)},
n:function(a,b,c){throw H.a(new P.k("Cannot assign element of immutable List."))},
sh:function(a,b){throw H.a(new P.k("Cannot resize immutable List."))},
gt:function(a){if(a.length>0)return a[0]
throw H.a(new P.t("No elements"))},
B:function(a,b){return this.i(a,b)},
$ish:1,
$ash:function(){return[P.aT]},
$isd:1,
$asd:function(){return[P.aT]},
"%":"SVGLengthList"},fU:{"^":"i+O;",
$ash:function(){return[P.aT]},
$asd:function(){return[P.aT]},
$ish:1,
$isd:1},h0:{"^":"fU+av;",
$ash:function(){return[P.aT]},
$asd:function(){return[P.aT]},
$ish:1,
$isd:1},m4:{"^":"u;",$isi:1,"%":"SVGMarkerElement"},m5:{"^":"u;",$isi:1,"%":"SVGMaskElement"},aU:{"^":"i;",$isb:1,"%":"SVGNumber"},mj:{"^":"h1;",
gh:function(a){return a.length},
i:function(a,b){if(b>>>0!==b||b>=a.length)throw H.a(P.Y(b,a,null,null,null))
return a.getItem(b)},
n:function(a,b,c){throw H.a(new P.k("Cannot assign element of immutable List."))},
sh:function(a,b){throw H.a(new P.k("Cannot resize immutable List."))},
gt:function(a){if(a.length>0)return a[0]
throw H.a(new P.t("No elements"))},
B:function(a,b){return this.i(a,b)},
$ish:1,
$ash:function(){return[P.aU]},
$isd:1,
$asd:function(){return[P.aU]},
"%":"SVGNumberList"},fV:{"^":"i+O;",
$ash:function(){return[P.aU]},
$asd:function(){return[P.aU]},
$ish:1,
$isd:1},h1:{"^":"fV+av;",
$ash:function(){return[P.aU]},
$asd:function(){return[P.aU]},
$ish:1,
$isd:1},mp:{"^":"u;",$isi:1,"%":"SVGPatternElement"},dD:{"^":"u;",$isdD:1,$isi:1,"%":"SVGScriptElement"},f4:{"^":"cT;a",
V:function(){var z,y,x,w,v,u
z=this.a.getAttribute("class")
y=P.Z(null,null,null,P.n)
if(z==null)return y
for(x=z.split(" "),w=x.length,v=0;v<x.length;x.length===w||(0,H.a7)(x),++v){u=J.cM(x[v])
if(u.length!==0)y.A(0,u)}return y},
bV:function(a){this.a.setAttribute("class",a.ak(0," "))}},u:{"^":"A;",
gcI:function(a){return new P.f4(a)},
gaE:function(a){return new P.d8(a,new W.V(a))},
scR:function(a,b){this.a_(a,b)},
Y:function(a,b,c,d){var z,y,x,w,v,u
if(d==null){z=H.v([],[W.dt])
d=new W.du(z)
z.push(W.e6(null))
z.push(W.eb())
z.push(new W.k4())}c=new W.ej(d)
y='<svg version="1.1">'+H.e(b)+"</svg>"
z=document
x=z.body
w=(x&&C.r).eC(x,y,c)
v=z.createDocumentFragment()
w.toString
z=new W.V(w)
u=z.gaq(z)
for(;z=u.firstChild,z!=null;)v.appendChild(z)
return v},
gaM:function(a){return new W.bG(a,"click",!1,[W.a0])},
$isu:1,
$isN:1,
$isi:1,
"%":"SVGComponentTransferFunctionElement|SVGDescElement|SVGDiscardElement|SVGFEDistantLightElement|SVGFEFuncAElement|SVGFEFuncBElement|SVGFEFuncGElement|SVGFEFuncRElement|SVGFEMergeNodeElement|SVGFEPointLightElement|SVGFESpotLightElement|SVGMetadataElement|SVGStopElement|SVGStyleElement|SVGTitleElement;SVGElement"},mw:{"^":"b8;",$isi:1,"%":"SVGSVGElement"},mx:{"^":"u;",$isi:1,"%":"SVGSymbolElement"},iz:{"^":"b8;","%":"SVGTSpanElement|SVGTextElement|SVGTextPositioningElement;SVGTextContentElement"},mB:{"^":"iz;",$isi:1,"%":"SVGTextPathElement"},aV:{"^":"i;",$isb:1,"%":"SVGTransform"},mC:{"^":"h2;",
gh:function(a){return a.length},
i:function(a,b){if(b>>>0!==b||b>=a.length)throw H.a(P.Y(b,a,null,null,null))
return a.getItem(b)},
n:function(a,b,c){throw H.a(new P.k("Cannot assign element of immutable List."))},
sh:function(a,b){throw H.a(new P.k("Cannot resize immutable List."))},
gt:function(a){if(a.length>0)return a[0]
throw H.a(new P.t("No elements"))},
B:function(a,b){return this.i(a,b)},
$ish:1,
$ash:function(){return[P.aV]},
$isd:1,
$asd:function(){return[P.aV]},
"%":"SVGTransformList"},fW:{"^":"i+O;",
$ash:function(){return[P.aV]},
$asd:function(){return[P.aV]},
$ish:1,
$isd:1},h2:{"^":"fW+av;",
$ash:function(){return[P.aV]},
$asd:function(){return[P.aV]},
$ish:1,
$isd:1},mD:{"^":"b8;",$isi:1,"%":"SVGUseElement"},mE:{"^":"u;",$isi:1,"%":"SVGViewElement"},mM:{"^":"u;",$isi:1,"%":"SVGGradientElement|SVGLinearGradientElement|SVGRadialGradientElement"},mR:{"^":"u;",$isi:1,"%":"SVGCursorElement"},mS:{"^":"u;",$isi:1,"%":"SVGFEDropShadowElement"},mT:{"^":"u;",$isi:1,"%":"SVGMPathElement"}}],["","",,P,{"^":"",bg:{"^":"b;",$ish:1,
$ash:function(){return[P.j]},
$isd:1,
$asd:function(){return[P.j]}}}],["","",,P,{"^":""}],["","",,P,{"^":""}],["","",,P,{"^":""}],["","",,A,{"^":"",db:{"^":"b;a,b",
j:function(a){return this.b},
m:{"^":"lT<"}},fs:{"^":"b;a,b,c,d,e",
dw:function(){this.b=0
this.a=document.querySelector("#header")
this.c=C.m
W.ae(window.document,"scroll",new A.fu(this),!1,W.aj)},
m:{
ft:function(){var z=new A.fs(null,null,null,!1,0)
z.dw()
return z}}},fu:{"^":"c:0;a",
$1:function(a){var z,y,x,w,v
z=this.a
y=z.b-C.h.gap(window)
if(y<0){z.e=0
if(z.c===C.m){x=C.h.gap(window)
w=z.a.clientHeight
if(typeof w!=="number")return H.p(w)
w=x>=w
x=w}else x=!1
if(x){J.ar(z.a).A(0,"scrollfollow")
J.ar(z.a).v(0,"scrolltop")
x=z.a
w=x.style
x=x.clientHeight
if(typeof x!=="number")return x.bX()
x=C.c.j(-x)+"px"
w.top=x
z.c=C.i}else{if(z.c===C.i){x=C.h.gap(window)
w=z.a.clientHeight
if(typeof w!=="number")return H.p(w)
w=x>=w
x=w}else x=!1
if(x){x=z.a.style.top
v=J.aq(H.al(C.a.k(x,0,C.a.aJ(x,"px")),null,null),y)
x=z.a.clientHeight
if(typeof x!=="number")return x.bX()
if(J.cE(v,-x)){x=z.a.clientHeight
if(typeof x!=="number")return x.bX()
v=-x}x=z.a.style
w=J.X(v)+"px"
x.top=w}}}else if(y>0&&!0){z.e=z.a.getBoundingClientRect().height
if(z.c===C.i&&C.h.gap(window)<=0){J.ar(z.a).A(0,"scrolltop")
J.ar(z.a).v(0,"scrollfollow")
x=z.a.style
x.top="0px"
z.c=C.m}else if(z.c===C.i&&C.h.gap(window)>0){x=z.a.style.top
v=J.aq(H.al(C.a.k(x,0,C.a.aJ(x,"px")),null,null),y)
if(J.bT(v,0))v=0
x=z.a.style
w=J.X(v)+"px"
x.top=w}}z.b=C.h.gap(window)}}}],["","",,T,{"^":"",hp:{"^":"b;a,b,c,d",
fq:[function(a){var z,y,x,w
z=H.bP(J.eT(a),"$isA")
z.toString
y=z.getAttribute("data-"+new W.e2(new W.cj(z)).au("value"))
z=window.location
x="https://"+H.e(y)+".hibis.com"
w=P.cf()
z.href=x+H.e(w.gbK(w))},"$1","geh",2,0,24],
dA:function(a){var z,y,x,w
z=this.a
y=z.querySelector("#selected-language")
this.d=y
J.eZ(y,a.bW("lang_"+a.b))
this.b=z.querySelector("#selected-language-options")
y=document
x=new W.cl(y.querySelectorAll(".language-option"),[null])
this.c=x.ab(x,!1)
z=J.ai(z)
W.ae(z.a,z.b,new T.hr(this),!1,H.F(z,0))
W.ae(y,"click",new T.hs(this),!1,W.a0)
for(z=this.c,y=z.length,x=this.geh(),w=0;w<z.length;z.length===y||(0,H.a7)(z),++w)J.ai(z[w]).bH(x)},
m:{
hq:function(a){var z=new T.hp(document.querySelector("#language-selector"),null,null,null)
z.dA(a)
return z}}},hr:{"^":"c:0;a",
$1:function(a){J.f2(a)
J.ar(this.a.b).v(0,"hide")}},hs:{"^":"c:0;a",
$1:function(a){return J.ar(this.a.b).A(0,"hide")}}}],["","",,V,{"^":"",
hN:function(a){var z=document
V.dw(z.querySelector("#header-content"),"inc/header.html",new V.hT(a,z.querySelector("#footer")))},
dw:function(a,b,c){if(a==null)throw H.a(P.b7("container"))
W.dc(b,null,null).a1(new V.hJ(a,c)).cH(new V.hK())},
mn:[function(a){var z,y
z=document.querySelector("#hamburger-menu").style
y=z.visibility==="visible"?"hidden":"visible"
z.visibility=y},"$1","lf",2,0,29],
hL:function(){var z,y
z=P.cf()
y=z.gaI(z)
z=$.$get$c9()
z.b=J.y(y).aJ(y,".")===2?C.a.k(y,0,2):"en"
T.hq(z)
z=new W.cl(document.querySelectorAll(".lang-exp"),[null])
z.L(z,new V.hM())},
hT:{"^":"c:1;a,b",
$0:function(){var z,y,x
z=this.a
y="#"+z
x=document
y=x.querySelector(y)
if(y!=null)J.ar(x.querySelector("#"+z)).A(0,"active")
H.bP(x.querySelector("#academy"),"$isbV").href="http://fraudacademy.hibis.com"
H.bP(x.querySelector("#academy_small"),"$isbV").href="http://fraudacademy.hibis.com"
z=J.ai(x.querySelector("#hamburger"))
W.ae(z.a,z.b,V.lf(),!1,H.F(z,0))
x=J.b5(x.querySelector("#micro-nav-list"))
x.L(x,new V.hR())
A.ft()
V.dw(this.b,"inc/footer.html",new V.hS())}},
hR:{"^":"c:25;",
$1:function(a){J.ai(J.bo(J.b5(a))).bH(new V.hQ())}},
hQ:{"^":"c:0;",
$1:function(a){var z=document.querySelector("#hamburger-menu").style
z.visibility="hidden"
return"hidden"}},
hS:{"^":"c:1;",
$0:function(){var z,y,x
z=document
y=new W.cl(z.querySelectorAll(".unresolved"),[null])
y.L(y,new V.hO())
V.hL()
if(window.location.hash.length!==0){x=z.querySelector(window.location.hash)
if(x!=null)P.az(C.I,new V.hP(x))}}},
hO:{"^":"c:9;",
$1:function(a){J.cK(J.cH(a),"opacity","1","")}},
hP:{"^":"c:1;a",
$0:function(){return C.h.d8(window,0,C.e.bP(this.a.offsetTop))}},
hJ:{"^":"c:3;a,b",
$1:function(a){var z
J.f_(this.a,a,new V.dL())
z=this.b
if(z!=null)z.$0()}},
hK:{"^":"c:0;",
$1:function(a){P.bn(J.X(a))}},
hM:{"^":"c:9;",
$1:function(a){var z,y,x
z=$.$get$c9()
y=J.q(a)
x=y.geD(a)
return y.bd(a,z.bW(x.a.a.getAttribute("data-"+x.au("exp"))),new V.dL())}},
dL:{"^":"b;",
af:function(a){return!0},
a9:function(a,b,c){return!0}}}],["","",,Z,{"^":"",hV:{"^":"b;a,b",
bW:function(a){var z=this.a
return z.i(0,this.b).J(a)?z.i(0,this.b).i(0,a):a}}}],["","",,S,{"^":"",
n_:[function(){S.fw("honesty1.json")},"$0","eF",0,0,2],
fv:{"^":"b;a,b,c,d,e,f,r,x,y,z,Q,ch",
fp:[function(a){var z,y,x,w,v,u
z=C.V.eE(a)
y=P.cf()
x=y.gaI(y)
w=J.aL(z,J.y(x).aJ(x,".")===2?C.a.k(x,0,2):"en")
if(w.J("questions")!==!0)throw H.a(new P.t("Missing required key: questions"))
y=w.i(0,"questions")
v=[P.n]
if(!H.aH(y,"$ish",v,"$ash"))throw H.a(new P.t("Invalid data: questions"))
if(J.as(H.ll(w.i(0,"questions"),"$ish",v,"$ash")))throw H.a(new P.t("Invalid data: no questions"))
if(w.J("feedback")!==!0)throw H.a(new P.t("Missing required key: feedback"))
if(w.J("finally")!==!0)throw H.a(new P.t("Missing required key: finally"))
if(w.J("prefix")!==!0)throw H.a(new P.t("Missing required key: prefix"))
if(w.J("start-question")!==!0)throw H.a(new P.t("Missing required key: start-question"))
y=document
J.b6(y.querySelector("#start-question"),w.i(0,"start-question"))
this.bA(y.querySelector("#angel"))
P.az(C.u,new S.fy(this))
v=J.ai(y.querySelector("#start-yes-button"))
v.gt(v).a1(new S.fz(this,w))
v=J.ai(y.querySelector("#start-no-button"))
v.gt(v).a1(new S.fA(this,w))
this.e=w.i(0,"feedback")
this.f=w.i(0,"finally")
this.x=w.J("per_page")===!0?w.i(0,"per_page"):4
this.Q=w.i(0,"questions")
this.y=w.J("total")===!0?w.i(0,"total"):J.Q(this.Q)
$.af=0
this.a=C.H
this.d=H.v([],[S.bB])
J.b6(y.querySelector("#question-prefix"),w.i(0,"prefix"))
this.c=y.querySelector("#question-container")
this.b=y.querySelector("#evilbar")
y=y.querySelector("#evilbar-container").getClientRects()
u=(y&&C.a1).gt(y)
y=J.q(u)
v=y.gcW(u)
y=y.gb7(u)
if(typeof v!=="number")return v.ar()
if(typeof y!=="number")return H.p(y)
y=C.e.d_(v-y)
$.bl=y
v=this.y
if(typeof v!=="number")return H.p(v)
this.r=C.c.aS(y,v)
this.ch=W.ae(window,"click",new S.fB(this),!1,W.a0)
this.co(this.x)
V.hN("honesty")},"$1","ge3",2,0,26],
co:function(a){var z,y,x,w,v,u,t,s,r,q,p,o
y=this.d;(y&&C.b).sh(y,0)
J.b5(this.c).U(0)
if(J.as(this.Q)!==!0){y=this.z
x=this.y
if(typeof y!=="number")return y.aQ()
if(typeof x!=="number")return H.p(x)
x=y>=x
y=x}else y=!0
if(y){this.ch.a0()
for(;J.Q(this.e.gK())>1;)try{z=J.eM(this.e.gK(),new S.fD())
if(z!=null)J.cJ(this.e,z)}catch(w){if(H.z(w) instanceof P.t)break
else throw w}y=document
v=y.querySelector("#question-prefix")
J.b6(v,J.aL(J.bo(J.cI(this.e)),"title"))
x=v.style
x.textAlign="center"
J.b6(y.querySelector("#honesty-feedback"),J.aL(J.bo(J.cI(this.e)),"description"))
u=y.querySelector("#honesty-suggestions")
if(u!=null){t=y.querySelector("#honesty-suggestions-button")
s=y.querySelector("#honesty-suggestions-textarea")
if(t!=null&&s!=null){x=t.style
x.padding="0.3rem 0.5rem"
J.ai(t).aw(0,new S.fE(u,s))}}x=y.querySelector("#honesty-submit-job-function").style
x.display="block"
x=J.ai(y.querySelector("#post-job-button"))
x.gt(x).a1(new S.fF())
r=y.querySelector("#honesty-final-feedback")
J.b6(r,this.f)
P.az(C.L,new S.fG(r))}else{if(typeof a!=="number")return H.p(a)
q=0
for(;q<a;++q){if(J.as(this.Q)!==!0){y=this.z
x=this.y
if(typeof y!=="number")return y.aQ()
if(typeof x!=="number")return H.p(x)
x=y>=x
y=x}else y=!0
if(y)break
y=this.Q
x=J.y(y)
p=x.i(y,this.a.bJ(x.gh(y)))
y=this.a.bJ(10)
o=this.a.bJ(this.r)+1
if(y+1===10)o*=-1
this.d.push(S.i_(p,this.c,o))
J.cJ(this.Q,p)
y=this.z
if(typeof y!=="number")return y.P()
this.z=y+1}}},
cm:function(a){var z=document
J.aN(z.querySelector("#start-yes-button"))
J.aN(z.querySelector("#start-no-button"))
J.b5(z.querySelector("#start-answer")).A(0,a)
P.az(C.J,new S.fC())},
bA:function(a){var z=a.style
C.f.a3(z,"transform",(z&&C.f).d5(z,"transform")==="scale(1, 1)"?"scale(0.8, 0.8)":"scale(1, 1)","")
P.az(C.u,new S.fI(this,a))},
cw:function(a){var z,y
z=a.style
y=z.visibility==="visible"?"hidden":"visible"
z.visibility=y
P.az(C.K,new S.fH(this,a))},
dz:function(a){W.dc(a,null,null).a1(this.ge3()).cH(new S.fJ())
this.z=0},
m:{
fw:function(a){var z=new S.fv(null,null,null,null,null,null,null,null,null,null,null,null)
z.dz(a)
return z}}},
fJ:{"^":"c:0;",
$1:function(a){return P.bn(a)}},
fy:{"^":"c:1;a",
$0:function(){return this.a.bA(document.querySelector("#devil"))}},
fz:{"^":"c:0;a,b",
$1:function(a){var z,y,x,w
z=document
y=z.createElement("p")
x=z.createElement("span")
w=z.createElement("span")
z=this.b
C.B.a_(x,z.i(0,"start_answer_yes"))
C.B.a_(w,C.a.P("&nbsp",z.i(0,"start_answer_yes_blinking")))
z=this.a
z.cw(w)
y.appendChild(x)
y.appendChild(w)
z.cm(y)}},
fA:{"^":"c:0;a,b",
$1:function(a){var z=document.createElement("p")
C.p.a_(z,this.b.i(0,"start_answer_no"))
this.a.cm(z)}},
fB:{"^":"c:0;a",
$1:function(a){var z,y,x,w,v,u
try{z=this.a.d;(z&&C.b).aw(z,new S.fx())}catch(y){if(H.z(y) instanceof P.t){z=this.a
z.co(z.x)}else throw y}z=$.bl
if(typeof z!=="number")return z.aS()
z=C.c.a7(z,2)
x=$.af
if(typeof x!=="number")return H.p(x)
w=z+x
x=this.a
z=x.b.style
v=C.e.j(w)+"px"
z.width=v
z=$.bl
if(typeof z!=="number")return H.p(z)
u=C.e.d_(0+w/z*200)
x=x.b.style
z="rgba("+u+",175,175,255)"
x.backgroundColor=z}},
fx:{"^":"c:27;",
$1:function(a){return J.eR(a)!==!0}},
fD:{"^":"c:3;",
$1:function(a){var z,y
z=$.af
y=H.al(a,null,null)
if(typeof z!=="number")return z.I()
if(typeof y!=="number")return H.p(y)
return z<y}},
fE:{"^":"c:0;a,b",
$1:function(a){var z,y,x,w
if(J.as(J.eU(this.b)))return!1
z=this.a
y=J.q(z)
y.gaE(z).U(0)
x=document.createElement("p")
C.p.a_(x,"Thank you!")
w=x.style
w.textAlign="center"
y.gaE(z).A(0,x)
return!0}},
fF:{"^":"c:0;",
$1:function(a){J.aN(document.querySelector("#honesty-submit-job-function"))}},
fG:{"^":"c:1;a",
$0:function(){var z=this.a.style;(z&&C.f).a3(z,"opacity","1","")}},
fC:{"^":"c:1;",
$0:function(){var z=document
J.aN(z.querySelector("#honesty-start-container"))
z=z.querySelector("#honesty-game-container").style
z.visibility="visible"}},
fI:{"^":"c:1;a,b",
$0:function(){return this.a.bA(this.b)}},
fH:{"^":"c:1;a,b",
$0:function(){return this.a.cw(this.b)}},
bB:{"^":"b;a,b,c,d,e,f",
gc_:function(a){return this.b},
dC:function(a,b,c){var z,y,x,w
if(a==null||J.as(a)===!0)throw H.a(P.b7("value"))
if(b==null)throw H.a(P.b7("container"))
z=document
y=z.createElement("div")
this.c=y
y.className="question"
y=z.createElement("p")
this.d=y
C.p.a_(y,a)
this.e=W.dd(null,"gfx/honesty_yes.png",null)
this.f=W.dd(null,"gfx/honesty_no.png",null)
this.b=!1
y=[W.a0]
x=new W.bG(this.e,"click",!1,y)
x.gt(x).a1(new S.i0(this))
y=new W.bG(this.f,"click",!1,y)
y.gt(y).a1(new S.i1(this))
w=z.createElement("div")
w.className="alt"
this.c.appendChild(this.d)
w.appendChild(this.e)
w.appendChild(this.f)
this.c.appendChild(w)
J.b5(b).A(0,this.c)},
m:{
i_:function(a,b,c){var z=new S.bB(c,null,null,null,null,null)
z.dC(a,b,c)
return z}}},
i0:{"^":"c:0;a",
$1:function(a){var z,y,x
z=this.a
if(!z.b){y=$.af
if(typeof y!=="number")return y.P()
y+=z.a
$.af=y
x=$.bl
if(typeof x!=="number")return x.aS()
x=-C.c.a7(x,2)
if(y<x)$.af=x
y=z.e.style;(y&&C.f).a3(y,"opacity","1","")
y=z.f.style;(y&&C.f).a3(y,"opacity","0.1","")
z.b=!0}}},
i1:{"^":"c:0;a",
$1:function(a){var z,y,x
z=this.a
if(!z.b){y=$.af
if(typeof y!=="number")return y.ar()
y-=z.a
$.af=y
x=$.bl
if(typeof x!=="number")return x.aS()
x=C.c.a7(x,2)
if(y>x)$.af=x
y=z.e.style;(y&&C.f).a3(y,"opacity","0.1","")
y=z.f.style;(y&&C.f).a3(y,"opacity","1","")
z.b=!0}}}},1]]
setupProgram(dart,0)
J.l=function(a){if(typeof a=="number"){if(Math.floor(a)==a)return J.dh.prototype
return J.he.prototype}if(typeof a=="string")return J.bc.prototype
if(a==null)return J.hf.prototype
if(typeof a=="boolean")return J.hd.prototype
if(a.constructor==Array)return J.ba.prototype
if(typeof a!="object"){if(typeof a=="function")return J.bd.prototype
return a}if(a instanceof P.b)return a
return J.bM(a)}
J.y=function(a){if(typeof a=="string")return J.bc.prototype
if(a==null)return a
if(a.constructor==Array)return J.ba.prototype
if(typeof a!="object"){if(typeof a=="function")return J.bd.prototype
return a}if(a instanceof P.b)return a
return J.bM(a)}
J.a2=function(a){if(a==null)return a
if(a.constructor==Array)return J.ba.prototype
if(typeof a!="object"){if(typeof a=="function")return J.bd.prototype
return a}if(a instanceof P.b)return a
return J.bM(a)}
J.cy=function(a){if(typeof a=="number")return J.bb.prototype
if(a==null)return a
if(!(a instanceof P.b))return J.bi.prototype
return a}
J.kW=function(a){if(typeof a=="number")return J.bb.prototype
if(typeof a=="string")return J.bc.prototype
if(a==null)return a
if(!(a instanceof P.b))return J.bi.prototype
return a}
J.b3=function(a){if(typeof a=="string")return J.bc.prototype
if(a==null)return a
if(!(a instanceof P.b))return J.bi.prototype
return a}
J.q=function(a){if(a==null)return a
if(typeof a!="object"){if(typeof a=="function")return J.bd.prototype
return a}if(a instanceof P.b)return a
return J.bM(a)}
J.aq=function(a,b){if(typeof a=="number"&&typeof b=="number")return a+b
return J.kW(a).P(a,b)}
J.C=function(a,b){if(a==null)return b==null
if(typeof a!="object")return b!=null&&a===b
return J.l(a).C(a,b)}
J.bT=function(a,b){if(typeof a=="number"&&typeof b=="number")return a>b
return J.cy(a).ao(a,b)}
J.cE=function(a,b){if(typeof a=="number"&&typeof b=="number")return a<b
return J.cy(a).I(a,b)}
J.aL=function(a,b){if(typeof b==="number")if(a.constructor==Array||typeof a=="string"||H.lb(a,a[init.dispatchPropertyName]))if(b>>>0===b&&b<a.length)return a[b]
return J.y(a).i(a,b)}
J.cF=function(a){return J.q(a).dQ(a)}
J.eJ=function(a,b,c){return J.q(a).ec(a,b,c)}
J.eK=function(a,b,c,d){return J.q(a).cD(a,b,c,d)}
J.bU=function(a,b,c){return J.y(a).eA(a,b,c)}
J.b4=function(a,b){return J.a2(a).B(a,b)}
J.eL=function(a,b,c,d){return J.a2(a).av(a,b,c,d)}
J.eM=function(a,b){return J.a2(a).aw(a,b)}
J.cG=function(a){return J.q(a).ger(a)}
J.b5=function(a){return J.q(a).gaE(a)}
J.ar=function(a){return J.q(a).gcI(a)}
J.aM=function(a){return J.q(a).gah(a)}
J.bo=function(a){return J.a2(a).gt(a)}
J.ag=function(a){return J.l(a).gF(a)}
J.as=function(a){return J.y(a).gu(a)}
J.ah=function(a){return J.a2(a).gw(a)}
J.Q=function(a){return J.y(a).gh(a)}
J.eN=function(a){return J.q(a).gf0(a)}
J.ai=function(a){return J.q(a).gaM(a)}
J.eO=function(a){return J.q(a).gf3(a)}
J.eP=function(a){return J.q(a).gf4(a)}
J.eQ=function(a){return J.q(a).gfa(a)}
J.eR=function(a){return J.q(a).gc_(a)}
J.cH=function(a){return J.q(a).gc0(a)}
J.eS=function(a){return J.q(a).gfd(a)}
J.eT=function(a){return J.q(a).gal(a)}
J.eU=function(a){return J.q(a).gS(a)}
J.cI=function(a){return J.q(a).ga2(a)}
J.eV=function(a,b){return J.a2(a).aa(a,b)}
J.aN=function(a){return J.a2(a).cT(a)}
J.cJ=function(a,b){return J.a2(a).v(a,b)}
J.eW=function(a,b,c,d){return J.q(a).cU(a,b,c,d)}
J.eX=function(a,b){return J.q(a).f9(a,b)}
J.aO=function(a,b){return J.q(a).aR(a,b)}
J.eY=function(a,b){return J.q(a).sb4(a,b)}
J.b6=function(a,b){return J.q(a).scR(a,b)}
J.eZ=function(a,b){return J.q(a).a_(a,b)}
J.f_=function(a,b,c){return J.q(a).bd(a,b,c)}
J.cK=function(a,b,c,d){return J.q(a).a3(a,b,c,d)}
J.f0=function(a,b){return J.a2(a).dk(a,b)}
J.f1=function(a,b){return J.b3(a).O(a,b)}
J.f2=function(a){return J.q(a).dl(a)}
J.cL=function(a){return J.b3(a).fe(a)}
J.X=function(a){return J.l(a).j(a)}
J.f3=function(a){return J.b3(a).ff(a)}
J.cM=function(a){return J.b3(a).fg(a)}
I.U=function(a){a.immutable$list=Array
a.fixed$length=Array
return a}
var $=I.p
C.r=W.bW.prototype
C.f=W.ff.prototype
C.M=W.b9.prototype
C.N=J.i.prototype
C.b=J.ba.prototype
C.c=J.dh.prototype
C.e=J.bb.prototype
C.a=J.bc.prototype
C.U=J.bd.prototype
C.a0=W.hD.prototype
C.p=W.hU.prototype
C.A=J.hW.prototype
C.B=W.ic.prototype
C.C=W.iw.prototype
C.q=J.bi.prototype
C.h=W.iO.prototype
C.a1=W.j1.prototype
C.E=new P.f6(!1)
C.D=new P.f5(C.E)
C.F=new P.hI()
C.G=new P.je()
C.H=new P.jD()
C.d=new P.jT()
C.t=new P.a9(0)
C.I=new P.a9(1e5)
C.u=new P.a9(1e6)
C.J=new P.a9(4e6)
C.K=new P.a9(5e5)
C.L=new P.a9(5e6)
C.m=new A.db(0,"HeaderState.top")
C.i=new A.db(1,"HeaderState.follow")
C.O=function() {  var toStringFunction = Object.prototype.toString;  function getTag(o) {    var s = toStringFunction.call(o);    return s.substring(8, s.length - 1);  }  function getUnknownTag(object, tag) {    if (/^HTML[A-Z].*Element$/.test(tag)) {      var name = toStringFunction.call(object);      if (name == "[object Object]") return null;      return "HTMLElement";    }  }  function getUnknownTagGenericBrowser(object, tag) {    if (self.HTMLElement && object instanceof HTMLElement) return "HTMLElement";    return getUnknownTag(object, tag);  }  function prototypeForTag(tag) {    if (typeof window == "undefined") return null;    if (typeof window[tag] == "undefined") return null;    var constructor = window[tag];    if (typeof constructor != "function") return null;    return constructor.prototype;  }  function discriminator(tag) { return null; }  var isBrowser = typeof navigator == "object";  return {    getTag: getTag,    getUnknownTag: isBrowser ? getUnknownTagGenericBrowser : getUnknownTag,    prototypeForTag: prototypeForTag,    discriminator: discriminator };}
C.v=function(hooks) { return hooks; }
C.P=function(hooks) {  if (typeof dartExperimentalFixupGetTag != "function") return hooks;  hooks.getTag = dartExperimentalFixupGetTag(hooks.getTag);}
C.Q=function(hooks) {  var getTag = hooks.getTag;  var prototypeForTag = hooks.prototypeForTag;  function getTagFixed(o) {    var tag = getTag(o);    if (tag == "Document") {      // "Document", so we check for the xmlVersion property, which is the empty      if (!!o.xmlVersion) return "!Document";      return "!HTMLDocument";    }    return tag;  }  function prototypeForTagFixed(tag) {    if (tag == "Document") return null;    return prototypeForTag(tag);  }  hooks.getTag = getTagFixed;  hooks.prototypeForTag = prototypeForTagFixed;}
C.R=function(hooks) {  var userAgent = typeof navigator == "object" ? navigator.userAgent : "";  if (userAgent.indexOf("Firefox") == -1) return hooks;  var getTag = hooks.getTag;  var quickMap = {    "BeforeUnloadEvent": "Event",    "DataTransfer": "Clipboard",    "GeoGeolocation": "Geolocation",    "Location": "!Location",    "WorkerMessageEvent": "MessageEvent",    "XMLDocument": "!Document"};  function getTagFirefox(o) {    var tag = getTag(o);    return quickMap[tag] || tag;  }  hooks.getTag = getTagFirefox;}
C.w=function getTagFallback(o) {  var s = Object.prototype.toString.call(o);  return s.substring(8, s.length - 1);}
C.S=function(hooks) {  var userAgent = typeof navigator == "object" ? navigator.userAgent : "";  if (userAgent.indexOf("Trident/") == -1) return hooks;  var getTag = hooks.getTag;  var quickMap = {    "BeforeUnloadEvent": "Event",    "DataTransfer": "Clipboard",    "HTMLDDElement": "HTMLElement",    "HTMLDTElement": "HTMLElement",    "HTMLPhraseElement": "HTMLElement",    "Position": "Geoposition"  };  function getTagIE(o) {    var tag = getTag(o);    var newTag = quickMap[tag];    if (newTag) return newTag;    if (tag == "Object") {      if (window.DataView && (o instanceof window.DataView)) return "DataView";    }    return tag;  }  function prototypeForTagIE(tag) {    var constructor = window[tag];    if (constructor == null) return null;    return constructor.prototype;  }  hooks.getTag = getTagIE;  hooks.prototypeForTag = prototypeForTagIE;}
C.T=function(getTagFallback) {  return function(hooks) {    if (typeof navigator != "object") return hooks;    var ua = navigator.userAgent;    if (ua.indexOf("DumpRenderTree") >= 0) return hooks;    if (ua.indexOf("Chrome") >= 0) {      function confirm(p) {        return typeof window == "object" && window[p] && window[p].name == p;      }      if (confirm("Window") && confirm("HTMLElement")) return hooks;    }    hooks.getTag = getTagFallback;  };}
C.V=new P.hn(null,null)
C.W=new P.ho(null)
C.j=I.U([0,0,32776,33792,1,10240,0,0])
C.X=H.v(I.U(["*::class","*::dir","*::draggable","*::hidden","*::id","*::inert","*::itemprop","*::itemref","*::itemscope","*::lang","*::spellcheck","*::title","*::translate","A::accesskey","A::coords","A::hreflang","A::name","A::shape","A::tabindex","A::target","A::type","AREA::accesskey","AREA::alt","AREA::coords","AREA::nohref","AREA::shape","AREA::tabindex","AREA::target","AUDIO::controls","AUDIO::loop","AUDIO::mediagroup","AUDIO::muted","AUDIO::preload","BDO::dir","BODY::alink","BODY::bgcolor","BODY::link","BODY::text","BODY::vlink","BR::clear","BUTTON::accesskey","BUTTON::disabled","BUTTON::name","BUTTON::tabindex","BUTTON::type","BUTTON::value","CANVAS::height","CANVAS::width","CAPTION::align","COL::align","COL::char","COL::charoff","COL::span","COL::valign","COL::width","COLGROUP::align","COLGROUP::char","COLGROUP::charoff","COLGROUP::span","COLGROUP::valign","COLGROUP::width","COMMAND::checked","COMMAND::command","COMMAND::disabled","COMMAND::label","COMMAND::radiogroup","COMMAND::type","DATA::value","DEL::datetime","DETAILS::open","DIR::compact","DIV::align","DL::compact","FIELDSET::disabled","FONT::color","FONT::face","FONT::size","FORM::accept","FORM::autocomplete","FORM::enctype","FORM::method","FORM::name","FORM::novalidate","FORM::target","FRAME::name","H1::align","H2::align","H3::align","H4::align","H5::align","H6::align","HR::align","HR::noshade","HR::size","HR::width","HTML::version","IFRAME::align","IFRAME::frameborder","IFRAME::height","IFRAME::marginheight","IFRAME::marginwidth","IFRAME::width","IMG::align","IMG::alt","IMG::border","IMG::height","IMG::hspace","IMG::ismap","IMG::name","IMG::usemap","IMG::vspace","IMG::width","INPUT::accept","INPUT::accesskey","INPUT::align","INPUT::alt","INPUT::autocomplete","INPUT::autofocus","INPUT::checked","INPUT::disabled","INPUT::inputmode","INPUT::ismap","INPUT::list","INPUT::max","INPUT::maxlength","INPUT::min","INPUT::multiple","INPUT::name","INPUT::placeholder","INPUT::readonly","INPUT::required","INPUT::size","INPUT::step","INPUT::tabindex","INPUT::type","INPUT::usemap","INPUT::value","INS::datetime","KEYGEN::disabled","KEYGEN::keytype","KEYGEN::name","LABEL::accesskey","LABEL::for","LEGEND::accesskey","LEGEND::align","LI::type","LI::value","LINK::sizes","MAP::name","MENU::compact","MENU::label","MENU::type","METER::high","METER::low","METER::max","METER::min","METER::value","OBJECT::typemustmatch","OL::compact","OL::reversed","OL::start","OL::type","OPTGROUP::disabled","OPTGROUP::label","OPTION::disabled","OPTION::label","OPTION::selected","OPTION::value","OUTPUT::for","OUTPUT::name","P::align","PRE::width","PROGRESS::max","PROGRESS::min","PROGRESS::value","SELECT::autocomplete","SELECT::disabled","SELECT::multiple","SELECT::name","SELECT::required","SELECT::size","SELECT::tabindex","SOURCE::type","TABLE::align","TABLE::bgcolor","TABLE::border","TABLE::cellpadding","TABLE::cellspacing","TABLE::frame","TABLE::rules","TABLE::summary","TABLE::width","TBODY::align","TBODY::char","TBODY::charoff","TBODY::valign","TD::abbr","TD::align","TD::axis","TD::bgcolor","TD::char","TD::charoff","TD::colspan","TD::headers","TD::height","TD::nowrap","TD::rowspan","TD::scope","TD::valign","TD::width","TEXTAREA::accesskey","TEXTAREA::autocomplete","TEXTAREA::cols","TEXTAREA::disabled","TEXTAREA::inputmode","TEXTAREA::name","TEXTAREA::placeholder","TEXTAREA::readonly","TEXTAREA::required","TEXTAREA::rows","TEXTAREA::tabindex","TEXTAREA::wrap","TFOOT::align","TFOOT::char","TFOOT::charoff","TFOOT::valign","TH::abbr","TH::align","TH::axis","TH::bgcolor","TH::char","TH::charoff","TH::colspan","TH::headers","TH::height","TH::nowrap","TH::rowspan","TH::scope","TH::valign","TH::width","THEAD::align","THEAD::char","THEAD::charoff","THEAD::valign","TR::align","TR::bgcolor","TR::char","TR::charoff","TR::valign","TRACK::default","TRACK::kind","TRACK::label","TRACK::srclang","UL::compact","UL::type","VIDEO::controls","VIDEO::height","VIDEO::loop","VIDEO::mediagroup","VIDEO::muted","VIDEO::preload","VIDEO::width"]),[P.n])
C.k=I.U([0,0,65490,45055,65535,34815,65534,18431])
C.l=I.U([0,0,26624,1023,65534,2047,65534,2047])
C.Y=I.U(["HEAD","AREA","BASE","BASEFONT","BR","COL","COLGROUP","EMBED","FRAME","FRAMESET","HR","IMAGE","IMG","INPUT","ISINDEX","LINK","META","PARAM","SOURCE","STYLE","TITLE","WBR"])
C.Z=I.U([])
C.a_=I.U([0,0,32722,12287,65534,34815,65534,18431])
C.x=I.U([0,0,24576,1023,65534,34815,65534,18431])
C.y=I.U([0,0,32754,11263,65534,34815,65534,18431])
C.z=I.U([0,0,65490,12287,65535,34815,65534,18431])
C.n=H.v(I.U(["bind","if","ref","repeat","syntax"]),[P.n])
C.o=H.v(I.U(["A::href","AREA::href","BLOCKQUOTE::cite","BODY::background","COMMAND::icon","DEL::cite","FORM::action","IMG::src","INPUT::src","INS::cite","Q::cite","VIDEO::poster"]),[P.n])
$.dy="$cachedFunction"
$.dz="$cachedInvocation"
$.a3=0
$.aR=null
$.cO=null
$.cz=null
$.eu=null
$.eE=null
$.bL=null
$.bQ=null
$.cA=null
$.aE=null
$.aZ=null
$.b_=null
$.ct=!1
$.o=C.d
$.d7=0
$.aa=null
$.c_=null
$.d5=null
$.d4=null
$.d1=null
$.d0=null
$.d_=null
$.cZ=null
$.af=null
$.bl=null
$=null
init.isHunkLoaded=function(a){return!!$dart_deferred_initializers$[a]}
init.deferredInitialized=new Object(null)
init.isHunkInitialized=function(a){return init.deferredInitialized[a]}
init.initializeLoadedHunk=function(a){$dart_deferred_initializers$[a]($globals$,$)
init.deferredInitialized[a]=true}
init.deferredLibraryUris={}
init.deferredLibraryHashes={};(function(a){for(var z=0;z<a.length;){var y=a[z++]
var x=a[z++]
var w=a[z++]
I.$lazy(y,x,w)}})(["cY","$get$cY",function(){return H.eA("_$dart_dartClosure")},"c0","$get$c0",function(){return H.eA("_$dart_js")},"de","$get$de",function(){return H.h9()},"df","$get$df",function(){if(typeof WeakMap=="function")var z=new WeakMap()
else{z=$.d7
$.d7=z+1
z="expando$key$"+z}return new P.fo(null,z)},"dM","$get$dM",function(){return H.a6(H.bE({
toString:function(){return"$receiver$"}}))},"dN","$get$dN",function(){return H.a6(H.bE({$method$:null,
toString:function(){return"$receiver$"}}))},"dO","$get$dO",function(){return H.a6(H.bE(null))},"dP","$get$dP",function(){return H.a6(function(){var $argumentsExpr$='$arguments$'
try{null.$method$($argumentsExpr$)}catch(z){return z.message}}())},"dT","$get$dT",function(){return H.a6(H.bE(void 0))},"dU","$get$dU",function(){return H.a6(function(){var $argumentsExpr$='$arguments$'
try{(void 0).$method$($argumentsExpr$)}catch(z){return z.message}}())},"dR","$get$dR",function(){return H.a6(H.dS(null))},"dQ","$get$dQ",function(){return H.a6(function(){try{null.$method$}catch(z){return z.message}}())},"dW","$get$dW",function(){return H.a6(H.dS(void 0))},"dV","$get$dV",function(){return H.a6(function(){try{(void 0).$method$}catch(z){return z.message}}())},"ch","$get$ch",function(){return P.iR()},"au","$get$au",function(){var z,y
z=P.by
y=new P.T(0,P.iP(),null,[z])
y.dI(null,z)
return y},"b0","$get$b0",function(){return[]},"e_","$get$e_",function(){return H.hC([-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-1,-2,-2,-2,-2,-2,62,-2,62,-2,63,52,53,54,55,56,57,58,59,60,61,-2,-2,-2,-1,-2,-2,-2,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,-2,-2,-2,-2,63,-2,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,-2,-2,-2,-2,-2])},"es","$get$es",function(){return P.kw()},"cX","$get$cX",function(){return{}},"e7","$get$e7",function(){return P.dk(["A","ABBR","ACRONYM","ADDRESS","AREA","ARTICLE","ASIDE","AUDIO","B","BDI","BDO","BIG","BLOCKQUOTE","BR","BUTTON","CANVAS","CAPTION","CENTER","CITE","CODE","COL","COLGROUP","COMMAND","DATA","DATALIST","DD","DEL","DETAILS","DFN","DIR","DIV","DL","DT","EM","FIELDSET","FIGCAPTION","FIGURE","FONT","FOOTER","FORM","H1","H2","H3","H4","H5","H6","HEADER","HGROUP","HR","I","IFRAME","IMG","INPUT","INS","KBD","LABEL","LEGEND","LI","MAP","MARK","MENU","METER","NAV","NOBR","OL","OPTGROUP","OPTION","OUTPUT","P","PRE","PROGRESS","Q","S","SAMP","SECTION","SELECT","SMALL","SOURCE","SPAN","STRIKE","STRONG","SUB","SUMMARY","SUP","TABLE","TBODY","TD","TEXTAREA","TFOOT","TH","THEAD","TIME","TR","TRACK","TT","U","UL","VAR","VIDEO","WBR"],null)},"co","$get$co",function(){return P.dj()},"cU","$get$cU",function(){return P.i6("^\\S+$",!0,!1)},"c9","$get$c9",function(){return new Z.hV(P.a5(["en",P.a5(["address_copenhagen","c/o Scillani Information AB<br />Vestergade 16<br />1456 Copenhagen<br />Denmark","address_gothenburg","Hibis AB<br />Kronhusgatan 11<br />411 05 G\xf6teborg<br />Sweden","address_helsinki","Hibis Associates<br />Centry Ltd","address_london","Hibis Europe Ltd","address_malmo","Hibis AB","address_oslo","Hibis AS<br /> Meltzersgt. 4<br/> 0275 Oslo<br/> Norway","address_rome","Hibis Associates","address_stockholm","Hibis AB","contact","Contact","contact_us","Contact us","contact_copenhagen","<strong>John Wallhoff</strong><br /><a href='mailto:john.wallhoff@hibis.com'>john.wallhoff@hibis.com</a><br />+ 45 70 77 43 131","contact_gothenburg","<strong>Carina S\xf6rqvist</strong><br /><a href='mailto:carina.sorqvist@hibis.com'>carina.sorqvist@hibis.com</a><br />+ 46 707 97 97 64","contact_helsinki","<strong>Petri Kelo</strong><br /><a href='mailto:petri.kelo@centry.global'>petri.kelo@centry.global</a><br />+ 358 40 50 001 068","contact_london","<strong>Allan McDonagh</strong><br /><a href='mailto:allan.mcdonagh@hibis.com'>allan.mcdonagh@hibis.com</a><br />+ 44 77 68 32 0161","contact_malmo","<strong>Richard Minogue</strong><br /><a href='mailto:richard.minogue@hibis.com'>richard.minogue@hibis.com</a><br />+ 46 761 882 497","contact_oslo","<strong>Veronica Morino</strong><br /><a href='mailto:veronica.morino@hibis.com'>veronica.morino@hibis.com</a><br />+ 47 91 86 32 19<br/><br/><strong>Nigel Krishna Iyer</strong><br /><a href='mailto:nigel.iyer@hibis.com'>nigel.iyer@hibis.com</a><br />+ 47 90 65 44 10<br/>+ 44 7523 570004 (UK)","contact_rome","<strong>Maurizio Carmignani</strong><br /><a href='mailto:maurizio.carmignani@hibis.com'>maurizio.carmignani@hibis.com</a><br />+ 39 3489501126","contact_stockholm","<strong>Richard Minogue</strong><br /><a href='mailto:richard.minogue@hibis.com'>richard.minogue@hibis.com</a><br />+ 46 761 882 497","copenhagen","Copenhagen","copyright","&copy;2017 Hibis. All rights reserved. Design by SoiaDg. Images by Floral Zu.","frontpage_title","<strong>Fraud and corruption <span class='orange-text'>can</span> be stopped</strong>","gothenburg","Gothenburg","hibis_associates","hibis associates","hibis_people","hibis people","helsinki","Helsinki","lang_en","English (english)","lang_no","Norwegian (norsk)","lang_it","Italian (italian)","language","Language","london","London","malmo","Malm\xf6","oslo","Oslo","our_history","Our history","our_history_text","<p><strong>Hibis</strong> was founded in 1998 by Martin Samociuk. Many of the people who joined at the start came from Network Security Management in London, a company which pioneered fraud investigation and prevention in the 1980\u2019s and 90\u2019s. In 1999, Martin was joined by Nigel Krishna Iyer and one year later by Allan McDonagh. Veronica Morino became part of the group in 2001 followed by Richard Minogue in 2002.The mission of Hibis has always been to put prevention and early detection FIRST. We share with clients the need to dramatically raise awareness of fraud and corruption, give them the ability to spot it early and provide advice and resources for well managed investigations. This includes training workshops, seminars, books, publications and films all with the purpose of stimulating this greater awareness and self-reliance.</p><p>Hibis' founder, Martin Samociuk, passed away in 2013 at the age of 62 from pancreatic cancer. He will be missed by all that knew him but we are grateful for the important work he left behind.</p><p>Today Hibis is an advisory organisation which we hope will help open people\u2019s eyes to the fact that even though fraud and corruption is all around us, it can be kept under control. Our aim is to provide innovative tools and techniques to deal with it, as well as the confidence to spot it early. We aim to support those people who wish to take a stand against fraud and corruption.</p><p>Finally, if you like what you have read, and feel that you are our sort of person, then do take contact with us. We don\u2019t recruit in the traditional manner \u2013 like-minded people usually find us\u2026</p>","profile_allan","Allan\u2019s long experience from 1967 includes UK Customs and Excise Investigations and New Scotland Yard, where he specialized in narcotics and organised crime. Between 1985 and 1997 Allan worked as Deputy Managing Director with Martin Samociuk at Network Security Management Limited, Europe\u2019s leading fraud investigation consultancy. Apart from leading hundreds of investigations and recovery projects throughout the world for both commercial and government clients, he created the highly successful Forensic Laboratories which were eventually acquired by Control Risks Group. Allan has project managed many successful investigations around the world.","profile_carina","Carina S\xf6rqvist has over 15 years of experience of preventing and investigating fraud and corruption. She has acted as the investigator and project leader in investigations for clients in various different industries. Her long experience of structured investigations of real fraud and corruption cases is used in seminars and trainings regarding investigation technique. She has, for several clients, developed action plans for how to handle incidents such as suspected fraud and/or corruption. She has worked as a Senior Consultant since 2003 and before that she worked with compliance as the manager of the Internal Control department in a multinational company. Carina has a financial background and her specialities are forensic accounting and interview techniques.","profile_jan","Jan has performed a number of forensic investigations and fraud detection projects, as well as held courses in red flag detection within fraud and corruption and corporate governance.  He holds an MBA and CPA degree from the Norwegian School of Economics and Business Administration in Bergen. After spending 4 years as an external auditor he was Chief Financial Officer for 9 years in an international construction company with operations in East Africa. After that he worked for over 20 years as advisor (on, among others, business development, sustainability evaluations, performance audit and background checks) for the Norwegian Ministry of Foreign Affairs (NORAD, Embassies and Norfund) and private sector companies operating in East-Africa, The Balkans, Baltic states, Georgia, Sri Lanka, Nepal and the Palestine Territories.","profile_john","John Wallhoff, a computer security and data-analysis expert for many years, develops and implements data models to detect patterns of fraud and corruption. John participates in investigations, leads trainings and supports his colleagues through development of leading edge models to pinpoint patterns of malpractice and unethical business behavior. In addition John has built information security strategies and contingency plans for a number of companies and as a compliment to fraud detection, develops data-analysis solutions for continuous monitoring of internal controls.","profile_martina","Martina has a combined Masters degree in Business and Economics (majoring in finance) from the Norwegian Business School (BI) and the University of Ljubljana (Slovenia). Right from an early age she wanted to play an active part in eradicating systematic inefficiencies. She recognized that corruption and fraud is one of the major obstacles to sustainability and growth and was able to apply her passion at Hibis. Martina specializes in identifying red flags of corruption through internal and external analysis, and understanding and investigating them across a wide range of countries and languages-zones.","profile_fridtjof","Fridtjof Klareng Dale's passion for fighting corruption and fraud started while studying for his bachelor in European Studies at the Norwegian University of Science and Technology (NTNU). Through his strong engagement in volunteerism, he joined the newly founded student organisation Anti-Corruption International (ACI) and helped build the organisation, spearheading projects showing that \u201cyoung people not only can play a part in eradicating a global problem, but can also take the lead.\u201d Through ACI he got to know Hibis, where he is now successfully working as a fraud investigator combining this with his anti-corruption activities.","profile_maurizio","Maurizio has 18 years\u2019 experience in innovation and organisational development in a wide variety of sectors which include telecommunications and technology, banking, retail and consumer products, culture, education and government, in primarily Italy, Switzerland and Brazil. He provides training to achieve fulfilment of goals both at a personal and organisational level. Finding fraud and corruption early, dealing with it responsibly to foster organisational robustness is an important cornerstone of his work today.","profile_nigel","Nigel has over 20 years experience investigating and detecting fraud and corruption. A computer scientist and qualified chartered accountant Nigel soon found that his true passion lay in rooting out corruption and fraud. Nigel is also today a qualified dramatist and has written a number of films and plays based on experiences, many of which are used in teaching worldwide. He has written several books and papers, and teaches widely how to defend organisations against the \u201ccommercial dark arts\u201d. He is also a fellow of the University of Leicester School of Business.","profile_petri","Petri Kelo is Hibis\u2019 associated partner in Finland. His academic background includes a Masters of Security from Helsinki University of Technology. Petri has worked for over 25 years with logistics, service quality and security as well as managing the risk of fraud and corruption. Petri is also one of the founders of Centry Ltd, a security company specialized in logistics & transportation security, cyber security, security risk management and compliance & investigative services. Petri is a well-known speaker and trainer in TAPA (Transportation Asset Protection Association), AEO (Authorized Economic Operator), ISO 28000 (Supply Chain Security Management) and logistics security.","profile_richard","Since his first full time job as internal auditor starting in 1975, Richard has accumulated experience in audit, investigation, financial control, and general management. Inquisitive by nature, he knows there is usually more than one right way to do things, and many wrong ways. Richard\u2019s talent for penetrating complexity and understanding his clients\u2019 business processes makes him a valuable resource for assessment, investigation and improvement projects. Richard graduated BSc in Accountancy, and is qualified CPA and CIA.","profile_veronica","Veronica has over 15 years\u2019 experience investigating, finding and training others on how to prevent and manage fraud and corruption around the world. A sociologist of work and economics with a master in organisational science, she has developed holistic desktop investigative research and analysis tools to explore organisations, business partners, suppliers, customers and key individuals and discover what is really going on at a fraction of the resources normally associated with investigation. Veronica has also worked for several years with the assessment of the effectiveness of organisations\u2019 anti-fraud and corruption programs and is currently completing a PhD degree on that subject.","red_flag_game","The <span class='red-text'>red</span><br />flag Game","rome","Rome","rulebending_final_question","It would assist our research if you could provide us with details of your job functions (anonymously)","rules_game","How far can you bend the rules?","search","Search","send","send","stockholm","Stockholm","the_fraud_academy","The Fraud Academy","what_we_do","What we do","what_we_do_collapsed_text_1",'<p>There is plenty of fraud and corruption around that can be found (preferably in the early stages) and stopped. Usually fraudulent and corrupt activities are cloaked in legitimacy, and finding the truth requires experience, effort and specialist knowledge.</p><p>Our proven structured methodology "B4" (which is short for "Finding fraud before it finds you") has been developed to efficiently find and effectively deal with fraud. B4 includes activities such as:</p><ul><li>Following the money, performing structured analysis, and running B4 algorithms on transactions to find the red flags.</li><li>Convening \u201cthinking like a thief\u201d sessions (an approach invented in the 1980\u2019s by Martin Samociuk, Hibis\u2019 founder) to anticipate how the fraudsters\u2019 mind works and build a profile of the types of frauds that are occurring or likely to occur.</li><li>Finding behavioural red flags by performing holistic desktop investigative research and analysis of organisations, business partners, suppliers, customers and key individuals. All with a special focus on opportunities, motives and how people rationalize dishonest or unethical behaviour.</li><li>Analysing indications of fraud and corruption to understand which issues are the most important, and condensing them into a manageable list for our clients to resolve.</li><li>Working together with our clients to find the most effective course of action to resolve problems. Long experience gives us an overview of different approaches, which ones are appropriate in different situations, and how they should be implemented.</li></li></ul><p>If not detected early, fraud and corruption will spread. Eventually, the problem will be discovered when it becomes too large to ignore, or is reported by whistle-blowers, or both. But why wait for the whistle-blower when you can use fraud detective techniques and uncover where early stage fraud and corruption is developing now? It\u2019s better to stay ahead of the game!</p>',"what_we_do_collapsed_text_2",'<p>We probably will never totally eradicate fraud and corruption. But by raising awareness and managing the risks we can control the cost and make corrupt behaviour less acceptable. Surprisingly, much fraud and corruption involves normal, good people such as valuable and trusted employees or business partners. Awareness is a powerful tool to help good people avoid bad mistakes they will later regret, and to show them how to protect the organisation against career fraudsters. As Nelson Mandela said, education is one of the most powerful ways to change the world. We have developed courses and techniques to bridge the skills gap and constantly look for innovative new ways to raise the awareness, spread knowledge and bring people together in the fight of corruption and fraud. Examples (details can be found in our Fraud Academy page) include:</p><ul><li>Practical open courses and workshops (including our "think like a thief methodology" and "fraud detective school")</li><li>Accredited management courses</li><li>On the job-training, in-house workshops and clinics</li><li>Multimedia based training delivered over the internet (or intranet)</li><li>Experiential learning, including drama, scenarios, live simulations, \u201ccorruption-theatre\u201d and films</li><li>Publications and books</li></ul>',"what_we_do_collapsed_text_3","<p>When it is required by the client, we investigate fraud and corruption constructively and effectively.</p><p>We believe in the beauty of small investigations that win back value. We have a track record of solving our client\u2019s problems efficiently and in a way which both identifies root causes and prevents recurrence.</p><p>Exceptional situations do occur from time to time for which a deep investigation may be required, such as when an organisation needs to prepare legal actions to recover major assets or salvage parts of a business. We manage all investigations in a controlled way avoiding unnecessary expenditure and ensuring that our client is always in the driver\u2019s seat.</p>","what_we_do_collapsed_text_4","<p>The scope and complexity of external regulation, designed to protect the public and punish corporate offenders is increasing. This absorbs management attention and leaves less room for more practical programs designed to protect the organisation. Management can fall into the trap of accepting bureaucratic solutions that appear to fulfil regulatory requirements, but which do not effectively address the issue of fraudulent and corrupt behaviour. Compliance programs based on checklists are unlikely to be effective!</p><p>We are able to measure the impact and effectiveness of your existing anti-fraud and corruption activities, identifying gaps and potential improvements that will bring down the cost of fraud and corruption and strengthen the ethical culture.</p><p>Our holistic framework and assessment tool brings together years of practical experience with a distillation of the most essential knowledge from widely used existing frameworks.</p>","what_we_do_collapsed_title_1","We find early fraud and help you resolve it","what_we_do_collapsed_title_2","We raise awareness, share knowledge and transfer skills","what_we_do_collapsed_title_3","We investigate fraud and corruption responsibly","what_we_do_collapsed_title_4","We assess effectiveness of existing anti-fraud and corruption programs","what_we_do_list_1_item_1","<strong>Finding</strong> and interpreting the many <strong>red flags</strong>","what_we_do_list_1_item_2","<strong>Investigations</strong> carried out in an efficient, responsible manner","what_we_do_list_1_item_3","<strong>Analysing</strong> the root causes of incidents to identify improvement opportunities","what_we_do_list_1_item_4","<strong>Providing</strong> (through practical workshops, training and other innovative devices) the <strong>skills</strong> to turn what looks like \"bad news\" into an opportunity to save money (see <a href='http://fraudacademy.hibis.com' target='_blank'>Hibis Fraud Academy</a>)","what_we_do_list_1_item_5","<strong>Assessing</strong> and <strong>measuring</strong> the <strong>effectiveness</strong>, strengths and weaknesses of existing anti-fraud and corruption programmes","what_we_do_paragraph_1","Fraud and corruption happens all the time and is arguably one of the greatest unmanaged costs in organisations and society today. Yet most management and employees have not had any practical training in this area. Our aim is to significantly raise awareness of fraud and corruption and its consequences. We assist and advise organisations, companies and everyone else concerned by:","who_we_are","Who we are"]),"it",P.a5(["address_copenhagen","c/o Scillani Information AB<br />Vestergade 16<br />1456 Copenhagen<br />Danimarca","address_gothenburg","Hibis AB<br />Kronhusgatan 11<br />411 05 G\xf6teborg<br />Svezia","address_helsinki","Hibis Associates<br />Centry Ltd","address_london","Hibis Europe Ltd","address_malmo","Hibis AB","address_oslo","Hibis AS<br /> Meltzersgt. 4<br/> 0275 Oslo<br/> Norvegia","address_rome","Hibis Associates","address_stockholm","Hibis AB","contact","Contatti","contact_us","Contatti","contact_copenhagen","<strong>John Wallhoff</strong><br /><a href='mailto:john.wallhoff@hibis.com'>john.wallhoff@hibis.com</a><br />+ 45 70 77 43 131","contact_gothenburg","<strong>Carina S\xf6rqvist</strong><br /><a href='mailto:carina.sorqvist@hibis.com'>carina.sorqvist@hibis.com</a><br />+ 46 707 97 97 64","contact_helsinki","<strong>Petri Kelo</strong><br /><a href='mailto:petri.kelo@centry.global'>petri.kelo@centry.global</a><br />+ 358 40 50 001 068","contact_london","<strong>Allan McDonagh</strong><br /><a href='mailto:allan.mcdonagh@hibis.com'>allan.mcdonagh@hibis.com</a><br />+ 44 77 68 32 0161","contact_malmo","<strong>Richard Minogue</strong><br /><a href='mailto:richard.minogue@hibis.com'>richard.minogue@hibis.com</a><br />+ 46 761 882 497","contact_oslo","<strong>Veronica Morino</strong><br /><a href='mailto:veronica.morino@hibis.com'>veronica.morino@hibis.com</a><br />+ 47 91 86 32 19<br/><br/><strong>Nigel Krishna Iyer</strong><br /><a href='mailto:nigel.iyer@hibis.com'>nigel.iyer@hibis.com</a><br />+ 47 90 65 44 10<br/>+ 44 7523 570004 (UK)","contact_rome","<strong>Maurizio Carmignani</strong><br /><a href='mailto:maurizio.carmignani@hibis.com'>maurizio.carmignani@hibis.com</a><br />+ 39 3489501126","contact_stockholm","<strong>Richard Minogue</strong><br /><a href='mailto:richard.minogue@hibis.com'>richard.minogue@hibis.com</a><br />+ 46 761 882 497","copenhagen","Copenhagen","copyright","&copy;2017 Hibis. All rights reserved. Design by SoiaDg. Images by Floral Zu.","frontpage_title","<strong>Fraud and corruption <span class='orange-text'>can</span> be stopped</strong>","gothenburg","Gothenburg","hibis_associates","Hibis associates","hibis_people","Hibis team","helsinki","Helsinki","language","Lingua","lang_en","Inglese (english)","lang_no","Norvegese (norsk)","lang_it","Italiano (italian)","london","Londra","malmo","Malm\xf6","oslo","Oslo","our_history","La nostra storia","our_history_text","<p><strong>Hibis</strong> nasce nel 1998 grazie a un'idea di Martin Samociuk. La sua visione viene accolta entusiasticamente da un team che aveva lavorato precedentemente per Network Security Management a Londra, un'azienda all'avanguardia nel campo delle investigazioni e della prevenzione della frode negli anni Ottanta e Novanta. Nel 1999, Martin viene affiancato da Nigel Krishna Iyer e, un anno dopo, da Allan McDonagh. Veronica Morino li raggiunge nel 2001, subito seguita da Richard Minogue nel 2002. Hibis ha da sempre deciso di porre al primo posto la prevenzione e la rilevazione precoce di frodi. Avvertiamo, insieme ai nostri clienti, il bisogno di richiamare drasticamente l'attenzione sulla frode e la corruzione, formandoli su come scovare gli illeciti per tempo, oltre a fornire consulenze e risorse per gestire al meglio eventuali investigazioni. Abbiamo sviluppato apposite attivit\xe0 di formazione quali workshop e seminari, libri, articoli e film, il tutto con lo scopo di sensibilizzare garantire l'autosufficienza nel campo per i nostri clienti.</p> <p>Hibis opera nel Regno Unito e in Scandinavia dal 1999</p><p>Hibis \xe8 un'organizzazione di esperti dedicati a dimostrare che, sebbene frode e corruzione permeino l'ambiente in cui viviamo, \xe8 comunque possibile tenerli sotto controllo e arginare o evitare i danni. Il nostro obiettivo \xe8 fornire strumenti e tecniche all'avanguardia per gestire il rischio di frode, insieme alla certezza della prevenzione. Offriamo il miglior supporto a chi intende darci un taglio con frode e corruzione.</p><p>Se avete trovato la nostra presentazione di vostro gradimento, e ritenete che potrebbe essere l'ambiente lavorativo giusto per voi, non esitate a contattarci. </p> ","profile_allan","Dal 1967 ad oggi, Allan ha lavorato a New Scotland Yard occupandosi di investigazioni doganali nel Regno Unito, e in particolare di droga e criminalit\xe0 organizzata. Tra il 1985 e il 1997 Allan ha lavorato come vice-direttore di Network Secutiry Management Limited (assieme a Martin Samociuk, fondatore di Hibis), una tra le migliori ditte di consulenza a livello Europeo in materia di investigazioni anti-frode. Oltre ad aver condotto con successo centinaia di investigazioni in tutto il mondo sia per clienti privati che per aziende pubbliche, ha inoltre fondato i Forensic Laboratories, successivamente acquisiti da Control Risks Group.","profile_carina","Carina S\xf6rqvist da oltre 15 anni previene e ricerca episodi di frode e corruzione. Ha ricoperto ruoli di investigatrice a capo di inchieste per diversi clienti in vari settori. La sua pluriennale esperienza in materia di investigazioni complesse di casi di frode e corruzione \xe8 oggi sfruttata in seminari e training sulle tecniche investigative. Ha sviluppato piani d'azione per svariati clienti, suggerendo come comportarsi in caso di incidenti di sospetta natura fraudolenta. Dal 2003 ha lavorato come consulente, dopo essersi cimentata nel ramo della compliance per il dipartimento di controllo di una multinazionale. Carina ha completato studi di ragioneria e finanza, specializzandosi nell'ambito della revisione contabile e delle tecniche di interrogazione.","profile_jan","Jan ha svolto diverse investigazioni forensi e ha partecipato a una moltitudine di progetti anti-frode, oltre ad aver condotto svariati corsi di detezione dei segnali della frode nell'ambito della corporate governance. Ha ottenuto i titoli di MBA e CPA dalla Norwegian School of Economics and Business Administration di Bergen. Dopo 4 anni come revisore dei conti esterno, \xe8 stato per 9 anni CFO di una ditta di costruzioni internazionale, con operazioni nell'Africa orientale. Successivamente ha ricoperto per oltre 20 anni il ruolo di consulente (in materie quali sviluppo, valutazioni di sostenibilit\xe0, controlli di gestione, controllo dei precedenti) presso il Ministero Norvegese degli Affari Esteri (NORAD, Ambasciate e Norfund), oltre ad assistere nella medesima funzione aziende del settore privato operanti nell'Africa orientale, nei Balcani, nei paesi Baltici, Georgia, Sri Lanka, Nepal, e Palestina.","profile_john","John Wallhoff \xe8 un esperto nel settore della sicurezza digitale e nell'analisi dei dati, campi in cui ha lavorato per anni. Con Hibis in particolare, sviluppa e raffina modelli in grado di analizzare grandi quantit\xe0 di dati e ricostruire \u201cpattern\u201d fraudolenti. John partecipa a investigazioni, conduce training, e fornisce attivit\xe0 di supporto ai colleghi grazie al costante raffinamento e adattamento dei modelli agli scenari che i nostri clienti si trovano ad affrontare, per scovare qualsiasi tipo di comportamento \u201cindesiderato\u201d. Inoltre, John ha costruito strategie di sicurezza per network interni, oltre a piani d'azione in caso di emergenze per svariate organizzazioni. Complementando l'attivit\xe0 di detezione della frode, John offre anche soluzioni di analisi dei dati per monitorare periodicamente l'efficacia dei controlli interni.","profile_martina","Martina ha ottenuto una laurea magistrale in finanza e gestione aziendale presso la BI Norwegian Business School di Oslo e l'universit\xe0 di Ljubljana, in Slovenia. In quanto economista di formazione, si interessa alla frode come spreco di risorse, che potrebbero essere altrimenti allocate in maniera ottimale, favorendo una crescita e uno sviluppo sostenibile. Grazie a Hibis ha avuto modo di applicare la sua passione a diversi scenari: in particolare, si occupa di identificare le \u201cred flag\u201d attraverso analisi interne e investigazioni esterne, e si avvale spesso della propria conoscenza delle lingue per tracciare flussi monetari in vari paesi.","profile_fridtjof","Fridtjof Klareng Dale ha sviluppato uno spiccato interesse per la lotta alla corruzione mentre frequentava la facolt\xe0 di studi europei presso l'universit\xe0 norvegese della scienza e della tecnica di Trondheim (NTNU). Attraverso numerosi impegni di volontariato, si \xe8 unito al neo-fondato gruppo \"Anti-Corruption International (ACI)\", contribuendo a trasformarlo in una vera e propria organizzazione internazionale che finora, attraverso numerosi progetti, ha dimostrato come i giovani possano non solo contribuire a eradicare un problema globale, ma possano anche assumere un ruolo di guida nella lotta alla corruzione. Proprio attraverso ACI \xe8 entrato in contatto con Hibis, dove ora pu\xf2 affiancare l'attivismo anti-frode alle investigazioni.","profile_maurizio","Da 18 anni lavora come libero professionista e consulente direzionale, advisor, mentor e trainer. Ha maturato esperienze in diversi ed eterogenei settori: sviluppo e innovazione, telecomunicazioni e tecnologie per le imprese, banche e assicurazioni, moda, industria degli occhiali, industria culturale e della formazione, settore farmaceutico e sanitario, beni culturali e turismo. Ha lavorato in Italia, Svizzera e Brasile. Le aree di maggiore interesse ed esperienza sono: creazione e gestione di impresa, innovazione e gestione del cambiamento, marketing e comunicazione, formazione e sviluppo organizzativo. All'interno di questi ambiti, la detezione precoce e la gestione responsabile della frode svolgono un ruolo fondamentale.","profile_nigel","Nigel ha pi\xf9 di 20 anni di esperienza nel campo dell'investigazione della frode. Ha ottenuto un Bachelor Degree in informatica, e subito dopo ha superato l'esame nazionale per dottori commercialisti nel Regno Unito. Fin dalle prime esperienze lavorative, ha scoperto la propria vocazione di \u201cfraud detective\u201d. Successivamente si \xe8 interessato anche alla produzione teatrale, ottenendo un Master of Arts in sceneggiatura e regia teatrale. Ha scritto e prodotto numerosi testi teatrali e film basati su esperienze personali, che poi vengono utilizzati per la formazione. Sulla frode ha scritto diversi articoli e pubblicato 3 libri, e, oltre a insegnare le proprie tecniche in diversi paesi, ricopre il ruolo di Fellow presso la Leicester School of Business.","profile_petri","Petri Kelo \xe8 il partner Hibis in Finlandia. Ha ottenuto un Master's Degree in Security presso la Helsinki University of Technology. Negli ultimi 25 anni si \xe8 occupato di logistica, qualit\xe0 del servizio, sicurezza, oltre alla gestione del rischio di frode. Petri ha inoltre fondato Centry Ltd, una realt\xe0 che si occupa di sicurezza nel settore della logistica, supply chain, gestione dei rischi, compliance e servizi investigativi. Svolge tutt'ora attivit\xe0 di training in materia di AEO (Authorized Economic Operator), TAPA (Transportation Asset Protection Association) e sicurezza nella logistica (ISO 28000 \u2013 Supply chain security management).","profile_richard","Richard ha maturato decenni di esperienza nel settore dell'audit, investigazione, controllo e gestione a partire dal 1975, quando ha iniziato a lavorare come revisore dei conti (internal auditor). Curioso di natura, ha la capacit\xe0 innata di risolvere situazioni complesse e comprendere a fondo i processi dei propri clienti, offrendo loro la soluzione pi\xf9 adatta, ben consapevole che esista pi\xf9 di una risposta esatta, e allo stesso tempo molte risposte sbagliate. Richard ha conseguito un Bachelor Degree in economia aziendale, superando gli esami CPA e CIA. In tempi recenti si \xe8 dedicato alla valutazione, all'investigazione, e al miglioramento dei sistemi di controllo in vigore in varie organizzazioni.","profile_veronica","Veronica ha oltre 15 anni di esperienza nell'investigazione e prevenzione della frode, e in particolare nella formazione anti-frode e nella gestione dei rischi associati. Laureata in sociologia del lavoro presso l\u2019Universit\xe0 di Roma \u201cLa Sapienza\u201d, ha sviluppato una metodologia di ricerca olistica che permette di analizzare organizzazioni, aziende, soci in affari, fornitori, clienti, e personaggi chiave per capire che cosa vi sia davvero dietro. Inoltre, Veronica da diversi anni valuta ed esamina l'efficacia dei programmi anti-frode e corruzione adottati da varie organizzazioni, e al momento sta completando il proprio dottorato di ricerca in materia.","red_flag_game","The <span class='red-text'>red</span><br />flag Game","rome","Roma","rulebending_final_question","Ai fini della nostra ricerca, vi saremmo molto grati se poteste fornirci (in modo anonimo) una descrizione dettagliata delle vostre mansioni","rules_game","Quanto \xe8 flessibile la vostra morale?","search","Cerca","send","Invia","stockholm","Stoccolma","the_fraud_academy","Fraud Academy","what_we_do","Attivit\xe0","what_we_do_collapsed_text_1",'<p>Gran parte delle frodi di cui sentiamo parlare quotidianamente potrebbe essere segnalata (anche se in fase iniziale) e fermata. Spesso, attivit\xe0 illegittime hanno parvenza di legalit\xe0 e trovare la verit\xe0 richiede esperienza, fatica, e l\'aiuto di esperti.</p><p>La nostra soluzione "B4" (o "before" nel senso di "Finding fraud before it finds you") \xe8 stata sviluppata apposta per scovare qualsiasi frode in maniera efficiente ed eliminarla efficacemente. La soluzione "B4" si fa carico di attivit\xe0 quali:</p><ul><li>Analisi dei flussi monetari, divisi per categorie, ed esecuzione degli algoritmi della suite B4 sulle singole transazioni</li><li>Ricostruzioni \u201cthink like a thief\u201d (un approccio inventato negli anni Ottanta da Martin Samociuk, il fondatore di Hibis), per vestire i panni di un malintenzionato e profilare i diversi tipi di frode, sia quelli in corso che quelli potenzialmente pericolosi</li><li>Identificare comportamenti a rischio attraverso un approccio integrato che prevede l\'uso di \u201cdesktop research\u201d per analizzare organizzazioni, soci in affari, fornitori, clienti e figure chiave, il tutto tenendo sempre a mente l\'opportunit\xe0, le motivazioni, e il fenomeno della razionalizzazione del comportamento disonesto</li><li>Dopo aver identificato e classificato i segnali di frode, stilare una lista che permetta poi ai nostri clienti di avere una visione chiara dei problemi pi\xf9 importanti da risolvere</li><li>Collaborare con i nostri clienti per giungere al corso d\'azione pi\xf9 efficace per risolvere problemi. La nostra pluriennale esperienza ci pone in una posizione unica per valutare e suggerire soluzioni commisurate alla gravit\xe0 di ciascuna situazione.</li></li></ul><p>Se non si agisce per tempo, si rischia che i segnali iniziali si sviluppino in vere e proprie frodi, diffondendosi attraverso intere organizzazioni. A quel punto, il problema emerger\xe0 nuovamente quando sar\xe0 ormai impossibile ignorarlo, o per le dimensioni raggiunte o perch\xe9 denunciato anonimamente (o entrambi). Perch\xe9 dunque attendere inerti che ci\xf2 accada quando si possono usare tecniche di investigazione per scoprire ora le aree affette dai primi segni di frode? \xc8 meglio giocare d\'anticipo!</p>',"what_we_do_collapsed_text_2",'<p>Pensare di riuscire a eliminare del tutto le frodi \xe8 senz\'altro un\'utopia. Tuttavia, prestando attenzione al problema e gestendone il rischio in maniera appropriata, sar\xe0 possibile controllarne il costo e rendere i comportamenti disonesti meno accettabili. Non \xe8 un caso che le frodi pi\xf9 comuni siano di solito perpetrate da persone \u201cnormali\u201d, nella media, quali potrebbero essere impiegati o soci d\'affari fidati. Aumentare la consapevolezza del fenomeno potr\xe0 aiutare chiunque a evitare errori di cui poi si pentir\xe0, oltre a formarvi per difendere la vostra organizzazione da malintenzionati. Citando Nelson Mandela, \u201cl\'istruzione \xe8 uno dei modi pi\xf9 potenti per cambiare il mondo\u201d. Abbiamo sviluppato metodi per facilitare il \u201cknowledge transfer\u201d nei confronti dei nostri clienti, e siamo costantemente alla ricerca di modi innovativi per sensibilizzare, diffondere il know-how necessario e permettere un confronto aperto e costruttivo in materia di frode e corruzione. Alcuni esempi sono (per una descrizione pi\xf9 dettagliata si veda la pagina Fraud Academy):</p><ul><li>Corsi pratici e laboratori (tra cui il metodo "Think like a thief" e la "fraud detective school")</li><li>Corsi certificati per il management</li><li>Training sul luogo di lavoro, laboratori "in-house" e workshop a tema</li><li>Corsi multimediali tenuti via internet (o intranet)</li><li>Corsi interattivi con drammi teatrali, allestimento di scenari e giochi di ruolo per i partecipanti, film a tema</li><li>Libri e altre pubblicazioni su riviste specializzate</li></ul>',"what_we_do_collapsed_text_3","<p>Aiutiamo i nostri clienti a investigare i comportamenti illeciti in maniera costruttiva ed efficace.</p><p>Siamo fautori di piccole investigazioni che aiutano a recuperare le risorse perdute. Abbiamo un comprovato numero di situazioni risolte con successo ed efficienza, in cui siamo riusciti a identificare le mancanze alla radice e correggerle, impedendo che il problema si ripetesse. Talvolta, grandi investigazioni sono necessarie, ad esempio qualora un'organizzazione avesse bisogno di prepararsi ad azioni legali per recuperare beni o salvare parte del proprio business. Gestiamo ogni investigazione in maniera discreta, evitando costi superflui e accertandoci allo stesso tempo di mantenere il cliente sempre al corrente.</p>","what_we_do_collapsed_text_4","<p>La mole e la portata dei regolamenti esterni, studiati per proteggere i consumatori e dissuadere potenziali criminali, \xe8 sempre in aumento. Ci\xf2 richiede sempre pi\xf9 attenzione da parte del management, a scapito di programmi pi\xf9 pratici, disegnati specificatamente per proteggere l'azienda. Di conseguenza, la direzione potrebbe cadere nella trappola di voler assecondare soluzioni \u201cburocratiche\u201d in conformit\xe0 con la legge, ma nella realt\xe0 poco adatte a prevenire azioni fraudolente. Le attivit\xe0 di \"compliance\", intesa come una lista di controlli da manuale, difficilmente daranno risultati concreti.</p><p>Siamo lieti di mettere al vostro servizio la nostra esperienza, offrendovi una valutazione dei vostri sistemi di controllo per far emergere potenziali debolezze. Insieme potremo migliorarli per abbattere il costo della frode e riaffermare i valori e l'etica della vostra azienda.</p><p>Partendo dai framework pi\xf9 comuni in uso, abbiamo selezionato i punti chiave, combinandoli con anni di esperienza sul campo per offrirvi uno strumento di valutazione complessivo, frutto di un approccio olistico.</p>","what_we_do_collapsed_title_1","Scoviamo i primi segni di frode e ti aiutiamo a risolverli","what_we_do_collapsed_title_2","Mettiamo la nostra esperienza al vostro servizio, sensibilizzando in materia di frode","what_we_do_collapsed_title_3","Investighiamo la frode responsabilmente","what_we_do_collapsed_title_4","Testiamo l'efficacia dei vostri programmi anti-frode","what_we_do_list_1_item_1","<strong>Trovare</strong> e interpretare i primi segnali (Le <strong>red flags</strong>)","what_we_do_list_1_item_2","<strong>Investigare</strong> in modo efficiente, competente e responsabile","what_we_do_list_1_item_3","<strong>Analizzare</strong> i problemi alla radice per identificare aree di miglioramento","what_we_do_list_1_item_4","<strong>Formare</strong> attraverso workshop pratici, conferenze, training e altri strumenti innovativi, le <strong>competenze necessarie</strong> per trasformare le \"brutte notizie\" in opportunit\xe0 di risparmio (si veda anche <a href='http://fraudacademy.hibis.com' target='_blank'>Hibis Fraud Academy</a>)","what_we_do_list_1_item_5","<strong>Testare</strong> e <strong>misurare</strong> l'<strong>efficacia</strong>, i punti di forza e le debolezze dei programmi antifrode gi\xe0 presenti","what_we_do_paragraph_1","Frodi e corruzione avvengono costantemente e sono tra i costi pi\xf9 difficili da gestire per aziende e organizzazioni. Gran parte dei dirigenti e degli impiegati per\xf2 non ha mai ricevuto alcuna formazione pratica su questo tema. Il nostro obiettivo \xe8 richiamare l'attenzione su frodi e corruzione e sulle conseguenze che possono comportare. Da anni assistiamo e consigliamo aziende, organizzazioni e chiunque abbia bisogno di aiuto pratico per","who_we_are","Chi siamo"]),"no",P.a5(["address_copenhagen","c/o Scillani Information AB<br />Vestergade 16<br />1456 Kj\xf8benhavn<br />Danmark","address_gothenburg","Hibis AB<br />Kronhusgatan 11<br />411 05 G\xf6teborg<br />Sverige","address_helsinki","Hibis Associates<br />Centry Ltd","address_london","Hibis Europe Ltd","address_malmo","Hibis AB","address_oslo","Hibis AS<br /> Meltzersgt. 4<br/> 0275 Oslo<br/> Norge","address_rome","Hibis Associates","address_stockholm","Hibis AB","contact","Kontakt","contact_us","Kontakt oss","contact_copenhagen","<strong>John Wallhoff</strong><br /><a href='mailto:john.wallhoff@hibis.com'>john.wallhoff@hibis.com</a><br />+ 45 70 77 43 131","contact_gothenburg","<strong>Carina S\xf6rqvist</strong><br /><a href='mailto:carina.sorqvist@hibis.com'>carina.sorqvist@hibis.com</a><br />+ 46 707 97 97 64","contact_helsinki","<strong>Petri Kelo</strong><br /><a href='mailto:petri.kelo@centry.global'>petri.kelo@centry.global</a><br />+ 358 40 50 001 068","contact_london","<strong>Allan McDonagh</strong><br /><a href='mailto:allan.mcdonagh@hibis.com'>allan.mcdonagh@hibis.com</a><br />+ 44 77 68 32 0161","contact_malmo","<strong>Richard Minogue</strong><br /><a href='mailto:richard.minogue@hibis.com'>richard.minogue@hibis.com</a><br />+ 46 761 882 497","contact_oslo","<strong>Veronica Morino</strong><br /><a href='mailto:veronica.morino@hibis.com'>veronica.morino@hibis.com</a><br />+ 47 91 86 32 19<br/><br/><strong>Nigel Krishna Iyer</strong><br /><a href='mailto:nigel.iyer@hibis.com'>nigel.iyer@hibis.com</a><br />+ 47 90 65 44 10<br/>+ 44 7523 570004 (UK)","contact_rome","<strong>Maurizio Carmignani</strong><br /><a href='mailto:maurizio.carmignani@hibis.com'>maurizio.carmignani@hibis.com</a><br />+ 39 3489501126","contact_stockholm","<strong>Richard Minogue</strong><br /><a href='mailto:richard.minogue@hibis.com'>richard.minogue@hibis.com</a><br />+ 46 761 882 497","copenhagen","Kj\xf8benhavn","copyright","&copy;2017 Hibis. All rights reserved. Design by SoiaDg. Images by Floral Zu.","frontpage_title","<strong>Fraud and corruption <span class='orange-text'>can</span> be stopped</strong>","gothenburg","G\xf6teborg","hibis_associates","Hibis assosierte","hibis_people","Hibis ansatte","helsinki","Helsinki","language","Spr\xe5k","lang_en","Engelsk (english)","lang_no","Norsk (norwegian)","lang_it","Italiensk (italian)","london","London","malmo","Malm\xf6","oslo","Oslo","our_history","V\xe5r historie","our_history_text","<p><strong>Hibis</strong> ble grunnlagt i 1998 av Martin Samociuk. Mange av dem som ble med i starten kom fra Network Security Management i London, et selskap som var pionerer forebygging og etterforsking av bedrageri p\xe5 1980og -90-tallet. I 1999 sluttet Nigel Krishna Iyer seg til Martin og et \xe5r senere ble ogs\xe5 Allan McDonagh med. Veronica Morino ble en del av gruppen i 2001, etterfulgt av Richard Minogue i 2002. Hibis sitt oppdrag har alltid v\xe6rt \xe5 sette forebygging og tidlig oppdagelse F\xd8RST. Vi deler med v\xe5re kunder n\xf8dvendigheten av dramatisk \xf8kning av for \xe5 vesentlig \xf8ke bevisstheten rundt misligheter og korrupsjon, gi dem muligheten til \xe5 oppdage det tidlig og bist\xe5 med r\xe5d ressurser til vellykkede etterforskinger. Dette inkluderer trening i workshops, seminarer, b\xf8ker, publikasjoner og filmer alle med det form\xe5let \xe5 stimulere til st\xf8rre bevissthet og selvtillit.</p><p>Hibis grunnlegger, Martin Samociuk, d\xf8de i 2013 i en alder av 62 \xe5r fra bukspyttkjertels kreft. Han vil bli savnet av alle som kjente ham og vi er takknemlige for det viktige arbeidet han etterlot seg.</p><p>I dag er Hibis en r\xe5dgivende organisasjon som vi h\xe5per vil bidra til \xe5 \xe5pne folks \xf8yne for det faktum at selv om misligheter og korrupsjon er rundt oss, kan den holdes under kontroll. V\xe5rt m\xe5l er \xe5 tilby nyskapende verkt\xf8y og teknikker for \xe5 h\xe5ndtere dette, samt mulighet til \xe5 oppdage det tidlig. V\xe5rt m\xe5l er \xe5 st\xf8tte de menneskene som \xf8nsker \xe5 st\xe5 opp mot misligheter og korrupsjon.</p><p>I dag er Hibis en r\xe5dgivende organisasjon som vi h\xe5per vil bidra til \xe5 \xe5pne folks \xf8yne for det faktum at selv om misligheter og korrupsjon er rundt oss, kan den holdes under kontroll. V\xe5rt m\xe5l er \xe5 tilby nyskapende verkt\xf8y og teknikker for \xe5 h\xe5ndtere dette, samt mulighet til \xe5 oppdage det tidlig. V\xe5rt m\xe5l er \xe5 st\xf8tte de menneskene som \xf8nsker \xe5 st\xe5 opp mot misligheter og korrupsjon.</p><p>Til slutt, hvis du liker det du har lest, og tenker som oss, s\xe5 ta gjerne kontakt. Vi rekrutterer ikke p\xe5 tradisjonell m\xe5te - likesinnede mennesker finner oss vanligvis...</p>","profile_allan","Allans lange erfaring fra 1967 inkluderer britiske toll- og fortollingsetterforskning og New Scotland Yard, der han spesialiserte seg p\xe5 narkotikakriminalitet og organisert kriminalitet. Mellom 1985 og 1997 jobbet Allan som assisterende direkt\xf8r med Martin Samociuk p\xe5 Network Security Management Limited, Europas ledende konsultasjonssjef for etterforsking av svindel. I tillegg til \xe5 ha ledet hundrevis av etterforskinger og gjenopprettingsprosjekter over hele verden for b\xe5de kommersielle og offentlige kunder, skapte han de sv\xe6rt vellykkede \xabForensic Laboratories\xbb som til slutt ble kj\xf8pt av Control Risks Group. Allan har v\xe6rt prosjektleder for mange vellykkede etterforskinger rundt om i verden.","profile_carina","Carina S\xf6rqvist har over 15 \xe5rs erfaring med \xe5 forebygge og etterforske misligheter og korrupsjon. Hun har opptr\xe5dt som etterforsker og prosjektleder i etterforskinger for kunder i ulike bransjer. Hennes lange erfaring med strukturerte etterforskinger av mislighet- og korrupsjonssaker blir brukt i seminarer og oppl\xe6ring i forbindelse med etterforskningsteknikker. Hun har, for flere kunder, utviklet handlingsplaner for hvordan man skal h\xe5ndtere hendelser hvor man mistenker misligheter og/eller korrupsjon. Hun har jobbet som seniorkonsulent siden 2003 og f\xf8r det arbeidet hun med compliance som leder av internkontrollavdelingen i et multinasjonalt selskap. Carina har \xf8konomisk bakgrunn og hennes spesialiteter er regnskapsetterforskning og intervjueteknikker.","profile_jan","Jan har utf\xf8rt en rekke etterforskinger og prosjekter for \xe5 oppdage misligheter, samt holdt kurs i r\xf8d-flaggs-avdekking innen bedrageri, korrupsjon og bedriftsstyring. Han har en MBA og CPA-grad fra Handelsh\xf8yskolen i Bergen. Etter \xe5 ha v\xe6rt 4 \xe5r som ekstern revisor var han finansdirekt\xf8r i 9 \xe5r i et internasjonalt byggefirma med virksomhet i \xd8st-Afrika. Deretter jobbet han i over 20 \xe5r som r\xe5dgiver innen forretningsutvikling, b\xe6rekraftevalueringer, performance audit og bakgrunn analyser for Utenriksdepartementet (bl.a. oppdrag for NORAD, ambassader og Norfund) og private n\xe6ringsselskaper som opererer i \xd8st-Afrika, Balkan, Baltikum, Georgia, Sri Lanka, Nepal og Palestina. Han leder ogs\xe5 Styrenettverket i Econa Oslo/Akershus.","profile_john","John Wallhoff har mange \xe5rs erfaring som datasikkerhet- og dataanalyseekspert, og utvikler og implementerer datamodeller for \xe5 oppdage m\xf8nstre av misligheter og korrupsjon. John deltar i etterforskinger, leder oppl\xe6ring og st\xf8tter sine kolleger gjennom utvikling av ledende modeller for \xe5 finne frem til misligheter og uetisk forretningsadferd. I tillegg har John bygget informasjonssikkerhetsstrategier og beredskapsplaner for en rekke selskaper,  deltar i etterforskinger og utvikler dataanalysel\xf8sninger for kontinuerlig overv\xe5king av interne kontroller.","profile_martina","Martina har en mastergrad i business og \xf8konomi med finans som hovedprofil fra handelsh\xf8yskolen BI og universitetet i Ljubljana (Slovenia). Hun bestemte seg tidlig for at hun \xf8nsket \xe5 spille en aktiv rolle i \xe5 utrydde systematisk ineffektivitet. Hun inns\xe5 at korrupsjon og misligheter er noen av de st\xf8rste hindringene for b\xe6rekraftighet og vekst, og f\xe5r bruke sin lidenskap for temaet her hos oss i Hibis. Martina spesialiserer seg p\xe5 \xe5 identifisere r\xf8de flagg i relasjon til korrupsjon gjennom intern og ekstern analyse, og forst\xe5 og etterforske dem over et bredt spekter av land og spr\xe5k-soner.","profile_fridtjof","Fridtjof Klareng Dale's passion for fighting corruption and fraud started while studying for his bachelor in European Studies at the Norwegian University of Science and Technology (NTNU). Through his strong engagement in volunteerism, he joined the newly founded student organisation Anti-Corruption International (ACI) and helped build the organisation, spearheading projects showing that \u201cyoung people not only can play a part in eradicating a global problem, but can also take the lead.\u201d Through ACI he got to know Hibis, where he is now successfully working as a fraud investigator combining this with his anti-corruption activities.","profile_maurizio","Maurizio har 18 \xe5rs erfaring innen innovasjon og organisasjonsutvikling i et bredt spekter av sektorer som inkluderer telekommunikasjon og teknologi, bank, detaljhandel og forbrukerprodukter, kultur, utdanning og regjering, i hovedsak i Italia, Sveits og Brasil. Han gir oppl\xe6ring for \xe5 oppn\xe5 oppfyllelse av m\xe5l b\xe5de p\xe5 personlig og organisatorisk niv\xe5. Han bist\xe5r i \xe5 finne misligheter og korrupsjon tidlig, og h\xe5ndterer det p\xe5 en ansvarlig m\xe5te for \xe5 fremme organisatorisk robusthet.","profile_nigel","Nigel har over 20 \xe5rs erfaring med \xe5 unders\xf8ke og oppdage misligheter og korrupsjon. Som datavitenskapsmann og statsautorisert revisor, fant Nigel snart at hans sanne lidenskap l\xe5 i \xe5 bekjempe korrupsjon og misligheter. Nigel er ogs\xe5 i dag en kvalifisert dramatiker og har skrevet en rekke filmer og skuespill basert p\xe5 erfaringer, hvorav mange brukes i undervisning over hele verden. Han har skrevet flere b\xf8ker og vitenskapsartikler, og underviser i Norge og internasjonalt i hvordan man kan forsvare organisasjoner mot \xabkommersielle m\xf8rkekunster\xbb. Han er ogs\xe5 fellow ved University of Leicester School of Business.","profile_petri","Petri Kelo er Hibis tilknyttede partner i Finland. Hans faglige bakgrunn inkluderer en mastergrad i sikkerhet fra Helsinki University of Technology. Petri har jobbet i over 25 \xe5r med logistikk, kvalitet, sikkerhet, samt med \xe5 h\xe5ndtere risikoen for misligheter og korrupsjon. Petri er ogs\xe5 en av grunnleggerne av Centry Ltd. et sikkerhetsselskap spesialisert innen logistikk, forsyningskjede, sikkerhetsrisikostyring, etterlevelse og etterforskningstjenester. Petri er en velkjent foredragsholder og underviser  i TAPA (Transportation Asset Protection Association), AEO (Authorized Economic Operator), ISO 28000 (Supply Chain Security Management) og logistisk sikkerhet.","profile_richard","Siden sin f\xf8rste heltidsjobb som internrevisor i 1975, har Richard opparbeidet seg erfaring innen revisjon, etterforskning, finansiell kontroll og generell ledelseskompetanse. Nysgjerrig av naturen han vet at det er vanligvis er mer enn \xe8n m\xe5te \xe5 gj\xf8re ting riktig p\xe5, og mange feil m\xe5ter. Richards talent for \xe5 trenge inn i komplekse situasjoner samt forst\xe5 kundens forretningsprosesser gj\xf8r ham til en verdifull ressurs for vurderings-, etterforsknings- og forbedringsprosjekter. Richard har uteksaminert seg med BSc i regnskap, og er kvalifisert CPA og CIA.","profile_veronica","Veronica har over 15 \xe5rs erfaring med \xe5 etterforske, finne og trene andre i hvordan man kan forebygge og h\xe5ndtere misligheter og korrupsjon over hele verden. Hun er utdannet \xf8konomi-og arbeidssosiologi og har en mastergrad i organisasjonsbygging og ledelse har hun utviklet helhetlige unders\xf8kelses- og analyseverkt\xf8y for \xe5 etterforske organisasjoner, samarbeidspartnere, leverand\xf8rer, kunder og n\xf8kkelpersoner, og oppdage hva som egentlig foreg\xe5r med bare en br\xf8kdel av ressursene som normalt er forbundet med en etterforskning. Veronica har ogs\xe5 jobbet i flere \xe5r med vurdering av effektiviteten av organisasjons anti-mislighet og korrupsjonsprogrammer og fullf\xf8rer for tiden en doktorgradsutdanning p\xe5 dette emnet.","red_flag_game","The <span class='red-text'>red</span><br />flag Game","rome","Roma","rulebending_final_question","It would assist our research if you could provide us with details of your job functions (anonymously)","rules_game","Hvor mye kan du b\xf8ye reglene?","search","S\xf8ke","send","send inn","stockholm","Stockholm","the_fraud_academy","The fraud academy","what_we_do","Hva vi gj\xf8r","what_we_do_collapsed_text_1",'<p>I de fleste virksomheter er det mange muligheter for misligheter og korrupsjon som kan spores, avdekkes (helst i de tidlige stadiene) og stoppes. Vanligvis er handlinger som misligheter og korrupsjon skjult bak tilsynelatende legitime handlinger. \xc5 finne sannheten krever erfaring, innsats og spesialkunnskap.</p><p>V\xe5r strukturerte "B4- metodikk" (kort for "Find fraud before it finds you") er utviklet for effektivt \xe5 avdekke og h\xe5ndtere misligheter. B4 inkluderer aktiviteter som:</p><ul><li>F\xf8lge pengestr\xf8mmene, utf\xf8re strukturerte analyser og kj\xf8re B4-algoritmer p\xe5 transaksjoner for \xe5 finne de r\xf8de flaggene.</li><li>\xd8velsen \u201ctenk som en tyv\u201d (en \xf8velse oppfunnet p\xe5 1980-tallet av Martin Samociuk, Hibis grunnlegger) for \xe5 forutse hvordan bedragere tenker og for \xe5 bygge opp en profil av de typer misligheter som oppst\xe5r eller som det kan v\xe6re risiko for at de vil kunne oppst\xe5.</li><li>Finne atferdsmessige r\xf8de flagg ved \xe5 utf\xf8re helhetlige unders\xf8kelser og analyse av organisasjoner, forretningspartnere, leverand\xf8rer, kunder og andre n\xf8kkelpersoner. Alle med et spesielt fokus p\xe5 muligheter, motiver og hvordan folk rasjonaliserer rundt u\xe6rlig eller uetisk oppf\xf8rsel.</li><li>Analysere indikasjoner p\xe5 bedrageri og korrupsjon for \xe5 f\xe5 frem de viktigste omr\xe5der, for s\xe5 \xe5 strukturere disse til en h\xe5ndterlig liste som v\xe5re kunder kan arbeide videre med.</li><li>Samarbeide med v\xe5re oppdragsgivere for \xe5 finne den mest effektive l\xf8sningen p\xe5 utfordringene. Lang erfaring har gitt oss en oversikt over ulike tiln\xe6rminger, hvilke som passer i ulike situasjoner, og hvordan de kan implementeres.</li></li></ul><p>Hvis det ikke oppdages tidlig, vil misligheter og korrupsjon spre seg. Til slutt vil problemet bli oppdaget n\xe5r det blir for stort til \xe5 ignoreres, eller rapporteres av varslere, eller begge deler. Men hvorfor vente p\xe5 varslere n\xe5r du kan bruke etterforskningsteknikker og avdekke der hvor misligheter og korrupsjon i tidlig stadium utvikler seg n\xe5? Det er bedre \xe5 v\xe6re f\xf8re var og holde seg i forkant!</p>',"what_we_do_collapsed_text_2","<p>Vi vil nok aldri helt utrydde misligheter og korrupsjon, men ved \xe5 \xf8ke bevisstheten og h\xe5ndtere risikoen kan vi kontrollere kostnadene og gj\xf8re korrupte handlinger mindre akseptable. Overraskende nok beg\xe5s mye av misligheter og korrupsjon av helt normale, gode mennesker som regnes som verdifulle og p\xe5litelige ansatte eller forretningspartnere. Bevisstgj\xf8ring, er et kraftig verkt\xf8y for \xe5 hjelpe de gode menneskene til \xe5 unng\xe5 og beg\xe5 feil de senere vil kunne angre p\xe5, og samtidig vise dem hvordan de skal beskytte organisasjonen mot karrierekriminelle. Som Nelson Mandela sa, er utdanning en av de beste m\xe5tene \xe5 forandre verden p\xe5. Vi har utviklet kurs og teknikker for \xe5 minimere dette kompetansegapet samt stadig og kontinuerlig p\xe5 s\xf8kt etter nye innovative m\xe5ter \xe5 \xf8ke bevisstheten, spre kunnskapen og f\xf8re folk sammen i kampen mot korrupsjon og misligheter. Eksempler (detaljer finner du under Fraud Academy-siden v\xe5r) som inkluderer:</p><ul><li>Praktiske kurs og workshops (inkludert v\xe5r \u201ctenk-som-en-tyv-metodikken\u201d og \u201cfraud detective school\u201d)</li><li>Akkrediterte ledelses kurs</li><li>Jobb, in-house og laboratorier treining</li><li>Multimediabasert oppl\xe6ring over internett (eller intranett)</li><li>Ekspertoppl\xe6ring, inkludert drama, scenariooppgaver, live-simuleringer, \u201ckorrupsjonsteater\u201d og filmer</li><li>Publikasjoner og b\xf8ker</li></ul>","what_we_do_collapsed_text_3","<p>Dersom kunden har behov, etterforsker vi ogs\xe5 misligheter og korrupsjon konstruktivt og effektivt.</p><p>Vi tror p\xe5 filosofien med sm\xe5 etterforskinger som \u201cwin value back\u201d. V\xe5r portef\xf8lje viser til kunder som har f\xe5tt l\xf8st sine problemer p\xe5 en effektiv m\xe5te som b\xe5de identifiserer grunnleggende \xe5rsaker og hindrer gjentakelse.</p><p>Spesielle situasjoner forekommer fra tid til annen, hvor en s\xe5kalt dypdykketterforskning kan v\xe6re n\xf8dvendig, for eksempel n\xe5r en organisasjon m\xe5 g\xe5 rettens vei for \xe5 f\xe5 erstattet store verdier eller redde deler av virksomheten. Vi h\xe5ndterer alle etterforskinger p\xe5 en kontrollert m\xe5te, unng\xe5r un\xf8dvendige kostnader og sikrer at kunden alltid er i f\xf8rersetet under prosessen.</p>","what_we_do_collapsed_text_4","<p>Omfang og kompleksitet i regelverk knyttet til samfunnsansvar og straffeansvar p\xe5 brudd p\xe5 dette er \xf8kende. Dette krever ledelsens oppmerksomhet og gir mindre plass til mer praktiske tiltak som er designet for \xe5 beskytte organisasjonen. Det kan v\xe6re fristende for en ledelse \xe5 g\xe5 i den fellen og velge enkle l\xf8sninger som ser ut til \xe5 oppfylle lovkrav, men som ikke l\xf8ser problemet med misligheter og korrupsjon p\xe5 en effektivt m\xe5te. Complianceprogrammer basert p\xe5 sjekklister viser seg ofte ikke \xe5 v\xe6re effektive!</p><p>Vi er i stand til \xe5 m\xe5le resultatet og effekten av dine eksisterende anti-mislighet og korrupsjonsprogrammer, identifisere smutthull og potensielle forbedringer som vil kunne redusere kostnadene av misligheter og korrupsjon og styrke den etiske kulturen.</p><p>V\xe5rt helhetlige rammeverk og vurderingsverkt\xf8y sammenfattet mange \xe5rs praktisk erfaring med den beste kunnskapen fra en omfattende bruk av tilgjengelige rammeverk.</p>","what_we_do_collapsed_title_1","Vi avdekker misligheter tidlig og hjelper deg med l\xe5 finne l\xf8sninger og motvirkende tiltak","what_we_do_collapsed_title_2","Vi \xf8ker bevisstheten, deler kunnskap og overf\xf8rer ferdigheter","what_we_do_collapsed_title_3","Vi etterforsker misligheter og korrupsjon p\xe5 en ansvarlig m\xe5te","what_we_do_collapsed_title_4","Vi vurderer effektiviteten av eksisterende antimislighet- og korrupsjonsprogrammer","what_we_do_list_1_item_1","<strong>Finne</strong> og tolke de mange <strong>r\xf8de flaggene</strong>","what_we_do_list_1_item_2","<strong>Utf\xf8re granskninger</strong> p\xe5 en effektiv, ansvarlig og omsorgsfull m\xe5te","what_we_do_list_1_item_3","<strong>Analysere</strong> \xe5rsakene til forskjellige hendelser for \xe5 identifisere forbedringsmuligheter","what_we_do_list_1_item_4","<strong>Tilby</strong> (gjennom praktiske workshops, oppl\xe6ring og andre innovative teknikker) <strong>ferdighetene</strong> til \xe5 omgj\xf8re det som ser ut til \xe5 v\xe6re \"d\xe5rlige nyheter\" til en mulighet til \xe5 spare penger (se <a href='http://fraudacademy.hibis.com' target='_blank'>Hibis Fraud Academy</a>)","what_we_do_list_1_item_5","<strong>Vurdere</strong> og <strong>m\xe5le effektivitet</strong>, <strong>styrker</strong> og <strong>svakheter</strong> i eksisterende anti-mislighet og korrupsjonsprogrammer","what_we_do_paragraph_1","Misligheter og korrupsjon skjer hele tiden og utgj\xf8r muligens noen av de st\xf8rste ukontrollerte kostnadene for organisasjoner og samfunnet for\xf8vrig. Til tross for dette har flesteparten av ledere og ansatte ikke hatt praktisk oppl\xe6ring innenfor dette omr\xe5det. V\xe5rt m\xe5l er \xe5 betraktelig \xf8ke bevisstheten om misligheter og korrupsjon og de p\xe5f\xf8lgende konsekvensene. Vi bist\xe5r og gir r\xe5d til organisasjoner, bedrifter og alle andre som er interessert i \xe5:","who_we_are","Hvem vi er"])]),"en")}])
I=I.$finishIsolateConstructor(I)
$=new I()
init.metadata=[null,0]
init.types=[{func:1,args:[,]},{func:1},{func:1,v:true},{func:1,args:[P.n]},{func:1,v:true,args:[P.b],opt:[P.ay]},{func:1,v:true,args:[{func:1,v:true}]},{func:1,ret:P.n,args:[P.j]},{func:1,v:true,args:[P.bg,P.n,P.j]},{func:1,args:[P.n,P.n]},{func:1,args:[W.A]},{func:1,ret:P.b1,args:[W.A,P.n,P.n,W.cn]},{func:1,args:[,P.n]},{func:1,args:[{func:1,v:true}]},{func:1,args:[,],opt:[,]},{func:1,args:[P.b1]},{func:1,args:[,P.ay]},{func:1,v:true,args:[,P.ay]},{func:1,args:[,,]},{func:1,v:true,args:[P.n,P.j]},{func:1,v:true,args:[P.n],opt:[,]},{func:1,ret:P.j,args:[P.j,P.j]},{func:1,ret:P.bg,args:[,,]},{func:1,args:[W.b9]},{func:1,v:true,args:[W.m,W.m]},{func:1,v:true,args:[W.a0]},{func:1,args:[W.c3]},{func:1,v:true,args:[P.n]},{func:1,args:[S.bB]},{func:1,v:true,args:[P.b]},{func:1,v:true,args:[W.aj]}]
function convertToFastObject(a){function MyClass(){}MyClass.prototype=a
new MyClass()
return a}function convertToSlowObject(a){a.__MAGIC_SLOW_PROPERTY=1
delete a.__MAGIC_SLOW_PROPERTY
return a}A=convertToFastObject(A)
B=convertToFastObject(B)
C=convertToFastObject(C)
D=convertToFastObject(D)
E=convertToFastObject(E)
F=convertToFastObject(F)
G=convertToFastObject(G)
H=convertToFastObject(H)
J=convertToFastObject(J)
K=convertToFastObject(K)
L=convertToFastObject(L)
M=convertToFastObject(M)
N=convertToFastObject(N)
O=convertToFastObject(O)
P=convertToFastObject(P)
Q=convertToFastObject(Q)
R=convertToFastObject(R)
S=convertToFastObject(S)
T=convertToFastObject(T)
U=convertToFastObject(U)
V=convertToFastObject(V)
W=convertToFastObject(W)
X=convertToFastObject(X)
Y=convertToFastObject(Y)
Z=convertToFastObject(Z)
function init(){I.p=Object.create(null)
init.allClasses=map()
init.getTypeFromName=function(a){return init.allClasses[a]}
init.interceptorsByTag=map()
init.leafTags=map()
init.finishedClasses=map()
I.$lazy=function(a,b,c,d,e){if(!init.lazies)init.lazies=Object.create(null)
init.lazies[a]=b
e=e||I.p
var z={}
var y={}
e[a]=z
e[b]=function(){var x=this[a]
if(x==y)H.lm(d||a)
try{if(x===z){this[a]=y
try{x=this[a]=c()}finally{if(x===z)this[a]=null}}return x}finally{this[b]=function(){return this[a]}}}}
I.$finishIsolateConstructor=function(a){var z=a.p
function Isolate(){var y=Object.keys(z)
for(var x=0;x<y.length;x++){var w=y[x]
this[w]=z[w]}var v=init.lazies
var u=v?Object.keys(v):[]
for(var x=0;x<u.length;x++)this[v[u[x]]]=null
function ForceEfficientMap(){}ForceEfficientMap.prototype=this
new ForceEfficientMap()
for(var x=0;x<u.length;x++){var t=v[u[x]]
this[t]=z[t]}}Isolate.prototype=a.prototype
Isolate.prototype.constructor=Isolate
Isolate.p=z
Isolate.U=a.U
Isolate.L=a.L
return Isolate}}!function(){var z=function(a){var t={}
t[a]=1
return Object.keys(convertToFastObject(t))[0]}
init.getIsolateTag=function(a){return z("___dart_"+a+init.isolateTag)}
var y="___dart_isolate_tags_"
var x=Object[y]||(Object[y]=Object.create(null))
var w="_ZxYxX"
for(var v=0;;v++){var u=z(w+"_"+v+"_")
if(!(u in x)){x[u]=1
init.isolateTag=u
break}}init.dispatchPropertyName=init.getIsolateTag("dispatch_record")}();(function(a){if(typeof document==="undefined"){a(null)
return}if(typeof document.currentScript!='undefined'){a(document.currentScript)
return}var z=document.scripts
function onLoad(b){for(var x=0;x<z.length;++x)z[x].removeEventListener("load",onLoad,false)
a(b.target)}for(var y=0;y<z.length;++y)z[y].addEventListener("load",onLoad,false)})(function(a){init.currentScript=a
if(typeof dartMainRunner==="function")dartMainRunner(function(b){H.eH(S.eF(),b)},[])
else (function(b){H.eH(S.eF(),b)})([])})})()