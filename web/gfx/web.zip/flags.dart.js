(function(){var supportsDirectProtoAccess=function(){var z=function(){}
z.prototype={p:{}}
var y=new z()
if(!(y.__proto__&&y.__proto__.p===z.prototype.p))return false
try{if(typeof navigator!="undefined"&&typeof navigator.userAgent=="string"&&navigator.userAgent.indexOf("Chrome/")>=0)return true
if(typeof version=="function"&&version.length==0){var x=version()
if(/^\d+\.\d+\.\d+\.\d+$/.test(x))return true}}catch(w){}return false}()
function map(a){a=Object.create(null)
a.x=0
delete a.x
return a}var A=map()
var B=map()
var C=map()
var D=map()
var E=map()
var F=map()
var G=map()
var H=map()
var J=map()
var K=map()
var L=map()
var M=map()
var N=map()
var O=map()
var P=map()
var Q=map()
var R=map()
var S=map()
var T=map()
var U=map()
var V=map()
var W=map()
var X=map()
var Y=map()
var Z=map()
function I(){}init()
function setupProgram(a,b){"use strict"
function generateAccessor(a9,b0,b1){var g=a9.split("-")
var f=g[0]
var e=f.length
var d=f.charCodeAt(e-1)
var c
if(g.length>1)c=true
else c=false
d=d>=60&&d<=64?d-59:d>=123&&d<=126?d-117:d>=37&&d<=43?d-27:0
if(d){var a0=d&3
var a1=d>>2
var a2=f=f.substring(0,e-1)
var a3=f.indexOf(":")
if(a3>0){a2=f.substring(0,a3)
f=f.substring(a3+1)}if(a0){var a4=a0&2?"r":""
var a5=a0&1?"this":"r"
var a6="return "+a5+"."+f
var a7=b1+".prototype.g"+a2+"="
var a8="function("+a4+"){"+a6+"}"
if(c)b0.push(a7+"$reflectable("+a8+");\n")
else b0.push(a7+a8+";\n")}if(a1){var a4=a1&2?"r,v":"v"
var a5=a1&1?"this":"r"
var a6=a5+"."+f+"=v"
var a7=b1+".prototype.s"+a2+"="
var a8="function("+a4+"){"+a6+"}"
if(c)b0.push(a7+"$reflectable("+a8+");\n")
else b0.push(a7+a8+";\n")}}return f}function defineClass(a2,a3){var g=[]
var f="function "+a2+"("
var e=""
var d=""
for(var c=0;c<a3.length;c++){if(c!=0)f+=", "
var a0=generateAccessor(a3[c],g,a2)
d+="'"+a0+"',"
var a1="p_"+a0
f+=a1
e+="this."+a0+" = "+a1+";\n"}if(supportsDirectProtoAccess)e+="this."+"$deferredAction"+"();"
f+=") {\n"+e+"}\n"
f+=a2+".builtin$cls=\""+a2+"\";\n"
f+="$desc=$collectedClasses."+a2+"[1];\n"
f+=a2+".prototype = $desc;\n"
if(typeof defineClass.name!="string")f+=a2+".name=\""+a2+"\";\n"
f+=a2+"."+"$__fields__"+"=["+d+"];\n"
f+=g.join("")
return f}init.createNewIsolate=function(){return new I()}
init.classIdExtractor=function(c){return c.constructor.name}
init.classFieldsExtractor=function(c){var g=c.constructor.$__fields__
if(!g)return[]
var f=[]
f.length=g.length
for(var e=0;e<g.length;e++)f[e]=c[g[e]]
return f}
init.instanceFromClassId=function(c){return new init.allClasses[c]()}
init.initializeEmptyInstance=function(c,d,e){init.allClasses[c].apply(d,e)
return d}
var z=supportsDirectProtoAccess?function(c,d){var g=c.prototype
g.__proto__=d.prototype
g.constructor=c
g["$is"+c.name]=c
return convertToFastObject(g)}:function(){function tmp(){}return function(a0,a1){tmp.prototype=a1.prototype
var g=new tmp()
convertToSlowObject(g)
var f=a0.prototype
var e=Object.keys(f)
for(var d=0;d<e.length;d++){var c=e[d]
g[c]=f[c]}g["$is"+a0.name]=a0
g.constructor=a0
a0.prototype=g
return g}}()
function finishClasses(a4){var g=init.allClasses
a4.combinedConstructorFunction+="return [\n"+a4.constructorsList.join(",\n  ")+"\n]"
var f=new Function("$collectedClasses",a4.combinedConstructorFunction)(a4.collected)
a4.combinedConstructorFunction=null
for(var e=0;e<f.length;e++){var d=f[e]
var c=d.name
var a0=a4.collected[c]
var a1=a0[0]
a0=a0[1]
g[c]=d
a1[c]=d}f=null
var a2=init.finishedClasses
function finishClass(c1){if(a2[c1])return
a2[c1]=true
var a5=a4.pending[c1]
if(a5&&a5.indexOf("+")>0){var a6=a5.split("+")
a5=a6[0]
var a7=a6[1]
finishClass(a7)
var a8=g[a7]
var a9=a8.prototype
var b0=g[c1].prototype
var b1=Object.keys(a9)
for(var b2=0;b2<b1.length;b2++){var b3=b1[b2]
if(!u.call(b0,b3))b0[b3]=a9[b3]}}if(!a5||typeof a5!="string"){var b4=g[c1]
var b5=b4.prototype
b5.constructor=b4
b5.$isb=b4
b5.$deferredAction=function(){}
return}finishClass(a5)
var b6=g[a5]
if(!b6)b6=existingIsolateProperties[a5]
var b4=g[c1]
var b5=z(b4,b6)
if(a9)b5.$deferredAction=mixinDeferredActionHelper(a9,b5)
if(Object.prototype.hasOwnProperty.call(b5,"%")){var b7=b5["%"].split(";")
if(b7[0]){var b8=b7[0].split("|")
for(var b2=0;b2<b8.length;b2++){init.interceptorsByTag[b8[b2]]=b4
init.leafTags[b8[b2]]=true}}if(b7[1]){b8=b7[1].split("|")
if(b7[2]){var b9=b7[2].split("|")
for(var b2=0;b2<b9.length;b2++){var c0=g[b9[b2]]
c0.$nativeSuperclassTag=b8[0]}}for(b2=0;b2<b8.length;b2++){init.interceptorsByTag[b8[b2]]=b4
init.leafTags[b8[b2]]=false}}b5.$deferredAction()}if(b5.$ish)b5.$deferredAction()}var a3=Object.keys(a4.pending)
for(var e=0;e<a3.length;e++)finishClass(a3[e])}function finishAddStubsHelper(){var g=this
while(!g.hasOwnProperty("$deferredAction"))g=g.__proto__
delete g.$deferredAction
var f=Object.keys(g)
for(var e=0;e<f.length;e++){var d=f[e]
var c=d.charCodeAt(0)
var a0
if(d!=="^"&&d!=="$reflectable"&&c!==43&&c!==42&&(a0=g[d])!=null&&a0.constructor===Array&&d!=="<>")addStubs(g,a0,d,false,[])}convertToFastObject(g)
g=g.__proto__
g.$deferredAction()}function mixinDeferredActionHelper(c,d){var g
if(d.hasOwnProperty("$deferredAction"))g=d.$deferredAction
return function foo(){if(!supportsDirectProtoAccess)return
var f=this
while(!f.hasOwnProperty("$deferredAction"))f=f.__proto__
if(g)f.$deferredAction=g
else{delete f.$deferredAction
convertToFastObject(f)}c.$deferredAction()
f.$deferredAction()}}function processClassData(b1,b2,b3){b2=convertToSlowObject(b2)
var g
var f=Object.keys(b2)
var e=false
var d=supportsDirectProtoAccess&&b1!="b"
for(var c=0;c<f.length;c++){var a0=f[c]
var a1=a0.charCodeAt(0)
if(a0==="m"){processStatics(init.statics[b1]=b2.m,b3)
delete b2.m}else if(a1===43){w[g]=a0.substring(1)
var a2=b2[a0]
if(a2>0)b2[g].$reflectable=a2}else if(a1===42){b2[g].$D=b2[a0]
var a3=b2.$methodsWithOptionalArguments
if(!a3)b2.$methodsWithOptionalArguments=a3={}
a3[a0]=g}else{var a4=b2[a0]
if(a0!=="^"&&a4!=null&&a4.constructor===Array&&a0!=="<>")if(d)e=true
else addStubs(b2,a4,a0,false,[])
else g=a0}}if(e)b2.$deferredAction=finishAddStubsHelper
var a5=b2["^"],a6,a7,a8=a5
var a9=a8.split(";")
a8=a9[1]?a9[1].split(","):[]
a7=a9[0]
a6=a7.split(":")
if(a6.length==2){a7=a6[0]
var b0=a6[1]
if(b0)b2.$S=function(b4){return function(){return init.types[b4]}}(b0)}if(a7)b3.pending[b1]=a7
b3.combinedConstructorFunction+=defineClass(b1,a8)
b3.constructorsList.push(b1)
b3.collected[b1]=[m,b2]
i.push(b1)}function processStatics(a3,a4){var g=Object.keys(a3)
for(var f=0;f<g.length;f++){var e=g[f]
if(e==="^")continue
var d=a3[e]
var c=e.charCodeAt(0)
var a0
if(c===43){v[a0]=e.substring(1)
var a1=a3[e]
if(a1>0)a3[a0].$reflectable=a1
if(d&&d.length)init.typeInformation[a0]=d}else if(c===42){m[a0].$D=d
var a2=a3.$methodsWithOptionalArguments
if(!a2)a3.$methodsWithOptionalArguments=a2={}
a2[e]=a0}else if(typeof d==="function"){m[a0=e]=d
h.push(e)
init.globalFunctions[e]=d}else if(d.constructor===Array)addStubs(m,d,e,true,h)
else{a0=e
processClassData(e,d,a4)}}}function addStubs(b2,b3,b4,b5,b6){var g=0,f=b3[g],e
if(typeof f=="string")e=b3[++g]
else{e=f
f=b4}var d=[b2[b4]=b2[f]=e]
e.$stubName=b4
b6.push(b4)
for(g++;g<b3.length;g++){e=b3[g]
if(typeof e!="function")break
if(!b5)e.$stubName=b3[++g]
d.push(e)
if(e.$stubName){b2[e.$stubName]=e
b6.push(e.$stubName)}}for(var c=0;c<d.length;g++,c++)d[c].$callName=b3[g]
var a0=b3[g]
b3=b3.slice(++g)
var a1=b3[0]
var a2=a1>>1
var a3=(a1&1)===1
var a4=a1===3
var a5=a1===1
var a6=b3[1]
var a7=a6>>1
var a8=(a6&1)===1
var a9=a2+a7!=d[0].length
var b0=b3[2]
if(typeof b0=="number")b3[2]=b0+b
var b1=2*a7+a2+3
if(a0){e=tearOff(d,b3,b5,b4,a9)
b2[b4].$getter=e
e.$getterStub=true
if(b5){init.globalFunctions[b4]=e
b6.push(a0)}b2[a0]=e
d.push(e)
e.$stubName=a0
e.$callName=null}}function tearOffGetter(c,d,e,f){return f?new Function("funcs","reflectionInfo","name","H","c","return function tearOff_"+e+y+++"(x) {"+"if (c === null) c = "+"H.cy"+"("+"this, funcs, reflectionInfo, false, [x], name);"+"return new c(this, funcs[0], x, name);"+"}")(c,d,e,H,null):new Function("funcs","reflectionInfo","name","H","c","return function tearOff_"+e+y+++"() {"+"if (c === null) c = "+"H.cy"+"("+"this, funcs, reflectionInfo, false, [], name);"+"return new c(this, funcs[0], null, name);"+"}")(c,d,e,H,null)}function tearOff(c,d,e,f,a0){var g
return e?function(){if(g===void 0)g=H.cy(this,c,d,true,[],f).prototype
return g}:tearOffGetter(c,d,f,a0)}var y=0
if(!init.libraries)init.libraries=[]
if(!init.mangledNames)init.mangledNames=map()
if(!init.mangledGlobalNames)init.mangledGlobalNames=map()
if(!init.statics)init.statics=map()
if(!init.typeInformation)init.typeInformation=map()
if(!init.globalFunctions)init.globalFunctions=map()
var x=init.libraries
var w=init.mangledNames
var v=init.mangledGlobalNames
var u=Object.prototype.hasOwnProperty
var t=a.length
var s=map()
s.collected=map()
s.pending=map()
s.constructorsList=[]
s.combinedConstructorFunction="function $reflectable(fn){fn.$reflectable=1;return fn};\n"+"var $desc;\n"
for(var r=0;r<t;r++){var q=a[r]
var p=q[0]
var o=q[1]
var n=q[2]
var m=q[3]
var l=q[4]
var k=!!q[5]
var j=l&&l["^"]
if(j instanceof Array)j=j[0]
var i=[]
var h=[]
processStatics(l,s)
x.push([p,o,i,h,n,j,k,m])}finishClasses(s)}I.K=function(){}
var dart=[["","",,H,{"^":"",lW:{"^":"b;a"}}],["","",,J,{"^":"",
k:function(a){return void 0},
bN:function(a,b,c,d){return{i:a,p:b,e:c,x:d}},
bI:function(a){var z,y,x,w,v
z=a[init.dispatchPropertyName]
if(z==null)if($.cA==null){H.l0()
z=a[init.dispatchPropertyName]}if(z!=null){y=z.p
if(!1===y)return z.i
if(!0===y)return a
x=Object.getPrototypeOf(a)
if(y===x)return z.i
if(z.e===x)throw H.a(new P.bc("Return interceptor for "+H.d(y(a,z))))}w=a.constructor
v=w==null?null:w[$.$get$c3()]
if(v!=null)return v
v=H.l9(a)
if(v!=null)return v
if(typeof a=="function")return C.V
y=Object.getPrototypeOf(a)
if(y==null)return C.B
if(y===Object.prototype)return C.B
if(typeof w=="function"){Object.defineProperty(w,$.$get$c3(),{value:C.r,enumerable:false,writable:true,configurable:true})
return C.r}return C.r},
h:{"^":"b;",
A:function(a,b){return a===b},
gD:function(a){return H.ae(a)},
j:["dk",function(a){return H.bu(a)}],
"%":"Blob|CanvasGradient|CanvasPattern|Client|DOMError|DOMImplementation|File|FileError|MediaError|NavigatorUserMediaError|PositionError|PushMessageData|Range|SQLError|SVGAnimatedLength|SVGAnimatedLengthList|SVGAnimatedNumber|SVGAnimatedNumberList|SVGAnimatedString|WindowClient"},
he:{"^":"h;",
j:function(a){return String(a)},
gD:function(a){return a?519018:218159},
$isaY:1},
hf:{"^":"h;",
A:function(a,b){return null==b},
j:function(a){return"null"},
gD:function(a){return 0}},
c4:{"^":"h;",
gD:function(a){return 0},
j:["dm",function(a){return String(a)}],
$ishg:1},
hW:{"^":"c4;"},
bd:{"^":"c4;"},
b8:{"^":"c4;",
j:function(a){var z=a[$.$get$cY()]
return z==null?this.dm(a):J.P(z)},
$S:function(){return{func:1,opt:[,,,,,,,,,,,,,,,,]}}},
b5:{"^":"h;$ti",
by:function(a,b){if(!!a.immutable$list)throw H.a(new P.m(b))},
cC:function(a,b){if(!!a.fixed$length)throw H.a(new P.m(b))},
u:function(a,b){var z,y
z=a.length
for(y=0;y<z;++y){b.$1(a[y])
if(a.length!==z)throw H.a(new P.L(a))}},
a7:function(a,b){return new H.b9(a,b,[H.E(a,0),null])},
ai:function(a,b){var z,y,x,w
z=a.length
y=new Array(z)
y.fixed$length=Array
for(x=0;x<a.length;++x){w=H.d(a[x])
if(x>=z)return H.f(y,x)
y[x]=w}return y.join(b)},
G:function(a,b){if(b>>>0!==b||b>=a.length)return H.f(a,b)
return a[b]},
bY:function(a,b,c){if(b<0||b>a.length)throw H.a(P.x(b,0,a.length,"start",null))
if(c==null)c=a.length
else{if(typeof c!=="number"||Math.floor(c)!==c)throw H.a(H.D(c))
if(c<b||c>a.length)throw H.a(P.x(c,b,a.length,"end",null))}if(b===c)return H.w([],[H.E(a,0)])
return H.w(a.slice(b,c),[H.E(a,0)])},
gN:function(a){if(a.length>0)return a[0]
throw H.a(H.b4())},
gb1:function(a){var z=a.length
if(z>0)return a[z-1]
throw H.a(H.b4())},
E:function(a,b,c,d,e){var z,y,x
this.by(a,"setRange")
P.a_(b,c,a.length,null,null,null)
z=c-b
if(z===0)return
if(e<0)H.q(P.x(e,0,null,"skipCount",null))
if(e+z>d.length)throw H.a(H.de())
if(e<b)for(y=z-1;y>=0;--y){x=e+y
if(x>>>0!==x||x>=d.length)return H.f(d,x)
a[b+y]=d[x]}else for(y=0;y<z;++y){x=e+y
if(x>>>0!==x||x>=d.length)return H.f(d,x)
a[b+y]=d[x]}},
P:function(a,b,c,d){return this.E(a,b,c,d,0)},
as:function(a,b,c,d){var z
this.by(a,"fill range")
P.a_(b,c,a.length,null,null,null)
for(z=b;z<c;++z)a[z]=d},
O:function(a,b,c,d){var z,y,x,w,v,u
this.cC(a,"replaceRange")
P.a_(b,c,a.length,null,null,null)
d=C.a.ak(d)
if(typeof c!=="number")return c.R()
z=c-b
y=d.length
x=b+y
w=a.length
if(z>=y){v=z-y
u=w-v
this.P(a,b,x,d)
if(v!==0){this.E(a,x,u,a,c)
this.sh(a,u)}}else{u=w+(y-z)
this.sh(a,u)
this.E(a,x,u,a,c)
this.P(a,b,x,d)}},
cw:function(a,b){var z,y
z=a.length
for(y=0;y<z;++y){if(b.$1(a[y])===!0)return!0
if(a.length!==z)throw H.a(new P.L(a))}return!1},
at:function(a,b,c){var z
if(c>=a.length)return-1
if(c<0)c=0
for(z=c;z<a.length;++z)if(J.F(a[z],b))return z
return-1},
a6:function(a,b){return this.at(a,b,0)},
H:function(a,b){var z
for(z=0;z<a.length;++z)if(J.F(a[z],b))return!0
return!1},
gw:function(a){return a.length===0},
j:function(a){return P.bn(a,"[","]")},
gB:function(a){return new J.bY(a,a.length,0,null)},
gD:function(a){return H.ae(a)},
gh:function(a){return a.length},
sh:function(a,b){this.cC(a,"set length")
if(typeof b!=="number"||Math.floor(b)!==b)throw H.a(P.aM(b,"newLength",null))
if(b<0)throw H.a(P.x(b,0,null,"newLength",null))
a.length=b},
i:function(a,b){if(typeof b!=="number"||Math.floor(b)!==b)throw H.a(H.B(a,b))
if(b>=a.length||b<0)throw H.a(H.B(a,b))
return a[b]},
p:function(a,b,c){this.by(a,"indexed set")
if(typeof b!=="number"||Math.floor(b)!==b)throw H.a(H.B(a,b))
if(b>=a.length||b<0)throw H.a(H.B(a,b))
a[b]=c},
$isJ:1,
$asJ:I.K,
$isi:1,
$asi:null,
$ise:1,
$ase:null},
lV:{"^":"b5;$ti"},
bY:{"^":"b;a,b,c,d",
gt:function(){return this.d},
l:function(){var z,y,x
z=this.a
y=z.length
if(this.b!==y)throw H.a(H.aa(z))
x=this.c
if(x>=y){this.d=null
return!1}this.d=z[x]
this.c=x+1
return!0}},
b6:{"^":"h;",
bN:function(a){var z
if(a>=-2147483648&&a<=2147483647)return a|0
if(isFinite(a)){z=a<0?Math.ceil(a):Math.floor(a)
return z+0}throw H.a(new P.m(""+a+".toInt()"))},
b5:function(a){if(a>0){if(a!==1/0)return Math.round(a)}else if(a>-1/0)return 0-Math.round(0-a)
throw H.a(new P.m(""+a+".round()"))},
j:function(a){if(a===0&&1/a<0)return"-0.0"
else return""+a},
gD:function(a){return a&0x1FFFFFFF},
W:function(a,b){if(typeof b!=="number")throw H.a(H.D(b))
return a+b},
R:function(a,b){if(typeof b!=="number")throw H.a(H.D(b))
return a-b},
aK:function(a,b){if(typeof b!=="number")throw H.a(H.D(b))
return a*b},
b8:function(a,b){var z=a%b
if(z===0)return 0
if(z>0)return z
if(b<0)return z-b
else return z+b},
az:function(a,b){return(a|0)===a?a/b|0:this.en(a,b)},
en:function(a,b){var z=a/b
if(z>=-2147483648&&z<=2147483647)return z|0
if(z>0){if(z!==1/0)return Math.floor(z)}else if(z>-1/0)return Math.ceil(z)
throw H.a(new P.m("Result of truncating division is "+H.d(z)+": "+H.d(a)+" ~/ "+b))},
ab:function(a,b){var z
if(a>0)z=b>31?0:a>>>b
else{z=b>31?31:b
z=a>>z>>>0}return z},
ek:function(a,b){if(b<0)throw H.a(H.D(b))
return b>31?0:a>>>b},
I:function(a,b){if(typeof b!=="number")throw H.a(H.D(b))
return a<b},
am:function(a,b){if(typeof b!=="number")throw H.a(H.D(b))
return a>b},
$isaH:1},
dg:{"^":"b6;",$isaH:1,$isj:1},
df:{"^":"b6;",$isaH:1},
b7:{"^":"h;",
F:function(a,b){if(typeof b!=="number"||Math.floor(b)!==b)throw H.a(H.B(a,b))
if(b<0)throw H.a(H.B(a,b))
if(b>=a.length)H.q(H.B(a,b))
return a.charCodeAt(b)},
C:function(a,b){if(b>=a.length)throw H.a(H.B(a,b))
return a.charCodeAt(b)},
W:function(a,b){if(typeof b!=="string")throw H.a(P.aM(b,null,null))
return a+b},
fm:function(a,b,c,d){P.i_(d,0,a.length,"startIndex",null)
return H.li(a,b,c,d)},
fl:function(a,b,c){return this.fm(a,b,c,0)},
O:function(a,b,c,d){H.cx(b)
c=P.a_(b,c,a.length,null,null,null)
H.cx(c)
return H.eJ(a,b,c,d)},
Y:function(a,b,c){var z
H.cx(c)
if(typeof c!=="number")return c.I()
if(c<0||c>a.length)throw H.a(P.x(c,0,a.length,null,null))
z=c+b.length
if(z>a.length)return!1
return b===a.substring(c,z)},
M:function(a,b){return this.Y(a,b,0)},
k:function(a,b,c){if(typeof b!=="number"||Math.floor(b)!==b)H.q(H.D(b))
if(c==null)c=a.length
if(typeof c!=="number"||Math.floor(c)!==c)H.q(H.D(c))
if(typeof b!=="number")return b.I()
if(b<0)throw H.a(P.bw(b,null,null))
if(typeof c!=="number")return H.o(c)
if(b>c)throw H.a(P.bw(b,null,null))
if(c>a.length)throw H.a(P.bw(c,null,null))
return a.substring(b,c)},
ap:function(a,b){return this.k(a,b,null)},
ft:function(a){return a.toLowerCase()},
fu:function(a){return a.toUpperCase()},
fv:function(a){var z,y,x,w,v
z=a.trim()
y=z.length
if(y===0)return z
if(this.C(z,0)===133){x=J.hh(z,1)
if(x===y)return""}else x=0
w=y-1
v=this.F(z,w)===133?J.hi(z,w):y
if(x===0&&v===y)return z
return z.substring(x,v)},
aK:function(a,b){var z,y
if(0>=b)return""
if(b===1||a.length===0)return a
if(b!==b>>>0)throw H.a(C.F)
for(z=a,y="";!0;){if((b&1)===1)y=z+y
b=b>>>1
if(b===0)break
z+=z}return y},
at:function(a,b,c){var z
if(c<0||c>a.length)throw H.a(P.x(c,0,a.length,null,null))
z=a.indexOf(b,c)
return z},
a6:function(a,b){return this.at(a,b,0)},
eG:function(a,b,c){if(c>a.length)throw H.a(P.x(c,0,a.length,null,null))
return H.lh(a,b,c)},
gw:function(a){return a.length===0},
j:function(a){return a},
gD:function(a){var z,y,x
for(z=a.length,y=0,x=0;x<z;++x){y=536870911&y+a.charCodeAt(x)
y=536870911&y+((524287&y)<<10)
y^=y>>6}y=536870911&y+((67108863&y)<<3)
y^=y>>11
return 536870911&y+((16383&y)<<15)},
gh:function(a){return a.length},
i:function(a,b){if(typeof b!=="number"||Math.floor(b)!==b)throw H.a(H.B(a,b))
if(b>=a.length||b<0)throw H.a(H.B(a,b))
return a[b]},
$isJ:1,
$asJ:I.K,
$ist:1,
m:{
dh:function(a){if(a<256)switch(a){case 9:case 10:case 11:case 12:case 13:case 32:case 133:case 160:return!0
default:return!1}switch(a){case 5760:case 8192:case 8193:case 8194:case 8195:case 8196:case 8197:case 8198:case 8199:case 8200:case 8201:case 8202:case 8232:case 8233:case 8239:case 8287:case 12288:case 65279:return!0
default:return!1}},
hh:function(a,b){var z,y
for(z=a.length;b<z;){y=C.a.C(a,b)
if(y!==32&&y!==13&&!J.dh(y))break;++b}return b},
hi:function(a,b){var z,y
for(;b>0;b=z){z=b-1
y=C.a.F(a,z)
if(y!==32&&y!==13&&!J.dh(y))break}return b}}}}],["","",,H,{"^":"",
bK:function(a){var z,y
z=a^48
if(z<=9)return z
y=a|32
if(97<=y&&y<=102)return y-87
return-1},
ek:function(a){if(typeof a!=="number"||Math.floor(a)!==a)throw H.a(P.aM(a,"count","is not an integer"))
if(a<0)H.q(P.x(a,0,null,"count",null))
return a},
b4:function(){return new P.r("No element")},
hd:function(){return new P.r("Too many elements")},
de:function(){return new P.r("Too few elements")},
e:{"^":"I;$ti",$ase:null},
aQ:{"^":"e;$ti",
gB:function(a){return new H.c6(this,this.gh(this),0,null)},
u:function(a,b){var z,y
z=this.gh(this)
for(y=0;y<z;++y){b.$1(this.G(0,y))
if(z!==this.gh(this))throw H.a(new P.L(this))}},
gw:function(a){return this.gh(this)===0},
bQ:function(a,b){return this.dl(0,b)},
a7:function(a,b){return new H.b9(this,b,[H.z(this,"aQ",0),null])},
a8:function(a,b){var z,y,x
z=H.w([],[H.z(this,"aQ",0)])
C.b.sh(z,this.gh(this))
for(y=0;y<this.gh(this);++y){x=this.G(0,y)
if(y>=z.length)return H.f(z,y)
z[y]=x}return z},
ak:function(a){return this.a8(a,!0)}},
is:{"^":"aQ;a,b,c,$ti",
gdQ:function(){var z,y
z=J.W(this.a)
y=this.c
if(y==null||y>z)return z
return y},
gel:function(){var z,y
z=J.W(this.a)
y=this.b
if(y>z)return z
return y},
gh:function(a){var z,y,x
z=J.W(this.a)
y=this.b
if(y>=z)return 0
x=this.c
if(x==null||x>=z)return z-y
if(typeof x!=="number")return x.R()
return x-y},
G:function(a,b){var z,y
z=this.gel()
if(typeof b!=="number")return H.o(b)
y=z+b
if(!(b<0)){z=this.gdQ()
if(typeof z!=="number")return H.o(z)
z=y>=z}else z=!0
if(z)throw H.a(P.a3(b,this,"index",null,null))
return J.b_(this.a,y)},
a8:function(a,b){var z,y,x,w,v,u,t,s,r
z=this.b
y=this.a
x=J.y(y)
w=x.gh(y)
v=this.c
if(v!=null&&v<w)w=v
if(typeof w!=="number")return w.R()
u=w-z
if(u<0)u=0
t=H.w(new Array(u),this.$ti)
for(s=0;s<u;++s){r=x.G(y,z+s)
if(s>=t.length)return H.f(t,s)
t[s]=r
if(x.gh(y)<w)throw H.a(new P.L(this))}return t}},
c6:{"^":"b;a,b,c,d",
gt:function(){return this.d},
l:function(){var z,y,x,w
z=this.a
y=J.y(z)
x=y.gh(z)
if(this.b!==x)throw H.a(new P.L(z))
w=this.c
if(w>=x){this.d=null
return!1}this.d=y.G(z,w);++this.c
return!0}},
bq:{"^":"I;a,b,$ti",
gB:function(a){return new H.hz(null,J.aj(this.a),this.b,this.$ti)},
gh:function(a){return J.W(this.a)},
gw:function(a){return J.cH(this.a)},
G:function(a,b){return this.b.$1(J.b_(this.a,b))},
$asI:function(a,b){return[b]},
m:{
br:function(a,b,c,d){if(!!J.k(a).$ise)return new H.c1(a,b,[c,d])
return new H.bq(a,b,[c,d])}}},
c1:{"^":"bq;a,b,$ti",$ise:1,
$ase:function(a,b){return[b]}},
hz:{"^":"bo;a,b,c,$ti",
l:function(){var z=this.b
if(z.l()){this.a=this.c.$1(z.gt())
return!0}this.a=null
return!1},
gt:function(){return this.a}},
b9:{"^":"aQ;a,b,$ti",
gh:function(a){return J.W(this.a)},
G:function(a,b){return this.b.$1(J.b_(this.a,b))},
$asaQ:function(a,b){return[b]},
$ase:function(a,b){return[b]},
$asI:function(a,b){return[b]}},
ci:{"^":"I;a,b,$ti",
gB:function(a){return new H.iO(J.aj(this.a),this.b,this.$ti)},
a7:function(a,b){return new H.bq(this,b,[H.E(this,0),null])}},
iO:{"^":"bo;a,b,$ti",
l:function(){var z,y
for(z=this.a,y=this.b;z.l();)if(y.$1(z.gt())===!0)return!0
return!1},
gt:function(){return this.a.gt()}},
dH:{"^":"I;a,b,$ti",
gB:function(a){return new H.iv(J.aj(this.a),this.b,this.$ti)},
m:{
iu:function(a,b,c){if(typeof b!=="number"||Math.floor(b)!==b||b<0)throw H.a(P.ak(b))
if(!!J.k(a).$ise)return new H.fx(a,b,[c])
return new H.dH(a,b,[c])}}},
fx:{"^":"dH;a,b,$ti",
gh:function(a){var z,y
z=J.W(this.a)
y=this.b
if(z>y)return y
return z},
$ise:1,
$ase:null},
iv:{"^":"bo;a,b,$ti",
l:function(){if(--this.b>=0)return this.a.l()
this.b=-1
return!1},
gt:function(){if(this.b<0)return
return this.a.gt()}},
dD:{"^":"I;a,b,$ti",
gB:function(a){return new H.i8(J.aj(this.a),this.b,this.$ti)},
m:{
i7:function(a,b,c){if(!!J.k(a).$ise)return new H.fw(a,H.ek(b),[c])
return new H.dD(a,H.ek(b),[c])}}},
fw:{"^":"dD;a,b,$ti",
gh:function(a){var z=J.W(this.a)-this.b
if(z>=0)return z
return 0},
$ise:1,
$ase:null},
i8:{"^":"bo;a,b,$ti",
l:function(){var z,y
for(z=this.a,y=0;y<this.b;++y)z.l()
this.b=0
return z.l()},
gt:function(){return this.a.gt()}},
d8:{"^":"b;$ti",
sh:function(a,b){throw H.a(new P.m("Cannot change the length of a fixed-length list"))},
O:function(a,b,c,d){throw H.a(new P.m("Cannot remove from a fixed-length list"))}}}],["","",,H,{"^":"",
bf:function(a,b){var z=a.aC(b)
if(!init.globalState.d.cy)init.globalState.f.aI()
return z},
eI:function(a,b){var z,y,x,w,v,u
z={}
z.a=b
if(b==null){b=[]
z.a=b
y=b}else y=b
if(!J.k(y).$isi)throw H.a(P.ak("Arguments to main must be a List: "+H.d(y)))
init.globalState=new H.jI(0,0,1,null,null,null,null,null,null,null,null,null,a)
y=init.globalState
x=self.window==null
w=self.Worker
v=x&&!!self.postMessage
y.x=v
v=!v
if(v)w=w!=null&&$.$get$dc()!=null
else w=!0
y.y=w
y.r=x&&v
y.f=new H.ji(P.c7(null,H.be),0)
x=P.j
y.z=new H.ac(0,null,null,null,null,null,0,[x,H.cr])
y.ch=new H.ac(0,null,null,null,null,null,0,[x,null])
if(y.x===!0){w=new H.jH()
y.Q=w
self.onmessage=function(c,d){return function(e){c(d,e)}}(H.h6,w)
self.dartPrint=self.dartPrint||function(c){return function(d){if(self.console&&self.console.log)self.console.log(d)
else self.postMessage(c(d))}}(H.jJ)}if(init.globalState.x===!0)return
y=init.globalState.a++
w=P.Y(null,null,null,x)
v=new H.bx(0,null,!1)
u=new H.cr(y,new H.ac(0,null,null,null,null,null,0,[x,H.bx]),w,init.createNewIsolate(),v,new H.as(H.bO()),new H.as(H.bO()),!1,!1,[],P.Y(null,null,null,null),null,null,!1,!0,P.Y(null,null,null,null))
w.q(0,0)
u.c1(0,v)
init.globalState.e=u
init.globalState.d=u
if(H.aG(a,{func:1,args:[,]}))u.aC(new H.lf(z,a))
else if(H.aG(a,{func:1,args:[,,]}))u.aC(new H.lg(z,a))
else u.aC(a)
init.globalState.f.aI()},
ha:function(){var z=init.currentScript
if(z!=null)return String(z.src)
if(init.globalState.x===!0)return H.hb()
return},
hb:function(){var z,y
z=new Error().stack
if(z==null){z=function(){try{throw new Error()}catch(x){return x.stack}}()
if(z==null)throw H.a(new P.m("No stack trace"))}y=z.match(new RegExp("^ *at [^(]*\\((.*):[0-9]*:[0-9]*\\)$","m"))
if(y!=null)return y[1]
y=z.match(new RegExp("^[^@]*@(.*):[0-9]*$","m"))
if(y!=null)return y[1]
throw H.a(new P.m('Cannot extract URI from "'+z+'"'))},
h6:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n
z=new H.bB(!0,[]).ae(b.data)
y=J.y(z)
switch(y.i(z,"command")){case"start":init.globalState.b=y.i(z,"id")
x=y.i(z,"functionName")
w=x==null?init.globalState.cx:init.globalFunctions[x]()
v=y.i(z,"args")
u=new H.bB(!0,[]).ae(y.i(z,"msg"))
t=y.i(z,"isSpawnUri")
s=y.i(z,"startPaused")
r=new H.bB(!0,[]).ae(y.i(z,"replyTo"))
y=init.globalState.a++
q=P.j
p=P.Y(null,null,null,q)
o=new H.bx(0,null,!1)
n=new H.cr(y,new H.ac(0,null,null,null,null,null,0,[q,H.bx]),p,init.createNewIsolate(),o,new H.as(H.bO()),new H.as(H.bO()),!1,!1,[],P.Y(null,null,null,null),null,null,!1,!0,P.Y(null,null,null,null))
p.q(0,0)
n.c1(0,o)
init.globalState.f.a.a2(new H.be(n,new H.h7(w,v,u,t,s,r),"worker-start"))
init.globalState.d=n
init.globalState.f.aI()
break
case"spawn-worker":break
case"message":if(y.i(z,"port")!=null)J.aL(y.i(z,"port"),y.i(z,"msg"))
init.globalState.f.aI()
break
case"close":init.globalState.ch.V(0,$.$get$dd().i(0,a))
a.terminate()
init.globalState.f.aI()
break
case"log":H.h5(y.i(z,"msg"))
break
case"print":if(init.globalState.x===!0){y=init.globalState.Q
q=P.a4(["command","print","msg",z])
q=new H.az(!0,P.aT(null,P.j)).X(q)
y.toString
self.postMessage(q)}else P.aI(y.i(z,"msg"))
break
case"error":throw H.a(y.i(z,"msg"))}},
h5:function(a){var z,y,x,w
if(init.globalState.x===!0){y=init.globalState.Q
x=P.a4(["command","log","msg",a])
x=new H.az(!0,P.aT(null,P.j)).X(x)
y.toString
self.postMessage(x)}else try{self.console.log(a)}catch(w){H.C(w)
z=H.N(w)
y=P.bl(z)
throw H.a(y)}},
h8:function(a,b,c,d,e,f){var z,y,x,w
z=init.globalState.d
y=z.a
$.dx=$.dx+("_"+y)
$.dy=$.dy+("_"+y)
y=z.e
x=init.globalState.d.a
w=z.f
J.aL(f,["spawned",new H.bE(y,x),w,z.r])
x=new H.h9(a,b,c,d,z)
if(e===!0){z.cv(w,w)
init.globalState.f.a.a2(new H.be(z,x,"start isolate"))}else x.$0()},
kr:function(a){return new H.bB(!0,[]).ae(new H.az(!1,P.aT(null,P.j)).X(a))},
lf:{"^":"c:0;a,b",
$0:function(){this.b.$1(this.a.a)}},
lg:{"^":"c:0;a,b",
$0:function(){this.b.$2(this.a.a,null)}},
jI:{"^":"b;a,b,c,d,e,f,r,x,y,z,Q,ch,cx",m:{
jJ:function(a){var z=P.a4(["command","print","msg",a])
return new H.az(!0,P.aT(null,P.j)).X(z)}}},
cr:{"^":"b;a,b,c,f5:d<,eH:e<,f,r,x,y,z,Q,ch,cx,cy,db,dx",
cv:function(a,b){if(!this.f.A(0,a))return
if(this.Q.q(0,b)&&!this.y)this.y=!0
this.bv()},
fj:function(a){var z,y,x,w,v,u
if(!this.y)return
z=this.Q
z.V(0,a)
if(z.a===0){for(z=this.z;y=z.length,y!==0;){if(0>=y)return H.f(z,-1)
x=z.pop()
y=init.globalState.f.a
w=y.b
v=y.a
u=v.length
w=(w-1&u-1)>>>0
y.b=w
if(w<0||w>=u)return H.f(v,w)
v[w]=x
if(w===y.c)y.cb();++y.d}this.y=!1}this.bv()},
es:function(a,b){var z,y,x
if(this.ch==null)this.ch=[]
for(z=J.k(a),y=0;x=this.ch,y<x.length;y+=2)if(z.A(a,x[y])){z=this.ch
x=y+1
if(x>=z.length)return H.f(z,x)
z[x]=b
return}x.push(a)
this.ch.push(b)},
fi:function(a){var z,y,x
if(this.ch==null)return
for(z=J.k(a),y=0;x=this.ch,y<x.length;y+=2)if(z.A(a,x[y])){z=this.ch
x=y+2
z.toString
if(typeof z!=="object"||z===null||!!z.fixed$length)H.q(new P.m("removeRange"))
P.a_(y,x,z.length,null,null,null)
z.splice(y,x-y)
return}},
d8:function(a,b){if(!this.r.A(0,a))return
this.db=b},
eX:function(a,b,c){var z=J.k(b)
if(!z.A(b,0))z=z.A(b,1)&&!this.cy
else z=!0
if(z){J.aL(a,c)
return}z=this.cx
if(z==null){z=P.c7(null,null)
this.cx=z}z.a2(new H.jB(a,c))},
eW:function(a,b){var z
if(!this.r.A(0,a))return
z=J.k(b)
if(!z.A(b,0))z=z.A(b,1)&&!this.cy
else z=!0
if(z){this.bB()
return}z=this.cx
if(z==null){z=P.c7(null,null)
this.cx=z}z.a2(this.gf6())},
eY:function(a,b){var z,y,x
z=this.dx
if(z.a===0){if(this.db===!0&&this===init.globalState.e)return
if(self.console&&self.console.error)self.console.error(a,b)
else{P.aI(a)
if(b!=null)P.aI(b)}return}y=new Array(2)
y.fixed$length=Array
y[0]=J.P(a)
y[1]=b==null?null:J.P(b)
for(x=new P.aS(z,z.r,null,null),x.c=z.e;x.l();)J.aL(x.d,y)},
aC:function(a){var z,y,x,w,v,u,t
z=init.globalState.d
init.globalState.d=this
$=this.d
y=null
x=this.cy
this.cy=!0
try{y=a.$0()}catch(u){w=H.C(u)
v=H.N(u)
this.eY(w,v)
if(this.db===!0){this.bB()
if(this===init.globalState.e)throw u}}finally{this.cy=x
init.globalState.d=z
if(z!=null)$=z.gf5()
if(this.cx!=null)for(;t=this.cx,!t.gw(t);)this.cx.cP().$0()}return y},
bE:function(a){return this.b.i(0,a)},
c1:function(a,b){var z=this.b
if(z.v(a))throw H.a(P.bl("Registry: ports must be registered only once."))
z.p(0,a,b)},
bv:function(){var z=this.b
if(z.gh(z)-this.c.a>0||this.y||!this.x)init.globalState.z.p(0,this.a,this)
else this.bB()},
bB:[function(){var z,y,x,w,v
z=this.cx
if(z!=null)z.ad(0)
for(z=this.b,y=z.gbP(z),y=y.gB(y);y.l();)y.gt().dM()
z.ad(0)
this.c.ad(0)
init.globalState.z.V(0,this.a)
this.dx.ad(0)
if(this.ch!=null){for(x=0;z=this.ch,y=z.length,x<y;x+=2){w=z[x]
v=x+1
if(v>=y)return H.f(z,v)
J.aL(w,z[v])}this.ch=null}},"$0","gf6",0,0,2]},
jB:{"^":"c:2;a,b",
$0:function(){J.aL(this.a,this.b)}},
ji:{"^":"b;a,b",
eN:function(){var z=this.a
if(z.b===z.c)return
return z.cP()},
cR:function(){var z,y,x
z=this.eN()
if(z==null){if(init.globalState.e!=null)if(init.globalState.z.v(init.globalState.e.a))if(init.globalState.r===!0){y=init.globalState.e.b
y=y.gw(y)}else y=!1
else y=!1
else y=!1
if(y)H.q(P.bl("Program exited with open ReceivePorts."))
y=init.globalState
if(y.x===!0){x=y.z
x=x.gw(x)&&y.f.b===0}else x=!1
if(x){y=y.Q
x=P.a4(["command","close"])
x=new H.az(!0,new P.e9(0,null,null,null,null,null,0,[null,P.j])).X(x)
y.toString
self.postMessage(x)}return!1}z.fg()
return!0},
cm:function(){if(self.window!=null)new H.jj(this).$0()
else for(;this.cR(););},
aI:function(){var z,y,x,w,v
if(init.globalState.x!==!0)this.cm()
else try{this.cm()}catch(x){z=H.C(x)
y=H.N(x)
w=init.globalState.Q
v=P.a4(["command","error","msg",H.d(z)+"\n"+H.d(y)])
v=new H.az(!0,P.aT(null,P.j)).X(v)
w.toString
self.postMessage(v)}}},
jj:{"^":"c:2;a",
$0:function(){if(!this.a.cR())return
P.af(C.u,this)}},
be:{"^":"b;a,b,c",
fg:function(){var z=this.a
if(z.y){z.z.push(this)
return}z.aC(this.b)}},
jH:{"^":"b;"},
h7:{"^":"c:0;a,b,c,d,e,f",
$0:function(){H.h8(this.a,this.b,this.c,this.d,this.e,this.f)}},
h9:{"^":"c:2;a,b,c,d,e",
$0:function(){var z,y
z=this.e
z.x=!0
if(this.d!==!0)this.a.$1(this.c)
else{y=this.a
if(H.aG(y,{func:1,args:[,,]}))y.$2(this.b,this.c)
else if(H.aG(y,{func:1,args:[,]}))y.$1(this.b)
else y.$0()}z.bv()}},
e_:{"^":"b;"},
bE:{"^":"e_;b,a",
aL:function(a,b){var z,y,x
z=init.globalState.z.i(0,this.a)
if(z==null)return
y=this.b
if(y.gcf())return
x=H.kr(b)
if(z.geH()===y){y=J.y(x)
switch(y.i(x,0)){case"pause":z.cv(y.i(x,1),y.i(x,2))
break
case"resume":z.fj(y.i(x,1))
break
case"add-ondone":z.es(y.i(x,1),y.i(x,2))
break
case"remove-ondone":z.fi(y.i(x,1))
break
case"set-errors-fatal":z.d8(y.i(x,1),y.i(x,2))
break
case"ping":z.eX(y.i(x,1),y.i(x,2),y.i(x,3))
break
case"kill":z.eW(y.i(x,1),y.i(x,2))
break
case"getErrors":y=y.i(x,1)
z.dx.q(0,y)
break
case"stopErrors":y=y.i(x,1)
z.dx.V(0,y)
break}return}init.globalState.f.a.a2(new H.be(z,new H.jL(this,x),"receive"))},
A:function(a,b){if(b==null)return!1
return b instanceof H.bE&&J.F(this.b,b.b)},
gD:function(a){return this.b.gbo()}},
jL:{"^":"c:0;a,b",
$0:function(){var z=this.a.b
if(!z.gcf())z.dH(this.b)}},
ct:{"^":"e_;b,c,a",
aL:function(a,b){var z,y,x
z=P.a4(["command","message","port",this,"msg",b])
y=new H.az(!0,P.aT(null,P.j)).X(z)
if(init.globalState.x===!0){init.globalState.Q.toString
self.postMessage(y)}else{x=init.globalState.ch.i(0,this.b)
if(x!=null)x.postMessage(y)}},
A:function(a,b){if(b==null)return!1
return b instanceof H.ct&&J.F(this.b,b.b)&&J.F(this.a,b.a)&&J.F(this.c,b.c)},
gD:function(a){var z,y,x
z=this.b
if(typeof z!=="number")return z.bb()
y=this.a
if(typeof y!=="number")return y.bb()
x=this.c
if(typeof x!=="number")return H.o(x)
return(z<<16^y<<8^x)>>>0}},
bx:{"^":"b;bo:a<,b,cf:c<",
dM:function(){this.c=!0
this.b=null},
dH:function(a){if(this.c)return
this.b.$1(a)},
$isi0:1},
ix:{"^":"b;a,b,c",
a0:function(){if(self.setTimeout!=null){if(this.b)throw H.a(new P.m("Timer in event loop cannot be canceled."))
var z=this.c
if(z==null)return;--init.globalState.f.b
self.clearTimeout(z)
this.c=null}else throw H.a(new P.m("Canceling a timer."))},
dA:function(a,b){var z,y
if(a===0)z=self.setTimeout==null||init.globalState.x===!0
else z=!1
if(z){this.c=1
z=init.globalState.f
y=init.globalState.d
z.a.a2(new H.be(y,new H.iz(this,b),"timer"))
this.b=!0}else if(self.setTimeout!=null){++init.globalState.f.b
this.c=self.setTimeout(H.aE(new H.iA(this,b),0),a)}else throw H.a(new P.m("Timer greater than 0."))},
m:{
iy:function(a,b){var z=new H.ix(!0,!1,null)
z.dA(a,b)
return z}}},
iz:{"^":"c:2;a,b",
$0:function(){this.a.c=null
this.b.$0()}},
iA:{"^":"c:2;a,b",
$0:function(){this.a.c=null;--init.globalState.f.b
this.b.$0()}},
as:{"^":"b;bo:a<",
gD:function(a){var z=this.a
if(typeof z!=="number")return z.dh()
z=C.e.ab(z,0)^C.e.az(z,4294967296)
z=(~z>>>0)+(z<<15>>>0)&4294967295
z=((z^z>>>12)>>>0)*5&4294967295
z=((z^z>>>4)>>>0)*2057&4294967295
return(z^z>>>16)>>>0},
A:function(a,b){var z,y
if(b==null)return!1
if(b===this)return!0
if(b instanceof H.as){z=this.a
y=b.a
return z==null?y==null:z===y}return!1}},
az:{"^":"b;a,b",
X:[function(a){var z,y,x,w,v
if(a==null||typeof a==="string"||typeof a==="number"||typeof a==="boolean")return a
z=this.b
y=z.i(0,a)
if(y!=null)return["ref",y]
z.p(0,a,z.gh(z))
z=J.k(a)
if(!!z.$isdl)return["buffer",a]
if(!!z.$isc9)return["typed",a]
if(!!z.$isJ)return this.d4(a)
if(!!z.$ish4){x=this.gd1()
w=a.gT()
w=H.br(w,x,H.z(w,"I",0),null)
w=P.av(w,!0,H.z(w,"I",0))
z=z.gbP(a)
z=H.br(z,x,H.z(z,"I",0),null)
return["map",w,P.av(z,!0,H.z(z,"I",0))]}if(!!z.$ishg)return this.d5(a)
if(!!z.$ish)this.cT(a)
if(!!z.$isi0)this.aJ(a,"RawReceivePorts can't be transmitted:")
if(!!z.$isbE)return this.d6(a)
if(!!z.$isct)return this.d7(a)
if(!!z.$isc){v=a.$static_name
if(v==null)this.aJ(a,"Closures can't be transmitted:")
return["function",v]}if(!!z.$isas)return["capability",a.a]
if(!(a instanceof P.b))this.cT(a)
return["dart",init.classIdExtractor(a),this.d3(init.classFieldsExtractor(a))]},"$1","gd1",2,0,1],
aJ:function(a,b){throw H.a(new P.m((b==null?"Can't transmit:":b)+" "+H.d(a)))},
cT:function(a){return this.aJ(a,null)},
d4:function(a){var z=this.d2(a)
if(!!a.fixed$length)return["fixed",z]
if(!a.fixed$length)return["extendable",z]
if(!a.immutable$list)return["mutable",z]
if(a.constructor===Array)return["const",z]
this.aJ(a,"Can't serialize indexable: ")},
d2:function(a){var z,y,x
z=[]
C.b.sh(z,a.length)
for(y=0;y<a.length;++y){x=this.X(a[y])
if(y>=z.length)return H.f(z,y)
z[y]=x}return z},
d3:function(a){var z
for(z=0;z<a.length;++z)C.b.p(a,z,this.X(a[z]))
return a},
d5:function(a){var z,y,x,w
if(!!a.constructor&&a.constructor!==Object)this.aJ(a,"Only plain JS Objects are supported:")
z=Object.keys(a)
y=[]
C.b.sh(y,z.length)
for(x=0;x<z.length;++x){w=this.X(a[z[x]])
if(x>=y.length)return H.f(y,x)
y[x]=w}return["js-object",z,y]},
d7:function(a){if(this.a)return["sendport",a.b,a.a,a.c]
return["raw sendport",a]},
d6:function(a){if(this.a)return["sendport",init.globalState.b,a.a,a.b.gbo()]
return["raw sendport",a]}},
bB:{"^":"b;a,b",
ae:[function(a){var z,y,x,w,v,u
if(a==null||typeof a==="string"||typeof a==="number"||typeof a==="boolean")return a
if(typeof a!=="object"||a===null||a.constructor!==Array)throw H.a(P.ak("Bad serialized message: "+H.d(a)))
switch(C.b.gN(a)){case"ref":if(1>=a.length)return H.f(a,1)
z=a[1]
y=this.b
if(z>>>0!==z||z>=y.length)return H.f(y,z)
return y[z]
case"buffer":if(1>=a.length)return H.f(a,1)
x=a[1]
this.b.push(x)
return x
case"typed":if(1>=a.length)return H.f(a,1)
x=a[1]
this.b.push(x)
return x
case"fixed":if(1>=a.length)return H.f(a,1)
x=a[1]
this.b.push(x)
y=H.w(this.aB(x),[null])
y.fixed$length=Array
return y
case"extendable":if(1>=a.length)return H.f(a,1)
x=a[1]
this.b.push(x)
return H.w(this.aB(x),[null])
case"mutable":if(1>=a.length)return H.f(a,1)
x=a[1]
this.b.push(x)
return this.aB(x)
case"const":if(1>=a.length)return H.f(a,1)
x=a[1]
this.b.push(x)
y=H.w(this.aB(x),[null])
y.fixed$length=Array
return y
case"map":return this.eQ(a)
case"sendport":return this.eR(a)
case"raw sendport":if(1>=a.length)return H.f(a,1)
x=a[1]
this.b.push(x)
return x
case"js-object":return this.eP(a)
case"function":if(1>=a.length)return H.f(a,1)
x=init.globalFunctions[a[1]]()
this.b.push(x)
return x
case"capability":if(1>=a.length)return H.f(a,1)
return new H.as(a[1])
case"dart":y=a.length
if(1>=y)return H.f(a,1)
w=a[1]
if(2>=y)return H.f(a,2)
v=a[2]
u=init.instanceFromClassId(w)
this.b.push(u)
this.aB(v)
return init.initializeEmptyInstance(w,u,v)
default:throw H.a("couldn't deserialize: "+H.d(a))}},"$1","geO",2,0,1],
aB:function(a){var z,y,x
z=J.y(a)
y=0
while(!0){x=z.gh(a)
if(typeof x!=="number")return H.o(x)
if(!(y<x))break
z.p(a,y,this.ae(z.i(a,y)));++y}return a},
eQ:function(a){var z,y,x,w,v,u
z=a.length
if(1>=z)return H.f(a,1)
y=a[1]
if(2>=z)return H.f(a,2)
x=a[2]
w=P.di()
this.b.push(w)
y=J.eZ(y,this.geO()).ak(0)
for(z=J.y(y),v=J.y(x),u=0;u<z.gh(y);++u){if(u>=y.length)return H.f(y,u)
w.p(0,y[u],this.ae(v.i(x,u)))}return w},
eR:function(a){var z,y,x,w,v,u,t
z=a.length
if(1>=z)return H.f(a,1)
y=a[1]
if(2>=z)return H.f(a,2)
x=a[2]
if(3>=z)return H.f(a,3)
w=a[3]
if(J.F(y,init.globalState.b)){v=init.globalState.z.i(0,x)
if(v==null)return
u=v.bE(w)
if(u==null)return
t=new H.bE(u,x)}else t=new H.ct(y,w,x)
this.b.push(t)
return t},
eP:function(a){var z,y,x,w,v,u,t
z=a.length
if(1>=z)return H.f(a,1)
y=a[1]
if(2>=z)return H.f(a,2)
x=a[2]
w={}
this.b.push(w)
z=J.y(y)
v=J.y(x)
u=0
while(!0){t=z.gh(y)
if(typeof t!=="number")return H.o(t)
if(!(u<t))break
w[z.i(y,u)]=this.ae(v.i(x,u));++u}return w}}}],["","",,H,{"^":"",
kU:function(a){return init.types[a]},
l8:function(a,b){var z
if(b!=null){z=b.x
if(z!=null)return z}return!!J.k(a).$isQ},
d:function(a){var z
if(typeof a==="string")return a
if(typeof a==="number"){if(a!==0)return""+a}else if(!0===a)return"true"
else if(!1===a)return"false"
else if(a==null)return"null"
z=J.P(a)
if(typeof z!=="string")throw H.a(H.D(a))
return z},
ae:function(a){var z=a.$identityHash
if(z==null){z=Math.random()*0x3fffffff|0
a.$identityHash=z}return z},
cc:function(a,b){if(b==null)throw H.a(new P.G(a,null,null))
return b.$1(a)},
al:function(a,b,c){var z,y,x,w,v,u
z=/^\s*[+-]?((0x[a-f0-9]+)|(\d+)|([a-z0-9]+))\s*$/i.exec(a)
if(z==null)return H.cc(a,c)
if(3>=z.length)return H.f(z,3)
y=z[3]
if(b==null){if(y!=null)return parseInt(a,10)
if(z[2]!=null)return parseInt(a,16)
return H.cc(a,c)}if(b<2||b>36)throw H.a(P.x(b,2,36,"radix",null))
if(b===10&&y!=null)return parseInt(a,10)
if(b<10||y==null){x=b<=10?47+b:86+b
w=z[1]
for(v=w.length,u=0;u<v;++u)if((C.a.C(w,u)|32)>x)return H.cc(a,c)}return parseInt(a,b)},
ce:function(a){var z,y,x,w,v,u,t,s
z=J.k(a)
y=z.constructor
if(typeof y=="function"){x=y.name
w=typeof x==="string"?x:null}else w=null
if(w==null||z===C.N||!!J.k(a).$isbd){v=C.w(a)
if(v==="Object"){u=a.constructor
if(typeof u=="function"){t=String(u).match(/^\s*function\s*([\w$]*)\s*\(/)
s=t==null?null:t[1]
if(typeof s==="string"&&/^\w+$/.test(s))w=s}if(w==null)w=v}else w=v}w=w
if(w.length>1&&C.a.C(w,0)===36)w=C.a.ap(w,1)
return function(b,c){return b.replace(/[^<,> ]+/g,function(d){return c[d]||d})}(w+H.eE(H.bJ(a),0,null),init.mangledGlobalNames)},
bu:function(a){return"Instance of '"+H.ce(a)+"'"},
hX:function(){if(!!self.location)return self.location.href
return},
dw:function(a){var z,y,x,w,v
z=a.length
if(z<=500)return String.fromCharCode.apply(null,a)
for(y="",x=0;x<z;x=w){w=x+500
v=w<z?w:z
y+=String.fromCharCode.apply(null,a.slice(x,v))}return y},
hY:function(a){var z,y,x,w
z=H.w([],[P.j])
for(y=a.length,x=0;x<a.length;a.length===y||(0,H.aa)(a),++x){w=a[x]
if(typeof w!=="number"||Math.floor(w)!==w)throw H.a(H.D(w))
if(w<=65535)z.push(w)
else if(w<=1114111){z.push(55296+(C.c.ab(w-65536,10)&1023))
z.push(56320+(w&1023))}else throw H.a(H.D(w))}return H.dw(z)},
dB:function(a){var z,y,x,w
for(z=a.length,y=0;x=a.length,y<x;x===z||(0,H.aa)(a),++y){w=a[y]
if(typeof w!=="number"||Math.floor(w)!==w)throw H.a(H.D(w))
if(w<0)throw H.a(H.D(w))
if(w>65535)return H.hY(a)}return H.dw(a)},
hZ:function(a,b,c){var z,y,x,w
if(typeof c!=="number")return c.fz()
if(c<=500&&b===0&&c===a.length)return String.fromCharCode.apply(null,a)
for(z=b,y="";z<c;z=x){x=z+500
if(x<c)w=x
else w=c
y+=String.fromCharCode.apply(null,a.subarray(z,w))}return y},
dA:function(a){var z
if(0<=a){if(a<=65535)return String.fromCharCode(a)
if(a<=1114111){z=a-65536
return String.fromCharCode((55296|C.c.ab(z,10))>>>0,56320|z&1023)}}throw H.a(P.x(a,0,1114111,null,null))},
cd:function(a,b){if(a==null||typeof a==="boolean"||typeof a==="number"||typeof a==="string")throw H.a(H.D(a))
return a[b]},
dz:function(a,b,c){if(a==null||typeof a==="boolean"||typeof a==="number"||typeof a==="string")throw H.a(H.D(a))
a[b]=c},
o:function(a){throw H.a(H.D(a))},
f:function(a,b){if(a==null)J.W(a)
throw H.a(H.B(a,b))},
B:function(a,b){var z,y
if(typeof b!=="number"||Math.floor(b)!==b)return new P.Z(!0,b,"index",null)
z=J.W(a)
if(!(b<0)){if(typeof z!=="number")return H.o(z)
y=b>=z}else y=!0
if(y)return P.a3(b,a,"index",null,z)
return P.bw(b,"index",null)},
kQ:function(a,b,c){if(a<0||a>c)return new P.bv(0,c,!0,a,"start","Invalid value")
if(b!=null){if(typeof b!=="number"||Math.floor(b)!==b)return new P.Z(!0,b,"end",null)
if(b<a||b>c)return new P.bv(a,c,!0,b,"end","Invalid value")}return new P.Z(!0,b,"end",null)},
D:function(a){return new P.Z(!0,a,null,null)},
cx:function(a){if(typeof a!=="number"||Math.floor(a)!==a)throw H.a(H.D(a))
return a},
a:function(a){var z
if(a==null)a=new P.ca()
z=new Error()
z.dartException=a
if("defineProperty" in Object){Object.defineProperty(z,"message",{get:H.eK})
z.name=""}else z.toString=H.eK
return z},
eK:function(){return J.P(this.dartException)},
q:function(a){throw H.a(a)},
aa:function(a){throw H.a(new P.L(a))},
C:function(a){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l
z=new H.lk(a)
if(a==null)return
if(typeof a!=="object")return a
if("dartException" in a)return z.$1(a.dartException)
else if(!("message" in a))return a
y=a.message
if("number" in a&&typeof a.number=="number"){x=a.number
w=x&65535
if((C.c.ab(x,16)&8191)===10)switch(w){case 438:return z.$1(H.c5(H.d(y)+" (Error "+w+")",null))
case 445:case 5007:v=H.d(y)+" (Error "+w+")"
return z.$1(new H.du(v,null))}}if(a instanceof TypeError){u=$.$get$dL()
t=$.$get$dM()
s=$.$get$dN()
r=$.$get$dO()
q=$.$get$dS()
p=$.$get$dT()
o=$.$get$dQ()
$.$get$dP()
n=$.$get$dV()
m=$.$get$dU()
l=u.Z(y)
if(l!=null)return z.$1(H.c5(y,l))
else{l=t.Z(y)
if(l!=null){l.method="call"
return z.$1(H.c5(y,l))}else{l=s.Z(y)
if(l==null){l=r.Z(y)
if(l==null){l=q.Z(y)
if(l==null){l=p.Z(y)
if(l==null){l=o.Z(y)
if(l==null){l=r.Z(y)
if(l==null){l=n.Z(y)
if(l==null){l=m.Z(y)
v=l!=null}else v=!0}else v=!0}else v=!0}else v=!0}else v=!0}else v=!0}else v=!0
if(v)return z.$1(new H.du(y,l==null?null:l.method))}}return z.$1(new H.iH(typeof y==="string"?y:""))}if(a instanceof RangeError){if(typeof y==="string"&&y.indexOf("call stack")!==-1)return new P.dE()
y=function(b){try{return String(b)}catch(k){}return null}(a)
return z.$1(new P.Z(!1,null,null,typeof y==="string"?y.replace(/^RangeError:\s*/,""):y))}if(typeof InternalError=="function"&&a instanceof InternalError)if(typeof y==="string"&&y==="too much recursion")return new P.dE()
return a},
N:function(a){var z
if(a==null)return new H.ea(a,null)
z=a.$cachedTrace
if(z!=null)return z
return a.$cachedTrace=new H.ea(a,null)},
lb:function(a){if(a==null||typeof a!='object')return J.ai(a)
else return H.ae(a)},
kT:function(a,b){var z,y,x,w
z=a.length
for(y=0;y<z;y=w){x=y+1
w=x+1
b.p(0,a[y],a[x])}return b},
l2:function(a,b,c,d,e,f,g){switch(c){case 0:return H.bf(b,new H.l3(a))
case 1:return H.bf(b,new H.l4(a,d))
case 2:return H.bf(b,new H.l5(a,d,e))
case 3:return H.bf(b,new H.l6(a,d,e,f))
case 4:return H.bf(b,new H.l7(a,d,e,f,g))}throw H.a(P.bl("Unsupported number of arguments for wrapped closure"))},
aE:function(a,b){var z
if(a==null)return
z=a.$identity
if(!!z)return z
z=function(c,d,e,f){return function(g,h,i,j){return f(c,e,d,g,h,i,j)}}(a,b,init.globalState.d,H.l2)
a.$identity=z
return z},
fm:function(a,b,c,d,e,f){var z,y,x,w,v,u,t,s,r,q,p,o,n,m
z=b[0]
y=z.$callName
if(!!J.k(c).$isi){z.$reflectionInfo=c
x=H.i2(z).r}else x=c
w=d?Object.create(new H.ia().constructor.prototype):Object.create(new H.c_(null,null,null,null).constructor.prototype)
w.$initialize=w.constructor
if(d)v=function(){this.$initialize()}
else{u=$.a0
$.a0=J.aq(u,1)
v=new Function("a,b,c,d"+u,"this.$initialize(a,b,c,d"+u+")")}w.constructor=v
v.prototype=w
if(!d){t=e.length==1&&!0
s=H.cR(a,z,t)
s.$reflectionInfo=c}else{w.$static_name=f
s=z
t=!1}if(typeof x=="number")r=function(g,h){return function(){return g(h)}}(H.kU,x)
else if(typeof x=="function")if(d)r=x
else{q=t?H.cQ:H.c0
r=function(g,h){return function(){return g.apply({$receiver:h(this)},arguments)}}(x,q)}else throw H.a("Error in reflectionInfo.")
w.$S=r
w[y]=s
for(u=b.length,p=1;p<u;++p){o=b[p]
n=o.$callName
if(n!=null){m=d?o:H.cR(a,o,t)
w[n]=m}}w["call*"]=s
w.$R=z.$R
w.$D=z.$D
return v},
fj:function(a,b,c,d){var z=H.c0
switch(b?-1:a){case 0:return function(e,f){return function(){return f(this)[e]()}}(c,z)
case 1:return function(e,f){return function(g){return f(this)[e](g)}}(c,z)
case 2:return function(e,f){return function(g,h){return f(this)[e](g,h)}}(c,z)
case 3:return function(e,f){return function(g,h,i){return f(this)[e](g,h,i)}}(c,z)
case 4:return function(e,f){return function(g,h,i,j){return f(this)[e](g,h,i,j)}}(c,z)
case 5:return function(e,f){return function(g,h,i,j,k){return f(this)[e](g,h,i,j,k)}}(c,z)
default:return function(e,f){return function(){return e.apply(f(this),arguments)}}(d,z)}},
cR:function(a,b,c){var z,y,x,w,v,u,t
if(c)return H.fl(a,b)
z=b.$stubName
y=b.length
x=a[z]
w=b==null?x==null:b===x
v=!w||y>=27
if(v)return H.fj(y,!w,z,b)
if(y===0){w=$.a0
$.a0=J.aq(w,1)
u="self"+H.d(w)
w="return function(){var "+u+" = this."
v=$.aN
if(v==null){v=H.bk("self")
$.aN=v}return new Function(w+H.d(v)+";return "+u+"."+H.d(z)+"();}")()}t="abcdefghijklmnopqrstuvwxyz".split("").splice(0,y).join(",")
w=$.a0
$.a0=J.aq(w,1)
t+=H.d(w)
w="return function("+t+"){return this."
v=$.aN
if(v==null){v=H.bk("self")
$.aN=v}return new Function(w+H.d(v)+"."+H.d(z)+"("+t+");}")()},
fk:function(a,b,c,d){var z,y
z=H.c0
y=H.cQ
switch(b?-1:a){case 0:throw H.a(new H.i4("Intercepted function with no arguments."))
case 1:return function(e,f,g){return function(){return f(this)[e](g(this))}}(c,z,y)
case 2:return function(e,f,g){return function(h){return f(this)[e](g(this),h)}}(c,z,y)
case 3:return function(e,f,g){return function(h,i){return f(this)[e](g(this),h,i)}}(c,z,y)
case 4:return function(e,f,g){return function(h,i,j){return f(this)[e](g(this),h,i,j)}}(c,z,y)
case 5:return function(e,f,g){return function(h,i,j,k){return f(this)[e](g(this),h,i,j,k)}}(c,z,y)
case 6:return function(e,f,g){return function(h,i,j,k,l){return f(this)[e](g(this),h,i,j,k,l)}}(c,z,y)
default:return function(e,f,g,h){return function(){h=[g(this)]
Array.prototype.push.apply(h,arguments)
return e.apply(f(this),h)}}(d,z,y)}},
fl:function(a,b){var z,y,x,w,v,u,t,s
z=H.fe()
y=$.cP
if(y==null){y=H.bk("receiver")
$.cP=y}x=b.$stubName
w=b.length
v=a[x]
u=b==null?v==null:b===v
t=!u||w>=28
if(t)return H.fk(w,!u,x,b)
if(w===1){y="return function(){return this."+H.d(z)+"."+H.d(x)+"(this."+H.d(y)+");"
u=$.a0
$.a0=J.aq(u,1)
return new Function(y+H.d(u)+"}")()}s="abcdefghijklmnopqrstuvwxyz".split("").splice(0,w-1).join(",")
y="return function("+s+"){return this."+H.d(z)+"."+H.d(x)+"(this."+H.d(y)+", "+s+");"
u=$.a0
$.a0=J.aq(u,1)
return new Function(y+H.d(u)+"}")()},
cy:function(a,b,c,d,e,f){var z
b.fixed$length=Array
if(!!J.k(c).$isi){c.fixed$length=Array
z=c}else z=c
return H.fm(a,b,z,!!d,e,f)},
le:function(a,b){var z=J.y(b)
throw H.a(H.fh(H.ce(a),z.k(b,3,z.gh(b))))},
bL:function(a,b){var z
if(a!=null)z=(typeof a==="object"||typeof a==="function")&&J.k(a)[b]
else z=!0
if(z)return a
H.le(a,b)},
kR:function(a){var z=J.k(a)
return"$S" in z?z.$S():null},
aG:function(a,b){var z
if(a==null)return!1
z=H.kR(a)
return z==null?!1:H.eD(z,b)},
lj:function(a){throw H.a(new P.fq(a))},
bO:function(){return(Math.random()*0x100000000>>>0)+(Math.random()*0x100000000>>>0)*4294967296},
eB:function(a){return init.getIsolateTag(a)},
w:function(a,b){a.$ti=b
return a},
bJ:function(a){if(a==null)return
return a.$ti},
eC:function(a,b){return H.cC(a["$as"+H.d(b)],H.bJ(a))},
z:function(a,b,c){var z=H.eC(a,b)
return z==null?null:z[c]},
E:function(a,b){var z=H.bJ(a)
return z==null?null:z[b]},
aJ:function(a,b){var z
if(a==null)return"dynamic"
if(typeof a==="object"&&a!==null&&a.constructor===Array)return a[0].builtin$cls+H.eE(a,1,b)
if(typeof a=="function")return a.builtin$cls
if(typeof a==="number"&&Math.floor(a)===a)return H.d(a)
if(typeof a.func!="undefined"){z=a.typedef
if(z!=null)return H.aJ(z,b)
return H.kz(a,b)}return"unknown-reified-type"},
kz:function(a,b){var z,y,x,w,v,u,t,s,r,q,p
z=!!a.v?"void":H.aJ(a.ret,b)
if("args" in a){y=a.args
for(x=y.length,w="",v="",u=0;u<x;++u,v=", "){t=y[u]
w=w+v+H.aJ(t,b)}}else{w=""
v=""}if("opt" in a){s=a.opt
w+=v+"["
for(x=s.length,v="",u=0;u<x;++u,v=", "){t=s[u]
w=w+v+H.aJ(t,b)}w+="]"}if("named" in a){r=a.named
w+=v+"{"
for(x=H.kS(r),q=x.length,v="",u=0;u<q;++u,v=", "){p=x[u]
w=w+v+H.aJ(r[p],b)+(" "+H.d(p))}w+="}"}return"("+w+") => "+z},
eE:function(a,b,c){var z,y,x,w,v,u
if(a==null)return""
z=new P.am("")
for(y=b,x=!0,w=!0,v="";y<a.length;++y){if(x)x=!1
else z.n=v+", "
u=a[y]
if(u!=null)w=!1
v=z.n+=H.aJ(u,c)}return w?"":"<"+z.j(0)+">"},
cC:function(a,b){if(a==null)return b
a=a.apply(null,b)
if(a==null)return
if(typeof a==="object"&&a!==null&&a.constructor===Array)return a
if(typeof a=="function")return a.apply(null,b)
return b},
bg:function(a,b,c,d){var z,y
if(a==null)return!1
z=H.bJ(a)
y=J.k(a)
if(y[b]==null)return!1
return H.ew(H.cC(y[d],z),c)},
ew:function(a,b){var z,y
if(a==null||b==null)return!0
z=a.length
for(y=0;y<z;++y)if(!H.V(a[y],b[y]))return!1
return!0},
aZ:function(a,b,c){return a.apply(b,H.eC(b,c))},
V:function(a,b){var z,y,x,w,v,u
if(a===b)return!0
if(a==null||b==null)return!0
if(a.builtin$cls==="bt")return!0
if('func' in b)return H.eD(a,b)
if('func' in a)return b.builtin$cls==="lQ"||b.builtin$cls==="b"
z=typeof a==="object"&&a!==null&&a.constructor===Array
y=z?a[0]:a
x=typeof b==="object"&&b!==null&&b.constructor===Array
w=x?b[0]:b
if(w!==y){v=H.aJ(w,null)
if(!('$is'+v in y.prototype))return!1
u=y.prototype["$as"+v]}else u=null
if(!z&&u==null||!x)return!0
z=z?a.slice(1):null
x=b.slice(1)
return H.ew(H.cC(u,z),x)},
ev:function(a,b,c){var z,y,x,w,v
z=b==null
if(z&&a==null)return!0
if(z)return c
if(a==null)return!1
y=a.length
x=b.length
if(c){if(y<x)return!1}else if(y!==x)return!1
for(w=0;w<x;++w){z=a[w]
v=b[w]
if(!(H.V(z,v)||H.V(v,z)))return!1}return!0},
kI:function(a,b){var z,y,x,w,v,u
if(b==null)return!0
if(a==null)return!1
z=Object.getOwnPropertyNames(b)
z.fixed$length=Array
y=z
for(z=y.length,x=0;x<z;++x){w=y[x]
if(!Object.hasOwnProperty.call(a,w))return!1
v=b[w]
u=a[w]
if(!(H.V(v,u)||H.V(u,v)))return!1}return!0},
eD:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l
if(!('func' in a))return!1
if("v" in a){if(!("v" in b)&&"ret" in b)return!1}else if(!("v" in b)){z=a.ret
y=b.ret
if(!(H.V(z,y)||H.V(y,z)))return!1}x=a.args
w=b.args
v=a.opt
u=b.opt
t=x!=null?x.length:0
s=w!=null?w.length:0
r=v!=null?v.length:0
q=u!=null?u.length:0
if(t>s)return!1
if(t+r<s+q)return!1
if(t===s){if(!H.ev(x,w,!1))return!1
if(!H.ev(v,u,!0))return!1}else{for(p=0;p<t;++p){o=x[p]
n=w[p]
if(!(H.V(o,n)||H.V(n,o)))return!1}for(m=p,l=0;m<s;++l,++m){o=v[l]
n=w[m]
if(!(H.V(o,n)||H.V(n,o)))return!1}for(m=0;m<q;++l,++m){o=v[l]
n=u[m]
if(!(H.V(o,n)||H.V(n,o)))return!1}}return H.kI(a.named,b.named)},
mW:function(a){var z=$.cz
return"Instance of "+(z==null?"<Unknown>":z.$1(a))},
mU:function(a){return H.ae(a)},
mT:function(a,b,c){Object.defineProperty(a,b,{value:c,enumerable:false,writable:true,configurable:true})},
l9:function(a){var z,y,x,w,v,u
z=$.cz.$1(a)
y=$.bG[z]
if(y!=null){Object.defineProperty(a,init.dispatchPropertyName,{value:y,enumerable:false,writable:true,configurable:true})
return y.i}x=$.bM[z]
if(x!=null)return x
w=init.interceptorsByTag[z]
if(w==null){z=$.eu.$2(a,z)
if(z!=null){y=$.bG[z]
if(y!=null){Object.defineProperty(a,init.dispatchPropertyName,{value:y,enumerable:false,writable:true,configurable:true})
return y.i}x=$.bM[z]
if(x!=null)return x
w=init.interceptorsByTag[z]}}if(w==null)return
x=w.prototype
v=z[0]
if(v==="!"){y=H.cB(x)
$.bG[z]=y
Object.defineProperty(a,init.dispatchPropertyName,{value:y,enumerable:false,writable:true,configurable:true})
return y.i}if(v==="~"){$.bM[z]=x
return x}if(v==="-"){u=H.cB(x)
Object.defineProperty(Object.getPrototypeOf(a),init.dispatchPropertyName,{value:u,enumerable:false,writable:true,configurable:true})
return u.i}if(v==="+")return H.eF(a,x)
if(v==="*")throw H.a(new P.bc(z))
if(init.leafTags[z]===true){u=H.cB(x)
Object.defineProperty(Object.getPrototypeOf(a),init.dispatchPropertyName,{value:u,enumerable:false,writable:true,configurable:true})
return u.i}else return H.eF(a,x)},
eF:function(a,b){var z=Object.getPrototypeOf(a)
Object.defineProperty(z,init.dispatchPropertyName,{value:J.bN(b,z,null,null),enumerable:false,writable:true,configurable:true})
return b},
cB:function(a){return J.bN(a,!1,null,!!a.$isQ)},
la:function(a,b,c){var z=b.prototype
if(init.leafTags[a]===true)return J.bN(z,!1,null,!!z.$isQ)
else return J.bN(z,c,null,null)},
l0:function(){if(!0===$.cA)return
$.cA=!0
H.l1()},
l1:function(){var z,y,x,w,v,u,t,s
$.bG=Object.create(null)
$.bM=Object.create(null)
H.kX()
z=init.interceptorsByTag
y=Object.getOwnPropertyNames(z)
if(typeof window!="undefined"){window
x=function(){}
for(w=0;w<y.length;++w){v=y[w]
u=$.eG.$1(v)
if(u!=null){t=H.la(v,z[v],u)
if(t!=null){Object.defineProperty(u,init.dispatchPropertyName,{value:t,enumerable:false,writable:true,configurable:true})
x.prototype=u}}}}for(w=0;w<y.length;++w){v=y[w]
if(/^[A-Za-z_]/.test(v)){s=z[v]
z["!"+v]=s
z["~"+v]=s
z["-"+v]=s
z["+"+v]=s
z["*"+v]=s}}},
kX:function(){var z,y,x,w,v,u,t
z=C.P()
z=H.aD(C.Q,H.aD(C.R,H.aD(C.v,H.aD(C.v,H.aD(C.T,H.aD(C.S,H.aD(C.U(C.w),z)))))))
if(typeof dartNativeDispatchHooksTransformer!="undefined"){y=dartNativeDispatchHooksTransformer
if(typeof y=="function")y=[y]
if(y.constructor==Array)for(x=0;x<y.length;++x){w=y[x]
if(typeof w=="function")z=w(z)||z}}v=z.getTag
u=z.getUnknownTag
t=z.prototypeForTag
$.cz=new H.kY(v)
$.eu=new H.kZ(u)
$.eG=new H.l_(t)},
aD:function(a,b){return a(b)||b},
lh:function(a,b,c){var z=a.indexOf(b,c)
return z>=0},
li:function(a,b,c,d){var z=a.indexOf(b,d)
if(z<0)return a
return H.eJ(a,z,z+b.length,c)},
eJ:function(a,b,c,d){var z,y
z=a.substring(0,b)
y=a.substring(c)
return z+d+y},
i1:{"^":"b;a,b,c,d,e,f,r,x",m:{
i2:function(a){var z,y,x
z=a.$reflectionInfo
if(z==null)return
z.fixed$length=Array
z=z
y=z[0]
x=z[1]
return new H.i1(a,z,(y&1)===1,y>>1,x>>1,(x&1)===1,z[2],null)}}},
iF:{"^":"b;a,b,c,d,e,f",
Z:function(a){var z,y,x
z=new RegExp(this.a).exec(a)
if(z==null)return
y=Object.create(null)
x=this.b
if(x!==-1)y.arguments=z[x+1]
x=this.c
if(x!==-1)y.argumentsExpr=z[x+1]
x=this.d
if(x!==-1)y.expr=z[x+1]
x=this.e
if(x!==-1)y.method=z[x+1]
x=this.f
if(x!==-1)y.receiver=z[x+1]
return y},
m:{
a7:function(a){var z,y,x,w,v,u
a=a.replace(String({}),'$receiver$').replace(/[[\]{}()*+?.\\^$|]/g,"\\$&")
z=a.match(/\\\$[a-zA-Z]+\\\$/g)
if(z==null)z=[]
y=z.indexOf("\\$arguments\\$")
x=z.indexOf("\\$argumentsExpr\\$")
w=z.indexOf("\\$expr\\$")
v=z.indexOf("\\$method\\$")
u=z.indexOf("\\$receiver\\$")
return new H.iF(a.replace(new RegExp('\\\\\\$arguments\\\\\\$','g'),'((?:x|[^x])*)').replace(new RegExp('\\\\\\$argumentsExpr\\\\\\$','g'),'((?:x|[^x])*)').replace(new RegExp('\\\\\\$expr\\\\\\$','g'),'((?:x|[^x])*)').replace(new RegExp('\\\\\\$method\\\\\\$','g'),'((?:x|[^x])*)').replace(new RegExp('\\\\\\$receiver\\\\\\$','g'),'((?:x|[^x])*)'),y,x,w,v,u)},
bz:function(a){return function($expr$){var $argumentsExpr$='$arguments$'
try{$expr$.$method$($argumentsExpr$)}catch(z){return z.message}}(a)},
dR:function(a){return function($expr$){try{$expr$.$method$}catch(z){return z.message}}(a)}}},
du:{"^":"H;a,b",
j:function(a){var z=this.b
if(z==null)return"NullError: "+H.d(this.a)
return"NullError: method not found: '"+H.d(z)+"' on null"}},
hm:{"^":"H;a,b,c",
j:function(a){var z,y
z=this.b
if(z==null)return"NoSuchMethodError: "+H.d(this.a)
y=this.c
if(y==null)return"NoSuchMethodError: method not found: '"+z+"' ("+H.d(this.a)+")"
return"NoSuchMethodError: method not found: '"+z+"' on '"+y+"' ("+H.d(this.a)+")"},
m:{
c5:function(a,b){var z,y
z=b==null
y=z?null:b.method
return new H.hm(a,y,z?null:b.receiver)}}},
iH:{"^":"H;a",
j:function(a){var z=this.a
return z.length===0?"Error":"Error: "+z}},
lk:{"^":"c:1;a",
$1:function(a){if(!!J.k(a).$isH)if(a.$thrownJsError==null)a.$thrownJsError=this.a
return a}},
ea:{"^":"b;a,b",
j:function(a){var z,y
z=this.b
if(z!=null)return z
z=this.a
y=z!==null&&typeof z==="object"?z.stack:null
z=y==null?"":y
this.b=z
return z}},
l3:{"^":"c:0;a",
$0:function(){return this.a.$0()}},
l4:{"^":"c:0;a,b",
$0:function(){return this.a.$1(this.b)}},
l5:{"^":"c:0;a,b,c",
$0:function(){return this.a.$2(this.b,this.c)}},
l6:{"^":"c:0;a,b,c,d",
$0:function(){return this.a.$3(this.b,this.c,this.d)}},
l7:{"^":"c:0;a,b,c,d,e",
$0:function(){return this.a.$4(this.b,this.c,this.d,this.e)}},
c:{"^":"b;",
j:function(a){return"Closure '"+H.ce(this).trim()+"'"},
gcX:function(){return this},
gcX:function(){return this}},
dI:{"^":"c;"},
ia:{"^":"dI;",
j:function(a){var z=this.$static_name
if(z==null)return"Closure of unknown static method"
return"Closure '"+z+"'"}},
c_:{"^":"dI;a,b,c,d",
A:function(a,b){if(b==null)return!1
if(this===b)return!0
if(!(b instanceof H.c_))return!1
return this.a===b.a&&this.b===b.b&&this.c===b.c},
gD:function(a){var z,y
z=this.c
if(z==null)y=H.ae(this.a)
else y=typeof z!=="object"?J.ai(z):H.ae(z)
z=H.ae(this.b)
if(typeof y!=="number")return y.fD()
return(y^z)>>>0},
j:function(a){var z=this.c
if(z==null)z=this.a
return"Closure '"+H.d(this.d)+"' of "+H.bu(z)},
m:{
c0:function(a){return a.a},
cQ:function(a){return a.c},
fe:function(){var z=$.aN
if(z==null){z=H.bk("self")
$.aN=z}return z},
bk:function(a){var z,y,x,w,v
z=new H.c_("self","target","receiver","name")
y=Object.getOwnPropertyNames(z)
y.fixed$length=Array
x=y
for(y=x.length,w=0;w<y;++w){v=x[w]
if(z[v]===a)return v}}}},
fg:{"^":"H;a",
j:function(a){return this.a},
m:{
fh:function(a,b){return new H.fg("CastError: Casting value of type '"+a+"' to incompatible type '"+b+"'")}}},
i4:{"^":"H;a",
j:function(a){return"RuntimeError: "+H.d(this.a)}},
ac:{"^":"b;a,b,c,d,e,f,r,$ti",
gh:function(a){return this.a},
gw:function(a){return this.a===0},
gT:function(){return new H.hu(this,[H.E(this,0)])},
gbP:function(a){return H.br(this.gT(),new H.hl(this),H.E(this,0),H.E(this,1))},
v:function(a){var z,y
if(typeof a==="string"){z=this.b
if(z==null)return!1
return this.c7(z,a)}else if(typeof a==="number"&&(a&0x3ffffff)===a){y=this.c
if(y==null)return!1
return this.c7(y,a)}else return this.f1(a)},
f1:function(a){var z=this.d
if(z==null)return!1
return this.aF(this.aS(z,this.aE(a)),a)>=0},
i:function(a,b){var z,y,x
if(typeof b==="string"){z=this.b
if(z==null)return
y=this.aw(z,b)
return y==null?null:y.gag()}else if(typeof b==="number"&&(b&0x3ffffff)===b){x=this.c
if(x==null)return
y=this.aw(x,b)
return y==null?null:y.gag()}else return this.f2(b)},
f2:function(a){var z,y,x
z=this.d
if(z==null)return
y=this.aS(z,this.aE(a))
x=this.aF(y,a)
if(x<0)return
return y[x].gag()},
p:function(a,b,c){var z,y,x,w,v,u
if(typeof b==="string"){z=this.b
if(z==null){z=this.bq()
this.b=z}this.c0(z,b,c)}else if(typeof b==="number"&&(b&0x3ffffff)===b){y=this.c
if(y==null){y=this.bq()
this.c=y}this.c0(y,b,c)}else{x=this.d
if(x==null){x=this.bq()
this.d=x}w=this.aE(b)
v=this.aS(x,w)
if(v==null)this.bu(x,w,[this.br(b,c)])
else{u=this.aF(v,b)
if(u>=0)v[u].sag(c)
else v.push(this.br(b,c))}}},
V:function(a,b){if(typeof b==="string")return this.ck(this.b,b)
else if(typeof b==="number"&&(b&0x3ffffff)===b)return this.ck(this.c,b)
else return this.f3(b)},
f3:function(a){var z,y,x,w
z=this.d
if(z==null)return
y=this.aS(z,this.aE(a))
x=this.aF(y,a)
if(x<0)return
w=y.splice(x,1)[0]
this.cs(w)
return w.gag()},
ad:function(a){if(this.a>0){this.f=null
this.e=null
this.d=null
this.c=null
this.b=null
this.a=0
this.r=this.r+1&67108863}},
u:function(a,b){var z,y
z=this.e
y=this.r
for(;z!=null;){b.$2(z.a,z.b)
if(y!==this.r)throw H.a(new P.L(this))
z=z.c}},
c0:function(a,b,c){var z=this.aw(a,b)
if(z==null)this.bu(a,b,this.br(b,c))
else z.sag(c)},
ck:function(a,b){var z
if(a==null)return
z=this.aw(a,b)
if(z==null)return
this.cs(z)
this.c8(a,b)
return z.gag()},
br:function(a,b){var z,y
z=new H.ht(a,b,null,null)
if(this.e==null){this.f=z
this.e=z}else{y=this.f
z.d=y
y.c=z
this.f=z}++this.a
this.r=this.r+1&67108863
return z},
cs:function(a){var z,y
z=a.ge2()
y=a.c
if(z==null)this.e=y
else z.c=y
if(y==null)this.f=z
else y.d=z;--this.a
this.r=this.r+1&67108863},
aE:function(a){return J.ai(a)&0x3ffffff},
aF:function(a,b){var z,y
if(a==null)return-1
z=a.length
for(y=0;y<z;++y)if(J.F(a[y].gcL(),b))return y
return-1},
j:function(a){return P.dk(this)},
aw:function(a,b){return a[b]},
aS:function(a,b){return a[b]},
bu:function(a,b,c){a[b]=c},
c8:function(a,b){delete a[b]},
c7:function(a,b){return this.aw(a,b)!=null},
bq:function(){var z=Object.create(null)
this.bu(z,"<non-identifier-key>",z)
this.c8(z,"<non-identifier-key>")
return z},
$ish4:1},
hl:{"^":"c:1;a",
$1:function(a){return this.a.i(0,a)}},
ht:{"^":"b;cL:a<,ag:b@,c,e2:d<"},
hu:{"^":"e;a,$ti",
gh:function(a){return this.a.a},
gw:function(a){return this.a.a===0},
gB:function(a){var z,y
z=this.a
y=new H.hv(z,z.r,null,null)
y.c=z.e
return y},
u:function(a,b){var z,y,x
z=this.a
y=z.e
x=z.r
for(;y!=null;){b.$1(y.a)
if(x!==z.r)throw H.a(new P.L(z))
y=y.c}}},
hv:{"^":"b;a,b,c,d",
gt:function(){return this.d},
l:function(){var z=this.a
if(this.b!==z.r)throw H.a(new P.L(z))
else{z=this.c
if(z==null){this.d=null
return!1}else{this.d=z.a
this.c=z.c
return!0}}}},
kY:{"^":"c:1;a",
$1:function(a){return this.a(a)}},
kZ:{"^":"c:13;a",
$2:function(a,b){return this.a(a,b)}},
l_:{"^":"c:5;a",
$1:function(a){return this.a(a)}},
hj:{"^":"b;a,b,c,d",
j:function(a){return"RegExp/"+this.a+"/"},
m:{
hk:function(a,b,c,d){var z,y,x,w
z=b?"m":""
y=c?"":"i"
x=d?"g":""
w=function(e,f){try{return new RegExp(e,f)}catch(v){return v}}(a,z+y+x)
if(w instanceof RegExp)return w
throw H.a(new P.G("Illegal RegExp pattern ("+String(w)+")",a,null))}}}}],["","",,H,{"^":"",
kS:function(a){var z=H.w(a?Object.keys(a):[],[null])
z.fixed$length=Array
return z}}],["","",,H,{"^":"",
ld:function(a){if(typeof dartPrint=="function"){dartPrint(a)
return}if(typeof console=="object"&&typeof console.log!="undefined"){console.log(a)
return}if(typeof window=="object")return
if(typeof print=="function"){print(a)
return}throw"Unable to print message: "+String(a)}}],["","",,H,{"^":"",
el:function(a){return a},
ky:function(a){return a},
hC:function(a){return new Int8Array(H.ky(a))},
kq:function(a,b,c){var z
if(!(a>>>0!==a))if(b==null)z=a>c
else if(!(b>>>0!==b)){if(typeof b!=="number")return H.o(b)
z=a>b||b>c}else z=!0
else z=!0
if(z)throw H.a(H.kQ(a,b,c))
if(b==null)return c
return b},
dl:{"^":"h;",$isdl:1,"%":"ArrayBuffer"},
c9:{"^":"h;",
dY:function(a,b,c,d){if(typeof b!=="number"||Math.floor(b)!==b)throw H.a(P.aM(b,d,"Invalid list position"))
else throw H.a(P.x(b,0,c,d,null))},
c3:function(a,b,c,d){if(b>>>0!==b||b>c)this.dY(a,b,c,d)},
$isc9:1,
"%":"DataView;ArrayBufferView;c8|dm|dp|bs|dn|dq|ad"},
c8:{"^":"c9;",
gh:function(a){return a.length},
cp:function(a,b,c,d,e){var z,y,x
z=a.length
this.c3(a,b,z,"start")
this.c3(a,c,z,"end")
if(b>c)throw H.a(P.x(b,0,c,null,null))
y=c-b
if(e<0)throw H.a(P.ak(e))
x=d.length
if(x-e<y)throw H.a(new P.r("Not enough elements"))
if(e!==0||x!==y)d=d.subarray(e,e+y)
a.set(d,b)},
$isQ:1,
$asQ:I.K,
$isJ:1,
$asJ:I.K},
bs:{"^":"dp;",
i:function(a,b){if(b>>>0!==b||b>=a.length)H.q(H.B(a,b))
return a[b]},
p:function(a,b,c){if(b>>>0!==b||b>=a.length)H.q(H.B(a,b))
a[b]=c},
E:function(a,b,c,d,e){if(!!J.k(d).$isbs){this.cp(a,b,c,d,e)
return}this.bZ(a,b,c,d,e)},
P:function(a,b,c,d){return this.E(a,b,c,d,0)}},
dm:{"^":"c8+S;",$asQ:I.K,$asJ:I.K,
$asi:function(){return[P.a8]},
$ase:function(){return[P.a8]},
$isi:1,
$ise:1},
dp:{"^":"dm+d8;",$asQ:I.K,$asJ:I.K,
$asi:function(){return[P.a8]},
$ase:function(){return[P.a8]}},
ad:{"^":"dq;",
p:function(a,b,c){if(b>>>0!==b||b>=a.length)H.q(H.B(a,b))
a[b]=c},
E:function(a,b,c,d,e){if(!!J.k(d).$isad){this.cp(a,b,c,d,e)
return}this.bZ(a,b,c,d,e)},
P:function(a,b,c,d){return this.E(a,b,c,d,0)},
$isi:1,
$asi:function(){return[P.j]},
$ise:1,
$ase:function(){return[P.j]}},
dn:{"^":"c8+S;",$asQ:I.K,$asJ:I.K,
$asi:function(){return[P.j]},
$ase:function(){return[P.j]},
$isi:1,
$ise:1},
dq:{"^":"dn+d8;",$asQ:I.K,$asJ:I.K,
$asi:function(){return[P.j]},
$ase:function(){return[P.j]}},
m6:{"^":"bs;",$isi:1,
$asi:function(){return[P.a8]},
$ise:1,
$ase:function(){return[P.a8]},
"%":"Float32Array"},
m7:{"^":"bs;",$isi:1,
$asi:function(){return[P.a8]},
$ise:1,
$ase:function(){return[P.a8]},
"%":"Float64Array"},
m8:{"^":"ad;",
i:function(a,b){if(b>>>0!==b||b>=a.length)H.q(H.B(a,b))
return a[b]},
$isi:1,
$asi:function(){return[P.j]},
$ise:1,
$ase:function(){return[P.j]},
"%":"Int16Array"},
m9:{"^":"ad;",
i:function(a,b){if(b>>>0!==b||b>=a.length)H.q(H.B(a,b))
return a[b]},
$isi:1,
$asi:function(){return[P.j]},
$ise:1,
$ase:function(){return[P.j]},
"%":"Int32Array"},
ma:{"^":"ad;",
i:function(a,b){if(b>>>0!==b||b>=a.length)H.q(H.B(a,b))
return a[b]},
$isi:1,
$asi:function(){return[P.j]},
$ise:1,
$ase:function(){return[P.j]},
"%":"Int8Array"},
mb:{"^":"ad;",
i:function(a,b){if(b>>>0!==b||b>=a.length)H.q(H.B(a,b))
return a[b]},
$isi:1,
$asi:function(){return[P.j]},
$ise:1,
$ase:function(){return[P.j]},
"%":"Uint16Array"},
mc:{"^":"ad;",
i:function(a,b){if(b>>>0!==b||b>=a.length)H.q(H.B(a,b))
return a[b]},
$isi:1,
$asi:function(){return[P.j]},
$ise:1,
$ase:function(){return[P.j]},
"%":"Uint32Array"},
md:{"^":"ad;",
gh:function(a){return a.length},
i:function(a,b){if(b>>>0!==b||b>=a.length)H.q(H.B(a,b))
return a[b]},
$isi:1,
$asi:function(){return[P.j]},
$ise:1,
$ase:function(){return[P.j]},
"%":"CanvasPixelArray|Uint8ClampedArray"},
dr:{"^":"ad;",
gh:function(a){return a.length},
i:function(a,b){if(b>>>0!==b||b>=a.length)H.q(H.B(a,b))
return a[b]},
bY:function(a,b,c){return new Uint8Array(a.subarray(b,H.kq(b,c,a.length)))},
$isdr:1,
$isi:1,
$asi:function(){return[P.j]},
$ise:1,
$ase:function(){return[P.j]},
"%":";Uint8Array"}}],["","",,P,{"^":"",
iS:function(){var z,y,x
z={}
if(self.scheduleImmediate!=null)return P.kJ()
if(self.MutationObserver!=null&&self.document!=null){y=self.document.createElement("div")
x=self.document.createElement("span")
z.a=null
new self.MutationObserver(H.aE(new P.iU(z),1)).observe(y,{childList:true})
return new P.iT(z,y,x)}else if(self.setImmediate!=null)return P.kK()
return P.kL()},
mA:[function(a){++init.globalState.f.b
self.scheduleImmediate(H.aE(new P.iV(a),0))},"$1","kJ",2,0,4],
mB:[function(a){++init.globalState.f.b
self.setImmediate(H.aE(new P.iW(a),0))},"$1","kK",2,0,4],
mC:[function(a){P.cf(C.u,a)},"$1","kL",2,0,4],
cw:function(a,b){if(H.aG(a,{func:1,args:[P.bt,P.bt]})){b.toString
return a}else{b.toString
return a}},
kB:function(){var z,y
for(;z=$.aB,z!=null;){$.aW=null
y=z.b
$.aB=y
if(y==null)$.aV=null
z.a.$0()}},
mS:[function(){$.cu=!0
try{P.kB()}finally{$.aW=null
$.cu=!1
if($.aB!=null)$.$get$cj().$1(P.ey())}},"$0","ey",0,0,2],
es:function(a){var z=new P.dY(a,null)
if($.aB==null){$.aV=z
$.aB=z
if(!$.cu)$.$get$cj().$1(P.ey())}else{$.aV.b=z
$.aV=z}},
kG:function(a){var z,y,x
z=$.aB
if(z==null){P.es(a)
$.aW=$.aV
return}y=new P.dY(a,null)
x=$.aW
if(x==null){y.b=z
$.aW=y
$.aB=y}else{y.b=x.b
x.b=y
$.aW=y
if(y.b==null)$.aV=y}},
eH:function(a){var z=$.n
if(C.d===z){P.ao(null,null,C.d,a)
return}z.toString
P.ao(null,null,z,z.bx(a,!0))},
ep:function(a){var z,y,x,w
if(a==null)return
try{a.$0()}catch(x){z=H.C(x)
y=H.N(x)
w=$.n
w.toString
P.aC(null,null,w,z,y)}},
mQ:[function(a){},"$1","kM",2,0,30],
kC:[function(a,b){var z=$.n
z.toString
P.aC(null,null,z,a,b)},function(a){return P.kC(a,null)},"$2","$1","kN",2,2,3,0],
mR:[function(){},"$0","ex",0,0,2],
kF:function(a,b,c){var z,y,x,w,v,u,t
try{b.$1(a.$0())}catch(u){z=H.C(u)
y=H.N(u)
$.n.toString
x=null
if(x==null)c.$2(z,y)
else{t=J.aK(x)
w=t
v=x.ga1()
c.$2(w,v)}}},
kk:function(a,b,c,d){var z=a.a0()
if(!!J.k(z).$isa2&&z!==$.$get$at())z.b7(new P.kn(b,c,d))
else b.aq(c,d)},
kl:function(a,b){return new P.km(a,b)},
ko:function(a,b,c){var z=a.a0()
if(!!J.k(z).$isa2&&z!==$.$get$at())z.b7(new P.kp(b,c))
else b.a9(c)},
kj:function(a,b,c){$.n.toString
a.bd(b,c)},
af:function(a,b){var z=$.n
if(z===C.d){z.toString
return P.cf(a,b)}return P.cf(a,z.bx(b,!0))},
cf:function(a,b){var z=C.c.az(a.a,1000)
return H.iy(z<0?0:z,b)},
iQ:function(){return $.n},
aC:function(a,b,c,d,e){var z={}
z.a=d
P.kG(new P.kE(z,e))},
em:function(a,b,c,d){var z,y
y=$.n
if(y===c)return d.$0()
$.n=c
z=y
try{y=d.$0()
return y}finally{$.n=z}},
eo:function(a,b,c,d,e){var z,y
y=$.n
if(y===c)return d.$1(e)
$.n=c
z=y
try{y=d.$1(e)
return y}finally{$.n=z}},
en:function(a,b,c,d,e,f){var z,y
y=$.n
if(y===c)return d.$2(e,f)
$.n=c
z=y
try{y=d.$2(e,f)
return y}finally{$.n=z}},
ao:function(a,b,c,d){var z=C.d!==c
if(z)d=c.bx(d,!(!z||!1))
P.es(d)},
iU:{"^":"c:1;a",
$1:function(a){var z,y;--init.globalState.f.b
z=this.a
y=z.a
z.a=null
y.$0()}},
iT:{"^":"c:14;a,b,c",
$1:function(a){var z,y;++init.globalState.f.b
this.a.a=a
z=this.b
y=this.c
z.firstChild?z.removeChild(y):z.appendChild(y)}},
iV:{"^":"c:0;a",
$0:function(){--init.globalState.f.b
this.a.$0()}},
iW:{"^":"c:0;a",
$0:function(){--init.globalState.f.b
this.a.$0()}},
iY:{"^":"e0;a,$ti"},
iZ:{"^":"j2;y,e1:z<,Q,x,a,b,c,d,e,f,r,$ti",
aV:[function(){},"$0","gaU",0,0,2],
aX:[function(){},"$0","gaW",0,0,2]},
ck:{"^":"b;ar:c<,$ti",
gaT:function(){return this.c<4},
dR:function(){var z=this.r
if(z!=null)return z
z=new P.U(0,$.n,null,[null])
this.r=z
return z},
cl:function(a){var z,y
z=a.Q
y=a.z
if(z==null)this.d=y
else z.z=y
if(y==null)this.e=z
else y.Q=z
a.Q=a
a.z=a},
em:function(a,b,c,d){var z,y,x,w
if((this.c&4)!==0){if(c==null)c=P.ex()
z=new P.jf($.n,0,c,this.$ti)
z.cn()
return z}z=$.n
y=d?1:0
x=new P.iZ(0,null,null,this,null,null,null,z,y,null,null,this.$ti)
x.c_(a,b,c,d,H.E(this,0))
x.Q=x
x.z=x
x.y=this.c&1
w=this.e
this.e=x
x.z=null
x.Q=w
if(w==null)this.d=x
else w.z=x
if(this.d===x)P.ep(this.a)
return x},
e4:function(a){var z
if(a.ge1()===a)return
z=a.y
if((z&2)!==0)a.y=z|4
else{this.cl(a)
if((this.c&2)===0&&this.d==null)this.bh()}return},
e5:function(a){},
e6:function(a){},
be:["dn",function(){if((this.c&4)!==0)return new P.r("Cannot add new events after calling close")
return new P.r("Cannot add new events while doing an addStream")}],
q:[function(a,b){if(!this.gaT())throw H.a(this.be())
this.b_(b)},"$1","ger",2,0,function(){return H.aZ(function(a){return{func:1,v:true,args:[a]}},this.$receiver,"ck")}],
cE:function(a){var z
if((this.c&4)!==0)return this.r
if(!this.gaT())throw H.a(this.be())
this.c|=4
z=this.dR()
this.ay()
return z},
ca:function(a){var z,y,x,w
z=this.c
if((z&2)!==0)throw H.a(new P.r("Cannot fire new event. Controller is already firing an event"))
y=this.d
if(y==null)return
x=z&1
this.c=z^3
for(;y!=null;){z=y.y
if((z&1)===x){y.y=z|2
a.$1(y)
z=y.y^=1
w=y.z
if((z&4)!==0)this.cl(y)
y.y&=4294967293
y=w}else y=y.z}this.c&=4294967293
if(this.d==null)this.bh()},
bh:function(){if((this.c&4)!==0&&this.r.a===0)this.r.bg(null)
P.ep(this.b)}},
cs:{"^":"ck;a,b,c,d,e,f,r,$ti",
gaT:function(){return P.ck.prototype.gaT.call(this)===!0&&(this.c&2)===0},
be:function(){if((this.c&2)!==0)return new P.r("Cannot fire new event. Controller is already firing an event")
return this.dn()},
b_:function(a){var z=this.d
if(z==null)return
if(z===this.e){this.c|=2
z.av(a)
this.c&=4294967293
if(this.d==null)this.bh()
return}this.ca(new P.k0(this,a))},
ay:function(){if(this.d!=null)this.ca(new P.k1(this))
else this.r.bg(null)}},
k0:{"^":"c;a,b",
$1:function(a){a.av(this.b)},
$S:function(){return H.aZ(function(a){return{func:1,args:[[P.ax,a]]}},this.a,"cs")}},
k1:{"^":"c;a",
$1:function(a){a.c2()},
$S:function(){return H.aZ(function(a){return{func:1,args:[[P.ax,a]]}},this.a,"cs")}},
j1:{"^":"b;$ti",
eF:[function(a,b){var z
if(a==null)a=new P.ca()
z=this.a
if(z.a!==0)throw H.a(new P.r("Future already completed"))
$.n.toString
z.dJ(a,b)},function(a){return this.eF(a,null)},"eE","$2","$1","geD",2,2,3,0]},
iR:{"^":"j1;a,$ti",
eC:function(a,b){var z=this.a
if(z.a!==0)throw H.a(new P.r("Future already completed"))
z.bg(b)}},
co:{"^":"b;bs:a<,b,c,d,e",
geq:function(){return this.b.b},
gcH:function(){return(this.c&1)!==0},
gf0:function(){return(this.c&2)!==0},
gcG:function(){return this.c===8},
eZ:function(a){return this.b.b.bL(this.d,a)},
f8:function(a){if(this.c!==6)return!0
return this.b.b.bL(this.d,J.aK(a))},
eV:function(a){var z,y,x
z=this.e
y=J.p(a)
x=this.b.b
if(H.aG(z,{func:1,args:[,,]}))return x.fp(z,y.gaf(a),a.ga1())
else return x.bL(z,y.gaf(a))},
f_:function(){return this.b.b.cQ(this.d)}},
U:{"^":"b;ar:a<,b,ed:c<,$ti",
gdZ:function(){return this.a===2},
gbp:function(){return this.a>=4},
cS:function(a,b){var z,y
z=$.n
if(z!==C.d){z.toString
if(b!=null)b=P.cw(b,z)}y=new P.U(0,z,null,[null])
this.aM(new P.co(null,y,b==null?1:3,a,b))
return y},
b6:function(a){return this.cS(a,null)},
ez:function(a,b){var z,y
z=$.n
y=new P.U(0,z,null,this.$ti)
if(z!==C.d)a=P.cw(a,z)
this.aM(new P.co(null,y,2,b,a))
return y},
cB:function(a){return this.ez(a,null)},
b7:function(a){var z,y
z=$.n
y=new P.U(0,z,null,this.$ti)
if(z!==C.d)z.toString
this.aM(new P.co(null,y,8,a,null))
return y},
aM:function(a){var z,y
z=this.a
if(z<=1){a.a=this.c
this.c=a}else{if(z===2){y=this.c
if(!y.gbp()){y.aM(a)
return}this.a=y.a
this.c=y.c}z=this.b
z.toString
P.ao(null,null,z,new P.jo(this,a))}},
cj:function(a){var z,y,x,w,v
z={}
z.a=a
if(a==null)return
y=this.a
if(y<=1){x=this.c
this.c=a
if(x!=null){for(w=a;w.gbs()!=null;)w=w.a
w.a=x}}else{if(y===2){v=this.c
if(!v.gbp()){v.cj(a)
return}this.a=v.a
this.c=v.c}z.a=this.aZ(a)
y=this.b
y.toString
P.ao(null,null,y,new P.jv(z,this))}},
aY:function(){var z=this.c
this.c=null
return this.aZ(z)},
aZ:function(a){var z,y,x
for(z=a,y=null;z!=null;y=z,z=x){x=z.gbs()
z.a=y}return y},
a9:function(a){var z,y
z=this.$ti
if(H.bg(a,"$isa2",z,"$asa2"))if(H.bg(a,"$isU",z,null))P.bD(a,this)
else P.e5(a,this)
else{y=this.aY()
this.a=4
this.c=a
P.ay(this,y)}},
aq:[function(a,b){var z=this.aY()
this.a=8
this.c=new P.bj(a,b)
P.ay(this,z)},function(a){return this.aq(a,null)},"fE","$2","$1","gaN",2,2,3,0],
bg:function(a){var z
if(H.bg(a,"$isa2",this.$ti,"$asa2")){this.dL(a)
return}this.a=1
z=this.b
z.toString
P.ao(null,null,z,new P.jq(this,a))},
dL:function(a){var z
if(H.bg(a,"$isU",this.$ti,null)){if(a.a===8){this.a=1
z=this.b
z.toString
P.ao(null,null,z,new P.ju(this,a))}else P.bD(a,this)
return}P.e5(a,this)},
dJ:function(a,b){var z
this.a=1
z=this.b
z.toString
P.ao(null,null,z,new P.jp(this,a,b))},
dE:function(a,b){this.a=4
this.c=a},
$isa2:1,
m:{
e5:function(a,b){var z,y,x
b.a=1
try{a.cS(new P.jr(b),new P.js(b))}catch(x){z=H.C(x)
y=H.N(x)
P.eH(new P.jt(b,z,y))}},
bD:function(a,b){var z,y,x
for(;a.gdZ();)a=a.c
z=a.gbp()
y=b.c
if(z){b.c=null
x=b.aZ(y)
b.a=a.a
b.c=a.c
P.ay(b,x)}else{b.a=2
b.c=a
a.cj(y)}},
ay:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n
z={}
z.a=a
for(y=a;!0;){x={}
w=y.a===8
if(b==null){if(w){v=y.c
y=y.b
u=J.aK(v)
t=v.ga1()
y.toString
P.aC(null,null,y,u,t)}return}for(;b.gbs()!=null;b=s){s=b.a
b.a=null
P.ay(z.a,b)}r=z.a.c
x.a=w
x.b=r
y=!w
if(!y||b.gcH()||b.gcG()){q=b.geq()
if(w){u=z.a.b
u.toString
u=u==null?q==null:u===q
if(!u)q.toString
else u=!0
u=!u}else u=!1
if(u){y=z.a
v=y.c
y=y.b
u=J.aK(v)
t=v.ga1()
y.toString
P.aC(null,null,y,u,t)
return}p=$.n
if(p==null?q!=null:p!==q)$.n=q
else p=null
if(b.gcG())new P.jy(z,x,w,b).$0()
else if(y){if(b.gcH())new P.jx(x,b,r).$0()}else if(b.gf0())new P.jw(z,x,b).$0()
if(p!=null)$.n=p
y=x.b
if(!!J.k(y).$isa2){o=b.b
if(y.a>=4){n=o.c
o.c=null
b=o.aZ(n)
o.a=y.a
o.c=y.c
z.a=y
continue}else P.bD(y,o)
return}}o=b.b
b=o.aY()
y=x.a
u=x.b
if(!y){o.a=4
o.c=u}else{o.a=8
o.c=u}z.a=o
y=o}}}},
jo:{"^":"c:0;a,b",
$0:function(){P.ay(this.a,this.b)}},
jv:{"^":"c:0;a,b",
$0:function(){P.ay(this.b,this.a.a)}},
jr:{"^":"c:1;a",
$1:function(a){var z=this.a
z.a=0
z.a9(a)}},
js:{"^":"c:15;a",
$2:function(a,b){this.a.aq(a,b)},
$1:function(a){return this.$2(a,null)}},
jt:{"^":"c:0;a,b,c",
$0:function(){this.a.aq(this.b,this.c)}},
jq:{"^":"c:0;a,b",
$0:function(){var z,y
z=this.a
y=z.aY()
z.a=4
z.c=this.b
P.ay(z,y)}},
ju:{"^":"c:0;a,b",
$0:function(){P.bD(this.b,this.a)}},
jp:{"^":"c:0;a,b,c",
$0:function(){this.a.aq(this.b,this.c)}},
jy:{"^":"c:2;a,b,c,d",
$0:function(){var z,y,x,w,v,u,t
z=null
try{z=this.d.f_()}catch(w){y=H.C(w)
x=H.N(w)
if(this.c){v=J.aK(this.a.a.c)
u=y
u=v==null?u==null:v===u
v=u}else v=!1
u=this.b
if(v)u.b=this.a.a.c
else u.b=new P.bj(y,x)
u.a=!0
return}if(!!J.k(z).$isa2){if(z instanceof P.U&&z.gar()>=4){if(z.gar()===8){v=this.b
v.b=z.ged()
v.a=!0}return}t=this.a.a
v=this.b
v.b=z.b6(new P.jz(t))
v.a=!1}}},
jz:{"^":"c:1;a",
$1:function(a){return this.a}},
jx:{"^":"c:2;a,b,c",
$0:function(){var z,y,x,w
try{this.a.b=this.b.eZ(this.c)}catch(x){z=H.C(x)
y=H.N(x)
w=this.a
w.b=new P.bj(z,y)
w.a=!0}}},
jw:{"^":"c:2;a,b,c",
$0:function(){var z,y,x,w,v,u,t,s
try{z=this.a.a.c
w=this.c
if(w.f8(z)===!0&&w.e!=null){v=this.b
v.b=w.eV(z)
v.a=!1}}catch(u){y=H.C(u)
x=H.N(u)
w=this.a
v=J.aK(w.a.c)
t=y
s=this.b
if(v==null?t==null:v===t)s.b=w.a.c
else s.b=new P.bj(y,x)
s.a=!0}}},
dY:{"^":"b;a,b"},
a6:{"^":"b;$ti",
a7:function(a,b){return new P.jK(b,this,[H.z(this,"a6",0),null])},
u:function(a,b){var z,y
z={}
y=new P.U(0,$.n,null,[null])
z.a=null
z.a=this.L(new P.ih(z,this,b,y),!0,new P.ii(y),y.gaN())
return y},
gh:function(a){var z,y
z={}
y=new P.U(0,$.n,null,[P.j])
z.a=0
this.L(new P.il(z),!0,new P.im(z,y),y.gaN())
return y},
gw:function(a){var z,y
z={}
y=new P.U(0,$.n,null,[P.aY])
z.a=null
z.a=this.L(new P.ij(z,y),!0,new P.ik(y),y.gaN())
return y},
ak:function(a){var z,y,x
z=H.z(this,"a6",0)
y=H.w([],[z])
x=new P.U(0,$.n,null,[[P.i,z]])
this.L(new P.io(this,y),!0,new P.ip(y,x),x.gaN())
return x}},
ih:{"^":"c;a,b,c,d",
$1:function(a){P.kF(new P.ie(this.c,a),new P.ig(),P.kl(this.a.a,this.d))},
$S:function(){return H.aZ(function(a){return{func:1,args:[a]}},this.b,"a6")}},
ie:{"^":"c:0;a,b",
$0:function(){return this.a.$1(this.b)}},
ig:{"^":"c:1;",
$1:function(a){}},
ii:{"^":"c:0;a",
$0:function(){this.a.a9(null)}},
il:{"^":"c:1;a",
$1:function(a){++this.a.a}},
im:{"^":"c:0;a,b",
$0:function(){this.b.a9(this.a.a)}},
ij:{"^":"c:1;a,b",
$1:function(a){P.ko(this.a.a,this.b,!1)}},
ik:{"^":"c:0;a",
$0:function(){this.a.a9(!0)}},
io:{"^":"c;a,b",
$1:function(a){this.b.push(a)},
$S:function(){return H.aZ(function(a){return{func:1,args:[a]}},this.a,"a6")}},
ip:{"^":"c:0;a,b",
$0:function(){this.b.a9(this.a)}},
dF:{"^":"b;$ti"},
e0:{"^":"jX;a,$ti",
gD:function(a){return(H.ae(this.a)^892482866)>>>0},
A:function(a,b){if(b==null)return!1
if(this===b)return!0
if(!(b instanceof P.e0))return!1
return b.a===this.a}},
j2:{"^":"ax;$ti",
bt:function(){return this.x.e4(this)},
aV:[function(){this.x.e5(this)},"$0","gaU",0,0,2],
aX:[function(){this.x.e6(this)},"$0","gaW",0,0,2]},
ax:{"^":"b;ar:e<,$ti",
aH:function(a,b){var z=this.e
if((z&8)!==0)return
this.e=(z+128|4)>>>0
if(z<128&&this.r!=null)this.r.cA()
if((z&4)===0&&(this.e&32)===0)this.cc(this.gaU())},
bG:function(a){return this.aH(a,null)},
bJ:function(){var z=this.e
if((z&8)!==0)return
if(z>=128){z-=128
this.e=z
if(z<128){if((z&64)!==0){z=this.r
z=!z.gw(z)}else z=!1
if(z)this.r.b9(this)
else{z=(this.e&4294967291)>>>0
this.e=z
if((z&32)===0)this.cc(this.gaW())}}}},
a0:function(){var z=(this.e&4294967279)>>>0
this.e=z
if((z&8)===0)this.bi()
z=this.f
return z==null?$.$get$at():z},
bi:function(){var z=(this.e|8)>>>0
this.e=z
if((z&64)!==0)this.r.cA()
if((this.e&32)===0)this.r=null
this.f=this.bt()},
av:["dq",function(a){var z=this.e
if((z&8)!==0)return
if(z<32)this.b_(a)
else this.bf(new P.jc(a,null,[H.z(this,"ax",0)]))}],
bd:["dr",function(a,b){var z=this.e
if((z&8)!==0)return
if(z<32)this.co(a,b)
else this.bf(new P.je(a,b,null))}],
c2:function(){var z=this.e
if((z&8)!==0)return
z=(z|2)>>>0
this.e=z
if(z<32)this.ay()
else this.bf(C.G)},
aV:[function(){},"$0","gaU",0,0,2],
aX:[function(){},"$0","gaW",0,0,2],
bt:function(){return},
bf:function(a){var z,y
z=this.r
if(z==null){z=new P.jY(null,null,0,[H.z(this,"ax",0)])
this.r=z}z.q(0,a)
y=this.e
if((y&64)===0){y=(y|64)>>>0
this.e=y
if(y<128)this.r.b9(this)}},
b_:function(a){var z=this.e
this.e=(z|32)>>>0
this.d.bM(this.a,a)
this.e=(this.e&4294967263)>>>0
this.bj((z&4)!==0)},
co:function(a,b){var z,y
z=this.e
y=new P.j0(this,a,b)
if((z&1)!==0){this.e=(z|16)>>>0
this.bi()
z=this.f
if(!!J.k(z).$isa2&&z!==$.$get$at())z.b7(y)
else y.$0()}else{y.$0()
this.bj((z&4)!==0)}},
ay:function(){var z,y
z=new P.j_(this)
this.bi()
this.e=(this.e|16)>>>0
y=this.f
if(!!J.k(y).$isa2&&y!==$.$get$at())y.b7(z)
else z.$0()},
cc:function(a){var z=this.e
this.e=(z|32)>>>0
a.$0()
this.e=(this.e&4294967263)>>>0
this.bj((z&4)!==0)},
bj:function(a){var z,y
if((this.e&64)!==0){z=this.r
z=z.gw(z)}else z=!1
if(z){z=(this.e&4294967231)>>>0
this.e=z
if((z&4)!==0)if(z<128){z=this.r
z=z==null||z.gw(z)}else z=!1
else z=!1
if(z)this.e=(this.e&4294967291)>>>0}for(;!0;a=y){z=this.e
if((z&8)!==0){this.r=null
return}y=(z&4)!==0
if(a===y)break
this.e=(z^32)>>>0
if(y)this.aV()
else this.aX()
this.e=(this.e&4294967263)>>>0}z=this.e
if((z&64)!==0&&z<128)this.r.b9(this)},
c_:function(a,b,c,d,e){var z,y
z=a==null?P.kM():a
y=this.d
y.toString
this.a=z
this.b=P.cw(b==null?P.kN():b,y)
this.c=c==null?P.ex():c}},
j0:{"^":"c:2;a,b,c",
$0:function(){var z,y,x,w,v,u
z=this.a
y=z.e
if((y&8)!==0&&(y&16)===0)return
z.e=(y|32)>>>0
y=z.b
x=H.aG(y,{func:1,args:[P.b,P.aw]})
w=z.d
v=this.b
u=z.b
if(x)w.fq(u,v,this.c)
else w.bM(u,v)
z.e=(z.e&4294967263)>>>0}},
j_:{"^":"c:2;a",
$0:function(){var z,y
z=this.a
y=z.e
if((y&16)===0)return
z.e=(y|42)>>>0
z.d.bK(z.c)
z.e=(z.e&4294967263)>>>0}},
jX:{"^":"a6;$ti",
L:function(a,b,c,d){return this.a.em(a,d,c,!0===b)},
b3:function(a,b,c){return this.L(a,null,b,c)}},
e2:{"^":"b;b4:a@"},
jc:{"^":"e2;b,a,$ti",
bH:function(a){a.b_(this.b)}},
je:{"^":"e2;af:b>,a1:c<,a",
bH:function(a){a.co(this.b,this.c)}},
jd:{"^":"b;",
bH:function(a){a.ay()},
gb4:function(){return},
sb4:function(a){throw H.a(new P.r("No events after a done."))}},
jM:{"^":"b;ar:a<",
b9:function(a){var z=this.a
if(z===1)return
if(z>=1){this.a=1
return}P.eH(new P.jN(this,a))
this.a=1},
cA:function(){if(this.a===1)this.a=3}},
jN:{"^":"c:0;a,b",
$0:function(){var z,y,x,w
z=this.a
y=z.a
z.a=0
if(y===3)return
x=z.b
w=x.gb4()
z.b=w
if(w==null)z.c=null
x.bH(this.b)}},
jY:{"^":"jM;b,c,a,$ti",
gw:function(a){return this.c==null},
q:function(a,b){var z=this.c
if(z==null){this.c=b
this.b=b}else{z.sb4(b)
this.c=b}}},
jf:{"^":"b;a,ar:b<,c,$ti",
cn:function(){if((this.b&2)!==0)return
var z=this.a
z.toString
P.ao(null,null,z,this.geg())
this.b=(this.b|2)>>>0},
aH:function(a,b){this.b+=4},
bG:function(a){return this.aH(a,null)},
bJ:function(){var z=this.b
if(z>=4){z-=4
this.b=z
if(z<4&&(z&1)===0)this.cn()}},
a0:function(){return $.$get$at()},
ay:[function(){var z=(this.b&4294967293)>>>0
this.b=z
if(z>=4)return
this.b=(z|1)>>>0
z=this.c
if(z!=null)this.a.bK(z)},"$0","geg",0,0,2]},
kn:{"^":"c:0;a,b,c",
$0:function(){return this.a.aq(this.b,this.c)}},
km:{"^":"c:16;a,b",
$2:function(a,b){P.kk(this.a,this.b,a,b)}},
kp:{"^":"c:0;a,b",
$0:function(){return this.a.a9(this.b)}},
cm:{"^":"a6;$ti",
L:function(a,b,c,d){return this.dP(a,d,c,!0===b)},
b3:function(a,b,c){return this.L(a,null,b,c)},
dP:function(a,b,c,d){return P.jn(this,a,b,c,d,H.z(this,"cm",0),H.z(this,"cm",1))},
cd:function(a,b){b.av(a)},
dX:function(a,b,c){c.bd(a,b)},
$asa6:function(a,b){return[b]}},
e4:{"^":"ax;x,y,a,b,c,d,e,f,r,$ti",
av:function(a){if((this.e&2)!==0)return
this.dq(a)},
bd:function(a,b){if((this.e&2)!==0)return
this.dr(a,b)},
aV:[function(){var z=this.y
if(z==null)return
z.bG(0)},"$0","gaU",0,0,2],
aX:[function(){var z=this.y
if(z==null)return
z.bJ()},"$0","gaW",0,0,2],
bt:function(){var z=this.y
if(z!=null){this.y=null
return z.a0()}return},
fG:[function(a){this.x.cd(a,this)},"$1","gdU",2,0,function(){return H.aZ(function(a,b){return{func:1,v:true,args:[a]}},this.$receiver,"e4")}],
fI:[function(a,b){this.x.dX(a,b,this)},"$2","gdW",4,0,17],
fH:[function(){this.c2()},"$0","gdV",0,0,2],
dD:function(a,b,c,d,e,f,g){this.y=this.x.a.b3(this.gdU(),this.gdV(),this.gdW())},
$asax:function(a,b){return[b]},
m:{
jn:function(a,b,c,d,e,f,g){var z,y
z=$.n
y=e?1:0
y=new P.e4(a,null,null,null,null,z,y,null,null,[f,g])
y.c_(b,c,d,e,g)
y.dD(a,b,c,d,e,f,g)
return y}}},
jK:{"^":"cm;b,a,$ti",
cd:function(a,b){var z,y,x,w
z=null
try{z=this.b.$1(a)}catch(w){y=H.C(w)
x=H.N(w)
P.kj(b,y,x)
return}b.av(z)}},
bj:{"^":"b;af:a>,a1:b<",
j:function(a){return H.d(this.a)},
$isH:1},
ki:{"^":"b;"},
kE:{"^":"c:0;a,b",
$0:function(){var z,y,x
z=this.a
y=z.a
if(y==null){x=new P.ca()
z.a=x
z=x}else z=y
y=this.b
if(y==null)throw H.a(z)
x=H.a(z)
x.stack=J.P(y)
throw x}},
jO:{"^":"ki;",
bK:function(a){var z,y,x,w
try{if(C.d===$.n){x=a.$0()
return x}x=P.em(null,null,this,a)
return x}catch(w){z=H.C(w)
y=H.N(w)
x=P.aC(null,null,this,z,y)
return x}},
bM:function(a,b){var z,y,x,w
try{if(C.d===$.n){x=a.$1(b)
return x}x=P.eo(null,null,this,a,b)
return x}catch(w){z=H.C(w)
y=H.N(w)
x=P.aC(null,null,this,z,y)
return x}},
fq:function(a,b,c){var z,y,x,w
try{if(C.d===$.n){x=a.$2(b,c)
return x}x=P.en(null,null,this,a,b,c)
return x}catch(w){z=H.C(w)
y=H.N(w)
x=P.aC(null,null,this,z,y)
return x}},
bx:function(a,b){if(b)return new P.jP(this,a)
else return new P.jQ(this,a)},
ey:function(a,b){return new P.jR(this,a)},
i:function(a,b){return},
cQ:function(a){if($.n===C.d)return a.$0()
return P.em(null,null,this,a)},
bL:function(a,b){if($.n===C.d)return a.$1(b)
return P.eo(null,null,this,a,b)},
fp:function(a,b,c){if($.n===C.d)return a.$2(b,c)
return P.en(null,null,this,a,b,c)}},
jP:{"^":"c:0;a,b",
$0:function(){return this.a.bK(this.b)}},
jQ:{"^":"c:0;a,b",
$0:function(){return this.a.cQ(this.b)}},
jR:{"^":"c:1;a,b",
$1:function(a){return this.a.bM(this.b,a)}}}],["","",,P,{"^":"",
hw:function(a,b){return new H.ac(0,null,null,null,null,null,0,[a,b])},
di:function(){return new H.ac(0,null,null,null,null,null,0,[null,null])},
a4:function(a){return H.kT(a,new H.ac(0,null,null,null,null,null,0,[null,null]))},
hc:function(a,b,c){var z,y
if(P.cv(a)){if(b==="("&&c===")")return"(...)"
return b+"..."+c}z=[]
y=$.$get$aX()
y.push(a)
try{P.kA(a,z)}finally{if(0>=y.length)return H.f(y,-1)
y.pop()}y=P.dG(b,z,", ")+c
return y.charCodeAt(0)==0?y:y},
bn:function(a,b,c){var z,y,x
if(P.cv(a))return b+"..."+c
z=new P.am(b)
y=$.$get$aX()
y.push(a)
try{x=z
x.n=P.dG(x.gn(),a,", ")}finally{if(0>=y.length)return H.f(y,-1)
y.pop()}y=z
y.n=y.gn()+c
y=z.gn()
return y.charCodeAt(0)==0?y:y},
cv:function(a){var z,y
for(z=0;y=$.$get$aX(),z<y.length;++z)if(a===y[z])return!0
return!1},
kA:function(a,b){var z,y,x,w,v,u,t,s,r,q
z=a.gB(a)
y=0
x=0
while(!0){if(!(y<80||x<3))break
if(!z.l())return
w=H.d(z.gt())
b.push(w)
y+=w.length+2;++x}if(!z.l()){if(x<=5)return
if(0>=b.length)return H.f(b,-1)
v=b.pop()
if(0>=b.length)return H.f(b,-1)
u=b.pop()}else{t=z.gt();++x
if(!z.l()){if(x<=4){b.push(H.d(t))
return}v=H.d(t)
if(0>=b.length)return H.f(b,-1)
u=b.pop()
y+=v.length+2}else{s=z.gt();++x
for(;z.l();t=s,s=r){r=z.gt();++x
if(x>100){while(!0){if(!(y>75&&x>3))break
if(0>=b.length)return H.f(b,-1)
y-=b.pop().length+2;--x}b.push("...")
return}}u=H.d(t)
v=H.d(s)
y+=v.length+u.length+4}}if(x>b.length+2){y+=5
q="..."}else q=null
while(!0){if(!(y>80&&b.length>3))break
if(0>=b.length)return H.f(b,-1)
y-=b.pop().length+2
if(q==null){y+=5
q="..."}}if(q!=null)b.push(q)
b.push(u)
b.push(v)},
Y:function(a,b,c,d){return new P.jD(0,null,null,null,null,null,0,[d])},
dj:function(a,b){var z,y,x
z=P.Y(null,null,null,b)
for(y=a.length,x=0;x<a.length;a.length===y||(0,H.aa)(a),++x)z.q(0,a[x])
return z},
dk:function(a){var z,y,x
z={}
if(P.cv(a))return"{...}"
y=new P.am("")
try{$.$get$aX().push(a)
x=y
x.n=x.gn()+"{"
z.a=!0
a.u(0,new P.hA(z,y))
z=y
z.n=z.gn()+"}"}finally{z=$.$get$aX()
if(0>=z.length)return H.f(z,-1)
z.pop()}z=y.gn()
return z.charCodeAt(0)==0?z:z},
e9:{"^":"ac;a,b,c,d,e,f,r,$ti",
aE:function(a){return H.lb(a)&0x3ffffff},
aF:function(a,b){var z,y,x
if(a==null)return-1
z=a.length
for(y=0;y<z;++y){x=a[y].gcL()
if(x==null?b==null:x===b)return y}return-1},
m:{
aT:function(a,b){return new P.e9(0,null,null,null,null,null,0,[a,b])}}},
jD:{"^":"jA;a,b,c,d,e,f,r,$ti",
gB:function(a){var z=new P.aS(this,this.r,null,null)
z.c=this.e
return z},
gh:function(a){return this.a},
gw:function(a){return this.a===0},
H:function(a,b){var z,y
if(typeof b==="string"&&b!=="__proto__"){z=this.b
if(z==null)return!1
return z[b]!=null}else if(typeof b==="number"&&(b&0x3ffffff)===b){y=this.c
if(y==null)return!1
return y[b]!=null}else return this.dO(b)},
dO:function(a){var z=this.d
if(z==null)return!1
return this.aR(z[this.aO(a)],a)>=0},
bE:function(a){var z
if(!(typeof a==="string"&&a!=="__proto__"))z=typeof a==="number"&&(a&0x3ffffff)===a
else z=!0
if(z)return this.H(0,a)?a:null
else return this.e0(a)},
e0:function(a){var z,y,x
z=this.d
if(z==null)return
y=z[this.aO(a)]
x=this.aR(y,a)
if(x<0)return
return J.O(y,x).gc9()},
u:function(a,b){var z,y
z=this.e
y=this.r
for(;z!=null;){b.$1(z.a)
if(y!==this.r)throw H.a(new P.L(this))
z=z.b}},
q:function(a,b){var z,y,x
if(typeof b==="string"&&b!=="__proto__"){z=this.b
if(z==null){y=Object.create(null)
y["<non-identifier-key>"]=y
delete y["<non-identifier-key>"]
this.b=y
z=y}return this.c4(z,b)}else if(typeof b==="number"&&(b&0x3ffffff)===b){x=this.c
if(x==null){y=Object.create(null)
y["<non-identifier-key>"]=y
delete y["<non-identifier-key>"]
this.c=y
x=y}return this.c4(x,b)}else return this.a2(b)},
a2:function(a){var z,y,x
z=this.d
if(z==null){z=P.jF()
this.d=z}y=this.aO(a)
x=z[y]
if(x==null)z[y]=[this.bk(a)]
else{if(this.aR(x,a)>=0)return!1
x.push(this.bk(a))}return!0},
V:function(a,b){if(typeof b==="string"&&b!=="__proto__")return this.c5(this.b,b)
else if(typeof b==="number"&&(b&0x3ffffff)===b)return this.c5(this.c,b)
else return this.e7(b)},
e7:function(a){var z,y,x
z=this.d
if(z==null)return!1
y=z[this.aO(a)]
x=this.aR(y,a)
if(x<0)return!1
this.c6(y.splice(x,1)[0])
return!0},
ad:function(a){if(this.a>0){this.f=null
this.e=null
this.d=null
this.c=null
this.b=null
this.a=0
this.r=this.r+1&67108863}},
c4:function(a,b){if(a[b]!=null)return!1
a[b]=this.bk(b)
return!0},
c5:function(a,b){var z
if(a==null)return!1
z=a[b]
if(z==null)return!1
this.c6(z)
delete a[b]
return!0},
bk:function(a){var z,y
z=new P.jE(a,null,null)
if(this.e==null){this.f=z
this.e=z}else{y=this.f
z.c=y
y.b=z
this.f=z}++this.a
this.r=this.r+1&67108863
return z},
c6:function(a){var z,y
z=a.gdN()
y=a.b
if(z==null)this.e=y
else z.b=y
if(y==null)this.f=z
else y.c=z;--this.a
this.r=this.r+1&67108863},
aO:function(a){return J.ai(a)&0x3ffffff},
aR:function(a,b){var z,y
if(a==null)return-1
z=a.length
for(y=0;y<z;++y)if(J.F(a[y].gc9(),b))return y
return-1},
$ise:1,
$ase:null,
m:{
jF:function(){var z=Object.create(null)
z["<non-identifier-key>"]=z
delete z["<non-identifier-key>"]
return z}}},
jE:{"^":"b;c9:a<,b,dN:c<"},
aS:{"^":"b;a,b,c,d",
gt:function(){return this.d},
l:function(){var z=this.a
if(this.b!==z.r)throw H.a(new P.L(z))
else{z=this.c
if(z==null){this.d=null
return!1}else{this.d=z.a
this.c=z.b
return!0}}}},
jA:{"^":"i5;$ti"},
au:{"^":"hH;$ti"},
hH:{"^":"b+S;",$asi:null,$ase:null,$isi:1,$ise:1},
S:{"^":"b;$ti",
gB:function(a){return new H.c6(a,this.gh(a),0,null)},
G:function(a,b){return this.i(a,b)},
u:function(a,b){var z,y
z=this.gh(a)
for(y=0;y<z;++y){b.$1(this.i(a,y))
if(z!==this.gh(a))throw H.a(new P.L(a))}},
gw:function(a){return this.gh(a)===0},
gN:function(a){if(this.gh(a)===0)throw H.a(H.b4())
return this.i(a,0)},
a7:function(a,b){return new H.b9(a,b,[H.z(a,"S",0),null])},
a8:function(a,b){var z,y,x
z=[H.z(a,"S",0)]
if(b){y=H.w([],z)
C.b.sh(y,this.gh(a))}else y=H.w(new Array(this.gh(a)),z)
for(x=0;x<this.gh(a);++x){z=this.i(a,x)
if(x>=y.length)return H.f(y,x)
y[x]=z}return y},
ak:function(a){return this.a8(a,!0)},
as:function(a,b,c,d){var z
P.a_(b,c,this.gh(a),null,null,null)
for(z=b;z<c;++z)this.p(a,z,d)},
E:["bZ",function(a,b,c,d,e){var z,y,x,w,v
P.a_(b,c,this.gh(a),null,null,null)
z=c-b
if(z===0)return
y=e<0
if(y)H.q(P.x(e,0,null,"skipCount",null))
if(H.bg(d,"$isi",[H.z(a,"S",0)],"$asi")){x=e
w=d}else{if(y)H.q(P.x(e,0,null,"start",null))
w=new H.is(d,e,null,[H.z(d,"S",0)]).a8(0,!1)
x=0}y=J.y(w)
if(x+z>y.gh(w))throw H.a(H.de())
if(x<b)for(v=z-1;v>=0;--v)this.p(a,b+v,y.i(w,x+v))
else for(v=0;v<z;++v)this.p(a,b+v,y.i(w,x+v))},function(a,b,c,d){return this.E(a,b,c,d,0)},"P",null,null,"gfB",6,2,null,1],
O:function(a,b,c,d){var z,y,x,w,v
P.a_(b,c,this.gh(a),null,null,null)
d=C.a.ak(d)
if(typeof c!=="number")return c.R()
z=c-b
y=d.length
x=b+y
if(z>=y){w=z-y
v=this.gh(a)-w
this.P(a,b,x,d)
if(w!==0){this.E(a,x,v,a,c)
this.sh(a,v)}}else{v=this.gh(a)+(y-z)
this.sh(a,v)
this.E(a,x,v,a,c)
this.P(a,b,x,d)}},
at:function(a,b,c){var z
if(c>=this.gh(a))return-1
if(c<0)c=0
for(z=c;z<this.gh(a);++z)if(J.F(this.i(a,z),b))return z
return-1},
a6:function(a,b){return this.at(a,b,0)},
j:function(a){return P.bn(a,"[","]")},
$isi:1,
$asi:null,
$ise:1,
$ase:null},
hA:{"^":"c:18;a,b",
$2:function(a,b){var z,y
z=this.a
if(!z.a)this.b.n+=", "
z.a=!1
z=this.b
y=z.n+=H.d(a)
z.n=y+": "
z.n+=H.d(b)}},
hx:{"^":"aQ;a,b,c,d,$ti",
gB:function(a){return new P.jG(this,this.c,this.d,this.b,null)},
u:function(a,b){var z,y,x
z=this.d
for(y=this.b;y!==this.c;y=(y+1&this.a.length-1)>>>0){x=this.a
if(y<0||y>=x.length)return H.f(x,y)
b.$1(x[y])
if(z!==this.d)H.q(new P.L(this))}},
gw:function(a){return this.b===this.c},
gh:function(a){return(this.c-this.b&this.a.length-1)>>>0},
G:function(a,b){var z,y,x,w
z=(this.c-this.b&this.a.length-1)>>>0
if(typeof b!=="number")return H.o(b)
if(0>b||b>=z)H.q(P.a3(b,this,"index",null,z))
y=this.a
x=y.length
w=(this.b+b&x-1)>>>0
if(w<0||w>=x)return H.f(y,w)
return y[w]},
ad:function(a){var z,y,x,w,v
z=this.b
y=this.c
if(z!==y){for(x=this.a,w=x.length,v=w-1;z!==y;z=(z+1&v)>>>0){if(z<0||z>=w)return H.f(x,z)
x[z]=null}this.c=0
this.b=0;++this.d}},
j:function(a){return P.bn(this,"{","}")},
cP:function(){var z,y,x,w
z=this.b
if(z===this.c)throw H.a(H.b4());++this.d
y=this.a
x=y.length
if(z>=x)return H.f(y,z)
w=y[z]
y[z]=null
this.b=(z+1&x-1)>>>0
return w},
a2:function(a){var z,y,x
z=this.a
y=this.c
x=z.length
if(y<0||y>=x)return H.f(z,y)
z[y]=a
x=(y+1&x-1)>>>0
this.c=x
if(this.b===x)this.cb();++this.d},
cb:function(){var z,y,x,w
z=new Array(this.a.length*2)
z.fixed$length=Array
y=H.w(z,this.$ti)
z=this.a
x=this.b
w=z.length-x
C.b.E(y,0,w,z,x)
C.b.E(y,w,w+this.b,this.a,0)
this.b=0
this.c=this.a.length
this.a=y},
dw:function(a,b){var z=new Array(8)
z.fixed$length=Array
this.a=H.w(z,[b])},
$ase:null,
m:{
c7:function(a,b){var z=new P.hx(null,0,0,0,[b])
z.dw(a,b)
return z}}},
jG:{"^":"b;a,b,c,d,e",
gt:function(){return this.e},
l:function(){var z,y,x
z=this.a
if(this.c!==z.d)H.q(new P.L(z))
y=this.d
if(y===this.b){this.e=null
return!1}z=z.a
x=z.length
if(y>=x)return H.f(z,y)
this.e=z[y]
this.d=(y+1&x-1)>>>0
return!0}},
i6:{"^":"b;$ti",
gw:function(a){return this.a===0},
a3:function(a,b){var z
for(z=J.aj(b);z.l();)this.q(0,z.gt())},
a7:function(a,b){return new H.c1(this,b,[H.E(this,0),null])},
j:function(a){return P.bn(this,"{","}")},
u:function(a,b){var z
for(z=new P.aS(this,this.r,null,null),z.c=this.e;z.l();)b.$1(z.d)},
ai:function(a,b){var z,y
z=new P.aS(this,this.r,null,null)
z.c=this.e
if(!z.l())return""
if(b===""){y=""
do y+=H.d(z.d)
while(z.l())}else{y=H.d(z.d)
for(;z.l();)y=y+b+H.d(z.d)}return y.charCodeAt(0)==0?y:y},
G:function(a,b){var z,y,x
if(typeof b!=="number"||Math.floor(b)!==b)throw H.a(P.b0("index"))
if(b<0)H.q(P.x(b,0,null,"index",null))
for(z=new P.aS(this,this.r,null,null),z.c=this.e,y=0;z.l();){x=z.d
if(b===y)return x;++y}throw H.a(P.a3(b,this,"index",null,y))},
$ise:1,
$ase:null},
i5:{"^":"i6;$ti"}}],["","",,P,{"^":"",
bF:function(a){var z
if(a==null)return
if(typeof a!="object")return a
if(Object.getPrototypeOf(a)!==Array.prototype)return new P.jC(a,Object.create(null),null)
for(z=0;z<a.length;++z)a[z]=P.bF(a[z])
return a},
kD:function(a,b){var z,y,x,w
if(typeof a!=="string")throw H.a(H.D(a))
z=null
try{z=JSON.parse(a)}catch(x){y=H.C(x)
w=String(y)
throw H.a(new P.G(w,null,null))}w=P.bF(z)
return w},
jC:{"^":"b;a,b,c",
i:function(a,b){var z,y
z=this.b
if(z==null)return this.c.i(0,b)
else if(typeof b!=="string")return
else{y=z[b]
return typeof y=="undefined"?this.e3(b):y}},
gh:function(a){var z
if(this.b==null){z=this.c
z=z.gh(z)}else z=this.aP().length
return z},
gw:function(a){var z
if(this.b==null){z=this.c
z=z.gh(z)}else z=this.aP().length
return z===0},
p:function(a,b,c){var z,y
if(this.b==null)this.c.p(0,b,c)
else if(this.v(b)){z=this.b
z[b]=c
y=this.a
if(y==null?z!=null:y!==z)y[b]=null}else this.ep().p(0,b,c)},
v:function(a){if(this.b==null)return this.c.v(a)
if(typeof a!=="string")return!1
return Object.prototype.hasOwnProperty.call(this.a,a)},
u:function(a,b){var z,y,x,w
if(this.b==null)return this.c.u(0,b)
z=this.aP()
for(y=0;y<z.length;++y){x=z[y]
w=this.b[x]
if(typeof w=="undefined"){w=P.bF(this.a[x])
this.b[x]=w}b.$2(x,w)
if(z!==this.c)throw H.a(new P.L(this))}},
j:function(a){return P.dk(this)},
aP:function(){var z=this.c
if(z==null){z=Object.keys(this.a)
this.c=z}return z},
ep:function(){var z,y,x,w,v
if(this.b==null)return this.c
z=P.hw(P.t,null)
y=this.aP()
for(x=0;w=y.length,x<w;++x){v=y[x]
z.p(0,v,this.i(0,v))}if(w===0)y.push(null)
else C.b.sh(y,0)
this.b=null
this.a=null
this.c=z
return z},
e3:function(a){var z
if(!Object.prototype.hasOwnProperty.call(this.a,a))return
z=P.bF(this.a[a])
return this.b[a]=z}},
fc:{"^":"cS;a",
fc:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i
z=J.y(a)
c=P.a_(b,c,z.gh(a),null,null,null)
y=$.$get$dZ()
if(typeof c!=="number")return H.o(c)
x=b
w=x
v=null
u=-1
t=-1
s=0
for(;x<c;x=r){r=x+1
q=z.F(a,x)
if(q===37){p=r+2
if(p<=c){o=H.bK(C.a.C(a,r))
n=H.bK(C.a.C(a,r+1))
m=o*16+n-(n&256)
if(m===37)m=-1
r=p}else m=-1}else m=q
if(0<=m&&m<=127){if(m<0||m>=y.length)return H.f(y,m)
l=y[m]
if(l>=0){m=C.a.F("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",l)
if(m===q)continue
q=m}else{if(l===-1){if(u<0){k=v==null?v:v.n.length
if(k==null)k=0
if(typeof k!=="number")return k.W()
u=k+(x-w)
t=x}++s
if(q===61)continue}q=m}if(l!==-2){if(v==null)v=new P.am("")
v.n+=C.a.k(a,w,x)
v.n+=H.dA(q)
w=r
continue}}throw H.a(new P.G("Invalid base64 data",a,x))}if(v!=null){z=v.n+=z.k(a,w,c)
k=z.length
if(u>=0)P.cO(a,t,c,u,s,k)
else{j=C.c.b8(k-1,4)+1
if(j===1)throw H.a(new P.G("Invalid base64 encoding length ",a,c))
for(;j<4;){z+="="
v.n=z;++j}}z=v.n
return C.a.O(a,b,c,z.charCodeAt(0)==0?z:z)}i=c-b
if(u>=0)P.cO(a,t,c,u,s,i)
else{j=C.e.b8(i,4)
if(j===1)throw H.a(new P.G("Invalid base64 encoding length ",a,c))
if(j>1)a=z.O(a,c,c,j===2?"==":"=")}return a},
m:{
cO:function(a,b,c,d,e,f){if(C.e.b8(f,4)!==0)throw H.a(new P.G("Invalid base64 padding, padded length must be multiple of four, is "+H.d(f),a,c))
if(d+e!==f)throw H.a(new P.G("Invalid base64 padding, '=' not at the end",a,b))
if(e>2)throw H.a(new P.G("Invalid base64 padding, more than two '=' characters",a,b))}}},
fd:{"^":"cT;a"},
cS:{"^":"b;"},
cT:{"^":"b;"},
hn:{"^":"cS;a,b",
eL:function(a,b){var z=P.kD(a,this.geM().a)
return z},
eK:function(a){return this.eL(a,null)},
geM:function(){return C.X}},
ho:{"^":"cT;a"}}],["","",,P,{"^":"",
ir:function(a,b,c){var z,y,x,w
if(b<0)throw H.a(P.x(b,0,a.length,null,null))
z=c==null
if(!z&&c<b)throw H.a(P.x(c,b,a.length,null,null))
y=J.aj(a)
for(x=0;x<b;++x)if(!y.l())throw H.a(P.x(b,0,x,null,null))
w=[]
if(z)for(;y.l();)w.push(y.gt())
else for(x=b;x<c;++x){if(!y.l())throw H.a(P.x(c,b,x,null,null))
w.push(y.gt())}return H.dB(w)},
d5:function(a){if(typeof a==="number"||typeof a==="boolean"||null==a)return J.P(a)
if(typeof a==="string")return JSON.stringify(a)
return P.fz(a)},
fz:function(a){var z=J.k(a)
if(!!z.$isc)return z.j(a)
return H.bu(a)},
bl:function(a){return new P.jm(a)},
av:function(a,b,c){var z,y
z=H.w([],[c])
for(y=J.aj(a);y.l();)z.push(y.gt())
if(b)return z
z.fixed$length=Array
return z},
hy:function(a,b,c,d){var z,y,x
z=H.w([],[d])
C.b.sh(z,a)
for(y=0;y<a;++y){x=b.$1(y)
if(y>=z.length)return H.f(z,y)
z[y]=x}return z},
aI:function(a){H.ld(H.d(a))},
i3:function(a,b,c){return new H.hj(a,H.hk(a,!1,!0,!1),null,null)},
iq:function(a,b,c){var z,y
if(typeof a==="object"&&a!==null&&a.constructor===Array){z=a.length
c=P.a_(b,c,z,null,null,null)
if(b<=0){if(typeof c!=="number")return c.I()
y=c<z}else y=!0
return H.dB(y?J.f8(a,b,c):a)}if(!!J.k(a).$isdr)return H.hZ(a,b,P.a_(b,c,a.length,null,null,null))
return P.ir(a,b,c)},
ch:function(){var z=H.hX()
if(z!=null)return P.iL(z,0,null)
throw H.a(new P.m("'Uri.base' is not supported"))},
iL:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n,m
c=a.length
z=b+5
if(c>=z){y=((C.a.C(a,b+4)^58)*3|C.a.C(a,b)^100|C.a.C(a,b+1)^97|C.a.C(a,b+2)^116|C.a.C(a,b+3)^97)>>>0
if(y===0)return P.dW(b>0||c<c?C.a.k(a,b,c):a,5,null).gcU()
else if(y===32)return P.dW(C.a.k(a,z,c),0,null).gcU()}x=H.w(new Array(8),[P.j])
x[0]=0
w=b-1
x[1]=w
x[2]=w
x[7]=w
x[3]=b
x[4]=b
x[5]=c
x[6]=c
if(P.eq(a,b,c,0,x)>=14)x[7]=c
v=x[1]
if(typeof v!=="number")return v.bS()
if(v>=b)if(P.eq(a,b,v,20,x)===20)x[7]=v
w=x[2]
if(typeof w!=="number")return w.W()
u=w+1
t=x[3]
s=x[4]
r=x[5]
q=x[6]
if(typeof q!=="number")return q.I()
if(typeof r!=="number")return H.o(r)
if(q<r)r=q
if(typeof s!=="number")return s.I()
if(s<u||s<=v)s=r
if(typeof t!=="number")return t.I()
if(t<u)t=s
w=x[7]
if(typeof w!=="number")return w.I()
p=w<b
if(p)if(u>v+3){o=null
p=!1}else{w=t>b
if(w&&t+1===s){o=null
p=!1}else{if(!(r<c&&r===s+2&&C.a.Y(a,"..",s)))n=r>s+2&&C.a.Y(a,"/..",r-3)
else n=!0
if(n){o=null
p=!1}else{if(v===b+4)if(C.a.Y(a,"file",b)){if(u<=b){if(!C.a.Y(a,"/",s)){m="file:///"
y=3}else{m="file://"
y=2}a=m+C.a.k(a,s,c)
v-=b
z=y-b
r+=z
q+=z
c=a.length
b=0
u=7
t=7
s=7}else if(s===r)if(b===0&&!0){a=C.a.O(a,s,r,"/");++r;++q;++c}else{a=C.a.k(a,b,s)+"/"+C.a.k(a,r,c)
v-=b
u-=b
t-=b
s-=b
z=1-b
r+=z
q+=z
c=a.length
b=0}o="file"}else if(C.a.Y(a,"http",b)){if(w&&t+3===s&&C.a.Y(a,"80",t+1))if(b===0&&!0){a=C.a.O(a,t,s,"")
s-=3
r-=3
q-=3
c-=3}else{a=C.a.k(a,b,t)+C.a.k(a,s,c)
v-=b
u-=b
t-=b
z=3+b
s-=z
r-=z
q-=z
c=a.length
b=0}o="http"}else o=null
else if(v===z&&C.a.Y(a,"https",b)){if(w&&t+4===s&&C.a.Y(a,"443",t+1))if(b===0&&!0){a=C.a.O(a,t,s,"")
s-=4
r-=4
q-=4
c-=3}else{a=C.a.k(a,b,t)+C.a.k(a,s,c)
v-=b
u-=b
t-=b
z=4+b
s-=z
r-=z
q-=z
c=a.length
b=0}o="https"}else o=null
p=!0}}}else o=null
if(p){if(b>0||c<a.length){a=C.a.k(a,b,c)
v-=b
u-=b
t-=b
s-=b
r-=b
q-=b}return new P.jW(a,v,u,t,s,r,q,o,null)}return P.k4(a,b,c,v,u,t,s,r,q,o)},
iJ:function(a,b,c){var z,y,x,w,v,u,t,s,r
z=new P.iK(a)
y=H.el(4)
x=new Uint8Array(y)
for(w=b,v=w,u=0;w<c;++w){t=C.a.F(a,w)
if(t!==46){if((t^48)>9)z.$2("invalid character",w)}else{if(u===3)z.$2("IPv4 address should contain exactly 4 parts",w)
s=H.al(C.a.k(a,v,w),null,null)
if(J.bP(s,255))z.$2("each part must be in the range 0..255",v)
r=u+1
if(u>=y)return H.f(x,u)
x[u]=s
v=w+1
u=r}}if(u!==3)z.$2("IPv4 address should contain exactly 4 parts",c)
s=H.al(C.a.k(a,v,c),null,null)
if(J.bP(s,255))z.$2("each part must be in the range 0..255",v)
if(u>=y)return H.f(x,u)
x[u]=s
return x},
dX:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i
if(c==null)c=a.length
z=new P.iM(a)
y=new P.iN(a,z)
if(a.length<2)z.$1("address is too short")
x=[]
for(w=b,v=w,u=!1,t=!1;w<c;++w){s=C.a.F(a,w)
if(s===58){if(w===b){++w
if(C.a.F(a,w)!==58)z.$2("invalid start colon.",w)
v=w}if(w===v){if(u)z.$2("only one wildcard `::` is allowed",w)
x.push(-1)
u=!0}else x.push(y.$2(v,w))
v=w+1}else if(s===46)t=!0}if(x.length===0)z.$1("too few parts")
r=v===c
q=J.F(C.b.gb1(x),-1)
if(r&&!q)z.$2("expected a part after last `:`",c)
if(!r)if(!t)x.push(y.$2(v,c))
else{p=P.iJ(a,v,c)
o=p[0]
if(typeof o!=="number")return o.bb()
n=p[1]
if(typeof n!=="number")return H.o(n)
x.push((o<<8|n)>>>0)
n=p[2]
if(typeof n!=="number")return n.bb()
o=p[3]
if(typeof o!=="number")return H.o(o)
x.push((n<<8|o)>>>0)}if(u){if(x.length>7)z.$1("an address with a wildcard must have less than 7 parts")}else if(x.length!==8)z.$1("an address without a wildcard must contain exactly 8 parts")
m=new Uint8Array(16)
for(w=0,l=0;w<x.length;++w){k=x[w]
if(J.k(k).A(k,-1)){j=9-x.length
for(i=0;i<j;++i){if(l<0||l>=16)return H.f(m,l)
m[l]=0
o=l+1
if(o>=16)return H.f(m,o)
m[o]=0
l+=2}}else{if(typeof k!=="number")return k.dh()
o=C.e.ab(k,8)
if(l<0||l>=16)return H.f(m,l)
m[l]=o
o=l+1
if(o>=16)return H.f(m,o)
m[o]=k&255
l+=2}}return m},
kt:function(){var z,y,x,w,v
z=P.hy(22,new P.kv(),!0,P.bb)
y=new P.ku(z)
x=new P.kw()
w=new P.kx()
v=y.$2(0,225)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",1)
x.$3(v,".",14)
x.$3(v,":",34)
x.$3(v,"/",3)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(14,225)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",1)
x.$3(v,".",15)
x.$3(v,":",34)
x.$3(v,"/",234)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(15,225)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",1)
x.$3(v,"%",225)
x.$3(v,":",34)
x.$3(v,"/",9)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(1,225)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",1)
x.$3(v,":",34)
x.$3(v,"/",10)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(2,235)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",139)
x.$3(v,"/",131)
x.$3(v,".",146)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(3,235)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",11)
x.$3(v,"/",68)
x.$3(v,".",18)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(4,229)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",5)
w.$3(v,"AZ",229)
x.$3(v,":",102)
x.$3(v,"@",68)
x.$3(v,"[",232)
x.$3(v,"/",138)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(5,229)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",5)
w.$3(v,"AZ",229)
x.$3(v,":",102)
x.$3(v,"@",68)
x.$3(v,"/",138)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(6,231)
w.$3(v,"19",7)
x.$3(v,"@",68)
x.$3(v,"/",138)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(7,231)
w.$3(v,"09",7)
x.$3(v,"@",68)
x.$3(v,"/",138)
x.$3(v,"?",172)
x.$3(v,"#",205)
x.$3(y.$2(8,8),"]",5)
v=y.$2(9,235)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",11)
x.$3(v,".",16)
x.$3(v,"/",234)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(16,235)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",11)
x.$3(v,".",17)
x.$3(v,"/",234)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(17,235)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",11)
x.$3(v,"/",9)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(10,235)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",11)
x.$3(v,".",18)
x.$3(v,"/",234)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(18,235)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",11)
x.$3(v,".",19)
x.$3(v,"/",234)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(19,235)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",11)
x.$3(v,"/",234)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(11,235)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",11)
x.$3(v,"/",10)
x.$3(v,"?",172)
x.$3(v,"#",205)
v=y.$2(12,236)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",12)
x.$3(v,"?",12)
x.$3(v,"#",205)
v=y.$2(13,237)
x.$3(v,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-._~!$&'()*+,;=",13)
x.$3(v,"?",13)
w.$3(y.$2(20,245),"az",21)
v=y.$2(21,245)
w.$3(v,"az",21)
w.$3(v,"09",21)
x.$3(v,"+-.",21)
return z},
eq:function(a,b,c,d,e){var z,y,x,w,v,u
z=$.$get$er()
for(y=b;y<c;++y){if(d<0||d>=z.length)return H.f(z,d)
x=z[d]
w=C.a.C(a,y)^96
v=J.O(x,w>95?31:w)
if(typeof v!=="number")return v.fw()
d=v&31
u=C.e.ab(v,5)
if(u>=8)return H.f(e,u)
e[u]=y}return d},
aY:{"^":"b;"},
"+bool":0,
a8:{"^":"aH;"},
"+double":0,
X:{"^":"b;aQ:a<",
W:function(a,b){return new P.X(C.c.W(this.a,b.gaQ()))},
R:function(a,b){return new P.X(this.a-b.gaQ())},
aK:function(a,b){return new P.X(C.e.b5(this.a*b))},
I:function(a,b){return C.c.I(this.a,b.gaQ())},
am:function(a,b){return C.c.am(this.a,b.gaQ())},
A:function(a,b){if(b==null)return!1
if(!(b instanceof P.X))return!1
return this.a===b.a},
gD:function(a){return this.a&0x1FFFFFFF},
j:function(a){var z,y,x,w,v
z=new P.fv()
y=this.a
if(y<0)return"-"+new P.X(0-y).j(0)
x=z.$1(C.c.az(y,6e7)%60)
w=z.$1(C.c.az(y,1e6)%60)
v=new P.fu().$1(y%1e6)
return""+C.c.az(y,36e8)+":"+H.d(x)+":"+H.d(w)+"."+H.d(v)},
m:{
ft:function(a,b,c,d,e,f){return new P.X(864e8*a+36e8*b+6e7*e+1e6*f+1000*d+c)}}},
fu:{"^":"c:6;",
$1:function(a){if(a>=1e5)return""+a
if(a>=1e4)return"0"+a
if(a>=1000)return"00"+a
if(a>=100)return"000"+a
if(a>=10)return"0000"+a
return"00000"+a}},
fv:{"^":"c:6;",
$1:function(a){if(a>=10)return""+a
return"0"+a}},
H:{"^":"b;",
ga1:function(){return H.N(this.$thrownJsError)}},
ca:{"^":"H;",
j:function(a){return"Throw of null."}},
Z:{"^":"H;a,b,c,d",
gbm:function(){return"Invalid argument"+(!this.a?"(s)":"")},
gbl:function(){return""},
j:function(a){var z,y,x,w,v,u
z=this.c
y=z!=null?" ("+z+")":""
z=this.d
x=z==null?"":": "+H.d(z)
w=this.gbm()+y+x
if(!this.a)return w
v=this.gbl()
u=P.d5(this.b)
return w+v+": "+H.d(u)},
m:{
ak:function(a){return new P.Z(!1,null,null,a)},
aM:function(a,b,c){return new P.Z(!0,a,b,c)},
b0:function(a){return new P.Z(!1,null,a,"Must not be null")}}},
bv:{"^":"Z;e,f,a,b,c,d",
gbm:function(){return"RangeError"},
gbl:function(){var z,y,x
z=this.e
if(z==null){z=this.f
y=z!=null?": Not less than or equal to "+H.d(z):""}else{x=this.f
if(x==null)y=": Not greater than or equal to "+H.d(z)
else{if(typeof x!=="number")return x.am()
if(x>z)y=": Not in range "+H.d(z)+".."+H.d(x)+", inclusive"
else y=x<z?": Valid value range is empty":": Only valid value is "+H.d(z)}}return y},
m:{
bw:function(a,b,c){return new P.bv(null,null,!0,a,b,"Value not in range")},
x:function(a,b,c,d,e){return new P.bv(b,c,!0,a,d,"Invalid value")},
i_:function(a,b,c,d,e){if(a<b||a>c)throw H.a(P.x(a,b,c,d,e))},
a_:function(a,b,c,d,e,f){var z
if(typeof a!=="number")return H.o(a)
if(!(0>a)){if(typeof c!=="number")return H.o(c)
z=a>c}else z=!0
if(z)throw H.a(P.x(a,0,c,"start",f))
if(b!=null){if(typeof b!=="number")return H.o(b)
if(!(a>b)){if(typeof c!=="number")return H.o(c)
z=b>c}else z=!0
if(z)throw H.a(P.x(b,a,c,"end",f))
return b}return c}}},
fT:{"^":"Z;e,h:f>,a,b,c,d",
gbm:function(){return"RangeError"},
gbl:function(){if(J.cD(this.b,0))return": index must not be negative"
var z=this.f
if(z===0)return": no indices are valid"
return": index should be less than "+H.d(z)},
m:{
a3:function(a,b,c,d,e){var z=e!=null?e:J.W(b)
return new P.fT(b,z,!0,a,c,"Index out of range")}}},
m:{"^":"H;a",
j:function(a){return"Unsupported operation: "+this.a}},
bc:{"^":"H;a",
j:function(a){var z=this.a
return z!=null?"UnimplementedError: "+H.d(z):"UnimplementedError"}},
r:{"^":"H;a",
j:function(a){return"Bad state: "+this.a}},
L:{"^":"H;a",
j:function(a){var z=this.a
if(z==null)return"Concurrent modification during iteration."
return"Concurrent modification during iteration: "+H.d(P.d5(z))+"."}},
hI:{"^":"b;",
j:function(a){return"Out of Memory"},
ga1:function(){return},
$isH:1},
dE:{"^":"b;",
j:function(a){return"Stack Overflow"},
ga1:function(){return},
$isH:1},
fq:{"^":"H;a",
j:function(a){var z=this.a
return z==null?"Reading static variable during its initialization":"Reading static variable '"+H.d(z)+"' during its initialization"}},
jm:{"^":"b;a",
j:function(a){var z=this.a
if(z==null)return"Exception"
return"Exception: "+H.d(z)}},
G:{"^":"b;a,b,c",
j:function(a){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l
z=this.a
y=""!==z?"FormatException: "+z:"FormatException"
x=this.c
w=this.b
if(typeof w!=="string")return x!=null?y+(" (at offset "+H.d(x)+")"):y
if(x!=null){if(typeof x!=="number")return x.I()
z=x<0||x>w.length}else z=!1
if(z)x=null
if(x==null){if(w.length>78)w=C.a.k(w,0,75)+"..."
return y+"\n"+w}if(typeof x!=="number")return H.o(x)
v=1
u=0
t=!1
s=0
for(;s<x;++s){r=C.a.C(w,s)
if(r===10){if(u!==s||!t)++v
u=s+1
t=!1}else if(r===13){++v
u=s+1
t=!0}}y=v>1?y+(" (at line "+v+", character "+H.d(x-u+1)+")\n"):y+(" (at character "+H.d(x+1)+")\n")
q=w.length
for(s=x;s<w.length;++s){r=C.a.F(w,s)
if(r===10||r===13){q=s
break}}if(q-u>78)if(x-u<75){p=u+75
o=u
n=""
m="..."}else{if(q-x<75){o=q-75
p=q
m=""}else{o=x-36
p=x+36
m="..."}n="..."}else{p=q
o=u
n=""
m=""}l=C.a.k(w,o,p)
return y+n+l+m+"\n"+C.a.aK(" ",x-o+n.length)+"^\n"}},
fA:{"^":"b;a,cg",
j:function(a){return"Expando:"+H.d(this.a)},
i:function(a,b){var z,y
z=this.cg
if(typeof z!=="string"){if(b==null||typeof b==="boolean"||typeof b==="number"||typeof b==="string")H.q(P.aM(b,"Expandos are not allowed on strings, numbers, booleans or null",null))
return z.get(b)}y=H.cd(b,"expando$values")
return y==null?null:H.cd(y,z)},
p:function(a,b,c){var z,y
z=this.cg
if(typeof z!=="string")z.set(b,c)
else{y=H.cd(b,"expando$values")
if(y==null){y=new P.b()
H.dz(b,"expando$values",y)}H.dz(y,z,c)}}},
j:{"^":"aH;"},
"+int":0,
I:{"^":"b;$ti",
a7:function(a,b){return H.br(this,b,H.z(this,"I",0),null)},
bQ:["dl",function(a,b){return new H.ci(this,b,[H.z(this,"I",0)])}],
u:function(a,b){var z
for(z=this.gB(this);z.l();)b.$1(z.gt())},
a8:function(a,b){return P.av(this,!0,H.z(this,"I",0))},
ak:function(a){return this.a8(a,!0)},
gh:function(a){var z,y
z=this.gB(this)
for(y=0;z.l();)++y
return y},
gw:function(a){return!this.gB(this).l()},
gao:function(a){var z,y
z=this.gB(this)
if(!z.l())throw H.a(H.b4())
y=z.gt()
if(z.l())throw H.a(H.hd())
return y},
G:function(a,b){var z,y,x
if(typeof b!=="number"||Math.floor(b)!==b)throw H.a(P.b0("index"))
if(b<0)H.q(P.x(b,0,null,"index",null))
for(z=this.gB(this),y=0;z.l();){x=z.gt()
if(b===y)return x;++y}throw H.a(P.a3(b,this,"index",null,y))},
j:function(a){return P.hc(this,"(",")")}},
bo:{"^":"b;"},
i:{"^":"b;$ti",$asi:null,$ise:1,$ase:null},
"+List":0,
bt:{"^":"b;",
gD:function(a){return P.b.prototype.gD.call(this,this)},
j:function(a){return"null"}},
"+Null":0,
aH:{"^":"b;"},
"+num":0,
b:{"^":";",
A:function(a,b){return this===b},
gD:function(a){return H.ae(this)},
j:function(a){return H.bu(this)},
toString:function(){return this.j(this)}},
aw:{"^":"b;"},
t:{"^":"b;"},
"+String":0,
am:{"^":"b;n<",
gh:function(a){return this.n.length},
gw:function(a){return this.n.length===0},
j:function(a){var z=this.n
return z.charCodeAt(0)==0?z:z},
m:{
dG:function(a,b,c){var z=J.aj(b)
if(!z.l())return a
if(c.length===0){do a+=H.d(z.gt())
while(z.l())}else{a+=H.d(z.gt())
for(;z.l();)a=a+c+H.d(z.gt())}return a}}},
iK:{"^":"c:19;a",
$2:function(a,b){throw H.a(new P.G("Illegal IPv4 address, "+a,this.a,b))}},
iM:{"^":"c:20;a",
$2:function(a,b){throw H.a(new P.G("Illegal IPv6 address, "+a,this.a,b))},
$1:function(a){return this.$2(a,null)}},
iN:{"^":"c:21;a,b",
$2:function(a,b){var z,y
if(b-a>4)this.b.$2("an IPv6 part can only contain a maximum of 4 hex digits",a)
z=H.al(C.a.k(this.a,a,b),16,null)
y=J.bH(z)
if(y.I(z,0)||y.am(z,65535))this.b.$2("each part must be in the range of `0x0..0xFFFF`",a)
return z}},
ec:{"^":"b;bW:a<,b,c,d,bF:e>,f,r,x,y,z,Q,ch",
gcW:function(){return this.b},
gaD:function(a){var z=this.c
if(z==null)return""
if(C.a.M(z,"["))return C.a.k(z,1,z.length-1)
return z},
gbI:function(a){var z=this.d
if(z==null)return P.ed(this.a)
return z},
gcN:function(a){var z=this.f
return z==null?"":z},
gcF:function(){var z=this.r
return z==null?"":z},
gcI:function(){return this.c!=null},
gcK:function(){return this.f!=null},
gcJ:function(){return this.r!=null},
j:function(a){var z=this.y
if(z==null){z=this.ce()
this.y=z}return z},
ce:function(){var z,y,x,w
z=this.a
y=z.length!==0?z+":":""
x=this.c
w=x==null
if(!w||z==="file"){z=y+"//"
y=this.b
if(y.length!==0)z=z+H.d(y)+"@"
if(!w)z+=x
y=this.d
if(y!=null)z=z+":"+H.d(y)}else z=y
z+=H.d(this.e)
y=this.f
if(y!=null)z=z+"?"+y
y=this.r
if(y!=null)z=z+"#"+y
return z.charCodeAt(0)==0?z:z},
A:function(a,b){var z,y,x
if(b==null)return!1
if(this===b)return!0
z=J.k(b)
if(!!z.$iscg){if(this.a===b.gbW())if(this.c!=null===b.gcI()){y=this.b
x=b.gcW()
if(y==null?x==null:y===x){y=this.gaD(this)
x=z.gaD(b)
if(y==null?x==null:y===x)if(J.F(this.gbI(this),z.gbI(b)))if(J.F(this.e,z.gbF(b))){y=this.f
x=y==null
if(!x===b.gcK()){if(x)y=""
if(y===z.gcN(b)){z=this.r
y=z==null
if(!y===b.gcJ()){if(y)z=""
z=z===b.gcF()}else z=!1}else z=!1}else z=!1}else z=!1
else z=!1
else z=!1}else z=!1}else z=!1
else z=!1
return z}return!1},
gD:function(a){var z=this.z
if(z==null){z=this.y
if(z==null){z=this.ce()
this.y=z}z=C.a.gD(z)
this.z=z}return z},
$iscg:1,
m:{
k4:function(a,b,c,d,e,f,g,h,i,j){var z,y,x,w,v,u,t
if(j==null)if(d>b)j=P.kb(a,b,d)
else{if(d===b)P.aU(a,b,"Invalid empty scheme")
j=""}if(e>b){z=d+3
y=z<e?P.kc(a,z,e-1):""
x=P.k7(a,e,f,!1)
if(typeof f!=="number")return f.W()
w=f+1
if(typeof g!=="number")return H.o(g)
v=w<g?P.k9(H.al(C.a.k(a,w,g),null,new P.kP(a,f)),j):null}else{y=""
x=null
v=null}u=P.k8(a,g,h,null,j,x!=null)
if(typeof h!=="number")return h.I()
t=h<i?P.ka(a,h+1,i,null):null
return new P.ec(j,y,x,v,u,t,i<c?P.k6(a,i+1,c):null,null,null,null,null,null)},
ed:function(a){if(a==="http")return 80
if(a==="https")return 443
return 0},
aU:function(a,b,c){throw H.a(new P.G(c,a,b))},
k9:function(a,b){if(a!=null&&J.F(a,P.ed(b)))return
return a},
k7:function(a,b,c,d){var z,y
if(b===c)return""
if(C.a.F(a,b)===91){if(typeof c!=="number")return c.R()
z=c-1
if(C.a.F(a,z)!==93)P.aU(a,b,"Missing end `]` to match `[` in host")
P.dX(a,b+1,z)
return C.a.k(a,b,c).toLowerCase()}if(typeof c!=="number")return H.o(c)
y=b
for(;y<c;++y)if(C.a.F(a,y)===58){P.dX(a,b,c)
return"["+a+"]"}return P.ke(a,b,c)},
ke:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p
if(typeof c!=="number")return H.o(c)
z=b
y=z
x=null
w=!0
for(;z<c;){v=C.a.F(a,z)
if(v===37){u=P.ei(a,z,!0)
t=u==null
if(t&&w){z+=3
continue}if(x==null)x=new P.am("")
s=C.a.k(a,y,z)
r=x.n+=!w?s.toLowerCase():s
if(t){u=C.a.k(a,z,z+3)
q=3}else if(u==="%"){u="%25"
q=1}else q=3
x.n=r+u
z+=q
y=z
w=!0}else{if(v<127){t=v>>>4
if(t>=8)return H.f(C.y,t)
t=(C.y[t]&1<<(v&15))!==0}else t=!1
if(t){if(w&&65<=v&&90>=v){if(x==null)x=new P.am("")
if(y<z){x.n+=C.a.k(a,y,z)
y=z}w=!1}++z}else{if(v<=93){t=v>>>4
if(t>=8)return H.f(C.k,t)
t=(C.k[t]&1<<(v&15))!==0}else t=!1
if(t)P.aU(a,z,"Invalid character")
else{if((v&64512)===55296&&z+1<c){p=C.a.F(a,z+1)
if((p&64512)===56320){v=65536|(v&1023)<<10|p&1023
q=2}else q=1}else q=1
if(x==null)x=new P.am("")
s=C.a.k(a,y,z)
x.n+=!w?s.toLowerCase():s
x.n+=P.ee(v)
z+=q
y=z}}}}if(x==null)return C.a.k(a,b,c)
if(y<c){s=C.a.k(a,y,c)
x.n+=!w?s.toLowerCase():s}t=x.n
return t.charCodeAt(0)==0?t:t},
kb:function(a,b,c){var z,y,x,w
if(b===c)return""
if(!P.eg(C.a.C(a,b)))P.aU(a,b,"Scheme not starting with alphabetic character")
for(z=b,y=!1;z<c;++z){x=C.a.C(a,z)
if(x<128){w=x>>>4
if(w>=8)return H.f(C.m,w)
w=(C.m[w]&1<<(x&15))!==0}else w=!1
if(!w)P.aU(a,z,"Illegal scheme character")
if(65<=x&&x<=90)y=!0}a=C.a.k(a,b,c)
return P.k5(y?a.toLowerCase():a)},
k5:function(a){if(a==="http")return"http"
if(a==="file")return"file"
if(a==="https")return"https"
if(a==="package")return"package"
return a},
kc:function(a,b,c){var z=P.aA(a,b,c,C.a1,!1)
return z==null?C.a.k(a,b,c):z},
k8:function(a,b,c,d,e,f){var z,y,x
z=e==="file"
y=z||f
x=P.aA(a,b,c,C.z,!1)
if(x==null)x=C.a.k(a,b,c)
if(x.length===0){if(z)return"/"}else if(y&&!C.a.M(x,"/"))x="/"+x
return P.kd(x,e,f)},
kd:function(a,b,c){var z=b.length===0
if(z&&!c&&!C.a.M(a,"/"))return P.kf(a,!z||c)
return P.kg(a)},
ka:function(a,b,c,d){var z=P.aA(a,b,c,C.l,!1)
return z==null?C.a.k(a,b,c):z},
k6:function(a,b,c){var z=P.aA(a,b,c,C.l,!1)
return z==null?C.a.k(a,b,c):z},
ei:function(a,b,c){var z,y,x,w,v,u
z=b+2
if(z>=a.length)return"%"
y=C.a.F(a,b+1)
x=C.a.F(a,z)
w=H.bK(y)
v=H.bK(x)
if(w<0||v<0)return"%"
u=w*16+v
if(u<127){z=C.c.ab(u,4)
if(z>=8)return H.f(C.x,z)
z=(C.x[z]&1<<(u&15))!==0}else z=!1
if(z)return H.dA(c&&65<=u&&90>=u?(u|32)>>>0:u)
if(y>=97||x>=97)return C.a.k(a,b,b+3).toUpperCase()
return},
ee:function(a){var z,y,x,w,v,u,t,s
if(a<128){z=new Array(3)
z.fixed$length=Array
z[0]=37
z[1]=C.a.C("0123456789ABCDEF",a>>>4)
z[2]=C.a.C("0123456789ABCDEF",a&15)}else{if(a>2047)if(a>65535){y=240
x=4}else{y=224
x=3}else{y=192
x=2}w=3*x
z=new Array(w)
z.fixed$length=Array
for(v=0;--x,x>=0;y=128){u=C.c.ek(a,6*x)&63|y
if(v>=w)return H.f(z,v)
z[v]=37
t=v+1
s=C.a.C("0123456789ABCDEF",u>>>4)
if(t>=w)return H.f(z,t)
z[t]=s
s=v+2
t=C.a.C("0123456789ABCDEF",u&15)
if(s>=w)return H.f(z,s)
z[s]=t
v+=3}}return P.iq(z,0,null)},
aA:function(a,b,c,d,e){var z,y,x,w,v,u,t,s,r,q
z=!e
y=J.ap(a)
x=b
w=x
v=null
while(!0){if(typeof x!=="number")return x.I()
if(typeof c!=="number")return H.o(c)
if(!(x<c))break
c$0:{u=y.F(a,x)
if(u<127){t=u>>>4
if(t>=8)return H.f(d,t)
t=(d[t]&1<<(u&15))!==0}else t=!1
if(t)++x
else{if(u===37){s=P.ei(a,x,!1)
if(s==null){x+=3
break c$0}if("%"===s){s="%25"
r=1}else r=3}else{if(z)if(u<=93){t=u>>>4
if(t>=8)return H.f(C.k,t)
t=(C.k[t]&1<<(u&15))!==0}else t=!1
else t=!1
if(t){P.aU(a,x,"Invalid character")
s=null
r=null}else{if((u&64512)===55296){t=x+1
if(t<c){q=C.a.F(a,t)
if((q&64512)===56320){u=65536|(u&1023)<<10|q&1023
r=2}else r=1}else r=1}else r=1
s=P.ee(u)}}if(v==null)v=new P.am("")
v.n+=C.a.k(a,w,x)
v.n+=H.d(s)
if(typeof r!=="number")return H.o(r)
x+=r
w=x}}}if(v==null)return
if(typeof w!=="number")return w.I()
if(w<c)v.n+=y.k(a,w,c)
z=v.n
return z.charCodeAt(0)==0?z:z},
eh:function(a){if(C.a.M(a,"."))return!0
return C.a.a6(a,"/.")!==-1},
kg:function(a){var z,y,x,w,v,u,t
if(!P.eh(a))return a
z=[]
for(y=a.split("/"),x=y.length,w=!1,v=0;v<y.length;y.length===x||(0,H.aa)(y),++v){u=y[v]
if(J.F(u,"..")){t=z.length
if(t!==0){if(0>=t)return H.f(z,-1)
z.pop()
if(z.length===0)z.push("")}w=!0}else if("."===u)w=!0
else{z.push(u)
w=!1}}if(w)z.push("")
return C.b.ai(z,"/")},
kf:function(a,b){var z,y,x,w,v,u
if(!P.eh(a))return!b?P.ef(a):a
z=[]
for(y=a.split("/"),x=y.length,w=!1,v=0;v<y.length;y.length===x||(0,H.aa)(y),++v){u=y[v]
if(".."===u)if(z.length!==0&&!J.F(C.b.gb1(z),"..")){if(0>=z.length)return H.f(z,-1)
z.pop()
w=!0}else{z.push("..")
w=!1}else if("."===u)w=!0
else{z.push(u)
w=!1}}y=z.length
if(y!==0)if(y===1){if(0>=y)return H.f(z,0)
y=J.cH(z[0])===!0}else y=!1
else y=!0
if(y)return"./"
if(w||J.F(C.b.gb1(z),".."))z.push("")
if(!b){if(0>=z.length)return H.f(z,0)
y=P.ef(z[0])
if(0>=z.length)return H.f(z,0)
z[0]=y}return C.b.ai(z,"/")},
ef:function(a){var z,y,x,w
z=J.y(a)
y=z.gh(a)
if(typeof y!=="number")return y.bS()
if(y>=2&&P.eg(z.F(a,0))){x=1
while(!0){y=z.gh(a)
if(typeof y!=="number")return H.o(y)
if(!(x<y))break
w=z.F(a,x)
if(w===58)return C.a.k(a,0,x)+"%3A"+C.a.ap(a,x+1)
if(w<=127){y=w>>>4
if(y>=8)return H.f(C.m,y)
y=(C.m[y]&1<<(w&15))===0}else y=!0
if(y)break;++x}}return a},
eg:function(a){var z=a|32
return 97<=z&&z<=122}}},
kP:{"^":"c:1;a,b",
$1:function(a){throw H.a(new P.G("Invalid port",this.a,this.b+1))}},
iI:{"^":"b;a,b,c",
gcU:function(){var z,y,x,w,v,u,t,s
z=this.c
if(z!=null)return z
z=this.b
if(0>=z.length)return H.f(z,0)
y=this.a
z=z[0]+1
x=J.y(y)
w=x.at(y,"?",z)
v=x.gh(y)
if(w>=0){u=w+1
t=P.aA(y,u,v,C.l,!1)
if(t==null)t=x.k(y,u,v)
v=w}else t=null
s=P.aA(y,z,v,C.z,!1)
z=new P.jb(this,"data",null,null,null,s==null?x.k(y,z,v):s,t,null,null,null,null,null,null)
this.c=z
return z},
j:function(a){var z,y
z=this.b
if(0>=z.length)return H.f(z,0)
y=this.a
return z[0]===-1?"data:"+H.d(y):y},
m:{
dW:function(a,b,c){var z,y,x,w,v,u,t,s,r
z=[b-1]
y=J.y(a)
x=b
w=-1
v=null
while(!0){u=y.gh(a)
if(typeof u!=="number")return H.o(u)
if(!(x<u))break
c$0:{v=y.F(a,x)
if(v===44||v===59)break
if(v===47){if(w<0){w=x
break c$0}throw H.a(new P.G("Invalid MIME type",a,x))}}++x}if(w<0&&x>b)throw H.a(new P.G("Invalid MIME type",a,x))
for(;v!==44;){z.push(x);++x
t=-1
while(!0){u=y.gh(a)
if(typeof u!=="number")return H.o(u)
if(!(x<u))break
v=y.F(a,x)
if(v===61){if(t<0)t=x}else if(v===59||v===44)break;++x}if(t>=0)z.push(t)
else{s=C.b.gb1(z)
if(v!==44||x!==s+7||!y.Y(a,"base64",s+1))throw H.a(new P.G("Expecting '='",a,x))
break}}z.push(x)
u=x+1
if((z.length&1)===1)a=C.D.fc(a,u,y.gh(a))
else{r=P.aA(a,u,y.gh(a),C.l,!0)
if(r!=null)a=y.O(a,u,y.gh(a),r)}return new P.iI(a,z,c)}}},
kv:{"^":"c:1;",
$1:function(a){return new Uint8Array(H.el(96))}},
ku:{"^":"c:22;a",
$2:function(a,b){var z=this.a
if(a>=z.length)return H.f(z,a)
z=z[a]
J.eP(z,0,96,b)
return z}},
kw:{"^":"c:7;",
$3:function(a,b,c){var z,y,x
for(z=b.length,y=J.a9(a),x=0;x<z;++x)y.p(a,C.a.C(b,x)^96,c)}},
kx:{"^":"c:7;",
$3:function(a,b,c){var z,y,x
for(z=C.a.C(b,0),y=C.a.C(b,1),x=J.a9(a);z<=y;++z)x.p(a,(z^96)>>>0,c)}},
jW:{"^":"b;a,b,c,d,e,f,r,x,y",
gcI:function(){return this.c>0},
gcK:function(){var z=this.f
if(typeof z!=="number")return z.I()
return z<this.r},
gcJ:function(){return this.r<this.a.length},
gbW:function(){var z,y
z=this.b
if(z<=0)return""
y=this.x
if(y!=null)return y
y=z===4
if(y&&C.a.M(this.a,"http")){this.x="http"
z="http"}else if(z===5&&C.a.M(this.a,"https")){this.x="https"
z="https"}else if(y&&C.a.M(this.a,"file")){this.x="file"
z="file"}else if(z===7&&C.a.M(this.a,"package")){this.x="package"
z="package"}else{z=C.a.k(this.a,0,z)
this.x=z}return z},
gcW:function(){var z,y
z=this.c
y=this.b+3
return z>y?C.a.k(this.a,y,z-1):""},
gaD:function(a){var z=this.c
return z>0?C.a.k(this.a,z,this.d):""},
gbI:function(a){var z,y
if(this.c>0){z=this.d
if(typeof z!=="number")return z.W()
y=this.e
if(typeof y!=="number")return H.o(y)
y=z+1<y
z=y}else z=!1
if(z){z=this.d
if(typeof z!=="number")return z.W()
return H.al(C.a.k(this.a,z+1,this.e),null,null)}z=this.b
if(z===4&&C.a.M(this.a,"http"))return 80
if(z===5&&C.a.M(this.a,"https"))return 443
return 0},
gbF:function(a){return C.a.k(this.a,this.e,this.f)},
gcN:function(a){var z,y
z=this.f
y=this.r
if(typeof z!=="number")return z.I()
return z<y?C.a.k(this.a,z+1,y):""},
gcF:function(){var z,y
z=this.r
y=this.a
return z<y.length?C.a.ap(y,z+1):""},
gD:function(a){var z=this.y
if(z==null){z=C.a.gD(this.a)
this.y=z}return z},
A:function(a,b){var z
if(b==null)return!1
if(this===b)return!0
z=J.k(b)
if(!!z.$iscg)return this.a===z.j(b)
return!1},
j:function(a){return this.a},
$iscg:1},
jb:{"^":"ec;cx,a,b,c,d,e,f,r,x,y,z,Q,ch"}}],["","",,W,{"^":"",
fp:function(a){return a.replace(/^-ms-/,"ms-").replace(/-([\da-z])/ig,function(b,c){return c.toUpperCase()})},
fy:function(a,b,c){var z,y
z=document.body
y=(z&&C.t).S(z,a,b,c)
y.toString
z=new H.ci(new W.T(y),new W.kO(),[W.l])
return z.gao(z)},
aO:function(a){var z,y,x
z="element tag unavailable"
try{y=J.eW(a)
if(typeof y==="string")z=a.tagName}catch(x){H.C(x)}return z},
db:function(a,b,c){return W.fR(a,null,null,b,null,null,null,c).b6(new W.fQ())},
fR:function(a,b,c,d,e,f,g,h){var z,y,x,w
z=W.b2
y=new P.U(0,$.n,null,[z])
x=new P.iR(y,[z])
w=new XMLHttpRequest()
C.M.fd(w,"GET",a,!0)
z=W.mm
W.ag(w,"load",new W.fS(x,w),!1,z)
W.ag(w,"error",x.geD(),!1,z)
w.send()
return y},
bm:function(a,b,c){var z=document.createElement("img")
if(b!=null)z.src=b
return z},
an:function(a,b){a=536870911&a+b
a=536870911&a+((524287&a)<<10)
return a^a>>>6},
e8:function(a){a=536870911&a+((67108863&a)<<3)
a^=a>>>11
return 536870911&a+((16383&a)<<15)},
ks:function(a){var z
if(a==null)return
if("postMessage" in a){z=W.j8(a)
if(!!J.k(z).$isM)return z
return}else return a},
et:function(a){var z=$.n
if(z===C.d)return a
return z.ey(a,!0)},
v:{"^":"A;","%":"HTMLBRElement|HTMLContentElement|HTMLDListElement|HTMLDataListElement|HTMLDetailsElement|HTMLDialogElement|HTMLDirectoryElement|HTMLDivElement|HTMLFontElement|HTMLFrameElement|HTMLHRElement|HTMLHeadElement|HTMLHeadingElement|HTMLHtmlElement|HTMLImageElement|HTMLLabelElement|HTMLLegendElement|HTMLMarqueeElement|HTMLMenuElement|HTMLMenuItemElement|HTMLMeterElement|HTMLModElement|HTMLOListElement|HTMLOptGroupElement|HTMLOptionElement|HTMLPictureElement|HTMLPreElement|HTMLProgressElement|HTMLQuoteElement|HTMLScriptElement|HTMLShadowElement|HTMLSourceElement|HTMLStyleElement|HTMLTableCaptionElement|HTMLTableCellElement|HTMLTableColElement|HTMLTableDataCellElement|HTMLTableHeaderCellElement|HTMLTitleElement|HTMLTrackElement|HTMLUListElement|HTMLUnknownElement;HTMLElement"},
bX:{"^":"v;aj:target=,b0:href}",
j:function(a){return String(a)},
$isbX:1,
$ish:1,
"%":"HTMLAnchorElement"},
ln:{"^":"v;aj:target=,b0:href}",
j:function(a){return String(a)},
$ish:1,
"%":"HTMLAreaElement"},
lo:{"^":"v;b0:href},aj:target=","%":"HTMLBaseElement"},
bZ:{"^":"v;",$isbZ:1,$isM:1,$ish:1,"%":"HTMLBodyElement"},
lp:{"^":"v;J:name=","%":"HTMLButtonElement"},
ff:{"^":"v;",
cZ:function(a,b,c){return a.getContext(b)},
cY:function(a,b){return this.cZ(a,b,null)},
"%":"HTMLCanvasElement"},
lq:{"^":"h;b2:lineWidth%",
ex:function(a){return a.beginPath()},
eA:function(a,b,c,d,e){return a.clearRect(b,c,d,e)},
fC:function(a,b){return a.stroke(b)},
dj:function(a){return a.stroke()},
fa:function(a,b,c){return a.moveTo(b,c)},
da:function(a,b,c,d,e){a.fillStyle="rgba("+b+", "+c+", "+d+", "+e+")"},
d9:function(a,b,c,d){return this.da(a,b,c,d,1)},
dd:function(a,b,c,d,e){a.strokeStyle="rgba("+b+", "+c+", "+d+", "+e+")"},
dc:function(a,b,c,d){return this.dd(a,b,c,d,1)},
ev:function(a,b,c,d,e,f,g){a.arc(b,c,d,e,f,!1)},
cz:function(a,b,c,d,e,f){return this.ev(a,b,c,d,e,f,!1)},
eU:function(a,b){a.fill(b)},
eT:function(a){return this.eU(a,"nonzero")},
"%":"CanvasRenderingContext2D"},
fi:{"^":"l;h:length=",$ish:1,"%":"CDATASection|Comment|Text;CharacterData"},
fo:{"^":"fU;h:length=",
a_:function(a,b,c,d){var z=this.dK(a,b)
a.setProperty(z,c,d)
return},
dK:function(a,b){var z,y
z=$.$get$cX()
y=z[b]
if(typeof y==="string")return y
y=W.fp(b) in a?b:P.fr()+b
z[b]=y
return y},
"%":"CSS2Properties|CSSStyleDeclaration|MSStyleCSSProperties"},
fU:{"^":"h+cW;"},
j3:{"^":"hG;a,b",
a_:function(a,b,c,d){this.b.u(0,new W.j6(b,c,d))},
dB:function(a){var z=P.av(this.a,!0,null)
this.b=new H.b9(z,new W.j5(),[H.E(z,0),null])},
m:{
j4:function(a){var z=new W.j3(a,null)
z.dB(a)
return z}}},
hG:{"^":"b+cW;"},
j5:{"^":"c:1;",
$1:function(a){return J.cI(a)}},
j6:{"^":"c:1;a,b,c",
$1:function(a){return J.cK(a,this.a,this.b,this.c)}},
cW:{"^":"b;"},
lr:{"^":"l;",
gaG:function(a){return new W.bC(a,"click",!1,[W.a5])},
"%":"Document|HTMLDocument|XMLDocument"},
ls:{"^":"l;",
ga5:function(a){if(a._docChildren==null)a._docChildren=new P.d7(a,new W.T(a))
return a._docChildren},
$ish:1,
"%":"DocumentFragment|ShadowRoot"},
lt:{"^":"h;",
j:function(a){return String(a)},
"%":"DOMException"},
fs:{"^":"h;",
j:function(a){return"Rectangle ("+H.d(a.left)+", "+H.d(a.top)+") "+H.d(this.gal(a))+" x "+H.d(this.gah(a))},
A:function(a,b){var z
if(b==null)return!1
z=J.k(b)
if(!z.$isba)return!1
return a.left===z.gbC(b)&&a.top===z.gbO(b)&&this.gal(a)===z.gal(b)&&this.gah(a)===z.gah(b)},
gD:function(a){var z,y,x,w
z=a.left
y=a.top
x=this.gal(a)
w=this.gah(a)
return W.e8(W.an(W.an(W.an(W.an(0,z&0x1FFFFFFF),y&0x1FFFFFFF),x&0x1FFFFFFF),w&0x1FFFFFFF))},
gah:function(a){return a.height},
gbC:function(a){return a.left},
gbO:function(a){return a.top},
gal:function(a){return a.width},
$isba:1,
$asba:I.K,
"%":";DOMRectReadOnly"},
lu:{"^":"h;h:length=","%":"DOMTokenList"},
bA:{"^":"au;bn:a<,b",
gw:function(a){return this.a.firstElementChild==null},
gh:function(a){return this.b.length},
i:function(a,b){var z=this.b
if(b>>>0!==b||b>=z.length)return H.f(z,b)
return z[b]},
p:function(a,b,c){var z=this.b
if(b>>>0!==b||b>=z.length)return H.f(z,b)
this.a.replaceChild(c,z[b])},
sh:function(a,b){throw H.a(new P.m("Cannot resize element lists"))},
q:function(a,b){this.a.appendChild(b)
return b},
gB:function(a){var z=this.ak(this)
return new J.bY(z,z.length,0,null)},
E:function(a,b,c,d,e){throw H.a(new P.bc(null))},
P:function(a,b,c,d){return this.E(a,b,c,d,0)},
O:function(a,b,c,d){throw H.a(new P.bc(null))},
as:function(a,b,c,d){throw H.a(new P.bc(null))},
bz:function(a,b,c){var z,y,x
z=this.b
y=z.length
if(b>y)throw H.a(P.x(b,0,this.gh(this),null,null))
x=this.a
if(b===y)x.appendChild(c)
else{if(b>=y)return H.f(z,b)
x.insertBefore(c,z[b])}},
gN:function(a){var z=this.a.firstElementChild
if(z==null)throw H.a(new P.r("No elements"))
return z},
$asau:function(){return[W.A]},
$asi:function(){return[W.A]},
$ase:function(){return[W.A]}},
cn:{"^":"au;a,$ti",
gh:function(a){return this.a.length},
i:function(a,b){var z=this.a
if(b>>>0!==b||b>=z.length)return H.f(z,b)
return z[b]},
p:function(a,b,c){throw H.a(new P.m("Cannot modify list"))},
sh:function(a,b){throw H.a(new P.m("Cannot modify list"))},
gN:function(a){return C.a2.gN(this.a)},
gbX:function(a){return W.j4(this)},
gaG:function(a){return new W.jh(this,!1,"click",[W.a5])},
$isi:1,
$asi:null,
$ise:1,
$ase:null},
A:{"^":"l;bX:style=,ci:namespaceURI=,fs:tagName=",
gew:function(a){return new W.cl(a)},
ga5:function(a){return new W.bA(a,a.children)},
gcD:function(a){return new W.jg(a)},
geJ:function(a){return new W.e1(new W.cl(a))},
j:function(a){return a.localName},
bA:function(a,b,c,d,e){var z,y
z=this.S(a,c,d,e)
switch(b.toLowerCase()){case"beforebegin":a.parentNode.insertBefore(z,a)
break
case"afterbegin":y=a.childNodes
a.insertBefore(z,y.length>0?y[0]:null)
break
case"beforeend":a.appendChild(z)
break
case"afterend":a.parentNode.insertBefore(z,a.nextSibling)
break
default:H.q(P.ak("Invalid position "+b))}},
S:["bc",function(a,b,c,d){var z,y,x,w,v
if(c==null){if(d==null){z=$.d4
if(z==null){z=H.w([],[W.ds])
y=new W.dt(z)
z.push(W.e6(null))
z.push(W.eb())
$.d4=y
d=y}else d=z}z=$.d3
if(z==null){z=new W.ej(d)
$.d3=z
c=z}else{z.a=d
c=z}}else if(d!=null)throw H.a(P.ak("validator can only be passed if treeSanitizer is null"))
if($.ab==null){z=document
y=z.implementation.createHTMLDocument("")
$.ab=y
$.c2=y.createRange()
y=$.ab
y.toString
x=y.createElement("base")
J.f3(x,z.baseURI)
$.ab.head.appendChild(x)}z=$.ab
if(z.body==null){z.toString
y=z.createElement("body")
z.body=y}z=$.ab
if(!!this.$isbZ)w=z.body
else{y=a.tagName
z.toString
w=z.createElement(y)
$.ab.body.appendChild(w)}if("createContextualFragment" in window.Range.prototype&&!C.b.H(C.a_,a.tagName)){$.c2.selectNodeContents(w)
v=$.c2.createContextualFragment(b)}else{w.innerHTML=b
v=$.ab.createDocumentFragment()
for(;z=w.firstChild,z!=null;)v.appendChild(z)}z=$.ab.body
if(w==null?z!=null:w!==z)J.cJ(w)
c.bV(v)
document.adoptNode(v)
return v},function(a,b,c){return this.S(a,b,c,null)},"eI",null,null,"gfL",2,5,null,0,0],
scM:function(a,b){this.K(a,b)},
au:function(a,b,c,d){a.textContent=null
a.appendChild(this.S(a,b,c,d))},
K:function(a,b){return this.au(a,b,null,null)},
ba:function(a,b,c){return this.au(a,b,null,c)},
gaG:function(a){return new W.e3(a,"click",!1,[W.a5])},
$isA:1,
$isl:1,
$isb:1,
$ish:1,
$isM:1,
"%":";Element"},
kO:{"^":"c:1;",
$1:function(a){return!!J.k(a).$isA}},
lv:{"^":"v;J:name=","%":"HTMLEmbedElement"},
lw:{"^":"a1;af:error=","%":"ErrorEvent"},
a1:{"^":"h;",
gaj:function(a){return W.ks(a.target)},
di:function(a){return a.stopPropagation()},
$isa1:1,
$isb:1,
"%":"AnimationEvent|AnimationPlayerEvent|ApplicationCacheErrorEvent|AudioProcessingEvent|AutocompleteErrorEvent|BeforeInstallPromptEvent|BeforeUnloadEvent|BlobEvent|ClipboardEvent|CloseEvent|CustomEvent|DeviceLightEvent|DeviceMotionEvent|DeviceOrientationEvent|ExtendableEvent|ExtendableMessageEvent|FetchEvent|FontFaceSetLoadEvent|GamepadEvent|GeofencingEvent|HashChangeEvent|IDBVersionChangeEvent|InstallEvent|MIDIConnectionEvent|MIDIMessageEvent|MediaEncryptedEvent|MediaKeyMessageEvent|MediaQueryListEvent|MediaStreamEvent|MediaStreamTrackEvent|MessageEvent|NotificationEvent|OfflineAudioCompletionEvent|PageTransitionEvent|PopStateEvent|PresentationConnectionAvailableEvent|PresentationConnectionCloseEvent|ProgressEvent|PromiseRejectionEvent|PushEvent|RTCDTMFToneChangeEvent|RTCDataChannelEvent|RTCIceCandidateEvent|RTCPeerConnectionIceEvent|RelatedEvent|ResourceProgressEvent|SecurityPolicyViolationEvent|ServicePortConnectEvent|ServiceWorkerMessageEvent|SpeechRecognitionEvent|SpeechSynthesisEvent|StorageEvent|SyncEvent|TrackEvent|TransitionEvent|USBConnectionEvent|WebGLContextEvent|WebKitTransitionEvent;Event|InputEvent"},
M:{"^":"h;",
cu:function(a,b,c,d){if(c!=null)this.dI(a,b,c,!1)},
cO:function(a,b,c,d){if(c!=null)this.e8(a,b,c,!1)},
dI:function(a,b,c,d){return a.addEventListener(b,H.aE(c,1),!1)},
e8:function(a,b,c,d){return a.removeEventListener(b,H.aE(c,1),!1)},
$isM:1,
"%":"MediaStream|MessagePort;EventTarget"},
lN:{"^":"v;J:name=","%":"HTMLFieldSetElement"},
lP:{"^":"v;h:length=,J:name=,aj:target=","%":"HTMLFormElement"},
lR:{"^":"h_;",
gh:function(a){return a.length},
i:function(a,b){if(b>>>0!==b||b>=a.length)throw H.a(P.a3(b,a,null,null,null))
return a[b]},
p:function(a,b,c){throw H.a(new P.m("Cannot assign element of immutable List."))},
sh:function(a,b){throw H.a(new P.m("Cannot resize immutable List."))},
gN:function(a){if(a.length>0)return a[0]
throw H.a(new P.r("No elements"))},
G:function(a,b){if(b>>>0!==b||b>=a.length)return H.f(a,b)
return a[b]},
$isi:1,
$asi:function(){return[W.l]},
$ise:1,
$ase:function(){return[W.l]},
$isQ:1,
$asQ:function(){return[W.l]},
$isJ:1,
$asJ:function(){return[W.l]},
"%":"HTMLCollection|HTMLFormControlsCollection|HTMLOptionsCollection"},
fV:{"^":"h+S;",
$asi:function(){return[W.l]},
$ase:function(){return[W.l]},
$isi:1,
$ise:1},
h_:{"^":"fV+b3;",
$asi:function(){return[W.l]},
$ase:function(){return[W.l]},
$isi:1,
$ise:1},
b2:{"^":"fP;fo:responseText=",
fM:function(a,b,c,d,e,f){return a.open(b,c,!0,f,e)},
fd:function(a,b,c,d){return a.open(b,c,d)},
aL:function(a,b){return a.send(b)},
$isb2:1,
$isb:1,
"%":"XMLHttpRequest"},
fQ:{"^":"c:23;",
$1:function(a){return J.eV(a)}},
fS:{"^":"c:1;a,b",
$1:function(a){var z,y,x,w,v
z=this.b
y=z.status
if(typeof y!=="number")return y.bS()
x=y>=200&&y<300
w=y>307&&y<400
y=x||y===0||y===304||w
v=this.a
if(y)v.eC(0,z)
else v.eE(a)}},
fP:{"^":"M;","%":";XMLHttpRequestEventTarget"},
lS:{"^":"v;J:name=","%":"HTMLIFrameElement"},
lU:{"^":"v;J:name=",$isA:1,$ish:1,$isM:1,"%":"HTMLInputElement"},
lX:{"^":"v;J:name=","%":"HTMLKeygenElement"},
bp:{"^":"v;",$isbp:1,$isA:1,$isl:1,$isb:1,"%":"HTMLLIElement"},
lZ:{"^":"v;b0:href}","%":"HTMLLinkElement"},
m_:{"^":"h;",
j:function(a){return String(a)},
"%":"Location"},
m0:{"^":"v;J:name=","%":"HTMLMapElement"},
m3:{"^":"v;af:error=","%":"HTMLAudioElement|HTMLMediaElement|HTMLVideoElement"},
m4:{"^":"v;J:name=","%":"HTMLMetaElement"},
m5:{"^":"hB;",
fA:function(a,b,c){return a.send(b,c)},
aL:function(a,b){return a.send(b)},
"%":"MIDIOutput"},
hB:{"^":"M;","%":"MIDIInput;MIDIPort"},
a5:{"^":"iG;",$isa5:1,$isa1:1,$isb:1,"%":"DragEvent|MouseEvent|PointerEvent|WheelEvent"},
me:{"^":"h;",$ish:1,"%":"Navigator"},
T:{"^":"au;a",
gN:function(a){var z=this.a.firstChild
if(z==null)throw H.a(new P.r("No elements"))
return z},
gao:function(a){var z,y
z=this.a
y=z.childNodes.length
if(y===0)throw H.a(new P.r("No elements"))
if(y>1)throw H.a(new P.r("More than one element"))
return z.firstChild},
a3:function(a,b){var z,y,x,w
z=b.a
y=this.a
if(z!==y)for(x=z.childNodes.length,w=0;w<x;++w)y.appendChild(z.firstChild)
return},
p:function(a,b,c){var z,y
z=this.a
y=z.childNodes
if(b>>>0!==b||b>=y.length)return H.f(y,b)
z.replaceChild(c,y[b])},
gB:function(a){var z=this.a.childNodes
return new W.d9(z,z.length,-1,null)},
E:function(a,b,c,d,e){throw H.a(new P.m("Cannot setRange on Node list"))},
P:function(a,b,c,d){return this.E(a,b,c,d,0)},
as:function(a,b,c,d){throw H.a(new P.m("Cannot fillRange on Node list"))},
gh:function(a){return this.a.childNodes.length},
sh:function(a,b){throw H.a(new P.m("Cannot set length on immutable List."))},
i:function(a,b){var z=this.a.childNodes
if(b>>>0!==b||b>=z.length)return H.f(z,b)
return z[b]},
$asau:function(){return[W.l]},
$asi:function(){return[W.l]},
$ase:function(){return[W.l]}},
l:{"^":"M;fe:parentNode=,ff:previousSibling=",
gfb:function(a){return new W.T(a)},
fh:function(a){var z=a.parentNode
if(z!=null)z.removeChild(a)},
fn:function(a,b){var z,y
try{z=a.parentNode
J.eM(z,b,a)}catch(y){H.C(y)}return a},
j:function(a){var z=a.nodeValue
return z==null?this.dk(a):z},
eb:function(a,b,c){return a.replaceChild(b,c)},
$isl:1,
$isb:1,
"%":";Node"},
hD:{"^":"h0;",
gh:function(a){return a.length},
i:function(a,b){if(b>>>0!==b||b>=a.length)throw H.a(P.a3(b,a,null,null,null))
return a[b]},
p:function(a,b,c){throw H.a(new P.m("Cannot assign element of immutable List."))},
sh:function(a,b){throw H.a(new P.m("Cannot resize immutable List."))},
gN:function(a){if(a.length>0)return a[0]
throw H.a(new P.r("No elements"))},
G:function(a,b){if(b>>>0!==b||b>=a.length)return H.f(a,b)
return a[b]},
$isi:1,
$asi:function(){return[W.l]},
$ise:1,
$ase:function(){return[W.l]},
$isQ:1,
$asQ:function(){return[W.l]},
$isJ:1,
$asJ:function(){return[W.l]},
"%":"NodeList|RadioNodeList"},
fW:{"^":"h+S;",
$asi:function(){return[W.l]},
$ase:function(){return[W.l]},
$isi:1,
$ise:1},
h0:{"^":"fW+b3;",
$asi:function(){return[W.l]},
$ase:function(){return[W.l]},
$isi:1,
$ise:1},
mg:{"^":"v;J:name=","%":"HTMLObjectElement"},
mh:{"^":"v;J:name=","%":"HTMLOutputElement"},
hU:{"^":"v;","%":"HTMLParagraphElement"},
mj:{"^":"v;J:name=","%":"HTMLParamElement"},
ml:{"^":"fi;aj:target=","%":"ProcessingInstruction"},
mp:{"^":"v;h:length=,J:name=","%":"HTMLSelectElement"},
mq:{"^":"v;J:name=","%":"HTMLSlotElement"},
i9:{"^":"v;","%":"HTMLSpanElement"},
mr:{"^":"a1;af:error=","%":"SpeechRecognitionError"},
it:{"^":"v;",
S:function(a,b,c,d){var z,y
if("createContextualFragment" in window.Range.prototype)return this.bc(a,b,c,d)
z=W.fy("<table>"+H.d(b)+"</table>",c,d)
y=document.createDocumentFragment()
y.toString
new W.T(y).a3(0,J.eS(z))
return y},
"%":"HTMLTableElement"},
mu:{"^":"v;",
S:function(a,b,c,d){var z,y,x,w
if("createContextualFragment" in window.Range.prototype)return this.bc(a,b,c,d)
z=document
y=z.createDocumentFragment()
z=C.C.S(z.createElement("table"),b,c,d)
z.toString
z=new W.T(z)
x=z.gao(z)
x.toString
z=new W.T(x)
w=z.gao(z)
y.toString
w.toString
new W.T(y).a3(0,new W.T(w))
return y},
"%":"HTMLTableRowElement"},
mv:{"^":"v;",
S:function(a,b,c,d){var z,y,x
if("createContextualFragment" in window.Range.prototype)return this.bc(a,b,c,d)
z=document
y=z.createDocumentFragment()
z=C.C.S(z.createElement("table"),b,c,d)
z.toString
z=new W.T(z)
x=z.gao(z)
y.toString
x.toString
new W.T(y).a3(0,new W.T(x))
return y},
"%":"HTMLTableSectionElement"},
dJ:{"^":"v;",
au:function(a,b,c,d){var z
a.textContent=null
z=this.S(a,b,c,d)
a.content.appendChild(z)},
K:function(a,b){return this.au(a,b,null,null)},
ba:function(a,b,c){return this.au(a,b,null,c)},
$isdJ:1,
"%":"HTMLTemplateElement"},
mw:{"^":"v;J:name=","%":"HTMLTextAreaElement"},
iG:{"^":"a1;","%":"CompositionEvent|FocusEvent|KeyboardEvent|SVGZoomEvent|TextEvent|TouchEvent;UIEvent"},
iP:{"^":"M;",
ec:function(a,b){return a.requestAnimationFrame(H.aE(b,1))},
dS:function(a){if(!!(a.requestAnimationFrame&&a.cancelAnimationFrame))return;(function(b){var z=['ms','moz','webkit','o']
for(var y=0;y<z.length&&!b.requestAnimationFrame;++y){b.requestAnimationFrame=b[z[y]+'RequestAnimationFrame']
b.cancelAnimationFrame=b[z[y]+'CancelAnimationFrame']||b[z[y]+'CancelRequestAnimationFrame']}if(b.requestAnimationFrame&&b.cancelAnimationFrame)return
b.requestAnimationFrame=function(c){return window.setTimeout(function(){c(Date.now())},16)}
b.cancelAnimationFrame=function(c){clearTimeout(c)}})(a)},
d0:function(a,b,c,d){a.scrollTo(b,c)
return},
d_:function(a,b,c){return this.d0(a,b,c,null)},
gaG:function(a){return new W.bC(a,"click",!1,[W.a5])},
gan:function(a){return"scrollY" in a?C.e.b5(a.scrollY):C.e.b5(a.document.documentElement.scrollTop)},
$ish:1,
$isM:1,
"%":"DOMWindow|Window"},
mD:{"^":"l;J:name=,ci:namespaceURI=","%":"Attr"},
mE:{"^":"h;ah:height=,bC:left=,bO:top=,al:width=",
j:function(a){return"Rectangle ("+H.d(a.left)+", "+H.d(a.top)+") "+H.d(a.width)+" x "+H.d(a.height)},
A:function(a,b){var z,y,x
if(b==null)return!1
z=J.k(b)
if(!z.$isba)return!1
y=a.left
x=z.gbC(b)
if(y==null?x==null:y===x){y=a.top
x=z.gbO(b)
if(y==null?x==null:y===x){y=a.width
x=z.gal(b)
if(y==null?x==null:y===x){y=a.height
z=z.gah(b)
z=y==null?z==null:y===z}else z=!1}else z=!1}else z=!1
return z},
gD:function(a){var z,y,x,w
z=J.ai(a.left)
y=J.ai(a.top)
x=J.ai(a.width)
w=J.ai(a.height)
return W.e8(W.an(W.an(W.an(W.an(0,z),y),x),w))},
$isba:1,
$asba:I.K,
"%":"ClientRect"},
mF:{"^":"l;",$ish:1,"%":"DocumentType"},
mG:{"^":"fs;",
gah:function(a){return a.height},
gal:function(a){return a.width},
"%":"DOMRect"},
mI:{"^":"v;",$isM:1,$ish:1,"%":"HTMLFrameSetElement"},
mL:{"^":"h1;",
gh:function(a){return a.length},
i:function(a,b){if(b>>>0!==b||b>=a.length)throw H.a(P.a3(b,a,null,null,null))
return a[b]},
p:function(a,b,c){throw H.a(new P.m("Cannot assign element of immutable List."))},
sh:function(a,b){throw H.a(new P.m("Cannot resize immutable List."))},
gN:function(a){if(a.length>0)return a[0]
throw H.a(new P.r("No elements"))},
G:function(a,b){if(b>>>0!==b||b>=a.length)return H.f(a,b)
return a[b]},
$isi:1,
$asi:function(){return[W.l]},
$ise:1,
$ase:function(){return[W.l]},
$isQ:1,
$asQ:function(){return[W.l]},
$isJ:1,
$asJ:function(){return[W.l]},
"%":"MozNamedAttrMap|NamedNodeMap"},
fX:{"^":"h+S;",
$asi:function(){return[W.l]},
$ase:function(){return[W.l]},
$isi:1,
$ise:1},
h1:{"^":"fX+b3;",
$asi:function(){return[W.l]},
$ase:function(){return[W.l]},
$isi:1,
$ise:1},
mP:{"^":"M;",$isM:1,$ish:1,"%":"ServiceWorker"},
iX:{"^":"b;bn:a<",
u:function(a,b){var z,y,x,w,v
for(z=this.gT(),y=z.length,x=this.a,w=0;w<z.length;z.length===y||(0,H.aa)(z),++w){v=z[w]
b.$2(v,x.getAttribute(v))}},
gT:function(){var z,y,x,w,v,u
z=this.a.attributes
y=H.w([],[P.t])
for(x=z.length,w=0;w<x;++w){if(w>=z.length)return H.f(z,w)
v=z[w]
u=J.p(v)
if(u.gci(v)==null)y.push(u.gJ(v))}return y},
gw:function(a){return this.gT().length===0}},
cl:{"^":"iX;a",
v:function(a){return this.a.hasAttribute(a)},
i:function(a,b){return this.a.getAttribute(b)},
p:function(a,b,c){this.a.setAttribute(b,c)},
gh:function(a){return this.gT().length}},
e1:{"^":"b;a",
v:function(a){return this.a.a.hasAttribute("data-"+this.aA(a))},
i:function(a,b){return this.a.a.getAttribute("data-"+this.aA(b))},
p:function(a,b,c){this.a.a.setAttribute("data-"+this.aA(b),c)},
u:function(a,b){this.a.u(0,new W.j9(this,b))},
gT:function(){var z=H.w([],[P.t])
this.a.u(0,new W.ja(this,z))
return z},
gh:function(a){return this.gT().length},
gw:function(a){return this.gT().length===0},
eo:function(a,b){var z,y,x,w,v
z=a.split("-")
for(y=1;y<z.length;++y){x=z[y]
w=J.y(x)
v=w.gh(x)
if(typeof v!=="number")return v.am()
if(v>0){w=J.fa(w.i(x,0))+w.ap(x,1)
if(y>=z.length)return H.f(z,y)
z[y]=w}}return C.b.ai(z,"")},
cq:function(a){return this.eo(a,!1)},
aA:function(a){var z,y,x,w,v
z=J.y(a)
y=0
x=""
while(!0){w=z.gh(a)
if(typeof w!=="number")return H.o(w)
if(!(y<w))break
v=J.cM(z.i(a,y))
x=(!J.F(z.i(a,y),v)&&y>0?x+"-":x)+v;++y}return x.charCodeAt(0)==0?x:x}},
j9:{"^":"c:8;a,b",
$2:function(a,b){if(J.ap(a).M(a,"data-"))this.b.$2(this.a.cq(C.a.ap(a,5)),b)}},
ja:{"^":"c:8;a,b",
$2:function(a,b){if(J.ap(a).M(a,"data-"))this.b.push(this.a.cq(C.a.ap(a,5)))}},
jg:{"^":"cU;bn:a<",
U:function(){var z,y,x,w,v
z=P.Y(null,null,null,P.t)
for(y=this.a.className.split(" "),x=y.length,w=0;w<y.length;y.length===x||(0,H.aa)(y),++w){v=J.cN(y[w])
if(v.length!==0)z.q(0,v)}return z},
bR:function(a){this.a.className=a.ai(0," ")},
gh:function(a){return this.a.classList.length},
gw:function(a){return this.a.classList.length===0},
H:function(a,b){return typeof b==="string"&&this.a.classList.contains(b)},
q:function(a,b){var z,y
z=this.a.classList
y=z.contains(b)
z.add(b)
return!y},
V:function(a,b){var z,y
z=this.a.classList
y=z.contains(b)
z.remove(b)
return y}},
bC:{"^":"a6;a,b,c,$ti",
L:function(a,b,c,d){return W.ag(this.a,this.b,a,!1,H.E(this,0))},
b3:function(a,b,c){return this.L(a,null,b,c)},
bD:function(a){return this.L(a,null,null,null)}},
e3:{"^":"bC;a,b,c,$ti"},
jh:{"^":"a6;a,b,c,$ti",
L:function(a,b,c,d){var z,y,x,w
z=H.E(this,0)
y=this.$ti
x=new W.jZ(null,new H.ac(0,null,null,null,null,null,0,[[P.a6,z],[P.dF,z]]),y)
x.a=new P.cs(null,x.geB(x),0,null,null,null,null,y)
for(z=this.a,z=new H.c6(z,z.gh(z),0,null),w=this.c;z.l();)x.q(0,new W.bC(z.d,w,!1,y))
z=x.a
z.toString
return new P.iY(z,[H.E(z,0)]).L(a,b,c,d)},
b3:function(a,b,c){return this.L(a,null,b,c)},
bD:function(a){return this.L(a,null,null,null)}},
jk:{"^":"dF;a,b,c,d,e,$ti",
a0:function(){if(this.b==null)return
this.ct()
this.b=null
this.d=null
return},
aH:function(a,b){if(this.b==null)return;++this.a
this.ct()},
bG:function(a){return this.aH(a,null)},
bJ:function(){if(this.b==null||this.a<=0)return;--this.a
this.cr()},
cr:function(){var z=this.d
if(z!=null&&this.a<=0)J.eN(this.b,this.c,z,!1)},
ct:function(){var z=this.d
if(z!=null)J.f0(this.b,this.c,z,!1)},
dC:function(a,b,c,d,e){this.cr()},
m:{
ag:function(a,b,c,d,e){var z=c==null?null:W.et(new W.jl(c))
z=new W.jk(0,a,b,z,!1,[e])
z.dC(a,b,c,!1,e)
return z}}},
jl:{"^":"c:1;a",
$1:function(a){return this.a.$1(a)}},
jZ:{"^":"b;a,b,$ti",
q:function(a,b){var z,y
z=this.b
if(z.v(b))return
y=this.a
z.p(0,b,W.ag(b.a,b.b,y.ger(y),!1,H.E(b,0)))},
cE:[function(a){var z,y
for(z=this.b,y=z.gbP(z),y=y.gB(y);y.l();)y.gt().a0()
z.ad(0)
this.a.cE(0)},"$0","geB",0,0,2]},
cp:{"^":"b;cV:a<",
ac:function(a){return $.$get$e7().H(0,W.aO(a))},
a4:function(a,b,c){var z,y,x
z=W.aO(a)
y=$.$get$cq()
x=y.i(0,H.d(z)+"::"+b)
if(x==null)x=y.i(0,"*::"+b)
if(x==null)return!1
return x.$4(a,b,c,this)},
dF:function(a){var z,y
z=$.$get$cq()
if(z.gw(z)){for(y=0;y<262;++y)z.p(0,C.Z[y],W.kV())
for(y=0;y<12;++y)z.p(0,C.q[y],W.kW())}},
m:{
e6:function(a){var z,y
z=document.createElement("a")
y=new W.jS(z,window.location)
y=new W.cp(y)
y.dF(a)
return y},
mJ:[function(a,b,c,d){return!0},"$4","kV",8,0,12],
mK:[function(a,b,c,d){var z,y,x,w,v
z=d.gcV()
y=z.a
y.href=c
x=y.hostname
z=z.b
w=z.hostname
if(x==null?w==null:x===w){w=y.port
v=z.port
if(w==null?v==null:w===v){w=y.protocol
z=z.protocol
z=w==null?z==null:w===z}else z=!1}else z=!1
if(!z)if(x==="")if(y.port===""){z=y.protocol
z=z===":"||z===""}else z=!1
else z=!1
else z=!0
return z},"$4","kW",8,0,12]}},
b3:{"^":"b;$ti",
gB:function(a){return new W.d9(a,this.gh(a),-1,null)},
E:function(a,b,c,d,e){throw H.a(new P.m("Cannot setRange on immutable List."))},
P:function(a,b,c,d){return this.E(a,b,c,d,0)},
O:function(a,b,c,d){throw H.a(new P.m("Cannot modify an immutable List."))},
as:function(a,b,c,d){throw H.a(new P.m("Cannot modify an immutable List."))},
$isi:1,
$asi:null,
$ise:1,
$ase:null},
dt:{"^":"b;a",
ac:function(a){return C.b.cw(this.a,new W.hF(a))},
a4:function(a,b,c){return C.b.cw(this.a,new W.hE(a,b,c))}},
hF:{"^":"c:1;a",
$1:function(a){return a.ac(this.a)}},
hE:{"^":"c:1;a,b,c",
$1:function(a){return a.a4(this.a,this.b,this.c)}},
jT:{"^":"b;cV:d<",
ac:function(a){return this.a.H(0,W.aO(a))},
a4:["ds",function(a,b,c){var z,y
z=W.aO(a)
y=this.c
if(y.H(0,H.d(z)+"::"+b))return this.d.eu(c)
else if(y.H(0,"*::"+b))return this.d.eu(c)
else{y=this.b
if(y.H(0,H.d(z)+"::"+b))return!0
else if(y.H(0,"*::"+b))return!0
else if(y.H(0,H.d(z)+"::*"))return!0
else if(y.H(0,"*::*"))return!0}return!1}],
dG:function(a,b,c,d){var z,y,x
this.a.a3(0,c)
z=b.bQ(0,new W.jU())
y=b.bQ(0,new W.jV())
this.b.a3(0,z)
x=this.c
x.a3(0,C.a0)
x.a3(0,y)}},
jU:{"^":"c:1;",
$1:function(a){return!C.b.H(C.q,a)}},
jV:{"^":"c:1;",
$1:function(a){return C.b.H(C.q,a)}},
k2:{"^":"jT;e,a,b,c,d",
a4:function(a,b,c){if(this.ds(a,b,c))return!0
if(b==="template"&&c==="")return!0
if(J.cG(a).a.getAttribute("template")==="")return this.e.H(0,b)
return!1},
m:{
eb:function(){var z=P.t
z=new W.k2(P.dj(C.p,z),P.Y(null,null,null,z),P.Y(null,null,null,z),P.Y(null,null,null,z),null)
z.dG(null,new H.b9(C.p,new W.k3(),[H.E(C.p,0),null]),["TEMPLATE"],null)
return z}}},
k3:{"^":"c:1;",
$1:function(a){return"TEMPLATE::"+H.d(a)}},
k_:{"^":"b;",
ac:function(a){var z=J.k(a)
if(!!z.$isdC)return!1
z=!!z.$isu
if(z&&W.aO(a)==="foreignObject")return!1
if(z)return!0
return!1},
a4:function(a,b,c){if(b==="is"||C.a.M(b,"on"))return!1
return this.ac(a)}},
d9:{"^":"b;a,b,c,d",
l:function(){var z,y
z=this.c+1
y=this.b
if(z<y){this.d=J.O(this.a,z)
this.c=z
return!0}this.d=null
this.c=y
return!1},
gt:function(){return this.d}},
j7:{"^":"b;a",
cu:function(a,b,c,d){return H.q(new P.m("You can only attach EventListeners to your own window."))},
cO:function(a,b,c,d){return H.q(new P.m("You can only attach EventListeners to your own window."))},
$isM:1,
$ish:1,
m:{
j8:function(a){if(a===window)return a
else return new W.j7(a)}}},
ds:{"^":"b;"},
jS:{"^":"b;a,b"},
ej:{"^":"b;a",
bV:function(a){new W.kh(this).$2(a,null)},
ax:function(a,b){var z
if(b==null){z=a.parentNode
if(z!=null)z.removeChild(a)}else b.removeChild(a)},
ef:function(a,b){var z,y,x,w,v,u,t,s
z=!0
y=null
x=null
try{y=J.cG(a)
x=y.gbn().getAttribute("is")
w=function(c){if(!(c.attributes instanceof NamedNodeMap))return true
var r=c.childNodes
if(c.lastChild&&c.lastChild!==r[r.length-1])return true
if(c.children)if(!(c.children instanceof HTMLCollection||c.children instanceof NodeList))return true
var q=0
if(c.children)q=c.children.length
for(var p=0;p<q;p++){var o=c.children[p]
if(o.id=='attributes'||o.name=='attributes'||o.id=='lastChild'||o.name=='lastChild'||o.id=='children'||o.name=='children')return true}return false}(a)
z=w===!0?!0:!(a.attributes instanceof NamedNodeMap)}catch(t){H.C(t)}v="element unprintable"
try{v=J.P(a)}catch(t){H.C(t)}try{u=W.aO(a)
this.ee(a,b,z,v,u,y,x)}catch(t){if(H.C(t) instanceof P.Z)throw t
else{this.ax(a,b)
window
s="Removing corrupted element "+H.d(v)
if(typeof console!="undefined")console.warn(s)}}},
ee:function(a,b,c,d,e,f,g){var z,y,x,w,v
if(c){this.ax(a,b)
window
z="Removing element due to corrupted attributes on <"+d+">"
if(typeof console!="undefined")console.warn(z)
return}if(!this.a.ac(a)){this.ax(a,b)
window
z="Removing disallowed element <"+H.d(e)+"> from "+J.P(b)
if(typeof console!="undefined")console.warn(z)
return}if(g!=null)if(!this.a.a4(a,"is",g)){this.ax(a,b)
window
z="Removing disallowed type extension <"+H.d(e)+' is="'+g+'">'
if(typeof console!="undefined")console.warn(z)
return}z=f.gT()
y=H.w(z.slice(0),[H.E(z,0)])
for(x=f.gT().length-1,z=f.a;x>=0;--x){if(x>=y.length)return H.f(y,x)
w=y[x]
if(!this.a.a4(a,J.cM(w),z.getAttribute(w))){window
v="Removing disallowed attribute <"+H.d(e)+" "+w+'="'+H.d(z.getAttribute(w))+'">'
if(typeof console!="undefined")console.warn(v)
z.getAttribute(w)
z.removeAttribute(w)}}if(!!J.k(a).$isdJ)this.bV(a.content)}},
kh:{"^":"c:24;a",
$2:function(a,b){var z,y,x,w,v
x=this.a
switch(a.nodeType){case 1:x.ef(a,b)
break
case 8:case 11:case 3:case 4:break
default:x.ax(a,b)}z=a.lastChild
for(x=a==null;null!=z;){y=null
try{y=J.eU(z)}catch(w){H.C(w)
v=z
if(x){if(J.eT(v)!=null)v.parentNode.removeChild(v)}else a.removeChild(v)
z=null
y=a.lastChild}if(z!=null)this.$2(z,a)
z=y}}}}],["","",,P,{"^":"",
d2:function(){var z=$.d1
if(z==null){z=J.bS(window.navigator.userAgent,"Opera",0)
$.d1=z}return z},
fr:function(){var z,y
z=$.cZ
if(z!=null)return z
y=$.d_
if(y==null){y=J.bS(window.navigator.userAgent,"Firefox",0)
$.d_=y}if(y)z="-moz-"
else{y=$.d0
if(y==null){y=P.d2()!==!0&&J.bS(window.navigator.userAgent,"Trident/",0)
$.d0=y}if(y)z="-ms-"
else z=P.d2()===!0?"-o-":"-webkit-"}$.cZ=z
return z},
cU:{"^":"b;",
bw:function(a){if($.$get$cV().b.test(a))return a
throw H.a(P.aM(a,"value","Not a valid class token"))},
j:function(a){return this.U().ai(0," ")},
gB:function(a){var z,y
z=this.U()
y=new P.aS(z,z.r,null,null)
y.c=z.e
return y},
u:function(a,b){this.U().u(0,b)},
a7:function(a,b){var z=this.U()
return new H.c1(z,b,[H.E(z,0),null])},
gw:function(a){return this.U().a===0},
gh:function(a){return this.U().a},
H:function(a,b){if(typeof b!=="string")return!1
this.bw(b)
return this.U().H(0,b)},
bE:function(a){return this.H(0,a)?a:null},
q:function(a,b){this.bw(b)
return this.f9(new P.fn(b))},
V:function(a,b){var z,y
this.bw(b)
z=this.U()
y=z.V(0,b)
this.bR(z)
return y},
G:function(a,b){return this.U().G(0,b)},
f9:function(a){var z,y
z=this.U()
y=a.$1(z)
this.bR(z)
return y},
$ise:1,
$ase:function(){return[P.t]}},
fn:{"^":"c:1;a",
$1:function(a){return a.q(0,this.a)}},
d7:{"^":"au;a,b",
gaa:function(){var z,y
z=this.b
y=H.z(z,"S",0)
return new H.bq(new H.ci(z,new P.fB(),[y]),new P.fC(),[y,null])},
u:function(a,b){C.b.u(P.av(this.gaa(),!1,W.A),b)},
p:function(a,b,c){var z=this.gaa()
J.f2(z.b.$1(J.b_(z.a,b)),c)},
sh:function(a,b){var z=J.W(this.gaa().a)
if(b>=z)return
else if(b<0)throw H.a(P.ak("Invalid list length"))
this.fk(0,b,z)},
q:function(a,b){this.b.a.appendChild(b)},
E:function(a,b,c,d,e){throw H.a(new P.m("Cannot setRange on filtered list"))},
P:function(a,b,c,d){return this.E(a,b,c,d,0)},
as:function(a,b,c,d){throw H.a(new P.m("Cannot fillRange on filtered list"))},
O:function(a,b,c,d){throw H.a(new P.m("Cannot replaceRange on filtered list"))},
fk:function(a,b,c){var z=this.gaa()
z=H.i7(z,b,H.z(z,"I",0))
C.b.u(P.av(H.iu(z,c-b,H.z(z,"I",0)),!0,null),new P.fD())},
gh:function(a){return J.W(this.gaa().a)},
i:function(a,b){var z=this.gaa()
return z.b.$1(J.b_(z.a,b))},
gB:function(a){var z=P.av(this.gaa(),!1,W.A)
return new J.bY(z,z.length,0,null)},
$asau:function(){return[W.A]},
$asi:function(){return[W.A]},
$ase:function(){return[W.A]}},
fB:{"^":"c:1;",
$1:function(a){return!!J.k(a).$isA}},
fC:{"^":"c:1;",
$1:function(a){return H.bL(a,"$isA")}},
fD:{"^":"c:1;",
$1:function(a){return J.cJ(a)}}}],["","",,P,{"^":""}],["","",,P,{"^":"",ll:{"^":"b1;aj:target=",$ish:1,"%":"SVGAElement"},lm:{"^":"u;",$ish:1,"%":"SVGAnimateElement|SVGAnimateMotionElement|SVGAnimateTransformElement|SVGAnimationElement|SVGSetElement"},lx:{"^":"u;",$ish:1,"%":"SVGFEBlendElement"},ly:{"^":"u;",$ish:1,"%":"SVGFEColorMatrixElement"},lz:{"^":"u;",$ish:1,"%":"SVGFEComponentTransferElement"},lA:{"^":"u;",$ish:1,"%":"SVGFECompositeElement"},lB:{"^":"u;",$ish:1,"%":"SVGFEConvolveMatrixElement"},lC:{"^":"u;",$ish:1,"%":"SVGFEDiffuseLightingElement"},lD:{"^":"u;",$ish:1,"%":"SVGFEDisplacementMapElement"},lE:{"^":"u;",$ish:1,"%":"SVGFEFloodElement"},lF:{"^":"u;",$ish:1,"%":"SVGFEGaussianBlurElement"},lG:{"^":"u;",$ish:1,"%":"SVGFEImageElement"},lH:{"^":"u;",$ish:1,"%":"SVGFEMergeElement"},lI:{"^":"u;",$ish:1,"%":"SVGFEMorphologyElement"},lJ:{"^":"u;",$ish:1,"%":"SVGFEOffsetElement"},lK:{"^":"u;",$ish:1,"%":"SVGFESpecularLightingElement"},lL:{"^":"u;",$ish:1,"%":"SVGFETileElement"},lM:{"^":"u;",$ish:1,"%":"SVGFETurbulenceElement"},lO:{"^":"u;",$ish:1,"%":"SVGFilterElement"},b1:{"^":"u;",$ish:1,"%":"SVGCircleElement|SVGClipPathElement|SVGDefsElement|SVGEllipseElement|SVGForeignObjectElement|SVGGElement|SVGGeometryElement|SVGLineElement|SVGPathElement|SVGPolygonElement|SVGPolylineElement|SVGRectElement|SVGSwitchElement;SVGGraphicsElement"},lT:{"^":"b1;",$ish:1,"%":"SVGImageElement"},aP:{"^":"h;",$isb:1,"%":"SVGLength"},lY:{"^":"h2;",
gh:function(a){return a.length},
i:function(a,b){if(b>>>0!==b||b>=a.length)throw H.a(P.a3(b,a,null,null,null))
return a.getItem(b)},
p:function(a,b,c){throw H.a(new P.m("Cannot assign element of immutable List."))},
sh:function(a,b){throw H.a(new P.m("Cannot resize immutable List."))},
gN:function(a){if(a.length>0)return a[0]
throw H.a(new P.r("No elements"))},
G:function(a,b){return this.i(a,b)},
$isi:1,
$asi:function(){return[P.aP]},
$ise:1,
$ase:function(){return[P.aP]},
"%":"SVGLengthList"},fY:{"^":"h+S;",
$asi:function(){return[P.aP]},
$ase:function(){return[P.aP]},
$isi:1,
$ise:1},h2:{"^":"fY+b3;",
$asi:function(){return[P.aP]},
$ase:function(){return[P.aP]},
$isi:1,
$ise:1},m1:{"^":"u;",$ish:1,"%":"SVGMarkerElement"},m2:{"^":"u;",$ish:1,"%":"SVGMaskElement"},aR:{"^":"h;",$isb:1,"%":"SVGNumber"},mf:{"^":"h3;",
gh:function(a){return a.length},
i:function(a,b){if(b>>>0!==b||b>=a.length)throw H.a(P.a3(b,a,null,null,null))
return a.getItem(b)},
p:function(a,b,c){throw H.a(new P.m("Cannot assign element of immutable List."))},
sh:function(a,b){throw H.a(new P.m("Cannot resize immutable List."))},
gN:function(a){if(a.length>0)return a[0]
throw H.a(new P.r("No elements"))},
G:function(a,b){return this.i(a,b)},
$isi:1,
$asi:function(){return[P.aR]},
$ise:1,
$ase:function(){return[P.aR]},
"%":"SVGNumberList"},fZ:{"^":"h+S;",
$asi:function(){return[P.aR]},
$ase:function(){return[P.aR]},
$isi:1,
$ise:1},h3:{"^":"fZ+b3;",
$asi:function(){return[P.aR]},
$ase:function(){return[P.aR]},
$isi:1,
$ise:1},mk:{"^":"u;",$ish:1,"%":"SVGPatternElement"},dC:{"^":"u;",$isdC:1,$ish:1,"%":"SVGScriptElement"},fb:{"^":"cU;a",
U:function(){var z,y,x,w,v,u
z=this.a.getAttribute("class")
y=P.Y(null,null,null,P.t)
if(z==null)return y
for(x=z.split(" "),w=x.length,v=0;v<x.length;x.length===w||(0,H.aa)(x),++v){u=J.cN(x[v])
if(u.length!==0)y.q(0,u)}return y},
bR:function(a){this.a.setAttribute("class",a.ai(0," "))}},u:{"^":"A;",
gcD:function(a){return new P.fb(a)},
ga5:function(a){return new P.d7(a,new W.T(a))},
scM:function(a,b){this.K(a,b)},
S:function(a,b,c,d){var z,y,x,w,v,u
if(d==null){z=H.w([],[W.ds])
d=new W.dt(z)
z.push(W.e6(null))
z.push(W.eb())
z.push(new W.k_())}c=new W.ej(d)
y='<svg version="1.1">'+H.d(b)+"</svg>"
z=document
x=z.body
w=(x&&C.t).eI(x,y,c)
v=z.createDocumentFragment()
w.toString
z=new W.T(w)
u=z.gao(z)
for(;z=u.firstChild,z!=null;)v.appendChild(z)
return v},
gaG:function(a){return new W.e3(a,"click",!1,[W.a5])},
$isu:1,
$isM:1,
$ish:1,
"%":"SVGComponentTransferFunctionElement|SVGDescElement|SVGDiscardElement|SVGFEDistantLightElement|SVGFEFuncAElement|SVGFEFuncBElement|SVGFEFuncGElement|SVGFEFuncRElement|SVGFEMergeNodeElement|SVGFEPointLightElement|SVGFESpotLightElement|SVGMetadataElement|SVGStopElement|SVGStyleElement|SVGTitleElement;SVGElement"},ms:{"^":"b1;",$ish:1,"%":"SVGSVGElement"},mt:{"^":"u;",$ish:1,"%":"SVGSymbolElement"},iw:{"^":"b1;","%":"SVGTSpanElement|SVGTextElement|SVGTextPositioningElement;SVGTextContentElement"},mx:{"^":"iw;",$ish:1,"%":"SVGTextPathElement"},my:{"^":"b1;",$ish:1,"%":"SVGUseElement"},mz:{"^":"u;",$ish:1,"%":"SVGViewElement"},mH:{"^":"u;",$ish:1,"%":"SVGGradientElement|SVGLinearGradientElement|SVGRadialGradientElement"},mM:{"^":"u;",$ish:1,"%":"SVGCursorElement"},mN:{"^":"u;",$ish:1,"%":"SVGFEDropShadowElement"},mO:{"^":"u;",$ish:1,"%":"SVGMPathElement"}}],["","",,P,{"^":"",bb:{"^":"b;",$isi:1,
$asi:function(){return[P.j]},
$ise:1,
$ase:function(){return[P.j]}}}],["","",,P,{"^":""}],["","",,P,{"^":"",mn:{"^":"h;",
f7:[function(a,b){return a.lineWidth(b)},"$1","gb2",2,0,9],
"%":"WebGLRenderingContext"},mo:{"^":"h;",
f7:[function(a,b){return a.lineWidth(b)},"$1","gb2",2,0,9],
$ish:1,
"%":"WebGL2RenderingContext"}}],["","",,P,{"^":""}],["","",,G,{"^":"",kH:{"^":"b;"}}],["","",,F,{"^":"",ib:{"^":"kH;a,b,c,d,e,f,r,x,y,z,Q,ch,cx,cy,db,dx,dy,fr,fx",
ea:[function(a){var z,y,x,w,v
if(a!=null){if(this.b){this.Q=a
this.b=!1}z=J.eL(J.bQ(a,this.Q),this.r)
if(typeof z!=="number")return H.o(z)
this.x=-1.5707963267948966+z
z=this.f
y=this.c
J.cF(z,0,0,y,y)
J.bV(this.f,0,173,217)
J.cL(this.f,0,203,247)
J.bR(this.f)
y=this.f
z=this.y
x=this.z
if(typeof z!=="number")return z.R()
if(typeof x!=="number")return H.o(x)
J.cE(y,z,z,z-x,0,6.283185307179586)
J.bT(this.f)
J.bW(this.f)
J.bR(this.f)
x=this.f
z=this.y
J.f_(x,z,z)
J.bV(this.f,255,255,255)
z=this.f
x=this.y
y=this.z
if(typeof x!=="number")return x.R()
if(typeof y!=="number")return H.o(y)
w=J.p(z)
v=w.gb2(z)
if(typeof v!=="number")return H.o(v)
w.cz(z,x,x,x-y-0.5*v,-1.5707963267948966,this.x)
J.bT(this.f)
J.bW(this.f)}if(this.x<4.71238898038469&&!this.a){z=window
C.h.dS(z)
C.h.ec(z,W.et(this.ge9()))}else this.fr.$0()},"$1","ge9",2,0,25],
dz:function(a,b,c,d){var z,y,x,w,v,u,t,s,r,q,p,o
z=this.ch
if(z==null)throw H.a(P.b0("container"))
y=this.d
if(y<=0)throw H.a(P.ak("Duration must be > 0 seconds)"))
this.a=!0
this.fr=d
this.e=y/4000
this.b=!0
this.r=6.283185307179586/y
x=window.getComputedStyle(z,"").width
y=H.al(C.a.k(x,0,C.a.a6(x,"px")),null,null)
this.c=y
if(typeof y!=="number")return H.o(y)
this.y=0.5*y
y/=7
this.z=y
w=z.style
w.position="relative"
w=z.style
y=C.O.j(0.5*y)+"px"
w.margin=y
y=document
this.cx=y.createElement("span")
this.cy=y.createElement("span")
this.db=y.createElement("span")
w=y.createElement("span")
this.dx=w
v=this.cx
u=v.style
t=this.cy
s=t.style
r=this.db
q=r.style
p=w.style
p.color="#000"
q.color="#000"
s.color="#000"
u.color="#000"
u=v.style
s=t.style
q=r.style
p=w.style
p.fontSize="14px"
q.fontSize="14px"
s.fontSize="14px"
u.fontSize="14px"
u=v.style
t=t.style
s=r.style
w=w.style
w.position="absolute"
s.position="absolute"
t.position="absolute"
u.position="absolute"
w=v.style
r=r.style
v=this.c
u=this.z
if(typeof u!=="number")return H.o(u)
u=J.P(J.bQ(v,0.5*u))+"px"
r.top=u
w.bottom=u
w=this.cx
v=w.style
u=this.db
t=u.style
t.left="0"
v.left="0"
v=w.style
t=u.style
t.textAlign="center"
v.textAlign="center"
w=w.style
u=u.style
u.width="100%"
w.width="100%"
w=this.cy.style
v=this.dx.style
u=this.c
t=this.z
if(typeof t!=="number")return H.o(t)
t=J.P(J.bQ(u,0.5*t))+"px"
v.right=t
w.left=t
w=this.cy.style
v=this.dx.style
u=this.y
if(typeof u!=="number")return u.R()
u=C.e.j(u-7)+"px"
v.top=u
w.top=u
C.f.K(this.cx,"0'")
C.f.K(this.cy,C.c.j(C.e.bN(this.e))+"'")
C.f.K(this.db,C.c.j(C.e.bN(2*this.e))+"'")
C.f.K(this.dx,C.c.j(C.e.bN(3*this.e))+"'")
w=this.c
o=y.createElement("canvas")
y=w!=null
if(y)o.width=w
if(y)o.height=w
this.dy=o
y=C.H.cY(o,"2d")
this.f=y
J.f4(y,1)
y=J.p(z)
y.ga5(z).q(0,this.dy)
y.ga5(z).q(0,this.cx)
y.ga5(z).q(0,this.cy)
y.ga5(z).q(0,this.db)
y.ga5(z).q(0,this.dx)
this.x=-6.283185307179586
z=this.f
y=this.c
J.cF(z,0,0,y,y)
J.bV(this.f,0,173,217)
J.cL(this.f,0,203,247)
J.bR(this.f)
y=this.f
z=this.y
w=this.z
if(typeof z!=="number")return z.R()
if(typeof w!=="number")return H.o(w)
J.cE(y,z,z,z-w,0,6.283185307179586)
J.bT(this.f)
J.bW(this.f)
this.fx=P.af(c,new F.id(this))},
m:{
ic:function(a,b,c,d){var z=new F.ib(null,null,null,a,null,null,null,null,null,null,null,b,null,null,null,null,null,null,null)
z.dz(a,b,c,d)
return z}}},id:{"^":"c:0;a",
$0:function(){var z=this.a
z.a=!1
z.ea(null)}}}],["","",,T,{"^":"",
mV:[function(){T.fF("flags1.json")},"$0","ez",0,0,2],
fE:{"^":"b;a,b,c,d,e,f,r,x,y,z",
fJ:[function(a){var z,y,x,w,v,u,t,s,r
try{z=C.W.eK(a)
u=P.ch()
y=u.gaD(u)
x=J.eY(y,".")===2?J.f9(y,0,2):"en"
this.b=J.O(z,x)}catch(t){u=H.C(t)
if(u instanceof P.G){w=u
v=H.N(t)
P.aI(w)
P.aI(v)
return}else throw t}if(this.b.v("background")!==!0)throw H.a(new P.r("Loading FlagsGame: Missing required key: background"))
if(this.b.v("triggers")!==!0)throw H.a(new P.r("Loading FlagsGame: Missing required key: triggers"))
if(this.b.v("title")!==!0)throw H.a(new P.r("Loading FlagsGame: Missing required key: title"))
if(this.b.v("description")!==!0)throw H.a(new P.r("Loading FlagsGame: Missing required key: description"))
if(this.b.v("time-description")!==!0)throw H.a(new P.r("Loading FlagsGame: Missing required key: time-description"))
if(this.b.v("result")!==!0)throw H.a(new P.r("Loading FlagsGame: Missing required key: result"))
if(this.b.v("conclusion")!==!0)throw H.a(new P.r("Loading FlagsGame: Missing required key: conclusion"))
if(this.b.v("limit")!==!0)throw H.a(new P.r("Loading FlagsGame: Missing required key: limit"))
this.z=J.O(this.b,"limit")
u=document
s=u.querySelector("#flags-canvas")
this.c=s
s=s.style
r=this.b.v("w")===!0?J.O(this.b,"w"):"300px"
s.toString
s.width=r==null?"":r
s=this.c.style
r=this.b.v("h")===!0?J.O(this.b,"h"):"300px"
s.toString
s.height=r==null?"":r
s=this.c.style
r=C.a.W("url(",J.O(this.b,"background"))+")"
s.backgroundImage=r
this.d=H.w([],[T.by])
J.eQ(J.O(this.b,"triggers"),new T.fG(this))
s=u.querySelector("#flags-title")
this.e=s
J.bU(s,J.O(this.b,"title"))
s=u.querySelector("#flags-conclusion")
this.f=s
J.bU(s,J.O(this.b,"description"))
s=u.createElement("p")
this.r=s
C.A.K(s,J.O(this.b,"time-description"))
s=this.r
s.className="strong"
s.id="time-description"
J.ah(this.e).q(0,this.r)
this.x=F.ic(6e4,u.querySelector("#stopwatch-container"),P.ft(0,0,0,0,0,2),this.gei())
this.y=J.O(this.b,"conclusion")
V.hN("flags")},"$1","ge_",2,0,26],
ej:[function(){var z,y,x,w
z={}
z.a=null
if(this.a===!1){if($.bh>0){y=document
x=y.createElement("li")
z.a=x
x.className="invisible fade"
x.appendChild(y.createElement("hr"))
J.ah(y.querySelector("#answers")).q(0,x)}this.a=!0
y=this.d;(y&&C.b).u(y,new T.fI())}P.af(C.K,new T.fJ(z,this))
w=J.O(this.b,"result")
z=this.r;(z&&C.A).K(z,J.f1(w,"%",C.c.j($.bh)))
P.af(C.J,new T.fK(this))
z=this.x
y=z.fx
if(y!=null)y.a0()
z.a=!0},"$0","gei",0,0,2],
fF:[function(){var z,y
z=$.bh
y=this.z
if(typeof y!=="number")return H.o(y)
if(z>=y&&this.a===!1)this.ej()},"$0","gdT",0,0,2],
dt:function(a){W.db(a,null,null).b6(this.ge_()).cB(new T.fL())
this.a=!1},
m:{
fF:function(a){var z=new T.fE(null,null,null,null,null,null,null,null,null,null)
z.dt(a)
return z}}},
fL:{"^":"c:1;",
$1:function(a){return P.aI(a)}},
fG:{"^":"c:1;a",
$1:function(a){var z,y,x,w,v,u,t,s
z=this.a
y=z.d
x=z.c
w=document
v=w.querySelector("#answers")
u=new T.by(null,null,v,null,null,null,null,null,null,null,null,null)
if(a==null||x==null||v==null)H.q(P.b0(null))
if(a.v("flag")!==!0)H.q(new P.r("Loading FlagsGame: Missing required key: flag"))
if(a.v("description")!==!0)H.q(new P.r("Loading FlagsGame: Missing required key: description"))
if(a.v("w")!==!0)H.q(new P.r("Loading FlagsGame: Missing required key: w"))
if(a.v("h")!==!0)H.q(new P.r("Loading FlagsGame: Missing required key: h"))
if(a.v("x")!==!0)H.q(new P.r("Loading FlagsGame: Missing required key: x"))
if(a.v("y")!==!0)H.q(new P.r("Loading FlagsGame: Missing required key: y"))
v=a.i(0,"flag")
u.ch=v
u.z=z.gdT()
u.a=!1
z=W.bm(null,null,null)
u.f=z
z.src=v
z.className="flag"
z=w.createElement("span")
u.x=z
v=w.createElement("span")
u.y=v
z.className="flag-number"
v.className="answer-number"
if(a.v("btw-flag")===!0){z=W.bm(null,null,null)
u.r=z
z.src=a.i(0,"btw-flag")
z.className="btw-flag"}z=w.createElement("div")
u.b=z
z.className="trigger-zone fade"
v=z.style
t=a.i(0,"w")
v.toString
v.width=t==null?"":t
v=z.style
t=a.i(0,"h")
v.toString
v.height=t==null?"":t
v=z.style
t=a.i(0,"x")
v.toString
v.left=t==null?"":t
v=z.style
t=a.i(0,"y")
v.toString
v.top=t==null?"":t
u.Q=W.ag(z,"click",u.gde(u),!1,W.a5)
J.ah(x).q(0,u.b)
u.b.appendChild(u.x)
u.d=w.createElement("li")
s=w.createElement("span")
C.f.bA(s,"beforeend",a.i(0,"description"),null,null)
u.d.appendChild(s)
u.d.className="invisible fade"
if(u.r!=null){u.e=w.createElement("li")
z=a.v("btw-description")
x=u.e
w=x&&C.Y
if(z===!0)w.bA(x,"beforeend",a.i(0,"btw-description"),null,null)
else w.bA(x,"beforeend",a.i(0,"description"),null,null)
u.e.className="invisible fade"}y.push(u)}},
fI:{"^":"c:10;",
$1:function(a){J.eO(a)}},
fJ:{"^":"c:0;a,b",
$0:function(){var z=this.a.a
if(z!=null){z=z.style;(z&&C.i).a_(z,"opacity","1","")}z=this.b.d;(z&&C.b).u(z,new T.fH())}},
fH:{"^":"c:10;",
$1:function(a){if(a.gf4())a.df(0)}},
fK:{"^":"c:0;a",
$0:function(){var z=this.a
J.bU(z.f,z.y)}},
by:{"^":"b;a,b,c,d,e,f,r,x,y,z,Q,ch",
eS:function(a){var z=this.Q
if(z!=null)z.a0()},
dg:[function(a,b){var z,y,x,w
if(this.a)return!1
z=b==null
y=!z
this.a=y
if(y)$.bh=$.bh+1
if(z&&this.r!=null){this.b.appendChild(this.r)
this.b.appendChild(this.f)
x=W.bm(null,this.ch,null)
x.className="answer-number"
z=this.e
new W.bA(z,z.children).bz(0,0,x)
J.ah(this.c).q(0,this.e)
C.f.K(this.x,C.c.j($.aF))
P.af(C.L,new T.iC(this))}else{y=this.c
if(z){this.b.appendChild(this.f)
z=this.b.style;(z&&C.i).a_(z,"opacity","1","")
x=W.bm(null,this.ch,null)
x.className="answer-number"
z=this.d
new W.bA(z,z.children).bz(0,0,x)
J.ah(y).q(0,this.d)
P.af(C.n,new T.iD(this))
C.f.K(this.x,C.c.j($.aF))
$.aF=$.aF+1}else{z=this.d
new W.bA(z,z.children).bz(0,0,this.y)
this.b.appendChild(this.f)
z=this.b.style;(z&&C.i).a_(z,"opacity","1","")
J.ah(y).q(0,this.d)
P.af(C.n,new T.iE(this))
y=this.x
z=this.y
w=C.c.j($.aF)
C.f.K(z,w)
C.f.K(y,w)
$.aF=$.aF+1}}this.a=!0
this.z.$0()
return!0},function(a){return this.dg(a,null)},"df","$1","$0","gde",0,2,27,0],
gf4:function(){return!this.a}},
iC:{"^":"c:0;a",
$0:function(){var z,y
z=this.a
y=z.b.style;(y&&C.i).a_(y,"opacity","1","")
P.af(C.n,new T.iB(z))}},
iB:{"^":"c:0;a",
$0:function(){var z=this.a.e.style;(z&&C.i).a_(z,"opacity","1","")
return"1"}},
iD:{"^":"c:0;a",
$0:function(){var z=this.a.d.style;(z&&C.i).a_(z,"opacity","1","")
return"1"}},
iE:{"^":"c:0;a",
$0:function(){var z=this.a.d.style;(z&&C.i).a_(z,"opacity","1","")
return"1"}}},1],["","",,A,{"^":"",da:{"^":"b;a,b",
j:function(a){return this.b}},fM:{"^":"b;a,b,c,d,e",
du:function(){this.b=0
this.a=document.querySelector("#header")
this.c=C.o
W.ag(window.document,"scroll",new A.fO(this),!1,W.a1)},
m:{
fN:function(){var z=new A.fM(null,null,null,!1,0)
z.du()
return z}}},fO:{"^":"c:1;a",
$1:function(a){var z,y,x,w,v
z=this.a
y=z.b-C.h.gan(window)
if(y<0){z.e=0
if(z.c===C.o){x=C.h.gan(window)
w=z.a.clientHeight
if(typeof w!=="number")return H.o(w)
w=x>=w
x=w}else x=!1
if(x){J.ar(z.a).q(0,"scrollfollow")
J.ar(z.a).V(0,"scrolltop")
x=z.a
w=x.style
x=x.clientHeight
if(typeof x!=="number")return x.bU()
x=C.c.j(-x)+"px"
w.top=x
z.c=C.j}else{if(z.c===C.j){x=C.h.gan(window)
w=z.a.clientHeight
if(typeof w!=="number")return H.o(w)
w=x>=w
x=w}else x=!1
if(x){x=z.a.style.top
v=J.aq(H.al(C.a.k(x,0,C.a.a6(x,"px")),null,null),y)
x=z.a.clientHeight
if(typeof x!=="number")return x.bU()
if(J.cD(v,-x)){x=z.a.clientHeight
if(typeof x!=="number")return x.bU()
v=-x}x=z.a.style
w=J.P(v)+"px"
x.top=w}}}else if(y>0&&!0){z.e=z.a.getBoundingClientRect().height
if(z.c===C.j&&C.h.gan(window)<=0){J.ar(z.a).q(0,"scrolltop")
J.ar(z.a).V(0,"scrollfollow")
x=z.a.style
x.top="0px"
z.c=C.o}else if(z.c===C.j&&C.h.gan(window)>0){x=z.a.style.top
v=J.aq(H.al(C.a.k(x,0,C.a.a6(x,"px")),null,null),y)
if(J.bP(v,0))v=0
x=z.a.style
w=J.P(v)+"px"
x.top=w}}z.b=C.h.gan(window)}}}],["","",,T,{"^":"",hp:{"^":"b;a,b,c,d",
fK:[function(a){var z,y,x,w
z=H.bL(J.eX(a),"$isA")
z.toString
y=z.getAttribute("data-"+new W.e1(new W.cl(z)).aA("value"))
z=window.location
x="https://"+H.d(y)+".hibis.com"
w=P.ch()
z.href=x+H.d(w.gbF(w))},"$1","geh",2,0,28],
dv:function(a){var z,y,x,w
z=this.a
y=z.querySelector("#selected-language")
this.d=y
J.f5(y,a.bT("lang_"+a.b))
this.b=z.querySelector("#selected-language-options")
y=document
x=new W.cn(y.querySelectorAll(".language-option"),[null])
this.c=x.a8(x,!1)
z=J.bi(z)
W.ag(z.a,z.b,new T.hr(this),!1,H.E(z,0))
W.ag(y,"click",new T.hs(this),!1,W.a5)
for(z=this.c,y=z.length,x=this.geh(),w=0;w<z.length;z.length===y||(0,H.aa)(z),++w)J.bi(z[w]).bD(x)},
m:{
hq:function(a){var z=new T.hp(document.querySelector("#language-selector"),null,null,null)
z.dv(a)
return z}}},hr:{"^":"c:1;a",
$1:function(a){J.f7(a)
J.ar(this.a.b).V(0,"hide")}},hs:{"^":"c:1;a",
$1:function(a){return J.ar(this.a.b).q(0,"hide")}}}],["","",,V,{"^":"",
hN:function(a){var z=document
V.dv(z.querySelector("#header-content"),"inc/header.html",new V.hT(a,z.querySelector("#footer")))},
dv:function(a,b,c){if(a==null)throw H.a(P.b0("container"))
W.db(b,null,null).b6(new V.hJ(a,c)).cB(new V.hK())},
mi:[function(a){var z,y
z=document.querySelector("#hamburger-menu").style
y=z.visibility==="visible"?"hidden":"visible"
z.visibility=y},"$1","lc",2,0,31],
hL:function(){var z,y
z=P.ch()
y=z.gaD(z)
z=$.$get$cb()
z.b=J.y(y).a6(y,".")===2?C.a.k(y,0,2):"en"
T.hq(z)
z=new W.cn(document.querySelectorAll(".lang-exp"),[null])
z.u(z,new V.hM())},
hT:{"^":"c:0;a,b",
$0:function(){var z,y,x
z=this.a
y="#"+z
x=document
y=x.querySelector(y)
if(y!=null)J.ar(x.querySelector("#"+z)).q(0,"active")
H.bL(x.querySelector("#academy"),"$isbX").href="http://fraudacademy.hibis.com"
H.bL(x.querySelector("#academy_small"),"$isbX").href="http://fraudacademy.hibis.com"
z=J.bi(x.querySelector("#hamburger"))
W.ag(z.a,z.b,V.lc(),!1,H.E(z,0))
x=J.ah(x.querySelector("#micro-nav-list"))
x.u(x,new V.hR())
A.fN()
V.dv(this.b,"inc/footer.html",new V.hS())}},
hR:{"^":"c:29;",
$1:function(a){J.bi(J.eR(J.ah(a))).bD(new V.hQ())}},
hQ:{"^":"c:1;",
$1:function(a){var z=document.querySelector("#hamburger-menu").style
z.visibility="hidden"
return"hidden"}},
hS:{"^":"c:0;",
$0:function(){var z,y,x
z=document
y=new W.cn(z.querySelectorAll(".unresolved"),[null])
y.u(y,new V.hO())
V.hL()
if(window.location.hash.length!==0){x=z.querySelector(window.location.hash)
if(x!=null)P.af(C.I,new V.hP(x))}}},
hO:{"^":"c:11;",
$1:function(a){J.cK(J.cI(a),"opacity","1","")}},
hP:{"^":"c:0;a",
$0:function(){return C.h.d_(window,0,C.e.b5(this.a.offsetTop))}},
hJ:{"^":"c:5;a,b",
$1:function(a){var z
J.f6(this.a,a,new V.dK())
z=this.b
if(z!=null)z.$0()}},
hK:{"^":"c:1;",
$1:function(a){P.aI(J.P(a))}},
hM:{"^":"c:11;",
$1:function(a){var z,y,x
z=$.$get$cb()
y=J.p(a)
x=y.geJ(a)
return y.ba(a,z.bT(x.a.a.getAttribute("data-"+x.aA("exp"))),new V.dK())}},
dK:{"^":"b;",
ac:function(a){return!0},
a4:function(a,b,c){return!0}}}],["","",,Z,{"^":"",hV:{"^":"b;a,b",
bT:function(a){var z=this.a
return z.i(0,this.b).v(a)?z.i(0,this.b).i(0,a):a}}}]]
setupProgram(dart,0)
J.k=function(a){if(typeof a=="number"){if(Math.floor(a)==a)return J.dg.prototype
return J.df.prototype}if(typeof a=="string")return J.b7.prototype
if(a==null)return J.hf.prototype
if(typeof a=="boolean")return J.he.prototype
if(a.constructor==Array)return J.b5.prototype
if(typeof a!="object"){if(typeof a=="function")return J.b8.prototype
return a}if(a instanceof P.b)return a
return J.bI(a)}
J.y=function(a){if(typeof a=="string")return J.b7.prototype
if(a==null)return a
if(a.constructor==Array)return J.b5.prototype
if(typeof a!="object"){if(typeof a=="function")return J.b8.prototype
return a}if(a instanceof P.b)return a
return J.bI(a)}
J.a9=function(a){if(a==null)return a
if(a.constructor==Array)return J.b5.prototype
if(typeof a!="object"){if(typeof a=="function")return J.b8.prototype
return a}if(a instanceof P.b)return a
return J.bI(a)}
J.bH=function(a){if(typeof a=="number")return J.b6.prototype
if(a==null)return a
if(!(a instanceof P.b))return J.bd.prototype
return a}
J.eA=function(a){if(typeof a=="number")return J.b6.prototype
if(typeof a=="string")return J.b7.prototype
if(a==null)return a
if(!(a instanceof P.b))return J.bd.prototype
return a}
J.ap=function(a){if(typeof a=="string")return J.b7.prototype
if(a==null)return a
if(!(a instanceof P.b))return J.bd.prototype
return a}
J.p=function(a){if(a==null)return a
if(typeof a!="object"){if(typeof a=="function")return J.b8.prototype
return a}if(a instanceof P.b)return a
return J.bI(a)}
J.aq=function(a,b){if(typeof a=="number"&&typeof b=="number")return a+b
return J.eA(a).W(a,b)}
J.F=function(a,b){if(a==null)return b==null
if(typeof a!="object")return b!=null&&a===b
return J.k(a).A(a,b)}
J.bP=function(a,b){if(typeof a=="number"&&typeof b=="number")return a>b
return J.bH(a).am(a,b)}
J.cD=function(a,b){if(typeof a=="number"&&typeof b=="number")return a<b
return J.bH(a).I(a,b)}
J.eL=function(a,b){if(typeof a=="number"&&typeof b=="number")return a*b
return J.eA(a).aK(a,b)}
J.bQ=function(a,b){if(typeof a=="number"&&typeof b=="number")return a-b
return J.bH(a).R(a,b)}
J.O=function(a,b){if(typeof b==="number")if(a.constructor==Array||typeof a=="string"||H.l8(a,a[init.dispatchPropertyName]))if(b>>>0===b&&b<a.length)return a[b]
return J.y(a).i(a,b)}
J.eM=function(a,b,c){return J.p(a).eb(a,b,c)}
J.eN=function(a,b,c,d){return J.p(a).cu(a,b,c,d)}
J.cE=function(a,b,c,d,e,f){return J.p(a).cz(a,b,c,d,e,f)}
J.bR=function(a){return J.p(a).ex(a)}
J.cF=function(a,b,c,d,e){return J.p(a).eA(a,b,c,d,e)}
J.bS=function(a,b,c){return J.y(a).eG(a,b,c)}
J.eO=function(a){return J.p(a).eS(a)}
J.b_=function(a,b){return J.a9(a).G(a,b)}
J.bT=function(a){return J.p(a).eT(a)}
J.eP=function(a,b,c,d){return J.a9(a).as(a,b,c,d)}
J.eQ=function(a,b){return J.a9(a).u(a,b)}
J.cG=function(a){return J.p(a).gew(a)}
J.ah=function(a){return J.p(a).ga5(a)}
J.ar=function(a){return J.p(a).gcD(a)}
J.aK=function(a){return J.p(a).gaf(a)}
J.eR=function(a){return J.a9(a).gN(a)}
J.ai=function(a){return J.k(a).gD(a)}
J.cH=function(a){return J.y(a).gw(a)}
J.aj=function(a){return J.a9(a).gB(a)}
J.W=function(a){return J.y(a).gh(a)}
J.eS=function(a){return J.p(a).gfb(a)}
J.bi=function(a){return J.p(a).gaG(a)}
J.eT=function(a){return J.p(a).gfe(a)}
J.eU=function(a){return J.p(a).gff(a)}
J.eV=function(a){return J.p(a).gfo(a)}
J.cI=function(a){return J.p(a).gbX(a)}
J.eW=function(a){return J.p(a).gfs(a)}
J.eX=function(a){return J.p(a).gaj(a)}
J.eY=function(a,b){return J.y(a).a6(a,b)}
J.eZ=function(a,b){return J.a9(a).a7(a,b)}
J.f_=function(a,b,c){return J.p(a).fa(a,b,c)}
J.cJ=function(a){return J.a9(a).fh(a)}
J.f0=function(a,b,c,d){return J.p(a).cO(a,b,c,d)}
J.f1=function(a,b,c){return J.ap(a).fl(a,b,c)}
J.f2=function(a,b){return J.p(a).fn(a,b)}
J.aL=function(a,b){return J.p(a).aL(a,b)}
J.f3=function(a,b){return J.p(a).sb0(a,b)}
J.bU=function(a,b){return J.p(a).scM(a,b)}
J.f4=function(a,b){return J.p(a).sb2(a,b)}
J.bV=function(a,b,c,d){return J.p(a).d9(a,b,c,d)}
J.f5=function(a,b){return J.p(a).K(a,b)}
J.f6=function(a,b,c){return J.p(a).ba(a,b,c)}
J.cK=function(a,b,c,d){return J.p(a).a_(a,b,c,d)}
J.cL=function(a,b,c,d){return J.p(a).dc(a,b,c,d)}
J.f7=function(a){return J.p(a).di(a)}
J.bW=function(a){return J.p(a).dj(a)}
J.f8=function(a,b,c){return J.a9(a).bY(a,b,c)}
J.f9=function(a,b,c){return J.ap(a).k(a,b,c)}
J.cM=function(a){return J.ap(a).ft(a)}
J.P=function(a){return J.k(a).j(a)}
J.fa=function(a){return J.ap(a).fu(a)}
J.cN=function(a){return J.ap(a).fv(a)}
I.R=function(a){a.immutable$list=Array
a.fixed$length=Array
return a}
var $=I.p
C.t=W.bZ.prototype
C.H=W.ff.prototype
C.i=W.fo.prototype
C.M=W.b2.prototype
C.N=J.h.prototype
C.b=J.b5.prototype
C.O=J.df.prototype
C.c=J.dg.prototype
C.e=J.b6.prototype
C.a=J.b7.prototype
C.V=J.b8.prototype
C.Y=W.bp.prototype
C.a2=W.hD.prototype
C.A=W.hU.prototype
C.B=J.hW.prototype
C.f=W.i9.prototype
C.C=W.it.prototype
C.r=J.bd.prototype
C.h=W.iP.prototype
C.E=new P.fd(!1)
C.D=new P.fc(C.E)
C.F=new P.hI()
C.G=new P.jd()
C.d=new P.jO()
C.u=new P.X(0)
C.I=new P.X(1e5)
C.J=new P.X(2e6)
C.n=new P.X(3e5)
C.K=new P.X(7e6)
C.L=new P.X(8e6)
C.o=new A.da(0,"HeaderState.top")
C.j=new A.da(1,"HeaderState.follow")
C.P=function() {  var toStringFunction = Object.prototype.toString;  function getTag(o) {    var s = toStringFunction.call(o);    return s.substring(8, s.length - 1);  }  function getUnknownTag(object, tag) {    if (/^HTML[A-Z].*Element$/.test(tag)) {      var name = toStringFunction.call(object);      if (name == "[object Object]") return null;      return "HTMLElement";    }  }  function getUnknownTagGenericBrowser(object, tag) {    if (self.HTMLElement && object instanceof HTMLElement) return "HTMLElement";    return getUnknownTag(object, tag);  }  function prototypeForTag(tag) {    if (typeof window == "undefined") return null;    if (typeof window[tag] == "undefined") return null;    var constructor = window[tag];    if (typeof constructor != "function") return null;    return constructor.prototype;  }  function discriminator(tag) { return null; }  var isBrowser = typeof navigator == "object";  return {    getTag: getTag,    getUnknownTag: isBrowser ? getUnknownTagGenericBrowser : getUnknownTag,    prototypeForTag: prototypeForTag,    discriminator: discriminator };}
C.v=function(hooks) { return hooks; }
C.Q=function(hooks) {  if (typeof dartExperimentalFixupGetTag != "function") return hooks;  hooks.getTag = dartExperimentalFixupGetTag(hooks.getTag);}
C.R=function(hooks) {  var getTag = hooks.getTag;  var prototypeForTag = hooks.prototypeForTag;  function getTagFixed(o) {    var tag = getTag(o);    if (tag == "Document") {      // "Document", so we check for the xmlVersion property, which is the empty      if (!!o.xmlVersion) return "!Document";      return "!HTMLDocument";    }    return tag;  }  function prototypeForTagFixed(tag) {    if (tag == "Document") return null;    return prototypeForTag(tag);  }  hooks.getTag = getTagFixed;  hooks.prototypeForTag = prototypeForTagFixed;}
C.S=function(hooks) {  var userAgent = typeof navigator == "object" ? navigator.userAgent : "";  if (userAgent.indexOf("Firefox") == -1) return hooks;  var getTag = hooks.getTag;  var quickMap = {    "BeforeUnloadEvent": "Event",    "DataTransfer": "Clipboard",    "GeoGeolocation": "Geolocation",    "Location": "!Location",    "WorkerMessageEvent": "MessageEvent",    "XMLDocument": "!Document"};  function getTagFirefox(o) {    var tag = getTag(o);    return quickMap[tag] || tag;  }  hooks.getTag = getTagFirefox;}
C.w=function getTagFallback(o) {  var s = Object.prototype.toString.call(o);  return s.substring(8, s.length - 1);}
C.T=function(hooks) {  var userAgent = typeof navigator == "object" ? navigator.userAgent : "";  if (userAgent.indexOf("Trident/") == -1) return hooks;  var getTag = hooks.getTag;  var quickMap = {    "BeforeUnloadEvent": "Event",    "DataTransfer": "Clipboard",    "HTMLDDElement": "HTMLElement",    "HTMLDTElement": "HTMLElement",    "HTMLPhraseElement": "HTMLElement",    "Position": "Geoposition"  };  function getTagIE(o) {    var tag = getTag(o);    var newTag = quickMap[tag];    if (newTag) return newTag;    if (tag == "Object") {      if (window.DataView && (o instanceof window.DataView)) return "DataView";    }    return tag;  }  function prototypeForTagIE(tag) {    var constructor = window[tag];    if (constructor == null) return null;    return constructor.prototype;  }  hooks.getTag = getTagIE;  hooks.prototypeForTag = prototypeForTagIE;}
C.U=function(getTagFallback) {  return function(hooks) {    if (typeof navigator != "object") return hooks;    var ua = navigator.userAgent;    if (ua.indexOf("DumpRenderTree") >= 0) return hooks;    if (ua.indexOf("Chrome") >= 0) {      function confirm(p) {        return typeof window == "object" && window[p] && window[p].name == p;      }      if (confirm("Window") && confirm("HTMLElement")) return hooks;    }    hooks.getTag = getTagFallback;  };}
C.W=new P.hn(null,null)
C.X=new P.ho(null)
C.k=I.R([0,0,32776,33792,1,10240,0,0])
C.Z=H.w(I.R(["*::class","*::dir","*::draggable","*::hidden","*::id","*::inert","*::itemprop","*::itemref","*::itemscope","*::lang","*::spellcheck","*::title","*::translate","A::accesskey","A::coords","A::hreflang","A::name","A::shape","A::tabindex","A::target","A::type","AREA::accesskey","AREA::alt","AREA::coords","AREA::nohref","AREA::shape","AREA::tabindex","AREA::target","AUDIO::controls","AUDIO::loop","AUDIO::mediagroup","AUDIO::muted","AUDIO::preload","BDO::dir","BODY::alink","BODY::bgcolor","BODY::link","BODY::text","BODY::vlink","BR::clear","BUTTON::accesskey","BUTTON::disabled","BUTTON::name","BUTTON::tabindex","BUTTON::type","BUTTON::value","CANVAS::height","CANVAS::width","CAPTION::align","COL::align","COL::char","COL::charoff","COL::span","COL::valign","COL::width","COLGROUP::align","COLGROUP::char","COLGROUP::charoff","COLGROUP::span","COLGROUP::valign","COLGROUP::width","COMMAND::checked","COMMAND::command","COMMAND::disabled","COMMAND::label","COMMAND::radiogroup","COMMAND::type","DATA::value","DEL::datetime","DETAILS::open","DIR::compact","DIV::align","DL::compact","FIELDSET::disabled","FONT::color","FONT::face","FONT::size","FORM::accept","FORM::autocomplete","FORM::enctype","FORM::method","FORM::name","FORM::novalidate","FORM::target","FRAME::name","H1::align","H2::align","H3::align","H4::align","H5::align","H6::align","HR::align","HR::noshade","HR::size","HR::width","HTML::version","IFRAME::align","IFRAME::frameborder","IFRAME::height","IFRAME::marginheight","IFRAME::marginwidth","IFRAME::width","IMG::align","IMG::alt","IMG::border","IMG::height","IMG::hspace","IMG::ismap","IMG::name","IMG::usemap","IMG::vspace","IMG::width","INPUT::accept","INPUT::accesskey","INPUT::align","INPUT::alt","INPUT::autocomplete","INPUT::autofocus","INPUT::checked","INPUT::disabled","INPUT::inputmode","INPUT::ismap","INPUT::list","INPUT::max","INPUT::maxlength","INPUT::min","INPUT::multiple","INPUT::name","INPUT::placeholder","INPUT::readonly","INPUT::required","INPUT::size","INPUT::step","INPUT::tabindex","INPUT::type","INPUT::usemap","INPUT::value","INS::datetime","KEYGEN::disabled","KEYGEN::keytype","KEYGEN::name","LABEL::accesskey","LABEL::for","LEGEND::accesskey","LEGEND::align","LI::type","LI::value","LINK::sizes","MAP::name","MENU::compact","MENU::label","MENU::type","METER::high","METER::low","METER::max","METER::min","METER::value","OBJECT::typemustmatch","OL::compact","OL::reversed","OL::start","OL::type","OPTGROUP::disabled","OPTGROUP::label","OPTION::disabled","OPTION::label","OPTION::selected","OPTION::value","OUTPUT::for","OUTPUT::name","P::align","PRE::width","PROGRESS::max","PROGRESS::min","PROGRESS::value","SELECT::autocomplete","SELECT::disabled","SELECT::multiple","SELECT::name","SELECT::required","SELECT::size","SELECT::tabindex","SOURCE::type","TABLE::align","TABLE::bgcolor","TABLE::border","TABLE::cellpadding","TABLE::cellspacing","TABLE::frame","TABLE::rules","TABLE::summary","TABLE::width","TBODY::align","TBODY::char","TBODY::charoff","TBODY::valign","TD::abbr","TD::align","TD::axis","TD::bgcolor","TD::char","TD::charoff","TD::colspan","TD::headers","TD::height","TD::nowrap","TD::rowspan","TD::scope","TD::valign","TD::width","TEXTAREA::accesskey","TEXTAREA::autocomplete","TEXTAREA::cols","TEXTAREA::disabled","TEXTAREA::inputmode","TEXTAREA::name","TEXTAREA::placeholder","TEXTAREA::readonly","TEXTAREA::required","TEXTAREA::rows","TEXTAREA::tabindex","TEXTAREA::wrap","TFOOT::align","TFOOT::char","TFOOT::charoff","TFOOT::valign","TH::abbr","TH::align","TH::axis","TH::bgcolor","TH::char","TH::charoff","TH::colspan","TH::headers","TH::height","TH::nowrap","TH::rowspan","TH::scope","TH::valign","TH::width","THEAD::align","THEAD::char","THEAD::charoff","THEAD::valign","TR::align","TR::bgcolor","TR::char","TR::charoff","TR::valign","TRACK::default","TRACK::kind","TRACK::label","TRACK::srclang","UL::compact","UL::type","VIDEO::controls","VIDEO::height","VIDEO::loop","VIDEO::mediagroup","VIDEO::muted","VIDEO::preload","VIDEO::width"]),[P.t])
C.l=I.R([0,0,65490,45055,65535,34815,65534,18431])
C.m=I.R([0,0,26624,1023,65534,2047,65534,2047])
C.a_=I.R(["HEAD","AREA","BASE","BASEFONT","BR","COL","COLGROUP","EMBED","FRAME","FRAMESET","HR","IMAGE","IMG","INPUT","ISINDEX","LINK","META","PARAM","SOURCE","STYLE","TITLE","WBR"])
C.a0=I.R([])
C.a1=I.R([0,0,32722,12287,65534,34815,65534,18431])
C.x=I.R([0,0,24576,1023,65534,34815,65534,18431])
C.y=I.R([0,0,32754,11263,65534,34815,65534,18431])
C.z=I.R([0,0,65490,12287,65535,34815,65534,18431])
C.p=H.w(I.R(["bind","if","ref","repeat","syntax"]),[P.t])
C.q=H.w(I.R(["A::href","AREA::href","BLOCKQUOTE::cite","BODY::background","COMMAND::icon","DEL::cite","FORM::action","IMG::src","INPUT::src","INS::cite","Q::cite","VIDEO::poster"]),[P.t])
$.dx="$cachedFunction"
$.dy="$cachedInvocation"
$.a0=0
$.aN=null
$.cP=null
$.cz=null
$.eu=null
$.eG=null
$.bG=null
$.bM=null
$.cA=null
$.aB=null
$.aV=null
$.aW=null
$.cu=!1
$.n=C.d
$.d6=0
$.ab=null
$.c2=null
$.d4=null
$.d3=null
$.d1=null
$.d0=null
$.d_=null
$.cZ=null
$.aF=1
$.bh=0
$=null
init.isHunkLoaded=function(a){return!!$dart_deferred_initializers$[a]}
init.deferredInitialized=new Object(null)
init.isHunkInitialized=function(a){return init.deferredInitialized[a]}
init.initializeLoadedHunk=function(a){$dart_deferred_initializers$[a]($globals$,$)
init.deferredInitialized[a]=true}
init.deferredLibraryUris={}
init.deferredLibraryHashes={};(function(a){for(var z=0;z<a.length;){var y=a[z++]
var x=a[z++]
var w=a[z++]
I.$lazy(y,x,w)}})(["cY","$get$cY",function(){return H.eB("_$dart_dartClosure")},"c3","$get$c3",function(){return H.eB("_$dart_js")},"dc","$get$dc",function(){return H.ha()},"dd","$get$dd",function(){if(typeof WeakMap=="function")var z=new WeakMap()
else{z=$.d6
$.d6=z+1
z="expando$key$"+z}return new P.fA(null,z)},"dL","$get$dL",function(){return H.a7(H.bz({
toString:function(){return"$receiver$"}}))},"dM","$get$dM",function(){return H.a7(H.bz({$method$:null,
toString:function(){return"$receiver$"}}))},"dN","$get$dN",function(){return H.a7(H.bz(null))},"dO","$get$dO",function(){return H.a7(function(){var $argumentsExpr$='$arguments$'
try{null.$method$($argumentsExpr$)}catch(z){return z.message}}())},"dS","$get$dS",function(){return H.a7(H.bz(void 0))},"dT","$get$dT",function(){return H.a7(function(){var $argumentsExpr$='$arguments$'
try{(void 0).$method$($argumentsExpr$)}catch(z){return z.message}}())},"dQ","$get$dQ",function(){return H.a7(H.dR(null))},"dP","$get$dP",function(){return H.a7(function(){try{null.$method$}catch(z){return z.message}}())},"dV","$get$dV",function(){return H.a7(H.dR(void 0))},"dU","$get$dU",function(){return H.a7(function(){try{(void 0).$method$}catch(z){return z.message}}())},"cj","$get$cj",function(){return P.iS()},"at","$get$at",function(){var z,y
z=P.bt
y=new P.U(0,P.iQ(),null,[z])
y.dE(null,z)
return y},"aX","$get$aX",function(){return[]},"dZ","$get$dZ",function(){return H.hC([-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-1,-2,-2,-2,-2,-2,62,-2,62,-2,63,52,53,54,55,56,57,58,59,60,61,-2,-2,-2,-1,-2,-2,-2,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,-2,-2,-2,-2,63,-2,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,-2,-2,-2,-2,-2])},"er","$get$er",function(){return P.kt()},"cX","$get$cX",function(){return{}},"e7","$get$e7",function(){return P.dj(["A","ABBR","ACRONYM","ADDRESS","AREA","ARTICLE","ASIDE","AUDIO","B","BDI","BDO","BIG","BLOCKQUOTE","BR","BUTTON","CANVAS","CAPTION","CENTER","CITE","CODE","COL","COLGROUP","COMMAND","DATA","DATALIST","DD","DEL","DETAILS","DFN","DIR","DIV","DL","DT","EM","FIELDSET","FIGCAPTION","FIGURE","FONT","FOOTER","FORM","H1","H2","H3","H4","H5","H6","HEADER","HGROUP","HR","I","IFRAME","IMG","INPUT","INS","KBD","LABEL","LEGEND","LI","MAP","MARK","MENU","METER","NAV","NOBR","OL","OPTGROUP","OPTION","OUTPUT","P","PRE","PROGRESS","Q","S","SAMP","SECTION","SELECT","SMALL","SOURCE","SPAN","STRIKE","STRONG","SUB","SUMMARY","SUP","TABLE","TBODY","TD","TEXTAREA","TFOOT","TH","THEAD","TIME","TR","TRACK","TT","U","UL","VAR","VIDEO","WBR"],null)},"cq","$get$cq",function(){return P.di()},"cV","$get$cV",function(){return P.i3("^\\S+$",!0,!1)},"cb","$get$cb",function(){return new Z.hV(P.a4(["en",P.a4(["address_copenhagen","c/o Scillani Information AB<br />Vestergade 16<br />1456 Copenhagen<br />Denmark","address_gothenburg","Hibis AB<br />Kronhusgatan 11<br />411 05 G\xf6teborg<br />Sweden","address_helsinki","Hibis Associates<br />Centry Ltd","address_london","Hibis Europe Ltd","address_malmo","Hibis AB","address_oslo","Hibis AS<br /> Meltzersgt. 4<br/> 0275 Oslo<br/> Norway","address_rome","Hibis Associates","address_stockholm","Hibis AB","contact","Contact","contact_us","Contact us","contact_copenhagen","<strong>John Wallhoff</strong><br /><a href='mailto:john.wallhoff@hibis.com'>john.wallhoff@hibis.com</a><br />+ 45 70 77 43 131","contact_gothenburg","<strong>Carina S\xf6rqvist</strong><br /><a href='mailto:carina.sorqvist@hibis.com'>carina.sorqvist@hibis.com</a><br />+ 46 707 97 97 64","contact_helsinki","<strong>Petri Kelo</strong><br /><a href='mailto:petri.kelo@centry.global'>petri.kelo@centry.global</a><br />+ 358 40 50 001 068","contact_london","<strong>Allan McDonagh</strong><br /><a href='mailto:allan.mcdonagh@hibis.com'>allan.mcdonagh@hibis.com</a><br />+ 44 77 68 32 0161","contact_malmo","<strong>Richard Minogue</strong><br /><a href='mailto:richard.minogue@hibis.com'>richard.minogue@hibis.com</a><br />+ 46 761 882 497","contact_oslo","<strong>Veronica Morino</strong><br /><a href='mailto:veronica.morino@hibis.com'>veronica.morino@hibis.com</a><br />+ 47 91 86 32 19<br/><br/><strong>Nigel Krishna Iyer</strong><br /><a href='mailto:nigel.iyer@hibis.com'>nigel.iyer@hibis.com</a><br />+ 47 90 65 44 10<br/>+ 44 7523 570004 (UK)","contact_rome","<strong>Maurizio Carmignani</strong><br /><a href='mailto:maurizio.carmignani@hibis.com'>maurizio.carmignani@hibis.com</a><br />+ 39 3489501126","contact_stockholm","<strong>Richard Minogue</strong><br /><a href='mailto:richard.minogue@hibis.com'>richard.minogue@hibis.com</a><br />+ 46 761 882 497","copenhagen","Copenhagen","copyright","&copy;2017 Hibis. All rights reserved. Design by SoiaDg. Images by Floral Zu.","frontpage_title","<strong>Fraud and corruption <span class='orange-text'>can</span> be stopped</strong>","gothenburg","Gothenburg","hibis_associates","hibis associates","hibis_people","hibis people","helsinki","Helsinki","lang_en","English (english)","lang_no","Norwegian (norsk)","lang_it","Italian (italian)","language","Language","london","London","malmo","Malm\xf6","oslo","Oslo","our_history","Our history","our_history_text","<p><strong>Hibis</strong> was founded in 1998 by Martin Samociuk. Many of the people who joined at the start came from Network Security Management in London, a company which pioneered fraud investigation and prevention in the 1980\u2019s and 90\u2019s. In 1999, Martin was joined by Nigel Krishna Iyer and one year later by Allan McDonagh. Veronica Morino became part of the group in 2001 followed by Richard Minogue in 2002.The mission of Hibis has always been to put prevention and early detection FIRST. We share with clients the need to dramatically raise awareness of fraud and corruption, give them the ability to spot it early and provide advice and resources for well managed investigations. This includes training workshops, seminars, books, publications and films all with the purpose of stimulating this greater awareness and self-reliance.</p><p>Hibis' founder, Martin Samociuk, passed away in 2013 at the age of 62 from pancreatic cancer. He will be missed by all that knew him but we are grateful for the important work he left behind.</p><p>Today Hibis is an advisory organisation which we hope will help open people\u2019s eyes to the fact that even though fraud and corruption is all around us, it can be kept under control. Our aim is to provide innovative tools and techniques to deal with it, as well as the confidence to spot it early. We aim to support those people who wish to take a stand against fraud and corruption.</p><p>Finally, if you like what you have read, and feel that you are our sort of person, then do take contact with us. We don\u2019t recruit in the traditional manner \u2013 like-minded people usually find us\u2026</p>","profile_allan","Allan\u2019s long experience from 1967 includes UK Customs and Excise Investigations and New Scotland Yard, where he specialized in narcotics and organised crime. Between 1985 and 1997 Allan worked as Deputy Managing Director with Martin Samociuk at Network Security Management Limited, Europe\u2019s leading fraud investigation consultancy. Apart from leading hundreds of investigations and recovery projects throughout the world for both commercial and government clients, he created the highly successful Forensic Laboratories which were eventually acquired by Control Risks Group. Allan has project managed many successful investigations around the world.","profile_carina","Carina S\xf6rqvist has over 15 years of experience of preventing and investigating fraud and corruption. She has acted as the investigator and project leader in investigations for clients in various different industries. Her long experience of structured investigations of real fraud and corruption cases is used in seminars and trainings regarding investigation technique. She has, for several clients, developed action plans for how to handle incidents such as suspected fraud and/or corruption. She has worked as a Senior Consultant since 2003 and before that she worked with compliance as the manager of the Internal Control department in a multinational company. Carina has a financial background and her specialities are forensic accounting and interview techniques.","profile_jan","Jan has performed a number of forensic investigations and fraud detection projects, as well as held courses in red flag detection within fraud and corruption and corporate governance.  He holds an MBA and CPA degree from the Norwegian School of Economics and Business Administration in Bergen. After spending 4 years as an external auditor he was Chief Financial Officer for 9 years in an international construction company with operations in East Africa. After that he worked for over 20 years as advisor (on, among others, business development, sustainability evaluations, performance audit and background checks) for the Norwegian Ministry of Foreign Affairs (NORAD, Embassies and Norfund) and private sector companies operating in East-Africa, The Balkans, Baltic states, Georgia, Sri Lanka, Nepal and the Palestine Territories.","profile_john","John Wallhoff, a computer security and data-analysis expert for many years, develops and implements data models to detect patterns of fraud and corruption. John participates in investigations, leads trainings and supports his colleagues through development of leading edge models to pinpoint patterns of malpractice and unethical business behavior. In addition John has built information security strategies and contingency plans for a number of companies and as a compliment to fraud detection, develops data-analysis solutions for continuous monitoring of internal controls.","profile_martina","Martina has a combined Masters degree in Business and Economics (majoring in finance) from the Norwegian Business School (BI) and the University of Ljubljana (Slovenia). Right from an early age she wanted to play an active part in eradicating systematic inefficiencies. She recognized that corruption and fraud is one of the major obstacles to sustainability and growth and was able to apply her passion at Hibis. Martina specializes in identifying red flags of corruption through internal and external analysis, and understanding and investigating them across a wide range of countries and languages-zones.","profile_fridtjof","Fridtjof Klareng Dale's passion for fighting corruption and fraud started while studying for his bachelor in European Studies at the Norwegian University of Science and Technology (NTNU). Through his strong engagement in volunteerism, he joined the newly founded student organisation Anti-Corruption International (ACI) and helped build the organisation, spearheading projects showing that \u201cyoung people not only can play a part in eradicating a global problem, but can also take the lead.\u201d Through ACI he got to know Hibis, where he is now successfully working as a fraud investigator combining this with his anti-corruption activities.","profile_maurizio","Maurizio has 18 years\u2019 experience in innovation and organisational development in a wide variety of sectors which include telecommunications and technology, banking, retail and consumer products, culture, education and government, in primarily Italy, Switzerland and Brazil. He provides training to achieve fulfilment of goals both at a personal and organisational level. Finding fraud and corruption early, dealing with it responsibly to foster organisational robustness is an important cornerstone of his work today.","profile_nigel","Nigel has over 20 years experience investigating and detecting fraud and corruption. A computer scientist and qualified chartered accountant Nigel soon found that his true passion lay in rooting out corruption and fraud. Nigel is also today a qualified dramatist and has written a number of films and plays based on experiences, many of which are used in teaching worldwide. He has written several books and papers, and teaches widely how to defend organisations against the \u201ccommercial dark arts\u201d. He is also a fellow of the University of Leicester School of Business.","profile_petri","Petri Kelo is Hibis\u2019 associated partner in Finland. His academic background includes a Masters of Security from Helsinki University of Technology. Petri has worked for over 25 years with logistics, service quality and security as well as managing the risk of fraud and corruption. Petri is also one of the founders of Centry Ltd, a security company specialized in logistics & transportation security, cyber security, security risk management and compliance & investigative services. Petri is a well-known speaker and trainer in TAPA (Transportation Asset Protection Association), AEO (Authorized Economic Operator), ISO 28000 (Supply Chain Security Management) and logistics security.","profile_richard","Since his first full time job as internal auditor starting in 1975, Richard has accumulated experience in audit, investigation, financial control, and general management. Inquisitive by nature, he knows there is usually more than one right way to do things, and many wrong ways. Richard\u2019s talent for penetrating complexity and understanding his clients\u2019 business processes makes him a valuable resource for assessment, investigation and improvement projects. Richard graduated BSc in Accountancy, and is qualified CPA and CIA.","profile_veronica","Veronica has over 15 years\u2019 experience investigating, finding and training others on how to prevent and manage fraud and corruption around the world. A sociologist of work and economics with a master in organisational science, she has developed holistic desktop investigative research and analysis tools to explore organisations, business partners, suppliers, customers and key individuals and discover what is really going on at a fraction of the resources normally associated with investigation. Veronica has also worked for several years with the assessment of the effectiveness of organisations\u2019 anti-fraud and corruption programs and is currently completing a PhD degree on that subject.","red_flag_game","The <span class='red-text'>red</span><br />flag Game","rome","Rome","rulebending_final_question","It would assist our research if you could provide us with details of your job functions (anonymously)","rules_game","How far can you bend the rules?","search","Search","send","send","stockholm","Stockholm","the_fraud_academy","The Fraud Academy","what_we_do","What we do","what_we_do_collapsed_text_1",'<p>There is plenty of fraud and corruption around that can be found (preferably in the early stages) and stopped. Usually fraudulent and corrupt activities are cloaked in legitimacy, and finding the truth requires experience, effort and specialist knowledge.</p><p>Our proven structured methodology "B4" (which is short for "Finding fraud before it finds you") has been developed to efficiently find and effectively deal with fraud. B4 includes activities such as:</p><ul><li>Following the money, performing structured analysis, and running B4 algorithms on transactions to find the red flags.</li><li>Convening \u201cthinking like a thief\u201d sessions (an approach invented in the 1980\u2019s by Martin Samociuk, Hibis\u2019 founder) to anticipate how the fraudsters\u2019 mind works and build a profile of the types of frauds that are occurring or likely to occur.</li><li>Finding behavioural red flags by performing holistic desktop investigative research and analysis of organisations, business partners, suppliers, customers and key individuals. All with a special focus on opportunities, motives and how people rationalize dishonest or unethical behaviour.</li><li>Analysing indications of fraud and corruption to understand which issues are the most important, and condensing them into a manageable list for our clients to resolve.</li><li>Working together with our clients to find the most effective course of action to resolve problems. Long experience gives us an overview of different approaches, which ones are appropriate in different situations, and how they should be implemented.</li></li></ul><p>If not detected early, fraud and corruption will spread. Eventually, the problem will be discovered when it becomes too large to ignore, or is reported by whistle-blowers, or both. But why wait for the whistle-blower when you can use fraud detective techniques and uncover where early stage fraud and corruption is developing now? It\u2019s better to stay ahead of the game!</p>',"what_we_do_collapsed_text_2",'<p>We probably will never totally eradicate fraud and corruption. But by raising awareness and managing the risks we can control the cost and make corrupt behaviour less acceptable. Surprisingly, much fraud and corruption involves normal, good people such as valuable and trusted employees or business partners. Awareness is a powerful tool to help good people avoid bad mistakes they will later regret, and to show them how to protect the organisation against career fraudsters. As Nelson Mandela said, education is one of the most powerful ways to change the world. We have developed courses and techniques to bridge the skills gap and constantly look for innovative new ways to raise the awareness, spread knowledge and bring people together in the fight of corruption and fraud. Examples (details can be found in our Fraud Academy page) include:</p><ul><li>Practical open courses and workshops (including our "think like a thief methodology" and "fraud detective school")</li><li>Accredited management courses</li><li>On the job-training, in-house workshops and clinics</li><li>Multimedia based training delivered over the internet (or intranet)</li><li>Experiential learning, including drama, scenarios, live simulations, \u201ccorruption-theatre\u201d and films</li><li>Publications and books</li></ul>',"what_we_do_collapsed_text_3","<p>When it is required by the client, we investigate fraud and corruption constructively and effectively.</p><p>We believe in the beauty of small investigations that win back value. We have a track record of solving our client\u2019s problems efficiently and in a way which both identifies root causes and prevents recurrence.</p><p>Exceptional situations do occur from time to time for which a deep investigation may be required, such as when an organisation needs to prepare legal actions to recover major assets or salvage parts of a business. We manage all investigations in a controlled way avoiding unnecessary expenditure and ensuring that our client is always in the driver\u2019s seat.</p>","what_we_do_collapsed_text_4","<p>The scope and complexity of external regulation, designed to protect the public and punish corporate offenders is increasing. This absorbs management attention and leaves less room for more practical programs designed to protect the organisation. Management can fall into the trap of accepting bureaucratic solutions that appear to fulfil regulatory requirements, but which do not effectively address the issue of fraudulent and corrupt behaviour. Compliance programs based on checklists are unlikely to be effective!</p><p>We are able to measure the impact and effectiveness of your existing anti-fraud and corruption activities, identifying gaps and potential improvements that will bring down the cost of fraud and corruption and strengthen the ethical culture.</p><p>Our holistic framework and assessment tool brings together years of practical experience with a distillation of the most essential knowledge from widely used existing frameworks.</p>","what_we_do_collapsed_title_1","We find early fraud and help you resolve it","what_we_do_collapsed_title_2","We raise awareness, share knowledge and transfer skills","what_we_do_collapsed_title_3","We investigate fraud and corruption responsibly","what_we_do_collapsed_title_4","We assess effectiveness of existing anti-fraud and corruption programs","what_we_do_list_1_item_1","<strong>Finding</strong> and interpreting the many <strong>red flags</strong>","what_we_do_list_1_item_2","<strong>Investigations</strong> carried out in an efficient, responsible manner","what_we_do_list_1_item_3","<strong>Analysing</strong> the root causes of incidents to identify improvement opportunities","what_we_do_list_1_item_4","<strong>Providing</strong> (through practical workshops, training and other innovative devices) the <strong>skills</strong> to turn what looks like \"bad news\" into an opportunity to save money (see <a href='http://fraudacademy.hibis.com' target='_blank'>Hibis Fraud Academy</a>)","what_we_do_list_1_item_5","<strong>Assessing</strong> and <strong>measuring</strong> the <strong>effectiveness</strong>, strengths and weaknesses of existing anti-fraud and corruption programmes","what_we_do_paragraph_1","Fraud and corruption happens all the time and is arguably one of the greatest unmanaged costs in organisations and society today. Yet most management and employees have not had any practical training in this area. Our aim is to significantly raise awareness of fraud and corruption and its consequences. We assist and advise organisations, companies and everyone else concerned by:","who_we_are","Who we are"]),"it",P.a4(["address_copenhagen","c/o Scillani Information AB<br />Vestergade 16<br />1456 Copenhagen<br />Danimarca","address_gothenburg","Hibis AB<br />Kronhusgatan 11<br />411 05 G\xf6teborg<br />Svezia","address_helsinki","Hibis Associates<br />Centry Ltd","address_london","Hibis Europe Ltd","address_malmo","Hibis AB","address_oslo","Hibis AS<br /> Meltzersgt. 4<br/> 0275 Oslo<br/> Norvegia","address_rome","Hibis Associates","address_stockholm","Hibis AB","contact","Contatti","contact_us","Contatti","contact_copenhagen","<strong>John Wallhoff</strong><br /><a href='mailto:john.wallhoff@hibis.com'>john.wallhoff@hibis.com</a><br />+ 45 70 77 43 131","contact_gothenburg","<strong>Carina S\xf6rqvist</strong><br /><a href='mailto:carina.sorqvist@hibis.com'>carina.sorqvist@hibis.com</a><br />+ 46 707 97 97 64","contact_helsinki","<strong>Petri Kelo</strong><br /><a href='mailto:petri.kelo@centry.global'>petri.kelo@centry.global</a><br />+ 358 40 50 001 068","contact_london","<strong>Allan McDonagh</strong><br /><a href='mailto:allan.mcdonagh@hibis.com'>allan.mcdonagh@hibis.com</a><br />+ 44 77 68 32 0161","contact_malmo","<strong>Richard Minogue</strong><br /><a href='mailto:richard.minogue@hibis.com'>richard.minogue@hibis.com</a><br />+ 46 761 882 497","contact_oslo","<strong>Veronica Morino</strong><br /><a href='mailto:veronica.morino@hibis.com'>veronica.morino@hibis.com</a><br />+ 47 91 86 32 19<br/><br/><strong>Nigel Krishna Iyer</strong><br /><a href='mailto:nigel.iyer@hibis.com'>nigel.iyer@hibis.com</a><br />+ 47 90 65 44 10<br/>+ 44 7523 570004 (UK)","contact_rome","<strong>Maurizio Carmignani</strong><br /><a href='mailto:maurizio.carmignani@hibis.com'>maurizio.carmignani@hibis.com</a><br />+ 39 3489501126","contact_stockholm","<strong>Richard Minogue</strong><br /><a href='mailto:richard.minogue@hibis.com'>richard.minogue@hibis.com</a><br />+ 46 761 882 497","copenhagen","Copenhagen","copyright","&copy;2017 Hibis. All rights reserved. Design by SoiaDg. Images by Floral Zu.","frontpage_title","<strong>Fraud and corruption <span class='orange-text'>can</span> be stopped</strong>","gothenburg","Gothenburg","hibis_associates","Hibis associates","hibis_people","Hibis team","helsinki","Helsinki","language","Lingua","lang_en","Inglese (english)","lang_no","Norvegese (norsk)","lang_it","Italiano (italian)","london","Londra","malmo","Malm\xf6","oslo","Oslo","our_history","La nostra storia","our_history_text","<p><strong>Hibis</strong> nasce nel 1998 grazie a un'idea di Martin Samociuk. La sua visione viene accolta entusiasticamente da un team che aveva lavorato precedentemente per Network Security Management a Londra, un'azienda all'avanguardia nel campo delle investigazioni e della prevenzione della frode negli anni Ottanta e Novanta. Nel 1999, Martin viene affiancato da Nigel Krishna Iyer e, un anno dopo, da Allan McDonagh. Veronica Morino li raggiunge nel 2001, subito seguita da Richard Minogue nel 2002. Hibis ha da sempre deciso di porre al primo posto la prevenzione e la rilevazione precoce di frodi. Avvertiamo, insieme ai nostri clienti, il bisogno di richiamare drasticamente l'attenzione sulla frode e la corruzione, formandoli su come scovare gli illeciti per tempo, oltre a fornire consulenze e risorse per gestire al meglio eventuali investigazioni. Abbiamo sviluppato apposite attivit\xe0 di formazione quali workshop e seminari, libri, articoli e film, il tutto con lo scopo di sensibilizzare garantire l'autosufficienza nel campo per i nostri clienti.</p> <p>Hibis opera nel Regno Unito e in Scandinavia dal 1999</p><p>Hibis \xe8 un'organizzazione di esperti dedicati a dimostrare che, sebbene frode e corruzione permeino l'ambiente in cui viviamo, \xe8 comunque possibile tenerli sotto controllo e arginare o evitare i danni. Il nostro obiettivo \xe8 fornire strumenti e tecniche all'avanguardia per gestire il rischio di frode, insieme alla certezza della prevenzione. Offriamo il miglior supporto a chi intende darci un taglio con frode e corruzione.</p><p>Se avete trovato la nostra presentazione di vostro gradimento, e ritenete che potrebbe essere l'ambiente lavorativo giusto per voi, non esitate a contattarci. </p> ","profile_allan","Dal 1967 ad oggi, Allan ha lavorato a New Scotland Yard occupandosi di investigazioni doganali nel Regno Unito, e in particolare di droga e criminalit\xe0 organizzata. Tra il 1985 e il 1997 Allan ha lavorato come vice-direttore di Network Secutiry Management Limited (assieme a Martin Samociuk, fondatore di Hibis), una tra le migliori ditte di consulenza a livello Europeo in materia di investigazioni anti-frode. Oltre ad aver condotto con successo centinaia di investigazioni in tutto il mondo sia per clienti privati che per aziende pubbliche, ha inoltre fondato i Forensic Laboratories, successivamente acquisiti da Control Risks Group.","profile_carina","Carina S\xf6rqvist da oltre 15 anni previene e ricerca episodi di frode e corruzione. Ha ricoperto ruoli di investigatrice a capo di inchieste per diversi clienti in vari settori. La sua pluriennale esperienza in materia di investigazioni complesse di casi di frode e corruzione \xe8 oggi sfruttata in seminari e training sulle tecniche investigative. Ha sviluppato piani d'azione per svariati clienti, suggerendo come comportarsi in caso di incidenti di sospetta natura fraudolenta. Dal 2003 ha lavorato come consulente, dopo essersi cimentata nel ramo della compliance per il dipartimento di controllo di una multinazionale. Carina ha completato studi di ragioneria e finanza, specializzandosi nell'ambito della revisione contabile e delle tecniche di interrogazione.","profile_jan","Jan ha svolto diverse investigazioni forensi e ha partecipato a una moltitudine di progetti anti-frode, oltre ad aver condotto svariati corsi di detezione dei segnali della frode nell'ambito della corporate governance. Ha ottenuto i titoli di MBA e CPA dalla Norwegian School of Economics and Business Administration di Bergen. Dopo 4 anni come revisore dei conti esterno, \xe8 stato per 9 anni CFO di una ditta di costruzioni internazionale, con operazioni nell'Africa orientale. Successivamente ha ricoperto per oltre 20 anni il ruolo di consulente (in materie quali sviluppo, valutazioni di sostenibilit\xe0, controlli di gestione, controllo dei precedenti) presso il Ministero Norvegese degli Affari Esteri (NORAD, Ambasciate e Norfund), oltre ad assistere nella medesima funzione aziende del settore privato operanti nell'Africa orientale, nei Balcani, nei paesi Baltici, Georgia, Sri Lanka, Nepal, e Palestina.","profile_john","John Wallhoff \xe8 un esperto nel settore della sicurezza digitale e nell'analisi dei dati, campi in cui ha lavorato per anni. Con Hibis in particolare, sviluppa e raffina modelli in grado di analizzare grandi quantit\xe0 di dati e ricostruire \u201cpattern\u201d fraudolenti. John partecipa a investigazioni, conduce training, e fornisce attivit\xe0 di supporto ai colleghi grazie al costante raffinamento e adattamento dei modelli agli scenari che i nostri clienti si trovano ad affrontare, per scovare qualsiasi tipo di comportamento \u201cindesiderato\u201d. Inoltre, John ha costruito strategie di sicurezza per network interni, oltre a piani d'azione in caso di emergenze per svariate organizzazioni. Complementando l'attivit\xe0 di detezione della frode, John offre anche soluzioni di analisi dei dati per monitorare periodicamente l'efficacia dei controlli interni.","profile_martina","Martina ha ottenuto una laurea magistrale in finanza e gestione aziendale presso la BI Norwegian Business School di Oslo e l'universit\xe0 di Ljubljana, in Slovenia. In quanto economista di formazione, si interessa alla frode come spreco di risorse, che potrebbero essere altrimenti allocate in maniera ottimale, favorendo una crescita e uno sviluppo sostenibile. Grazie a Hibis ha avuto modo di applicare la sua passione a diversi scenari: in particolare, si occupa di identificare le \u201cred flag\u201d attraverso analisi interne e investigazioni esterne, e si avvale spesso della propria conoscenza delle lingue per tracciare flussi monetari in vari paesi.","profile_fridtjof","Fridtjof Klareng Dale ha sviluppato uno spiccato interesse per la lotta alla corruzione mentre frequentava la facolt\xe0 di studi europei presso l'universit\xe0 norvegese della scienza e della tecnica di Trondheim (NTNU). Attraverso numerosi impegni di volontariato, si \xe8 unito al neo-fondato gruppo \"Anti-Corruption International (ACI)\", contribuendo a trasformarlo in una vera e propria organizzazione internazionale che finora, attraverso numerosi progetti, ha dimostrato come i giovani possano non solo contribuire a eradicare un problema globale, ma possano anche assumere un ruolo di guida nella lotta alla corruzione. Proprio attraverso ACI \xe8 entrato in contatto con Hibis, dove ora pu\xf2 affiancare l'attivismo anti-frode alle investigazioni.","profile_maurizio","Da 18 anni lavora come libero professionista e consulente direzionale, advisor, mentor e trainer. Ha maturato esperienze in diversi ed eterogenei settori: sviluppo e innovazione, telecomunicazioni e tecnologie per le imprese, banche e assicurazioni, moda, industria degli occhiali, industria culturale e della formazione, settore farmaceutico e sanitario, beni culturali e turismo. Ha lavorato in Italia, Svizzera e Brasile. Le aree di maggiore interesse ed esperienza sono: creazione e gestione di impresa, innovazione e gestione del cambiamento, marketing e comunicazione, formazione e sviluppo organizzativo. All'interno di questi ambiti, la detezione precoce e la gestione responsabile della frode svolgono un ruolo fondamentale.","profile_nigel","Nigel ha pi\xf9 di 20 anni di esperienza nel campo dell'investigazione della frode. Ha ottenuto un Bachelor Degree in informatica, e subito dopo ha superato l'esame nazionale per dottori commercialisti nel Regno Unito. Fin dalle prime esperienze lavorative, ha scoperto la propria vocazione di \u201cfraud detective\u201d. Successivamente si \xe8 interessato anche alla produzione teatrale, ottenendo un Master of Arts in sceneggiatura e regia teatrale. Ha scritto e prodotto numerosi testi teatrali e film basati su esperienze personali, che poi vengono utilizzati per la formazione. Sulla frode ha scritto diversi articoli e pubblicato 3 libri, e, oltre a insegnare le proprie tecniche in diversi paesi, ricopre il ruolo di Fellow presso la Leicester School of Business.","profile_petri","Petri Kelo \xe8 il partner Hibis in Finlandia. Ha ottenuto un Master's Degree in Security presso la Helsinki University of Technology. Negli ultimi 25 anni si \xe8 occupato di logistica, qualit\xe0 del servizio, sicurezza, oltre alla gestione del rischio di frode. Petri ha inoltre fondato Centry Ltd, una realt\xe0 che si occupa di sicurezza nel settore della logistica, supply chain, gestione dei rischi, compliance e servizi investigativi. Svolge tutt'ora attivit\xe0 di training in materia di AEO (Authorized Economic Operator), TAPA (Transportation Asset Protection Association) e sicurezza nella logistica (ISO 28000 \u2013 Supply chain security management).","profile_richard","Richard ha maturato decenni di esperienza nel settore dell'audit, investigazione, controllo e gestione a partire dal 1975, quando ha iniziato a lavorare come revisore dei conti (internal auditor). Curioso di natura, ha la capacit\xe0 innata di risolvere situazioni complesse e comprendere a fondo i processi dei propri clienti, offrendo loro la soluzione pi\xf9 adatta, ben consapevole che esista pi\xf9 di una risposta esatta, e allo stesso tempo molte risposte sbagliate. Richard ha conseguito un Bachelor Degree in economia aziendale, superando gli esami CPA e CIA. In tempi recenti si \xe8 dedicato alla valutazione, all'investigazione, e al miglioramento dei sistemi di controllo in vigore in varie organizzazioni.","profile_veronica","Veronica ha oltre 15 anni di esperienza nell'investigazione e prevenzione della frode, e in particolare nella formazione anti-frode e nella gestione dei rischi associati. Laureata in sociologia del lavoro presso l\u2019Universit\xe0 di Roma \u201cLa Sapienza\u201d, ha sviluppato una metodologia di ricerca olistica che permette di analizzare organizzazioni, aziende, soci in affari, fornitori, clienti, e personaggi chiave per capire che cosa vi sia davvero dietro. Inoltre, Veronica da diversi anni valuta ed esamina l'efficacia dei programmi anti-frode e corruzione adottati da varie organizzazioni, e al momento sta completando il proprio dottorato di ricerca in materia.","red_flag_game","The <span class='red-text'>red</span><br />flag Game","rome","Roma","rulebending_final_question","Ai fini della nostra ricerca, vi saremmo molto grati se poteste fornirci (in modo anonimo) una descrizione dettagliata delle vostre mansioni","rules_game","Quanto \xe8 flessibile la vostra morale?","search","Cerca","send","Invia","stockholm","Stoccolma","the_fraud_academy","Fraud Academy","what_we_do","Attivit\xe0","what_we_do_collapsed_text_1",'<p>Gran parte delle frodi di cui sentiamo parlare quotidianamente potrebbe essere segnalata (anche se in fase iniziale) e fermata. Spesso, attivit\xe0 illegittime hanno parvenza di legalit\xe0 e trovare la verit\xe0 richiede esperienza, fatica, e l\'aiuto di esperti.</p><p>La nostra soluzione "B4" (o "before" nel senso di "Finding fraud before it finds you") \xe8 stata sviluppata apposta per scovare qualsiasi frode in maniera efficiente ed eliminarla efficacemente. La soluzione "B4" si fa carico di attivit\xe0 quali:</p><ul><li>Analisi dei flussi monetari, divisi per categorie, ed esecuzione degli algoritmi della suite B4 sulle singole transazioni</li><li>Ricostruzioni \u201cthink like a thief\u201d (un approccio inventato negli anni Ottanta da Martin Samociuk, il fondatore di Hibis), per vestire i panni di un malintenzionato e profilare i diversi tipi di frode, sia quelli in corso che quelli potenzialmente pericolosi</li><li>Identificare comportamenti a rischio attraverso un approccio integrato che prevede l\'uso di \u201cdesktop research\u201d per analizzare organizzazioni, soci in affari, fornitori, clienti e figure chiave, il tutto tenendo sempre a mente l\'opportunit\xe0, le motivazioni, e il fenomeno della razionalizzazione del comportamento disonesto</li><li>Dopo aver identificato e classificato i segnali di frode, stilare una lista che permetta poi ai nostri clienti di avere una visione chiara dei problemi pi\xf9 importanti da risolvere</li><li>Collaborare con i nostri clienti per giungere al corso d\'azione pi\xf9 efficace per risolvere problemi. La nostra pluriennale esperienza ci pone in una posizione unica per valutare e suggerire soluzioni commisurate alla gravit\xe0 di ciascuna situazione.</li></li></ul><p>Se non si agisce per tempo, si rischia che i segnali iniziali si sviluppino in vere e proprie frodi, diffondendosi attraverso intere organizzazioni. A quel punto, il problema emerger\xe0 nuovamente quando sar\xe0 ormai impossibile ignorarlo, o per le dimensioni raggiunte o perch\xe9 denunciato anonimamente (o entrambi). Perch\xe9 dunque attendere inerti che ci\xf2 accada quando si possono usare tecniche di investigazione per scoprire ora le aree affette dai primi segni di frode? \xc8 meglio giocare d\'anticipo!</p>',"what_we_do_collapsed_text_2",'<p>Pensare di riuscire a eliminare del tutto le frodi \xe8 senz\'altro un\'utopia. Tuttavia, prestando attenzione al problema e gestendone il rischio in maniera appropriata, sar\xe0 possibile controllarne il costo e rendere i comportamenti disonesti meno accettabili. Non \xe8 un caso che le frodi pi\xf9 comuni siano di solito perpetrate da persone \u201cnormali\u201d, nella media, quali potrebbero essere impiegati o soci d\'affari fidati. Aumentare la consapevolezza del fenomeno potr\xe0 aiutare chiunque a evitare errori di cui poi si pentir\xe0, oltre a formarvi per difendere la vostra organizzazione da malintenzionati. Citando Nelson Mandela, \u201cl\'istruzione \xe8 uno dei modi pi\xf9 potenti per cambiare il mondo\u201d. Abbiamo sviluppato metodi per facilitare il \u201cknowledge transfer\u201d nei confronti dei nostri clienti, e siamo costantemente alla ricerca di modi innovativi per sensibilizzare, diffondere il know-how necessario e permettere un confronto aperto e costruttivo in materia di frode e corruzione. Alcuni esempi sono (per una descrizione pi\xf9 dettagliata si veda la pagina Fraud Academy):</p><ul><li>Corsi pratici e laboratori (tra cui il metodo "Think like a thief" e la "fraud detective school")</li><li>Corsi certificati per il management</li><li>Training sul luogo di lavoro, laboratori "in-house" e workshop a tema</li><li>Corsi multimediali tenuti via internet (o intranet)</li><li>Corsi interattivi con drammi teatrali, allestimento di scenari e giochi di ruolo per i partecipanti, film a tema</li><li>Libri e altre pubblicazioni su riviste specializzate</li></ul>',"what_we_do_collapsed_text_3","<p>Aiutiamo i nostri clienti a investigare i comportamenti illeciti in maniera costruttiva ed efficace.</p><p>Siamo fautori di piccole investigazioni che aiutano a recuperare le risorse perdute. Abbiamo un comprovato numero di situazioni risolte con successo ed efficienza, in cui siamo riusciti a identificare le mancanze alla radice e correggerle, impedendo che il problema si ripetesse. Talvolta, grandi investigazioni sono necessarie, ad esempio qualora un'organizzazione avesse bisogno di prepararsi ad azioni legali per recuperare beni o salvare parte del proprio business. Gestiamo ogni investigazione in maniera discreta, evitando costi superflui e accertandoci allo stesso tempo di mantenere il cliente sempre al corrente.</p>","what_we_do_collapsed_text_4","<p>La mole e la portata dei regolamenti esterni, studiati per proteggere i consumatori e dissuadere potenziali criminali, \xe8 sempre in aumento. Ci\xf2 richiede sempre pi\xf9 attenzione da parte del management, a scapito di programmi pi\xf9 pratici, disegnati specificatamente per proteggere l'azienda. Di conseguenza, la direzione potrebbe cadere nella trappola di voler assecondare soluzioni \u201cburocratiche\u201d in conformit\xe0 con la legge, ma nella realt\xe0 poco adatte a prevenire azioni fraudolente. Le attivit\xe0 di \"compliance\", intesa come una lista di controlli da manuale, difficilmente daranno risultati concreti.</p><p>Siamo lieti di mettere al vostro servizio la nostra esperienza, offrendovi una valutazione dei vostri sistemi di controllo per far emergere potenziali debolezze. Insieme potremo migliorarli per abbattere il costo della frode e riaffermare i valori e l'etica della vostra azienda.</p><p>Partendo dai framework pi\xf9 comuni in uso, abbiamo selezionato i punti chiave, combinandoli con anni di esperienza sul campo per offrirvi uno strumento di valutazione complessivo, frutto di un approccio olistico.</p>","what_we_do_collapsed_title_1","Scoviamo i primi segni di frode e ti aiutiamo a risolverli","what_we_do_collapsed_title_2","Mettiamo la nostra esperienza al vostro servizio, sensibilizzando in materia di frode","what_we_do_collapsed_title_3","Investighiamo la frode responsabilmente","what_we_do_collapsed_title_4","Testiamo l'efficacia dei vostri programmi anti-frode","what_we_do_list_1_item_1","<strong>Trovare</strong> e interpretare i primi segnali (Le <strong>red flags</strong>)","what_we_do_list_1_item_2","<strong>Investigare</strong> in modo efficiente, competente e responsabile","what_we_do_list_1_item_3","<strong>Analizzare</strong> i problemi alla radice per identificare aree di miglioramento","what_we_do_list_1_item_4","<strong>Formare</strong> attraverso workshop pratici, conferenze, training e altri strumenti innovativi, le <strong>competenze necessarie</strong> per trasformare le \"brutte notizie\" in opportunit\xe0 di risparmio (si veda anche <a href='http://fraudacademy.hibis.com' target='_blank'>Hibis Fraud Academy</a>)","what_we_do_list_1_item_5","<strong>Testare</strong> e <strong>misurare</strong> l'<strong>efficacia</strong>, i punti di forza e le debolezze dei programmi antifrode gi\xe0 presenti","what_we_do_paragraph_1","Frodi e corruzione avvengono costantemente e sono tra i costi pi\xf9 difficili da gestire per aziende e organizzazioni. Gran parte dei dirigenti e degli impiegati per\xf2 non ha mai ricevuto alcuna formazione pratica su questo tema. Il nostro obiettivo \xe8 richiamare l'attenzione su frodi e corruzione e sulle conseguenze che possono comportare. Da anni assistiamo e consigliamo aziende, organizzazioni e chiunque abbia bisogno di aiuto pratico per","who_we_are","Chi siamo"]),"no",P.a4(["address_copenhagen","c/o Scillani Information AB<br />Vestergade 16<br />1456 Kj\xf8benhavn<br />Danmark","address_gothenburg","Hibis AB<br />Kronhusgatan 11<br />411 05 G\xf6teborg<br />Sverige","address_helsinki","Hibis Associates<br />Centry Ltd","address_london","Hibis Europe Ltd","address_malmo","Hibis AB","address_oslo","Hibis AS<br /> Meltzersgt. 4<br/> 0275 Oslo<br/> Norge","address_rome","Hibis Associates","address_stockholm","Hibis AB","contact","Kontakt","contact_us","Kontakt oss","contact_copenhagen","<strong>John Wallhoff</strong><br /><a href='mailto:john.wallhoff@hibis.com'>john.wallhoff@hibis.com</a><br />+ 45 70 77 43 131","contact_gothenburg","<strong>Carina S\xf6rqvist</strong><br /><a href='mailto:carina.sorqvist@hibis.com'>carina.sorqvist@hibis.com</a><br />+ 46 707 97 97 64","contact_helsinki","<strong>Petri Kelo</strong><br /><a href='mailto:petri.kelo@centry.global'>petri.kelo@centry.global</a><br />+ 358 40 50 001 068","contact_london","<strong>Allan McDonagh</strong><br /><a href='mailto:allan.mcdonagh@hibis.com'>allan.mcdonagh@hibis.com</a><br />+ 44 77 68 32 0161","contact_malmo","<strong>Richard Minogue</strong><br /><a href='mailto:richard.minogue@hibis.com'>richard.minogue@hibis.com</a><br />+ 46 761 882 497","contact_oslo","<strong>Veronica Morino</strong><br /><a href='mailto:veronica.morino@hibis.com'>veronica.morino@hibis.com</a><br />+ 47 91 86 32 19<br/><br/><strong>Nigel Krishna Iyer</strong><br /><a href='mailto:nigel.iyer@hibis.com'>nigel.iyer@hibis.com</a><br />+ 47 90 65 44 10<br/>+ 44 7523 570004 (UK)","contact_rome","<strong>Maurizio Carmignani</strong><br /><a href='mailto:maurizio.carmignani@hibis.com'>maurizio.carmignani@hibis.com</a><br />+ 39 3489501126","contact_stockholm","<strong>Richard Minogue</strong><br /><a href='mailto:richard.minogue@hibis.com'>richard.minogue@hibis.com</a><br />+ 46 761 882 497","copenhagen","Kj\xf8benhavn","copyright","&copy;2017 Hibis. All rights reserved. Design by SoiaDg. Images by Floral Zu.","frontpage_title","<strong>Fraud and corruption <span class='orange-text'>can</span> be stopped</strong>","gothenburg","G\xf6teborg","hibis_associates","Hibis assosierte","hibis_people","Hibis ansatte","helsinki","Helsinki","language","Spr\xe5k","lang_en","Engelsk (english)","lang_no","Norsk (norwegian)","lang_it","Italiensk (italian)","london","London","malmo","Malm\xf6","oslo","Oslo","our_history","V\xe5r historie","our_history_text","<p><strong>Hibis</strong> ble grunnlagt i 1998 av Martin Samociuk. Mange av dem som ble med i starten kom fra Network Security Management i London, et selskap som var pionerer forebygging og etterforsking av bedrageri p\xe5 1980og -90-tallet. I 1999 sluttet Nigel Krishna Iyer seg til Martin og et \xe5r senere ble ogs\xe5 Allan McDonagh med. Veronica Morino ble en del av gruppen i 2001, etterfulgt av Richard Minogue i 2002. Hibis sitt oppdrag har alltid v\xe6rt \xe5 sette forebygging og tidlig oppdagelse F\xd8RST. Vi deler med v\xe5re kunder n\xf8dvendigheten av dramatisk \xf8kning av for \xe5 vesentlig \xf8ke bevisstheten rundt misligheter og korrupsjon, gi dem muligheten til \xe5 oppdage det tidlig og bist\xe5 med r\xe5d ressurser til vellykkede etterforskinger. Dette inkluderer trening i workshops, seminarer, b\xf8ker, publikasjoner og filmer alle med det form\xe5let \xe5 stimulere til st\xf8rre bevissthet og selvtillit.</p><p>Hibis grunnlegger, Martin Samociuk, d\xf8de i 2013 i en alder av 62 \xe5r fra bukspyttkjertels kreft. Han vil bli savnet av alle som kjente ham og vi er takknemlige for det viktige arbeidet han etterlot seg.</p><p>I dag er Hibis en r\xe5dgivende organisasjon som vi h\xe5per vil bidra til \xe5 \xe5pne folks \xf8yne for det faktum at selv om misligheter og korrupsjon er rundt oss, kan den holdes under kontroll. V\xe5rt m\xe5l er \xe5 tilby nyskapende verkt\xf8y og teknikker for \xe5 h\xe5ndtere dette, samt mulighet til \xe5 oppdage det tidlig. V\xe5rt m\xe5l er \xe5 st\xf8tte de menneskene som \xf8nsker \xe5 st\xe5 opp mot misligheter og korrupsjon.</p><p>I dag er Hibis en r\xe5dgivende organisasjon som vi h\xe5per vil bidra til \xe5 \xe5pne folks \xf8yne for det faktum at selv om misligheter og korrupsjon er rundt oss, kan den holdes under kontroll. V\xe5rt m\xe5l er \xe5 tilby nyskapende verkt\xf8y og teknikker for \xe5 h\xe5ndtere dette, samt mulighet til \xe5 oppdage det tidlig. V\xe5rt m\xe5l er \xe5 st\xf8tte de menneskene som \xf8nsker \xe5 st\xe5 opp mot misligheter og korrupsjon.</p><p>Til slutt, hvis du liker det du har lest, og tenker som oss, s\xe5 ta gjerne kontakt. Vi rekrutterer ikke p\xe5 tradisjonell m\xe5te - likesinnede mennesker finner oss vanligvis...</p>","profile_allan","Allans lange erfaring fra 1967 inkluderer britiske toll- og fortollingsetterforskning og New Scotland Yard, der han spesialiserte seg p\xe5 narkotikakriminalitet og organisert kriminalitet. Mellom 1985 og 1997 jobbet Allan som assisterende direkt\xf8r med Martin Samociuk p\xe5 Network Security Management Limited, Europas ledende konsultasjonssjef for etterforsking av svindel. I tillegg til \xe5 ha ledet hundrevis av etterforskinger og gjenopprettingsprosjekter over hele verden for b\xe5de kommersielle og offentlige kunder, skapte han de sv\xe6rt vellykkede \xabForensic Laboratories\xbb som til slutt ble kj\xf8pt av Control Risks Group. Allan har v\xe6rt prosjektleder for mange vellykkede etterforskinger rundt om i verden.","profile_carina","Carina S\xf6rqvist har over 15 \xe5rs erfaring med \xe5 forebygge og etterforske misligheter og korrupsjon. Hun har opptr\xe5dt som etterforsker og prosjektleder i etterforskinger for kunder i ulike bransjer. Hennes lange erfaring med strukturerte etterforskinger av mislighet- og korrupsjonssaker blir brukt i seminarer og oppl\xe6ring i forbindelse med etterforskningsteknikker. Hun har, for flere kunder, utviklet handlingsplaner for hvordan man skal h\xe5ndtere hendelser hvor man mistenker misligheter og/eller korrupsjon. Hun har jobbet som seniorkonsulent siden 2003 og f\xf8r det arbeidet hun med compliance som leder av internkontrollavdelingen i et multinasjonalt selskap. Carina har \xf8konomisk bakgrunn og hennes spesialiteter er regnskapsetterforskning og intervjueteknikker.","profile_jan","Jan har utf\xf8rt en rekke etterforskinger og prosjekter for \xe5 oppdage misligheter, samt holdt kurs i r\xf8d-flaggs-avdekking innen bedrageri, korrupsjon og bedriftsstyring. Han har en MBA og CPA-grad fra Handelsh\xf8yskolen i Bergen. Etter \xe5 ha v\xe6rt 4 \xe5r som ekstern revisor var han finansdirekt\xf8r i 9 \xe5r i et internasjonalt byggefirma med virksomhet i \xd8st-Afrika. Deretter jobbet han i over 20 \xe5r som r\xe5dgiver innen forretningsutvikling, b\xe6rekraftevalueringer, performance audit og bakgrunn analyser for Utenriksdepartementet (bl.a. oppdrag for NORAD, ambassader og Norfund) og private n\xe6ringsselskaper som opererer i \xd8st-Afrika, Balkan, Baltikum, Georgia, Sri Lanka, Nepal og Palestina. Han leder ogs\xe5 Styrenettverket i Econa Oslo/Akershus.","profile_john","John Wallhoff har mange \xe5rs erfaring som datasikkerhet- og dataanalyseekspert, og utvikler og implementerer datamodeller for \xe5 oppdage m\xf8nstre av misligheter og korrupsjon. John deltar i etterforskinger, leder oppl\xe6ring og st\xf8tter sine kolleger gjennom utvikling av ledende modeller for \xe5 finne frem til misligheter og uetisk forretningsadferd. I tillegg har John bygget informasjonssikkerhetsstrategier og beredskapsplaner for en rekke selskaper,  deltar i etterforskinger og utvikler dataanalysel\xf8sninger for kontinuerlig overv\xe5king av interne kontroller.","profile_martina","Martina har en mastergrad i business og \xf8konomi med finans som hovedprofil fra handelsh\xf8yskolen BI og universitetet i Ljubljana (Slovenia). Hun bestemte seg tidlig for at hun \xf8nsket \xe5 spille en aktiv rolle i \xe5 utrydde systematisk ineffektivitet. Hun inns\xe5 at korrupsjon og misligheter er noen av de st\xf8rste hindringene for b\xe6rekraftighet og vekst, og f\xe5r bruke sin lidenskap for temaet her hos oss i Hibis. Martina spesialiserer seg p\xe5 \xe5 identifisere r\xf8de flagg i relasjon til korrupsjon gjennom intern og ekstern analyse, og forst\xe5 og etterforske dem over et bredt spekter av land og spr\xe5k-soner.","profile_fridtjof","Fridtjof Klareng Dale's passion for fighting corruption and fraud started while studying for his bachelor in European Studies at the Norwegian University of Science and Technology (NTNU). Through his strong engagement in volunteerism, he joined the newly founded student organisation Anti-Corruption International (ACI) and helped build the organisation, spearheading projects showing that \u201cyoung people not only can play a part in eradicating a global problem, but can also take the lead.\u201d Through ACI he got to know Hibis, where he is now successfully working as a fraud investigator combining this with his anti-corruption activities.","profile_maurizio","Maurizio har 18 \xe5rs erfaring innen innovasjon og organisasjonsutvikling i et bredt spekter av sektorer som inkluderer telekommunikasjon og teknologi, bank, detaljhandel og forbrukerprodukter, kultur, utdanning og regjering, i hovedsak i Italia, Sveits og Brasil. Han gir oppl\xe6ring for \xe5 oppn\xe5 oppfyllelse av m\xe5l b\xe5de p\xe5 personlig og organisatorisk niv\xe5. Han bist\xe5r i \xe5 finne misligheter og korrupsjon tidlig, og h\xe5ndterer det p\xe5 en ansvarlig m\xe5te for \xe5 fremme organisatorisk robusthet.","profile_nigel","Nigel har over 20 \xe5rs erfaring med \xe5 unders\xf8ke og oppdage misligheter og korrupsjon. Som datavitenskapsmann og statsautorisert revisor, fant Nigel snart at hans sanne lidenskap l\xe5 i \xe5 bekjempe korrupsjon og misligheter. Nigel er ogs\xe5 i dag en kvalifisert dramatiker og har skrevet en rekke filmer og skuespill basert p\xe5 erfaringer, hvorav mange brukes i undervisning over hele verden. Han har skrevet flere b\xf8ker og vitenskapsartikler, og underviser i Norge og internasjonalt i hvordan man kan forsvare organisasjoner mot \xabkommersielle m\xf8rkekunster\xbb. Han er ogs\xe5 fellow ved University of Leicester School of Business.","profile_petri","Petri Kelo er Hibis tilknyttede partner i Finland. Hans faglige bakgrunn inkluderer en mastergrad i sikkerhet fra Helsinki University of Technology. Petri har jobbet i over 25 \xe5r med logistikk, kvalitet, sikkerhet, samt med \xe5 h\xe5ndtere risikoen for misligheter og korrupsjon. Petri er ogs\xe5 en av grunnleggerne av Centry Ltd. et sikkerhetsselskap spesialisert innen logistikk, forsyningskjede, sikkerhetsrisikostyring, etterlevelse og etterforskningstjenester. Petri er en velkjent foredragsholder og underviser  i TAPA (Transportation Asset Protection Association), AEO (Authorized Economic Operator), ISO 28000 (Supply Chain Security Management) og logistisk sikkerhet.","profile_richard","Siden sin f\xf8rste heltidsjobb som internrevisor i 1975, har Richard opparbeidet seg erfaring innen revisjon, etterforskning, finansiell kontroll og generell ledelseskompetanse. Nysgjerrig av naturen han vet at det er vanligvis er mer enn \xe8n m\xe5te \xe5 gj\xf8re ting riktig p\xe5, og mange feil m\xe5ter. Richards talent for \xe5 trenge inn i komplekse situasjoner samt forst\xe5 kundens forretningsprosesser gj\xf8r ham til en verdifull ressurs for vurderings-, etterforsknings- og forbedringsprosjekter. Richard har uteksaminert seg med BSc i regnskap, og er kvalifisert CPA og CIA.","profile_veronica","Veronica har over 15 \xe5rs erfaring med \xe5 etterforske, finne og trene andre i hvordan man kan forebygge og h\xe5ndtere misligheter og korrupsjon over hele verden. Hun er utdannet \xf8konomi-og arbeidssosiologi og har en mastergrad i organisasjonsbygging og ledelse har hun utviklet helhetlige unders\xf8kelses- og analyseverkt\xf8y for \xe5 etterforske organisasjoner, samarbeidspartnere, leverand\xf8rer, kunder og n\xf8kkelpersoner, og oppdage hva som egentlig foreg\xe5r med bare en br\xf8kdel av ressursene som normalt er forbundet med en etterforskning. Veronica har ogs\xe5 jobbet i flere \xe5r med vurdering av effektiviteten av organisasjons anti-mislighet og korrupsjonsprogrammer og fullf\xf8rer for tiden en doktorgradsutdanning p\xe5 dette emnet.","red_flag_game","The <span class='red-text'>red</span><br />flag Game","rome","Roma","rulebending_final_question","It would assist our research if you could provide us with details of your job functions (anonymously)","rules_game","Hvor mye kan du b\xf8ye reglene?","search","S\xf8ke","send","send inn","stockholm","Stockholm","the_fraud_academy","The fraud academy","what_we_do","Hva vi gj\xf8r","what_we_do_collapsed_text_1",'<p>I de fleste virksomheter er det mange muligheter for misligheter og korrupsjon som kan spores, avdekkes (helst i de tidlige stadiene) og stoppes. Vanligvis er handlinger som misligheter og korrupsjon skjult bak tilsynelatende legitime handlinger. \xc5 finne sannheten krever erfaring, innsats og spesialkunnskap.</p><p>V\xe5r strukturerte "B4- metodikk" (kort for "Find fraud before it finds you") er utviklet for effektivt \xe5 avdekke og h\xe5ndtere misligheter. B4 inkluderer aktiviteter som:</p><ul><li>F\xf8lge pengestr\xf8mmene, utf\xf8re strukturerte analyser og kj\xf8re B4-algoritmer p\xe5 transaksjoner for \xe5 finne de r\xf8de flaggene.</li><li>\xd8velsen \u201ctenk som en tyv\u201d (en \xf8velse oppfunnet p\xe5 1980-tallet av Martin Samociuk, Hibis grunnlegger) for \xe5 forutse hvordan bedragere tenker og for \xe5 bygge opp en profil av de typer misligheter som oppst\xe5r eller som det kan v\xe6re risiko for at de vil kunne oppst\xe5.</li><li>Finne atferdsmessige r\xf8de flagg ved \xe5 utf\xf8re helhetlige unders\xf8kelser og analyse av organisasjoner, forretningspartnere, leverand\xf8rer, kunder og andre n\xf8kkelpersoner. Alle med et spesielt fokus p\xe5 muligheter, motiver og hvordan folk rasjonaliserer rundt u\xe6rlig eller uetisk oppf\xf8rsel.</li><li>Analysere indikasjoner p\xe5 bedrageri og korrupsjon for \xe5 f\xe5 frem de viktigste omr\xe5der, for s\xe5 \xe5 strukturere disse til en h\xe5ndterlig liste som v\xe5re kunder kan arbeide videre med.</li><li>Samarbeide med v\xe5re oppdragsgivere for \xe5 finne den mest effektive l\xf8sningen p\xe5 utfordringene. Lang erfaring har gitt oss en oversikt over ulike tiln\xe6rminger, hvilke som passer i ulike situasjoner, og hvordan de kan implementeres.</li></li></ul><p>Hvis det ikke oppdages tidlig, vil misligheter og korrupsjon spre seg. Til slutt vil problemet bli oppdaget n\xe5r det blir for stort til \xe5 ignoreres, eller rapporteres av varslere, eller begge deler. Men hvorfor vente p\xe5 varslere n\xe5r du kan bruke etterforskningsteknikker og avdekke der hvor misligheter og korrupsjon i tidlig stadium utvikler seg n\xe5? Det er bedre \xe5 v\xe6re f\xf8re var og holde seg i forkant!</p>',"what_we_do_collapsed_text_2","<p>Vi vil nok aldri helt utrydde misligheter og korrupsjon, men ved \xe5 \xf8ke bevisstheten og h\xe5ndtere risikoen kan vi kontrollere kostnadene og gj\xf8re korrupte handlinger mindre akseptable. Overraskende nok beg\xe5s mye av misligheter og korrupsjon av helt normale, gode mennesker som regnes som verdifulle og p\xe5litelige ansatte eller forretningspartnere. Bevisstgj\xf8ring, er et kraftig verkt\xf8y for \xe5 hjelpe de gode menneskene til \xe5 unng\xe5 og beg\xe5 feil de senere vil kunne angre p\xe5, og samtidig vise dem hvordan de skal beskytte organisasjonen mot karrierekriminelle. Som Nelson Mandela sa, er utdanning en av de beste m\xe5tene \xe5 forandre verden p\xe5. Vi har utviklet kurs og teknikker for \xe5 minimere dette kompetansegapet samt stadig og kontinuerlig p\xe5 s\xf8kt etter nye innovative m\xe5ter \xe5 \xf8ke bevisstheten, spre kunnskapen og f\xf8re folk sammen i kampen mot korrupsjon og misligheter. Eksempler (detaljer finner du under Fraud Academy-siden v\xe5r) som inkluderer:</p><ul><li>Praktiske kurs og workshops (inkludert v\xe5r \u201ctenk-som-en-tyv-metodikken\u201d og \u201cfraud detective school\u201d)</li><li>Akkrediterte ledelses kurs</li><li>Jobb, in-house og laboratorier treining</li><li>Multimediabasert oppl\xe6ring over internett (eller intranett)</li><li>Ekspertoppl\xe6ring, inkludert drama, scenariooppgaver, live-simuleringer, \u201ckorrupsjonsteater\u201d og filmer</li><li>Publikasjoner og b\xf8ker</li></ul>","what_we_do_collapsed_text_3","<p>Dersom kunden har behov, etterforsker vi ogs\xe5 misligheter og korrupsjon konstruktivt og effektivt.</p><p>Vi tror p\xe5 filosofien med sm\xe5 etterforskinger som \u201cwin value back\u201d. V\xe5r portef\xf8lje viser til kunder som har f\xe5tt l\xf8st sine problemer p\xe5 en effektiv m\xe5te som b\xe5de identifiserer grunnleggende \xe5rsaker og hindrer gjentakelse.</p><p>Spesielle situasjoner forekommer fra tid til annen, hvor en s\xe5kalt dypdykketterforskning kan v\xe6re n\xf8dvendig, for eksempel n\xe5r en organisasjon m\xe5 g\xe5 rettens vei for \xe5 f\xe5 erstattet store verdier eller redde deler av virksomheten. Vi h\xe5ndterer alle etterforskinger p\xe5 en kontrollert m\xe5te, unng\xe5r un\xf8dvendige kostnader og sikrer at kunden alltid er i f\xf8rersetet under prosessen.</p>","what_we_do_collapsed_text_4","<p>Omfang og kompleksitet i regelverk knyttet til samfunnsansvar og straffeansvar p\xe5 brudd p\xe5 dette er \xf8kende. Dette krever ledelsens oppmerksomhet og gir mindre plass til mer praktiske tiltak som er designet for \xe5 beskytte organisasjonen. Det kan v\xe6re fristende for en ledelse \xe5 g\xe5 i den fellen og velge enkle l\xf8sninger som ser ut til \xe5 oppfylle lovkrav, men som ikke l\xf8ser problemet med misligheter og korrupsjon p\xe5 en effektivt m\xe5te. Complianceprogrammer basert p\xe5 sjekklister viser seg ofte ikke \xe5 v\xe6re effektive!</p><p>Vi er i stand til \xe5 m\xe5le resultatet og effekten av dine eksisterende anti-mislighet og korrupsjonsprogrammer, identifisere smutthull og potensielle forbedringer som vil kunne redusere kostnadene av misligheter og korrupsjon og styrke den etiske kulturen.</p><p>V\xe5rt helhetlige rammeverk og vurderingsverkt\xf8y sammenfattet mange \xe5rs praktisk erfaring med den beste kunnskapen fra en omfattende bruk av tilgjengelige rammeverk.</p>","what_we_do_collapsed_title_1","Vi avdekker misligheter tidlig og hjelper deg med l\xe5 finne l\xf8sninger og motvirkende tiltak","what_we_do_collapsed_title_2","Vi \xf8ker bevisstheten, deler kunnskap og overf\xf8rer ferdigheter","what_we_do_collapsed_title_3","Vi etterforsker misligheter og korrupsjon p\xe5 en ansvarlig m\xe5te","what_we_do_collapsed_title_4","Vi vurderer effektiviteten av eksisterende antimislighet- og korrupsjonsprogrammer","what_we_do_list_1_item_1","<strong>Finne</strong> og tolke de mange <strong>r\xf8de flaggene</strong>","what_we_do_list_1_item_2","<strong>Utf\xf8re granskninger</strong> p\xe5 en effektiv, ansvarlig og omsorgsfull m\xe5te","what_we_do_list_1_item_3","<strong>Analysere</strong> \xe5rsakene til forskjellige hendelser for \xe5 identifisere forbedringsmuligheter","what_we_do_list_1_item_4","<strong>Tilby</strong> (gjennom praktiske workshops, oppl\xe6ring og andre innovative teknikker) <strong>ferdighetene</strong> til \xe5 omgj\xf8re det som ser ut til \xe5 v\xe6re \"d\xe5rlige nyheter\" til en mulighet til \xe5 spare penger (se <a href='http://fraudacademy.hibis.com' target='_blank'>Hibis Fraud Academy</a>)","what_we_do_list_1_item_5","<strong>Vurdere</strong> og <strong>m\xe5le effektivitet</strong>, <strong>styrker</strong> og <strong>svakheter</strong> i eksisterende anti-mislighet og korrupsjonsprogrammer","what_we_do_paragraph_1","Misligheter og korrupsjon skjer hele tiden og utgj\xf8r muligens noen av de st\xf8rste ukontrollerte kostnadene for organisasjoner og samfunnet for\xf8vrig. Til tross for dette har flesteparten av ledere og ansatte ikke hatt praktisk oppl\xe6ring innenfor dette omr\xe5det. V\xe5rt m\xe5l er \xe5 betraktelig \xf8ke bevisstheten om misligheter og korrupsjon og de p\xe5f\xf8lgende konsekvensene. Vi bist\xe5r og gir r\xe5d til organisasjoner, bedrifter og alle andre som er interessert i \xe5:","who_we_are","Hvem vi er"])]),"en")}])
I=I.$finishIsolateConstructor(I)
$=new I()
init.metadata=[null,0]
init.types=[{func:1},{func:1,args:[,]},{func:1,v:true},{func:1,v:true,args:[P.b],opt:[P.aw]},{func:1,v:true,args:[{func:1,v:true}]},{func:1,args:[P.t]},{func:1,ret:P.t,args:[P.j]},{func:1,v:true,args:[P.bb,P.t,P.j]},{func:1,args:[P.t,P.t]},{func:1,v:true,args:[P.aH]},{func:1,args:[T.by]},{func:1,args:[W.A]},{func:1,ret:P.aY,args:[W.A,P.t,P.t,W.cp]},{func:1,args:[,P.t]},{func:1,args:[{func:1,v:true}]},{func:1,args:[,],opt:[,]},{func:1,args:[,P.aw]},{func:1,v:true,args:[,P.aw]},{func:1,args:[,,]},{func:1,v:true,args:[P.t,P.j]},{func:1,v:true,args:[P.t],opt:[,]},{func:1,ret:P.j,args:[P.j,P.j]},{func:1,ret:P.bb,args:[,,]},{func:1,args:[W.b2]},{func:1,v:true,args:[W.l,W.l]},{func:1,v:true,args:[P.a8]},{func:1,v:true,args:[P.t]},{func:1,ret:P.aY,opt:[W.a1]},{func:1,v:true,args:[W.a5]},{func:1,args:[W.bp]},{func:1,v:true,args:[P.b]},{func:1,v:true,args:[W.a1]}]
function convertToFastObject(a){function MyClass(){}MyClass.prototype=a
new MyClass()
return a}function convertToSlowObject(a){a.__MAGIC_SLOW_PROPERTY=1
delete a.__MAGIC_SLOW_PROPERTY
return a}A=convertToFastObject(A)
B=convertToFastObject(B)
C=convertToFastObject(C)
D=convertToFastObject(D)
E=convertToFastObject(E)
F=convertToFastObject(F)
G=convertToFastObject(G)
H=convertToFastObject(H)
J=convertToFastObject(J)
K=convertToFastObject(K)
L=convertToFastObject(L)
M=convertToFastObject(M)
N=convertToFastObject(N)
O=convertToFastObject(O)
P=convertToFastObject(P)
Q=convertToFastObject(Q)
R=convertToFastObject(R)
S=convertToFastObject(S)
T=convertToFastObject(T)
U=convertToFastObject(U)
V=convertToFastObject(V)
W=convertToFastObject(W)
X=convertToFastObject(X)
Y=convertToFastObject(Y)
Z=convertToFastObject(Z)
function init(){I.p=Object.create(null)
init.allClasses=map()
init.getTypeFromName=function(a){return init.allClasses[a]}
init.interceptorsByTag=map()
init.leafTags=map()
init.finishedClasses=map()
I.$lazy=function(a,b,c,d,e){if(!init.lazies)init.lazies=Object.create(null)
init.lazies[a]=b
e=e||I.p
var z={}
var y={}
e[a]=z
e[b]=function(){var x=this[a]
if(x==y)H.lj(d||a)
try{if(x===z){this[a]=y
try{x=this[a]=c()}finally{if(x===z)this[a]=null}}return x}finally{this[b]=function(){return this[a]}}}}
I.$finishIsolateConstructor=function(a){var z=a.p
function Isolate(){var y=Object.keys(z)
for(var x=0;x<y.length;x++){var w=y[x]
this[w]=z[w]}var v=init.lazies
var u=v?Object.keys(v):[]
for(var x=0;x<u.length;x++)this[v[u[x]]]=null
function ForceEfficientMap(){}ForceEfficientMap.prototype=this
new ForceEfficientMap()
for(var x=0;x<u.length;x++){var t=v[u[x]]
this[t]=z[t]}}Isolate.prototype=a.prototype
Isolate.prototype.constructor=Isolate
Isolate.p=z
Isolate.R=a.R
Isolate.K=a.K
return Isolate}}!function(){var z=function(a){var t={}
t[a]=1
return Object.keys(convertToFastObject(t))[0]}
init.getIsolateTag=function(a){return z("___dart_"+a+init.isolateTag)}
var y="___dart_isolate_tags_"
var x=Object[y]||(Object[y]=Object.create(null))
var w="_ZxYxX"
for(var v=0;;v++){var u=z(w+"_"+v+"_")
if(!(u in x)){x[u]=1
init.isolateTag=u
break}}init.dispatchPropertyName=init.getIsolateTag("dispatch_record")}();(function(a){if(typeof document==="undefined"){a(null)
return}if(typeof document.currentScript!='undefined'){a(document.currentScript)
return}var z=document.scripts
function onLoad(b){for(var x=0;x<z.length;++x)z[x].removeEventListener("load",onLoad,false)
a(b.target)}for(var y=0;y<z.length;++y)z[y].addEventListener("load",onLoad,false)})(function(a){init.currentScript=a
if(typeof dartMainRunner==="function")dartMainRunner(function(b){H.eI(T.ez(),b)},[])
else (function(b){H.eI(T.ez(),b)})([])})})()